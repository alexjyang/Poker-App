package com.pokercoach.app.ui

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.pokercoach.app.PokerCoachApplication
import com.pokercoach.app.data.Settings
import com.pokercoach.app.ui.glossary.GlossaryScreen
import com.pokercoach.app.ui.home.HomeScreen
import com.pokercoach.app.ui.training.ChartsScreen
import com.pokercoach.app.ui.training.DrillScreen
import com.pokercoach.app.ui.training.QuizScreen
import com.pokercoach.app.ui.training.TrainingHubScreen
import com.pokercoach.app.ui.training.TrainingViewModel
import com.pokercoach.engine.training.DrillType
import com.pokercoach.app.ui.replay.ReplayScreen
import com.pokercoach.app.ui.review.ReviewScreen
import com.pokercoach.app.ui.settings.SettingsScreen
import com.pokercoach.app.ui.stats.StatsScreen
import com.pokercoach.app.ui.stats.StatsViewModel
import com.pokercoach.app.ui.table.TableScreen
import com.pokercoach.app.ui.table.TableViewModel
import kotlinx.coroutines.launch

private enum class Screen { HOME, TABLE, REVIEW, STATS, REPLAY, STORED_REVIEW, SETTINGS, TRAINING, DRILL, QUIZ, CHARTS, GLOSSARY }

/**
 * Screen switching with a saveable enum plus a "return to" screen for Stats and Settings,
 * which can be opened from both the lobby and the table.
 */
@Composable
fun PokerCoachApp() {
    val tableViewModel: TableViewModel = viewModel()
    val statsViewModel: StatsViewModel = viewModel()
    val trainingViewModel: TrainingViewModel = viewModel()
    val app = LocalContext.current.applicationContext as PokerCoachApplication
    val storedSettings by app.settings.settings.collectAsStateWithLifecycle(initialValue = null)
    val settings = storedSettings ?: Settings()
    val scope = rememberCoroutineScope()

    var screen by rememberSaveable { mutableStateOf(Screen.HOME) }
    var returnTo by rememberSaveable { mutableStateOf(Screen.HOME) }
    var reviewHand by rememberSaveable { mutableLongStateOf(0L) }
    var storedHand by rememberSaveable { mutableLongStateOf(0L) }

    fun openStats(from: Screen) {
        returnTo = from
        screen = Screen.STATS
    }

    var glossaryQuery by rememberSaveable { mutableStateOf("") }
    var glossaryReturn by rememberSaveable { mutableStateOf(Screen.HOME) }
    fun openGlossary(from: Screen, query: String = "") {
        glossaryReturn = from
        glossaryQuery = query
        screen = Screen.GLOSSARY
    }

    fun openSettings(from: Screen) {
        returnTo = from
        screen = Screen.SETTINGS
    }

    when (screen) {
        Screen.HOME -> HomeScreen(
            prefs = settings.lobby,
            prefsLoaded = storedSettings != null,
            onPrefsChange = { p -> scope.launch { app.settings.update { it.copy(lobby = p) } } },
            onStart = { config ->
                tableViewModel.start(config)
                screen = Screen.TABLE
            },
            onOpenStats = { openStats(Screen.HOME) },
            onOpenSettings = { openSettings(Screen.HOME) },
            onOpenTraining = { screen = Screen.TRAINING },
            onOpenGlossary = { openGlossary(Screen.HOME) },
        )
        Screen.TRAINING -> {
            val stats by statsViewModel.state.collectAsStateWithLifecycle()
            TrainingHubScreen(
                stats = settings.training,
                rating = stats.rating,
                ratingTitle = stats.ratingTitle,
                recommended = stats.leaks.mapNotNull { DrillType.forLeak(it.key) }.distinct(),
                onDrill = { type ->
                    trainingViewModel.startDrill(type)
                    screen = Screen.DRILL
                },
                onQuiz = { screen = Screen.QUIZ },
                onCharts = { screen = Screen.CHARTS },
                onGlossary = { openGlossary(Screen.TRAINING) },
                onBack = { screen = Screen.HOME },
            )
        }
        Screen.DRILL -> DrillScreen(trainingViewModel, onBack = { screen = Screen.TRAINING }, onOpenGlossary = { t -> openGlossary(Screen.DRILL, t) })
        Screen.QUIZ -> QuizScreen(trainingViewModel, onBack = { screen = Screen.TRAINING })
        Screen.CHARTS -> ChartsScreen(onBack = { screen = Screen.TRAINING })
        Screen.GLOSSARY -> GlossaryScreen(initialQuery = glossaryQuery, onBack = { screen = glossaryReturn })
        Screen.TABLE -> TableScreen(
            viewModel = tableViewModel,
            onLeave = {
                tableViewModel.leave()
                screen = Screen.HOME
            },
            onReview = { hand ->
                reviewHand = hand
                screen = Screen.REVIEW
            },
            onOpenStats = { openStats(Screen.TABLE) },
            onOpenSettings = { openSettings(Screen.TABLE) },
            onOpenGlossary = { openGlossary(Screen.TABLE) },
        )
        Screen.REVIEW -> {
            val review = tableViewModel.reviewFor(reviewHand)
            if (review == null) {
                LaunchedEffect(Unit) { screen = Screen.TABLE }
            } else {
                ReviewScreen(
                    review = review, seatNames = tableViewModel.seatNames(), onBack = { screen = Screen.TABLE },
                    onOpenGlossary = { t -> openGlossary(Screen.REVIEW, t) },
                )
            }
        }
        Screen.STATS -> StatsScreen(
            viewModel = statsViewModel,
            onBack = { screen = returnTo },
            onReplay = { id ->
                storedHand = id
                screen = Screen.REPLAY
            },
            onReview = { id ->
                storedHand = id
                screen = Screen.STORED_REVIEW
            },
        )
        Screen.REPLAY -> {
            val replay by statsViewModel.replay.collectAsStateWithLifecycle()
            LaunchedEffect(storedHand) { if (replay?.handId != storedHand) statsViewModel.openReplay(storedHand) }
            ReplayScreen(
                replay = replay?.takeIf { it.handId == storedHand },
                settings = settings,
                onBack = { screen = Screen.STATS },
                onReview = { id ->
                    storedHand = id
                    screen = Screen.STORED_REVIEW
                },
            )
        }
        Screen.STORED_REVIEW -> {
            val stored by statsViewModel.review.collectAsStateWithLifecycle()
            LaunchedEffect(storedHand) { if (stored?.handId != storedHand) statsViewModel.openReview(storedHand) }
            val current = stored?.takeIf { it.handId == storedHand }
            val review = current?.review
            when {
                review != null -> ReviewScreen(
                    review = review, seatNames = current?.names ?: emptyMap(), onBack = { screen = Screen.STATS },
                    onOpenGlossary = { t -> openGlossary(Screen.STORED_REVIEW, t) },
                )
                current?.failed == true -> {
                    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { Text("This hand couldn't be analyzed.") }
                    LaunchedEffect(Unit) { screen = Screen.STATS }
                }
                else -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator() }
            }
        }
        Screen.SETTINGS -> SettingsScreen(
            settings = settings,
            onUpdate = { transform -> scope.launch { app.settings.update(transform) } },
            onBack = { screen = returnTo },
        )
    }
}
