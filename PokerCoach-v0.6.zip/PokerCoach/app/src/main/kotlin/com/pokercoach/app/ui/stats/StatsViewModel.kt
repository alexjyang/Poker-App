package com.pokercoach.app.ui.stats

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.pokercoach.app.PokerCoachApplication
import com.pokercoach.app.data.HandEntity
import com.pokercoach.app.data.toRecord
import com.pokercoach.app.data.toStatLine
import com.pokercoach.app.ui.table.TableViewModel
import com.pokercoach.engine.analysis.Grade
import com.pokercoach.engine.analysis.HandAnalyzer
import com.pokercoach.engine.analysis.HandReview
import com.pokercoach.engine.card.Card
import com.pokercoach.engine.game.HandEvent
import com.pokercoach.engine.replay.HandReplay
import com.pokercoach.engine.replay.ReplayFrame
import com.pokercoach.engine.stats.Leak
import com.pokercoach.engine.stats.LeakFinder
import com.pokercoach.engine.stats.StatsSummary
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

data class HandRowUi(
    val id: Long,
    val title: String,
    val heroCards: List<Card>,
    val board: List<Card>,
    val netBb: Double,
    val summary: String,
    val analyzed: Boolean,
    val worstGrade: Grade?,
    val evLostBb: Double,
)

data class StatsUiState(
    val loading: Boolean = true,
    val lifetime: Boolean = true,
    val summary: StatsSummary = StatsSummary.of(emptyList()),
    val leaks: List<Leak> = emptyList(),
    val rows: List<HandRowUi> = emptyList(),
    /** Cumulative result in BB, oldest to newest (downsampled). */
    val resultsCurve: List<Float> = emptyList(),
    /** Rolling share (0–100) of decisions graded Best or Good, oldest to newest. */
    val accuracyCurve: List<Float> = emptyList(),
    val accuracy: Double? = null,
    val analyzedDecisions: Int = 0,
)

data class ReplayUi(
    val handId: Long,
    val frames: List<ReplayFrame>,
    val names: Map<Int, String>,
    val tableSize: Int,
)

data class StoredReviewUi(
    val handId: Long,
    val review: HandReview?,
    val names: Map<Int, String>,
    val failed: Boolean = false,
)

/**
 * Everything built from the hand-history database: session and lifetime stats, leaks,
 * graphs, the hand list, the replayer and re-analysis of stored hands. Heavy work runs on
 * Dispatchers.Default; the database streams updates as new hands are saved.
 */
class StatsViewModel(application: Application) : AndroidViewModel(application) {
    private val repo = (application as PokerCoachApplication).repository
    private val lifetime = MutableStateFlow(true)

    val state: StateFlow<StatsUiState> = combine(
        repo.observeHands(),
        repo.observeDecisions(),
        repo.observeLatestSessionId(),
        lifetime,
    ) { hands, decisions, latest, all ->
        val scoped = if (all || latest == null) hands else hands.filter { it.sessionId == latest }
        val ids = scoped.map { it.id }.toHashSet()
        val records = decisions.filter { it.handId in ids }.mapNotNull { it.toRecord() }
        val chronological = scoped.asReversed()
        val lines = chronological.map { it.toStatLine() }

        var cum = 0.0
        val results = chronological.map { h -> cum += h.heroNet.toDouble() / h.bigBlind; cum.toFloat() }
        val window = 20
        val good = records.map { if (it.grade <= Grade.GOOD) 1f else 0f }
        val accuracy = if (good.size < window) {
            emptyList()
        } else {
            (window..good.size).map { end -> good.subList(end - window, end).sum() / window * 100f }
        }
        StatsUiState(
            loading = false,
            lifetime = all,
            summary = StatsSummary.of(lines),
            leaks = LeakFinder.find(scoped.map { it.id to it.toStatLine() }, records),
            rows = scoped.take(300).map { it.toRow() },
            resultsCurve = downsample(results, 240),
            accuracyCurve = downsample(accuracy, 240),
            accuracy = if (records.isEmpty()) null else good.sum().toDouble() / records.size,
            analyzedDecisions = records.size,
        )
    }.flowOn(Dispatchers.Default).stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), StatsUiState())

    fun setLifetime(all: Boolean) {
        lifetime.value = all
    }

    private val _replay = MutableStateFlow<ReplayUi?>(null)
    val replay: StateFlow<ReplayUi?> = _replay.asStateFlow()

    private val _review = MutableStateFlow<StoredReviewUi?>(null)
    val review: StateFlow<StoredReviewUi?> = _review.asStateFlow()

    fun openReplay(handId: Long) {
        _replay.value = null
        viewModelScope.launch {
            val events = safeLoad(handId) ?: return@launch
            val names = namesOf(events)
            val frames = withContext(Dispatchers.Default) {
                HandReplay.frames(events, TableViewModel.HERO_SEAT, { names[it] ?: "Seat ${it + 1}" })
            }
            val size = ((events.first() as HandEvent.HandStarted).players.maxOf { it.seat } + 1).coerceAtLeast(2)
            _replay.value = ReplayUi(handId, frames, names, size)
        }
    }

    fun openReview(handId: Long) {
        _review.value = StoredReviewUi(handId, null, emptyMap())
        viewModelScope.launch {
            val events = safeLoad(handId)
            if (events == null) {
                _review.value = StoredReviewUi(handId, null, emptyMap(), failed = true)
                return@launch
            }
            // Reviews are deterministic, so re-analyzing the stored hand gives the same result.
            val review = try {
                withContext(Dispatchers.Default) { HandAnalyzer(6_000).analyze(events, TableViewModel.HERO_SEAT) }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                null
            }
            _review.value = StoredReviewUi(handId, review, namesOf(events), failed = review == null)
        }
    }

    fun clearHistory() {
        viewModelScope.launch { repo.clearAll() }
    }

    private suspend fun safeLoad(handId: Long): List<HandEvent>? = try {
        repo.loadEvents(handId)
    } catch (e: CancellationException) {
        throw e
    } catch (e: Exception) {
        null
    }

    private fun namesOf(events: List<HandEvent>): Map<Int, String> =
        (events.first() as HandEvent.HandStarted).players.associate { it.seat to it.name }

    private fun HandEntity.toRow() = HandRowUi(
        id = id,
        title = "Hand #$id",
        heroCards = runCatching { Card.parseList(heroCards) }.getOrDefault(emptyList()),
        board = runCatching { Card.parseList(board) }.getOrDefault(emptyList()),
        netBb = heroNet.toDouble() / bigBlind,
        summary = summary,
        analyzed = analyzed,
        worstGrade = if (worstGrade in Grade.entries.indices) Grade.entries[worstGrade] else null,
        evLostBb = evLostBb,
    )

    private fun downsample(values: List<Float>, max: Int): List<Float> {
        if (values.size <= max) return values
        val step = values.size.toDouble() / max
        return List(max) { i -> values[(i * step).toInt().coerceAtMost(values.lastIndex)] } + values.last()
    }
}
