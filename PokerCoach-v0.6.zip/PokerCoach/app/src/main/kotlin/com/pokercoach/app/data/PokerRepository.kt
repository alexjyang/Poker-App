package com.pokercoach.app.data

import com.pokercoach.engine.analysis.Grade
import com.pokercoach.engine.analysis.HandReview
import com.pokercoach.engine.analysis.OptionKind
import com.pokercoach.engine.analysis.Spot
import com.pokercoach.engine.game.HandEvent
import com.pokercoach.engine.history.HandHistoryCodec
import com.pokercoach.engine.stats.DecisionRecord
import com.pokercoach.engine.stats.HandStatLine
import com.pokercoach.engine.stats.HandStats
import kotlinx.coroutines.flow.Flow

/** All persistence for played hands. Room runs suspend DAO calls off the main thread. */
class PokerRepository(private val dao: PokerDao) {

    suspend fun startSession(mode: String, players: Int, lineup: String): Long =
        dao.insertSession(SessionEntity(startedAt = System.currentTimeMillis(), mode = mode, players = players, lineup = lineup))

    /** Stores a finished hand. Returns its id, or null if the hero wasn't dealt in. */
    suspend fun saveHand(sessionId: Long, events: List<HandEvent>, heroSeat: Int, summary: String): Long? {
        val stats = HandStats.extract(events, heroSeat) ?: return null
        val start = events.first() as HandEvent.HandStarted
        val hole = events.filterIsInstance<HandEvent.HoleCardsDealt>().firstOrNull { it.seat == heroSeat }?.cards.orEmpty()
        val board = events.filterIsInstance<HandEvent.BoardDealt>().flatMap { it.cards }
        val id = dao.insertHand(
            HandEntity(
                sessionId = sessionId,
                handNumber = start.handNumber,
                playedAt = System.currentTimeMillis(),
                bigBlind = start.blinds.bigBlind,
                players = stats.players,
                heroNet = stats.netChips,
                heroCards = hole.joinToString(""),
                board = board.joinToString(""),
                summary = summary,
                vpip = stats.vpip, pfr = stats.pfr, threeBetOpp = stats.threeBetOpp, threeBet = stats.threeBet,
                sawFlop = stats.sawFlop, wentToShowdown = stats.wentToShowdown, wonAtShowdown = stats.wonAtShowdown,
                cbetOpp = stats.cbetOpp, cbet = stats.cbet, foldToCbetOpp = stats.foldToCbetOpp, foldToCbet = stats.foldToCbet,
                postflopAggressive = stats.postflopAggressive, postflopCalls = stats.postflopCalls,
            ),
        )
        dao.insertEvents(HandEventsEntity(id, HandHistoryCodec.encode(events)))
        return id
    }

    suspend fun saveReview(handId: Long, review: HandReview) {
        dao.insertDecisions(
            review.decisions.map { d ->
                DecisionEntity(
                    handId = handId, idx = d.index, street = d.street.name, spot = d.spot.name,
                    chosen = d.chosen.kind.name, best = d.best.kind.name, grade = d.grade.ordinal,
                    evLossBb = d.evLossBb, label = d.chosen.label,
                )
            },
        )
        dao.markAnalyzed(
            handId = handId,
            decisions = review.decisions.size,
            good = review.decisions.count { it.grade <= Grade.GOOD },
            evLost = review.totalEvLossBb,
            worst = review.decisions.maxOfOrNull { it.grade.ordinal } ?: -1,
        )
    }

    fun observeHands(): Flow<List<HandEntity>> = dao.observeHands()
    fun observeDecisions(): Flow<List<DecisionEntity>> = dao.observeDecisions()
    fun observeLatestSessionId(): Flow<Long?> = dao.observeLatestSessionId()

    suspend fun loadEvents(handId: Long): List<HandEvent>? = dao.events(handId)?.let(HandHistoryCodec::decode)

    suspend fun clearAll() {
        dao.clearDecisions()
        dao.clearEvents()
        dao.clearHands()
        dao.clearSessions()
    }
}

fun HandEntity.toStatLine() = HandStatLine(
    players = players, bigBlind = bigBlind, netChips = heroNet,
    vpip = vpip, pfr = pfr, threeBetOpp = threeBetOpp, threeBet = threeBet,
    sawFlop = sawFlop, wentToShowdown = wentToShowdown, wonAtShowdown = wonAtShowdown,
    cbetOpp = cbetOpp, cbet = cbet, foldToCbetOpp = foldToCbetOpp, foldToCbet = foldToCbet,
    postflopAggressive = postflopAggressive, postflopCalls = postflopCalls,
)

fun DecisionEntity.toRecord(): DecisionRecord? = runCatching {
    DecisionRecord(
        handId = handId,
        spot = Spot.valueOf(spot),
        chosen = OptionKind.valueOf(chosen),
        best = OptionKind.valueOf(best),
        grade = Grade.entries[grade],
        evLossBb = evLossBb,
    )
}.getOrNull()
