package com.pokercoach.app.ui.table

import com.pokercoach.engine.analysis.Grade
import com.pokercoach.engine.card.Card
import com.pokercoach.engine.game.LegalActions
import com.pokercoach.engine.game.Street

/** Everything the table screen draws. Built by [TableViewModel] from engine snapshots. */
data class TableUiState(
    val active: Boolean = false,
    val tableSize: Int = 6,
    val heroSeat: Int = 0,
    val seats: List<SeatUi> = emptyList(),
    val board: List<Card> = emptyList(),
    val pot: Long = 0,
    val street: Street? = null,
    val currentBet: Long = 0,
    val heroStreetCommit: Long = 0,
    val heroLegal: LegalActions? = null,
    val bigBlind: Long = 2,
    val modeLabel: String = "",
    val blindsLabel: String = "",
    val handNumber: Long = 0,
    val handInProgress: Boolean = false,
    val actingName: String? = null,
    val result: HandResultUi? = null,
    val review: ReviewSummaryUi? = null,
    val sessionOver: SessionOverUi? = null,
    val error: String? = null,
)

data class SeatUi(
    val seat: Int,
    val name: String,
    val style: String?,
    val avatarColor: Long,
    val stack: Long,
    val bet: Long,
    /** Visible hole cards, or null when face down / not shown. */
    val cards: List<Card>?,
    val dealtIn: Boolean,
    val folded: Boolean,
    val allIn: Boolean,
    val isHero: Boolean,
    val isButton: Boolean,
    val isActing: Boolean,
    val lastAction: String?,
    val wonAmount: Long,
    val busted: Boolean,
)

data class HandResultUi(
    val headline: String,
    val details: List<String>,
    val heroNet: Long,
    val footer: String,
)

/** Short verdict shown under the hand result, with a link to the full review. */
data class ReviewSummaryUi(
    val handNumber: Long,
    val analyzing: Boolean,
    val decisions: Int,
    val evLostBb: Double,
    val worst: Grade?,
    val mistakes: Int,
)

data class SessionOverUi(val title: String, val message: String)

fun chips(n: Long): String = "%,d".format(n)
