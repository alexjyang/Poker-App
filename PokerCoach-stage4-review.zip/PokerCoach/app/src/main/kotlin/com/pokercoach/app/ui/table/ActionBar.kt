package com.pokercoach.app.ui.table

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.background
import androidx.compose.ui.draw.clip
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.pokercoach.engine.analysis.Grade
import com.pokercoach.engine.game.LegalActions
import com.pokercoach.engine.game.PlayerAction
import com.pokercoach.engine.game.Street
import kotlin.math.roundToLong

/**
 * Bottom action bar: quick sizes, bet slider with tap-to-type amount, and three large buttons
 * within thumb reach (Fold / Check-Call / Bet-Raise).
 */
@Composable
fun ActionBar(state: TableUiState, onAction: (PlayerAction) -> Unit, modifier: Modifier = Modifier) {
    val legal = state.heroLegal ?: return
    var amount by remember(legal) { mutableLongStateOf(legal.minRaiseTo) }
    var editing by remember { mutableStateOf(false) }
    val unit = maxOf(1L, state.bigBlind / 2)

    Column(
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 12.dp, vertical = 10.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        if (legal.canRaise) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                sizePresets(state, legal).forEach { (label, value) ->
                    FilledTonalButton(
                        onClick = { amount = value },
                        modifier = Modifier
                            .weight(1f)
                            .height(38.dp),
                        contentPadding = PaddingValues(horizontal = 2.dp),
                    ) {
                        Text(label, fontSize = 13.sp, maxLines = 1)
                    }
                }
            }
            if (legal.maxRaiseTo > legal.minRaiseTo) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Slider(
                        value = amount.toFloat(),
                        onValueChange = { amount = snapAmount(it, legal, unit) },
                        valueRange = legal.minRaiseTo.toFloat()..legal.maxRaiseTo.toFloat(),
                        modifier = Modifier.weight(1f),
                    )
                    Spacer(Modifier.width(8.dp))
                    OutlinedButton(
                        onClick = { editing = true },
                        contentPadding = PaddingValues(horizontal = 12.dp),
                    ) {
                        Text(chips(amount), fontWeight = FontWeight.SemiBold)
                    }
                }
            }
        }

        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            val big = Modifier
                .weight(1f)
                .height(58.dp)
            Button(
                onClick = { onAction(PlayerAction.Fold) },
                modifier = big,
                colors = ButtonDefaults.buttonColors(
                    containerColor = MaterialTheme.colorScheme.errorContainer,
                    contentColor = MaterialTheme.colorScheme.onErrorContainer,
                ),
            ) { Text("Fold", fontWeight = FontWeight.Bold, fontSize = 16.sp) }

            Button(
                onClick = { onAction(if (legal.canCheck) PlayerAction.Check else PlayerAction.Call) },
                modifier = big,
                colors = ButtonDefaults.buttonColors(
                    containerColor = MaterialTheme.colorScheme.secondaryContainer,
                    contentColor = MaterialTheme.colorScheme.onSecondaryContainer,
                ),
                contentPadding = PaddingValues(horizontal = 4.dp),
            ) {
                ActionLabel(
                    title = when {
                        legal.canCheck -> "Check"
                        legal.callIsAllIn -> "Call all-in"
                        else -> "Call"
                    },
                    amount = if (legal.canCheck) null else legal.toCall,
                )
            }

            if (legal.canRaise) {
                val allIn = amount >= legal.maxRaiseTo
                Button(
                    onClick = {
                        onAction(if (allIn) PlayerAction.AllIn else PlayerAction.BetOrRaise(amount))
                    },
                    modifier = big,
                    contentPadding = PaddingValues(horizontal = 4.dp),
                ) {
                    ActionLabel(
                        title = when {
                            allIn -> "All-in"
                            legal.isBet -> "Bet"
                            else -> "Raise to"
                        },
                        amount = if (allIn) legal.maxRaiseTo else amount,
                    )
                }
            }
        }
    }

    if (editing) {
        AmountDialog(
            initial = amount,
            min = legal.minRaiseTo,
            max = legal.maxRaiseTo,
            onConfirm = { amount = it; editing = false },
            onDismiss = { editing = false },
        )
    }
}

@Composable
private fun ActionLabel(title: String, amount: Long?) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(title, fontWeight = FontWeight.Bold, fontSize = 15.sp, lineHeight = 17.sp, maxLines = 1)
        if (amount != null) Text(chips(amount), fontSize = 14.sp, lineHeight = 16.sp, maxLines = 1)
    }
}

/**
 * Quick sizes. Unopened preflop pots use big-blind multiples; otherwise pot fractions, where a
 * "pot-sized" raise means: call first, then raise by the size of the pot after the call.
 */
private fun sizePresets(state: TableUiState, legal: LegalActions): List<Pair<String, Long>> {
    val bb = state.bigBlind
    val raw = if (state.street == Street.PREFLOP && state.currentBet <= bb) {
        listOf("2.5 BB" to bb * 5 / 2, "3 BB" to bb * 3, "4 BB" to bb * 4)
    } else {
        val owed = state.currentBet - state.heroStreetCommit
        val potAfterCall = state.pot + owed
        listOf(
            "½ Pot" to state.currentBet + potAfterCall / 2,
            "⅔ Pot" to state.currentBet + potAfterCall * 2 / 3,
            "Pot" to state.currentBet + potAfterCall,
        )
    }
    return raw.map { (label, v) -> label to v.coerceIn(legal.minRaiseTo, legal.maxRaiseTo) } +
        ("All-in" to legal.maxRaiseTo)
}

private fun snapAmount(value: Float, legal: LegalActions, unit: Long): Long {
    val raw = value.roundToLong()
    if (raw >= legal.maxRaiseTo - unit / 2) return legal.maxRaiseTo
    val snapped = (raw.toDouble() / unit).roundToLong() * unit
    return snapped.coerceIn(legal.minRaiseTo, legal.maxRaiseTo)
}

@Composable
private fun AmountDialog(initial: Long, min: Long, max: Long, onConfirm: (Long) -> Unit, onDismiss: () -> Unit) {
    var text by remember { mutableStateOf(initial.toString()) }
    val value = text.toLongOrNull()
    val valid = value != null && value in min..max
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Bet amount") },
        text = {
            OutlinedTextField(
                value = text,
                onValueChange = { new -> text = new.filter { it.isDigit() }.take(12) },
                singleLine = true,
                isError = !valid,
                label = { Text("Total for this street") },
                supportingText = { Text("Between ${chips(min)} and ${chips(max)}") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
            )
        },
        confirmButton = {
            TextButton(onClick = { value?.let { onConfirm(it.coerceIn(min, max)) } }, enabled = value != null) {
                Text("OK")
            }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } },
    )
}

@Composable
fun ResultPanel(
    result: HandResultUi,
    review: ReviewSummaryUi?,
    onNext: () -> Unit,
    onReview: (Long) -> Unit,
    modifier: Modifier = Modifier,
) {
    Column(
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(3.dp),
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(
                result.headline,
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.weight(1f),
            )
            if (result.heroNet != 0L) {
                Text(
                    text = (if (result.heroNet > 0) "+" else "−") + chips(kotlin.math.abs(result.heroNet)),
                    color = if (result.heroNet > 0) Color(0xFF2E9E55) else MaterialTheme.colorScheme.error,
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                )
            }
        }
        result.details.forEach {
            Text(it, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Text(
            result.footer,
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f),
        )
        if (review != null) {
            Spacer(Modifier.height(4.dp))
            ReviewVerdict(review)
        }
        Spacer(Modifier.height(6.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            if (review != null && review.decisions > 0) {
                OutlinedButton(
                    onClick = { onReview(review.handNumber) },
                    modifier = Modifier
                        .weight(1f)
                        .height(52.dp),
                ) { Text("Review hand", fontWeight = FontWeight.SemiBold) }
            }
            Button(
                onClick = onNext,
                modifier = Modifier
                    .weight(1f)
                    .height(52.dp),
            ) { Text("Next hand", fontWeight = FontWeight.Bold, fontSize = 16.sp) }
        }
    }
}

@Composable
private fun ReviewVerdict(review: ReviewSummaryUi) {
    val worst = review.worst
    val text = when {
        review.analyzing -> "Analyzing your decisions…"
        review.decisions == 0 -> "No decisions to review."
        worst == null || worst <= Grade.GOOD -> "Coach: well played — ${review.decisions} decision${if (review.decisions > 1) "s" else ""}, " +
            "EV lost ${"%.2f".format(review.evLostBb)} BB."
        else -> "Coach: ${review.mistakes.takeIf { it > 0 }?.let { "$it mistake${if (it > 1) "s" else ""}" } ?: "an inaccuracy"}, " +
            "EV lost ${"%.2f".format(review.evLostBb)} BB. Worst: ${worst.label}."
    }
    Row(verticalAlignment = Alignment.CenterVertically) {
        if (worst != null && !review.analyzing) {
            GradeDot(worst)
            Spacer(Modifier.width(6.dp))
        }
        Text(text, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Medium)
    }
    if (review.analyzing) LinearProgressIndicator(Modifier.fillMaxWidth().padding(top = 4.dp))
}

@Composable
fun GradeDot(grade: Grade) {
    androidx.compose.foundation.layout.Box(
        Modifier
            .size(12.dp)
            .clip(androidx.compose.foundation.shape.CircleShape)
            .background(gradeColor(grade)),
    )
}

fun gradeColor(grade: Grade): Color = when (grade) {
    Grade.BEST -> Color(0xFF2E7D32)
    Grade.GOOD -> Color(0xFF7CB342)
    Grade.INACCURACY -> Color(0xFFF9A825)
    Grade.MISTAKE -> Color(0xFFEF6C00)
    Grade.BLUNDER -> Color(0xFFC62828)
}

@Composable
fun WaitingPanel(actingName: String?, modifier: Modifier = Modifier) {
    Column(
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 20.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        Text(
            text = actingName?.let { "$it is thinking…" } ?: "Dealing…",
            style = MaterialTheme.typography.bodyLarge,
            textAlign = TextAlign.Start,
        )
        LinearProgressIndicator(Modifier.fillMaxWidth())
    }
}
