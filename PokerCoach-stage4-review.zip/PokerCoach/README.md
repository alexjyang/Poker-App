# PokerCoach

A No-Limit Texas Hold'em training app for Android.

- **Stage 1** — pure-Kotlin rules engine, hand evaluator, tests ✅
- **Stage 2** — playable table UI with basic bots, installable APK ✅
- **Stage 4** — equity/EV calculator and post-hand analysis ✅ (done before Stage 3 by request)
- Stage 3 — difficulty levels and bot personalities
- Stage 5 — stats, leak finder, hand replayer
- Stage 6 — polish: animations, haptics, themes, settings

## Install on your phone without a computer

GitHub builds the APK for you on every upload.

1. Sign in at github.com in your phone's browser and create a new repository
   (**+ → New repository**, any name, tick **Add a README file**).
2. Upload the project: **Add file → Upload files**, pick the newest `PokerCoach-*.zip` as-is (don't
   unzip it), and commit. The build script finds the newest zip and unpacks it itself.
3. Add the build script: **Add file → Create new file**, type the name
   `.github/workflows/build.yml`, paste the contents of that file from this project, and
   tap **Commit changes**. This commit starts the first build.
4. Open the **Actions** tab. The build takes about 5–8 minutes; a green check means done.
5. Open **Releases** (on the repo's main page), tap the newest build, tap `PokerCoach.apk`.
6. Allow your browser to install unknown apps when Android asks. If Play Protect warns about an
   unknown developer, choose **Install anyway** (it's your own build).

For later stages, upload the new zip the same way; the app updates in place because every build
is signed with the same key (`app/debug.keystore`).

If a build fails, open the failed run in **Actions**, expand the red step, and copy the error.

## Post-hand analysis (Stage 4)

After each hand the result panel shows a one-line coach verdict (for example "1 mistake, EV lost
1.30 BB"). **Review hand** opens the full review, with a Beginner / Advanced toggle.

**Beginner mode** shows, for every decision:
- a grade: Best / Good / Inaccuracy / Mistake / Blunder
- equity, the equity you needed, EV bars for each option
- one plain-language explanation
- outs
- tappable concept chips with glossary definitions

**Advanced mode** adds:
- the EV of every option in BB and the EV you gave up
- the equity method and its error margin
- pot odds, MDF, SPR and implied odds
- a breakdown of each opponent's range (monsters, strong, medium, draws, air)
- 13×13 range grids for opponents and for your perceived range
- range and nut advantage, blocker effects, and a GTO-vs-exploit note on river bets

```
engine/range/     Combos (1,326 hands), HandClass (13×13 grid), weighted Range,
                  PreflopRanking (169 classes by equity vs a random hand), BoardStrength
engine/analysis/  RangeEstimator   ranges from actions: preflop templates by position and action,
                                   postflop narrowing by board-relative hand strength
                  EquityCalculator exact enumeration (heads-up turn/river) or seeded Monte Carlo
                  EvModel          EV of fold / check / call / bet / raise sizes
                  HandAnalyzer     replays the hand, analyzes each hero decision
                  Explainer        beginner text, advanced points, takeaway
                  ReviewModel      Grade, Concept glossary, Decision, HandReview
app/ui/review/    ReviewScreen (summary, decision cards, EV bars, range grids, glossary dialogs)
```

**How the numbers are made, and what is exact versus estimated:**
- **Exact arithmetic:** pot odds and required equity, MDF = pot ÷ (pot + bet), SPR, and hit
  probabilities for a given number of outs.
- **Equity:** exact enumeration heads-up on the turn and river. Otherwise Monte Carlo with a fixed
  seed, shown with a 95% error margin. Either way it is computed against *estimated* ranges.
- **Ranges:** estimated from actions the way a reasonable regular plays. They never use the
  opponents' real cards (the analyzer only reads your hole cards).
- **EV:** a one-decision model. Calls and checks use showdown equity × an equity-realization
  factor (in position > out of position). Bets and raises use fold equity: opponents continue
  with the strongest part of their range, as often as the larger of MDF and "strong enough for
  the price". Future streets, re-raises and side pots are not simulated. All options share one
  random seed, so the *differences* between options are precise.
- **Grades** scale with the pot: losing 2 BB in a 3 BB pot is a blunder, in a 200 BB pot it's not.
  A blunder must also cost at least 2 BB, and folding when you could check is always a mistake.
- **Deterministic:** the same hand always produces the same review.

Speed: about 13 ms per decision on a desktop JVM (roughly 0.1 s on a mid-range phone). Analysis
runs on `Dispatchers.Default` while you keep playing.

## Stage 2 architecture

```
app/  (Android, Jetpack Compose + Material 3)
├── MainActivity.kt              edge-to-edge, theme follows the system light/dark setting
├── ui/PokerCoachApp.kt          lobby ↔ table switch (Navigation arrives with Stage 5 screens)
├── ui/home/HomeScreen.kt        game type, players (2/6/9), buy-in, bot speed
├── ui/table/TableViewModel.kt   game loop: owns TableSession + bots, exposes StateFlow<TableUiState>
├── ui/table/TableArea.kt        oval felt, seats clockwise with you at the bottom, bets, dealer button, board
├── ui/table/ActionBar.kt        Fold / Check-Call / Bet-Raise, quick sizes, slider, typed amount
├── ui/table/PlayingCard.kt      cards with deal-in animation
└── ui/theme/Theme.kt            Material 3 color schemes + table colors
engine/bot/  (pure Kotlin)
├── BasicBot.kt                  preflop Chen score + position; postflop equity vs pot odds
└── QuickEquity.kt               Monte Carlo equity vs random hands
```

**MVVM with a single-owner game loop.** The ViewModel runs one coroutine that is the only code
touching the engine, so there is no shared mutable state. The UI sends intents (hero action,
next hand) through channels and renders an immutable `TableUiState`.

**Bots think off the main thread.** Each decision runs on `Dispatchers.Default` and receives
`snapshotFor(seat)`, which hides everyone else's cards, so bots cannot cheat by construction.

**Bots use numbers, not dice.** Preflop: Chen hand score against position-dependent thresholds,
3-bets with premiums, push/fold under 12 BB. Postflop: Monte Carlo equity against the live
opponents, discounted when facing a bet (a bettor's range beats a random hand), compared with
pot odds. Randomness only mixes between close options. Measured over 30 bot-only sit-and-gos:
VPIP ≈ 17%, PFR ≈ 11% (a solid, slightly tight style). Stage 3 adds the personalities.

**Presentation never changes the game.** Board run-outs after all-ins are revealed street by
street, and stacks show pre-payout values until the reveal ends, purely in the UI layer.

**Portrait and landscape.** Seat positions are computed from the available size; in landscape
the controls move to a side panel. The back gesture asks before leaving a hand in progress.



## Stage 1: engine

### Module layout

```
PokerCoach/
├── settings.gradle.kts          # includes :engine (":app" is added in Stage 2)
├── build.gradle.kts
├── gradle/libs.versions.toml    # version catalog
├── gradlew, gradlew.bat, gradle/wrapper/
└── engine/                      # pure Kotlin/JVM — zero Android dependencies
    └── src/main/kotlin/com/pokercoach/engine/
        ├── card/     Card, Rank, Suit, CardMask, Deck (seeded + SHA-256 commitment)
        ├── rng/      SeededRandom (xoshiro256** + SplitMix64)
        ├── eval/     HandEvaluator, HandValue, HandCategory
        ├── game/     HandEngine (state machine), PotCalculator, events, actions, snapshots
        └── session/  TableSession (cash / sit-and-go), BlindSchedule
```

### Architecture decisions

**Pure Kotlin engine.** The engine is a plain `kotlin("jvm")` module. The Android app will
depend on it, but it never depends on Android, so all rules are covered by fast JVM unit tests.

**Integer chips.** All amounts are `Long` chips. No floating point touches money.

**Cards as bits.** A card is an `Int` 0..51 laid out `suit * 13 + rank`, so a set of cards is a
52-bit `Long` and each suit's ranks are a 13-bit slice. This makes the evaluator and (in Stage 4)
Monte Carlo equity allocation-free.

**Evaluator.** Bitwise, 5–7 cards, one 8 KB straight lookup table. Pairs/trips/quads come from
AND/OR combinations of the four suit masks. The result is a single `Int` whose natural order is
poker order (category, then primary ranks, then kickers). About 33 ns per 7-card hand on a
desktop JVM; verified against all 133,784,560 seven-card hands.

**Deterministic, auditable shuffle.** The engine owns its RNG algorithm (xoshiro256**), so a
seed produces the same deck on every JVM, Android version and Kotlin release. Each hand stores
its seed and a SHA-256 commitment of the deck order; each hand's seed is derived from the session
seed, so a whole session replays from one number plus the recorded actions. A golden test locks
the shuffle so old replays can never silently break.

**State machine + event log.** `HandEngine` is driven by `act(action)` and exposes
`legalActions()`. Every step is appended to an immutable `HandEvent` list. `ActionTaken`
records the pot, the amount to call and the stack the player faced, which is exactly what
the post-hand analysis in Stage 4 needs to rebuild each decision.

**No cheating by construction.** `snapshotFor(seat)` hides every other player's hole cards
until showdown. Bots will only ever receive that view.

**Pot math isolated.** `PotCalculator` (uncalled bets, side pots, odd-chip splits) is a set of
pure functions tested independently of the state machine.

### Rules implemented

- 2–9 players; heads-up blind/position rules (button = small blind, first preflop, last postflop)
- Per-player antes (dead, posted before blinds) and big-blind ante (posted after the BB)
- Short blinds and antes post all-in; callers must still match the full big blind
- Minimum raise = last full raise increment (minimum one big blind)
- Incomplete all-in raises don't reopen betting for players who already acted, unless the
  total they now face is at least a full raise (TDA-style cumulative rule)
- A player who checked may raise any later bet, including an incomplete all-in bet
- Raising is disabled when all opponents are all-in
- Uncalled bets returned; any number of side pots; split pots with odd chips to the first
  winner left of the button; automatic board run-out when betting is closed
- Sessions: cash (auto-rebuy, top-ups) and sit-and-go (hand-based blind levels,
  finishing places, same-hand busts ranked by starting stack); moving button

## Build with a computer (optional)

Requirements: Android Studio (Ladybug or newer) or any JDK 17+.

**Android Studio:** File → Open → select the `PokerCoach` folder → let Gradle sync → pick the
`app` run configuration and press Run (phone via USB debugging or an emulator). Engine tests:
right-click `engine/src/test/kotlin` → *Run 'Tests in engine'*.

**Command line:**

```bash
./gradlew :engine:test          # all engine + bot tests
./gradlew :app:assembleDebug    # APK in app/build/outputs/apk/debug/
```

The first run downloads Gradle 8.14 and dependencies. The exhaustive 7-card evaluator test takes
about 5 seconds; everything else runs in about 2 seconds.

## Test coverage

| Suite | What it proves |
|---|---|
| `HandEvaluatorTest` | Category counts for all 2,598,960 five-card and 133,784,560 seven-card hands; 7,462 and 4,824 distinct strength classes; 7-card = best of 21 subsets (20k random); wheels, kickers, three pairs, two sets of trips, six-card flushes |
| `DeckTest` | Seed determinism, permutation validity, frozen golden order, uniformity (chi-square) |
| `PotCalculatorTest` | Multi-way side pots, dead money from folders, uncalled bets, odd-chip distribution |
| `HandEngineTest` | Positions, walks, min-raise, short all-in reopening rules, antes, short BB, side-pot showdown, split pots, run-outs, hidden cards, decision context; 5,000-hand random fuzz (chip conservation and pot accounting); exact replay |
| `TableSessionTest` | Full SNG to one winner, button movement, blind levels, rebuys, session replay |
| `AnalysisTest` | Folding the nuts = Blunder; calling off with 7-high = Mistake+; folding when checking is free is flagged; AA raises / 72o folds; exact turn equity matches brute force; flush draw = 9 outs with exact hit odds; board-strength ordering; 13×13 grid math; determinism; 60-hand review fuzz |
| `BotTest` | Chen scores, Monte Carlo equity vs known values (AA 85.2%, 72o 34.6%), bots raise aces / fold trash, 20 bot-only SNGs with no illegal actions |

UI tests for the table and review flow are still to do (planned with the Stage 6 polish pass).

## Next: Stage 3

Difficulty system and bot personalities: Beginner, Casual, Regular, Shark, GTO-approx, and
Custom sliders (VPIP, PFR/aggression, bluff frequency, tilt/adaptiveness), mixable at one table
with toggleable style labels.
