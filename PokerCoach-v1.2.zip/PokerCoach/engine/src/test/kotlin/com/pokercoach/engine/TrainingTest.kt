package com.pokercoach.engine

import com.pokercoach.engine.analysis.Grade
import com.pokercoach.engine.analysis.HandAnalyzer
import com.pokercoach.engine.bot.PreflopCharts.Pos
import com.pokercoach.engine.game.PlayerAction
import com.pokercoach.engine.game.Street
import com.pokercoach.engine.range.HandClass
import com.pokercoach.engine.rng.SeededRandom
import com.pokercoach.engine.training.Accuracy
import com.pokercoach.engine.training.DrillGenerator
import com.pokercoach.engine.training.DrillType
import com.pokercoach.engine.training.PreflopQuiz
import com.pokercoach.engine.training.QuizAnswer
import com.pokercoach.engine.training.QuizQuestion
import com.pokercoach.engine.training.QuizSpot
import com.pokercoach.engine.training.SkillRating
import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertNotNull
import kotlin.test.assertTrue

class TrainingTest {

    @Test
    fun `every drill lands on the decision it trains, and the coach can grade it`() {
        val rng = SeededRandom(7)
        for (type in DrillType.entries) repeat(3) {
            val spot = assertNotNull(DrillGenerator.generate(type, rng), "$type")
            val h = spot.engine
            assertEquals(0, h.actorSeat, "$type: hero to act")
            val legal = h.legalActions()!!
            val expectedStreet = when (type) {
                DrillType.PREFLOP_OPEN, DrillType.BB_DEFENSE, DrillType.FACING_3BET -> Street.PREFLOP
                DrillType.CBET_FLOP, DrillType.FACING_CBET -> Street.FLOP
                DrillType.TURN_BARREL -> Street.TURN
                DrillType.RIVER_BLUFFCATCH -> Street.RIVER
            }
            assertEquals(expectedStreet, h.street, "$type street")
            when (type) {
                DrillType.CBET_FLOP, DrillType.TURN_BARREL -> assertTrue(legal.canCheck, "$type: nobody has bet yet")
                DrillType.FACING_CBET, DrillType.RIVER_BLUFFCATCH, DrillType.BB_DEFENSE, DrillType.FACING_3BET -> assertTrue(legal.toCall > 0, "$type: facing a bet")
                DrillType.PREFLOP_OPEN -> assertTrue(h.events.filterIsInstance<com.pokercoach.engine.game.HandEvent.ActionTaken>().all { it.type == com.pokercoach.engine.game.ActionType.FOLD })
            }
            // The hero answers; the coach grades exactly that decision.
            h.act(if (legal.canCheck) PlayerAction.Check else PlayerAction.Call)
            val d = HandAnalyzer(800).analyze(h.events, 0).decisions.last()
            assertEquals(expectedStreet, d.street)
        }
    }

    @Test
    fun `drills map from leaks`() {
        assertEquals(DrillType.FACING_CBET, DrillType.forLeak("stat-bb-fold-cbet"))
        assertEquals(DrillType.RIVER_BLUFFCATCH, DrillType.forLeak("call-too-much-RIVER"))
        assertEquals(DrillType.PREFLOP_OPEN, DrillType.forLeak("pre-too-loose"))
        assertEquals(DrillType.CBET_FLOP, DrillType.forLeak("missed-bluffs"))
    }

    @Test
    fun `preflop quiz grades against the charts`() {
        fun q(spot: QuizSpot, hero: Pos, villain: Pos?, hand: String): QuizQuestion {
            val cls = HandClass.parse(hand).index
            return QuizQuestion(spot, hero, villain, cls, emptyList(), PreflopQuiz.frequencies(spot, hero, villain, cls)!!)
        }
        val aa = q(QuizSpot.OPEN, Pos.UTG, null, "AA")
        assertTrue(PreflopQuiz.grade(aa, QuizAnswer.RAISE).correct)
        assertTrue(!PreflopQuiz.grade(aa, QuizAnswer.FOLD).acceptable)
        val trash = q(QuizSpot.OPEN, Pos.UTG, null, "72o")
        assertEquals(QuizAnswer.FOLD, PreflopQuiz.grade(trash, QuizAnswer.RAISE).best)
        // Questions are well-formed and varied.
        val rng = SeededRandom(3)
        val qs = List(200) { PreflopQuiz.next(rng) }
        assertTrue(qs.map { it.spot }.toSet().size == 3)
        qs.forEach { assertEquals(1.0, it.frequencies.values.sum(), 0.01); assertEquals(2, it.cards.size) }
        // Uniformly random hands would be ~75% easy folds; the quiz favours hands near range edges.
        val notFold = qs.count { q -> q.frequencies.maxBy { it.value }.key != QuizAnswer.FOLD }
        assertTrue(notFold >= 60, "answers should be varied, not mostly folds: $notFold of 200")
    }

    @Test
    fun `accuracy and skill rating move with decision quality`() {
        assertEquals(100, Accuracy.of(List(5) { Grade.BEST }))
        assertEquals(75, Accuracy.of(listOf(Grade.BEST, Grade.GOOD, Grade.INACCURACY, Grade.GOOD, Grade.INACCURACY, Grade.BEST, Grade.MISTAKE, Grade.BEST, Grade.GOOD, Grade.INACCURACY)))
        val up = SkillRating.series(List(100) { Grade.BEST })
        assertTrue(up.zipWithNext().all { (a, b) -> b >= a } && up.last() > 2300)
        val down = SkillRating.series(List(100) { Grade.BLUNDER })
        assertTrue(down.last() < 500)
        assertEquals(SkillRating.START, SkillRating.current(emptyList()))
        assertEquals("Solid", SkillRating.title(1500))
    }
}
