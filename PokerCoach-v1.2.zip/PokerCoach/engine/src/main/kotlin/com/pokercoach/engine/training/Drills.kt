package com.pokercoach.engine.training

import com.pokercoach.engine.bot.BotProfile
import com.pokercoach.engine.bot.BotStyle
import com.pokercoach.engine.bot.PreflopCharts
import com.pokercoach.engine.bot.ProfileBot
import com.pokercoach.engine.game.ActionType
import com.pokercoach.engine.game.Blinds
import com.pokercoach.engine.game.HandEngine
import com.pokercoach.engine.game.HandEvent
import com.pokercoach.engine.game.PlayerAction
import com.pokercoach.engine.game.SeatedPlayer
import com.pokercoach.engine.game.Street
import com.pokercoach.engine.range.HandClass
import com.pokercoach.engine.rng.SeededRandom
import kotlin.math.roundToLong

enum class DrillType(val label: String, val description: String) {
    PREFLOP_OPEN("Opening", "Everyone folds to you: raise or fold, from every position."),
    BB_DEFENSE("Big blind defence", "Someone raises and you're in the big blind: fold, call or 3-bet."),
    FACING_3BET("Facing a 3-bet", "You opened and got re-raised: fold, call or 4-bet."),
    CBET_FLOP("Continuation bet", "You raised preflop and got one caller: bet or check the flop."),
    FACING_CBET("Facing a c-bet", "You called preflop and the raiser bets the flop."),
    TURN_BARREL("Turn barrel", "Your flop bet was called: keep betting on the turn or slow down?"),
    RIVER_BLUFFCATCH("River decision", "Facing a river bet: call with a bluff-catcher or fold."),
    ;

    companion object {
        /** The drill that trains a leak found by the leak finder (null if none fits). */
        fun forLeak(leakId: String): DrillType? = when {
            leakId in setOf("pre-too-loose", "pre-too-passive", "stat-vpip-high", "stat-vpip-low", "stat-passive-pre") -> PREFLOP_OPEN
            leakId == "pre-too-tight" -> BB_DEFENSE
            leakId in setOf("stat-bb-fold-cbet", "stat-fold-cbet") || leakId.endsWith("-FLOP") && leakId.startsWith("fold-too-much") -> FACING_CBET
            leakId in setOf("passive-value", "missed-bluffs", "stat-low-cbet", "stat-passive-post") || leakId == "over-aggressive-FLOP" -> CBET_FLOP
            leakId.endsWith("-TURN") || leakId == "sizing" -> TURN_BARREL
            leakId.endsWith("-RIVER") || leakId == "stat-calling-station" -> RIVER_BLUFFCATCH
            else -> null
        }
    }
}

/** A hand frozen at the hero's decision (seat 0), ready to play. */
class DrillSpot(val type: DrillType, val engine: HandEngine, val heroSeat: Int = 0)

/**
 * Deals hands with solid bots until the hero (seat 0) faces the requested kind of decision. The
 * hero's earlier actions follow a simple, sensible plan (open hands from the chart, call with
 * hands that defend, c-bet...), so the spot arises the way it would in a real game.
 */
object DrillGenerator {
    private const val BB = 10L
    private val heroButtonFor = mapOf( // hero is seat 0 of 6: where the button must be for each position
        PreflopCharts.Pos.UTG to 3, PreflopCharts.Pos.HJ to 2, PreflopCharts.Pos.CO to 1,
        PreflopCharts.Pos.BTN to 0, PreflopCharts.Pos.SB to 5, PreflopCharts.Pos.BB to 4,
    )

    fun generate(type: DrillType, rng: SeededRandom, maxAttempts: Int = 3_000): DrillSpot? {
        repeat(maxAttempts) {
            val seed = rng.nextLong()
            val heroPos = when (type) {
                DrillType.BB_DEFENSE -> PreflopCharts.Pos.BB
                DrillType.FACING_CBET, DrillType.RIVER_BLUFFCATCH ->
                    listOf(PreflopCharts.Pos.BB, PreflopCharts.Pos.BTN, PreflopCharts.Pos.CO)[rng.nextInt(3)]
                else -> listOf(PreflopCharts.Pos.UTG, PreflopCharts.Pos.HJ, PreflopCharts.Pos.CO, PreflopCharts.Pos.BTN, PreflopCharts.Pos.SB)[rng.nextInt(5)]
            }
            val button = heroButtonFor.getValue(heroPos)
            val engine = HandEngine((0 until 6).map { SeatedPlayer(it, "p$it", if (it == 0) "You" else NAMES[it], 100 * BB) }, button, Blinds(BB / 2, BB), seed)
            val bots = (1 until 6).associateWith {
                ProfileBot(BotProfile.preset(if ((it + seed).mod(3L) == 0L) BotStyle.GTO else BotStyle.REGULAR), seed + it, iterations = 120, solverBudgetMs = 0)
            }
            val spot = playUntilSpot(type, engine, bots, heroPos, rng)
            if (spot != null) return spot
        }
        return null
    }

    private fun playUntilSpot(type: DrillType, h: HandEngine, bots: Map<Int, ProfileBot>, heroPos: PreflopCharts.Pos, rng: SeededRandom): DrillSpot? {
        var guard = 0
        while (!h.isComplete && guard++ < 200) {
            val seat = h.actorSeat ?: return null
            if (seat != 0) {
                h.act(bots.getValue(seat).decide(h.snapshotFor(seat), seat, h.publicHistory(seat)))
                continue
            }
            if (isSpot(type, h, heroPos, rng)) return DrillSpot(type, h)
            val action = heroPlan(type, h, heroPos) ?: return null
            h.act(action)
        }
        return null
    }

    private fun actions(h: HandEngine) = h.events.filterIsInstance<HandEvent.ActionTaken>()
    private fun raises(h: HandEngine, street: Street) =
        actions(h).filter { it.street == street && (it.type == ActionType.RAISE || it.type == ActionType.BET) }
    private fun live(h: HandEngine) = h.snapshot().seats.count { !it.folded }
    private fun heroClass(h: HandEngine) = h.snapshot().seat(0).holeCards!!.let { HandClass.of(it[0], it[1]).index }
    private fun heroRaisedPre(h: HandEngine) = raises(h, Street.PREFLOP).firstOrNull()?.seat == 0

    /** Is the hero now facing the decision this drill trains? */
    private fun isSpot(type: DrillType, h: HandEngine, heroPos: PreflopCharts.Pos, rng: SeededRandom): Boolean {
        val pre = actions(h).filter { it.street == Street.PREFLOP }
        val cls = heroClass(h)
        val street = h.street
        val legal = h.legalActions() ?: return false
        return when (type) {
            DrillType.PREFLOP_OPEN -> street == Street.PREFLOP && pre.all { it.type == ActionType.FOLD } &&
                interesting(PreflopCharts.open(heroPos, cls, false), rng)
            DrillType.BB_DEFENSE -> street == Street.PREFLOP && pre.count { it.type == ActionType.RAISE } == 1 &&
                pre.none { it.type == ActionType.CALL } && run {
                    val opener = openerPos(h) ?: return@run false
                    interesting(PreflopCharts.vsOpen(heroPos, opener, cls, false)?.let { it.first + it.second }, rng)
                }
            DrillType.FACING_3BET -> street == Street.PREFLOP && heroRaisedPre(h) && pre.count { it.type == ActionType.RAISE } == 2 &&
                pre.none { it.type == ActionType.CALL } && live(h) == 2
            DrillType.CBET_FLOP -> street == Street.FLOP && heroRaisedPre(h) && raises(h, Street.PREFLOP).size == 1 &&
                live(h) == 2 && legal.canCheck
            DrillType.FACING_CBET -> street == Street.FLOP && !heroRaisedPre(h) && live(h) == 2 && legal.toCall > 0 &&
                raises(h, Street.FLOP).size == 1
            DrillType.TURN_BARREL -> street == Street.TURN && heroRaisedPre(h) && live(h) == 2 && legal.canCheck &&
                raises(h, Street.FLOP).singleOrNull()?.seat == 0
            DrillType.RIVER_BLUFFCATCH -> street == Street.RIVER && live(h) == 2 && legal.toCall > 0 && raises(h, Street.RIVER).size == 1
        }
    }

    /** Prefer hands whose answer isn't obvious; still include some clear ones. */
    private fun interesting(freq: Double?, rng: SeededRandom): Boolean {
        val f = freq ?: return false
        return f in 0.05..0.95 || rng.nextDouble() < 0.3
    }

    private fun openerPos(h: HandEngine): PreflopCharts.Pos? {
        val seat = raises(h, Street.PREFLOP).firstOrNull()?.seat ?: return null
        return positionOf(seat, h.buttonSeat)
    }

    private fun positionOffset(p: PreflopCharts.Pos) = when (p) {
        PreflopCharts.Pos.BTN -> 0; PreflopCharts.Pos.SB -> 1; PreflopCharts.Pos.BB -> 2
        PreflopCharts.Pos.UTG -> 3; PreflopCharts.Pos.HJ -> 4; PreflopCharts.Pos.CO -> 5
    }

    private fun positionOf(seat: Int, button: Int): PreflopCharts.Pos =
        PreflopCharts.Pos.entries.first { positionOffset(it) == (seat - button).mod(6) }

    /** The hero's plan before the drilled decision; null = this hand won't lead to the spot. */
    private fun heroPlan(type: DrillType, h: HandEngine, heroPos: PreflopCharts.Pos): PlayerAction? {
        val legal = h.legalActions() ?: return null
        val cls = heroClass(h)
        val pot = h.pot
        return when (h.street) {
            Street.PREFLOP -> when (type) {
                DrillType.FACING_3BET, DrillType.CBET_FLOP, DrillType.TURN_BARREL -> {
                    // Open hands the chart opens; then only continue toward the drill.
                    if (raises(h, Street.PREFLOP).isNotEmpty() || (PreflopCharts.open(heroPos, cls, false) ?: 0.0) < 0.5) null
                    else PlayerAction.BetOrRaise(((if (heroPos == PreflopCharts.Pos.SB) 3.0 else 2.5) * BB).roundToLong())
                }
                DrillType.FACING_CBET, DrillType.RIVER_BLUFFCATCH -> {
                    // Call a single open with hands that defend.
                    val opener = openerPos(h) ?: return null
                    val callFreq = PreflopCharts.vsOpen(heroPos, opener, cls, false)?.first ?: 0.0
                    if (raises(h, Street.PREFLOP).size == 1 && callFreq >= 0.3 && legal.canCall) PlayerAction.Call else null
                }
                else -> null
            }
            Street.FLOP -> when (type) {
                DrillType.TURN_BARREL -> if (legal.canCheck && legal.canRaise) PlayerAction.BetOrRaise(maxOf(legal.minRaiseTo, pot / 2)) else null
                DrillType.FACING_CBET -> if (legal.canCheck) PlayerAction.Check else null
                DrillType.RIVER_BLUFFCATCH -> if (legal.canCheck) PlayerAction.Check else PlayerAction.Call
                else -> null
            }
            Street.TURN -> when (type) {
                DrillType.RIVER_BLUFFCATCH -> if (legal.canCheck) PlayerAction.Check else PlayerAction.Call
                else -> null
            }
            Street.RIVER -> if (type == DrillType.RIVER_BLUFFCATCH && legal.canCheck) PlayerAction.Check else null
            Street.SHOWDOWN -> null
        }
    }

    private val NAMES = listOf("You", "Ava", "Bruno", "Chen", "Dara", "Emeka")
}
