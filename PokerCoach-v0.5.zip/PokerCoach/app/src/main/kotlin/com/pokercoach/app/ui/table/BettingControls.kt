@file:OptIn(ExperimentalLayoutApi::class)

package com.pokercoach.app.ui.table

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.pokercoach.engine.game.LegalActions
import com.pokercoach.engine.game.PlayerAction
import com.pokercoach.engine.game.Street
import kotlinx.coroutines.delay
import kotlin.math.abs
import kotlin.math.roundToInt
import kotlin.math.roundToLong

/**
 * Betting controls in the style of GGPoker / PokerStars mobile:
 *  - three large, calm buttons (Fold / Check-Call / Bet-Raise…) at the bottom, in thumb reach;
 *  - Bet/Raise opens a sizing sheet: context-aware presets (BB multiples when opening,
 *    multiples when re-raising, % pot after the flop), a slider that snaps to presets with a
 *    haptic tick, −/+ steppers, type-in, and one big confirm button showing the amount;
 *  - misclick protection: confirm before folding when checking is free, tap twice for all-in.
 */
@Composable
fun ActionBar(state: TableUiState, onAction: (PlayerAction) -> Unit, modifier: Modifier = Modifier) {
    val legal = state.heroLegal ?: return
    var sizing by remember(legal) { mutableStateOf(false) }
    var confirmFold by remember(legal) { mutableStateOf(false) }

    Column(
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 12.dp, vertical = 10.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        state.coachHint?.let { CoachHintRow(it) }
        if (sizing && legal.canRaise) {
            SizingPanel(state, legal, onBack = { sizing = false }, onConfirm = onAction)
        } else {
            MainButtons(
                state = state,
                legal = legal,
                onFold = {
                    if (legal.canCheck && state.settings.confirmFoldWhenCheck) confirmFold = true
                    else onAction(PlayerAction.Fold)
                },
                onCheckCall = { onAction(if (legal.canCheck) PlayerAction.Check else PlayerAction.Call) },
                onRaise = { sizing = true },
            )
        }
    }

    if (confirmFold) {
        AlertDialog(
            onDismissRequest = { confirmFold = false },
            title = { Text("Checking is free") },
            text = { Text("You can see the next card at no cost. Folding now gives up the pot for nothing.") },
            confirmButton = {
                TextButton(onClick = { confirmFold = false; onAction(PlayerAction.Check) }) { Text("Check instead") }
            },
            dismissButton = {
                TextButton(onClick = { confirmFold = false; onAction(PlayerAction.Fold) }) { Text("Fold anyway") }
            },
        )
    }
}

@Composable
private fun MainButtons(
    state: TableUiState,
    legal: LegalActions,
    onFold: () -> Unit,
    onCheckCall: () -> Unit,
    onRaise: () -> Unit,
) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        val big = Modifier
            .weight(1f)
            .height(64.dp)
        Button(
            onClick = onFold,
            modifier = big,
            colors = ButtonDefaults.buttonColors(
                containerColor = MaterialTheme.colorScheme.errorContainer,
                contentColor = MaterialTheme.colorScheme.onErrorContainer,
            ),
        ) { Text("Fold", fontWeight = FontWeight.Bold, fontSize = 17.sp) }

        Button(
            onClick = onCheckCall,
            modifier = big,
            colors = ButtonDefaults.buttonColors(
                containerColor = MaterialTheme.colorScheme.secondaryContainer,
                contentColor = MaterialTheme.colorScheme.onSecondaryContainer,
            ),
            contentPadding = PaddingValues(horizontal = 4.dp),
        ) {
            TwoLine(
                title = when {
                    legal.canCheck -> "Check"
                    legal.callIsAllIn -> "Call all-in"
                    else -> "Call"
                },
                subtitle = if (legal.canCheck) null else state.amount(legal.toCall),
            )
        }

        if (legal.canRaise) {
            Button(onClick = onRaise, modifier = big, contentPadding = PaddingValues(horizontal = 4.dp)) {
                TwoLine(
                    title = if (legal.isBet) "Bet…" else "Raise…",
                    subtitle = if (legal.minRaiseTo >= legal.maxRaiseTo) "all-in" else "from ${state.amount(legal.minRaiseTo)}",
                )
            }
        }
    }
}

@Composable
private fun TwoLine(title: String, subtitle: String?) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(title, fontWeight = FontWeight.Bold, fontSize = 16.sp, lineHeight = 18.sp, maxLines = 1)
        if (subtitle != null) Text(subtitle, fontSize = 13.sp, lineHeight = 15.sp, maxLines = 1)
    }
}

private data class Preset(val label: String, val value: Long)

/** Presets from the user's settings for this exact situation, clamped to legal sizes. */
private fun sizePresets(state: TableUiState, legal: LegalActions): List<Preset> {
    val bb = state.bigBlind
    val s = state.settings
    fun trim(x: Double) = if (x == Math.floor(x)) x.toLong().toString() else x.toString()
    val raw: List<Pair<String, Long>> = when {
        state.street == Street.PREFLOP && state.currentBet <= bb ->
            s.openSizes.map { "${trim(it)} BB" to (it * bb).roundToLong() }
        state.street == Street.PREFLOP ->
            s.reraiseSizes.map { "${trim(it)}x" to (it * state.currentBet).roundToLong() }
        legal.isBet ->
            s.postflopSizes.map { "$it%" to (state.pot * it / 100.0).roundToLong() }
        else -> {
            // Pot-fraction raise: call first, then raise by that share of the pot after calling.
            val owed = state.currentBet - state.heroStreetCommit
            val potAfterCall = state.pot + owed
            s.postflopSizes.map { "$it%" to state.currentBet + (potAfterCall * it / 100.0).roundToLong() }
        }
    }
    return (raw.map { (label, v) -> Preset(label, v.coerceIn(legal.minRaiseTo, legal.maxRaiseTo)) } +
        Preset("All-in", legal.maxRaiseTo)).distinctBy { it.value }
}

@Composable
private fun SizingPanel(
    state: TableUiState,
    legal: LegalActions,
    onBack: () -> Unit,
    onConfirm: (PlayerAction) -> Unit,
) {
    val haptics = LocalHapticFeedback.current
    val presets = remember(legal, state.settings) { sizePresets(state, legal) }
    var amount by remember(legal) { mutableLongStateOf(presets.first().value) }
    var armed by remember(legal) { mutableStateOf(false) }
    var editing by remember { mutableStateOf(false) }
    var lastTick by remember(legal) { mutableLongStateOf(-1L) }
    val step = maxOf(1L, state.bigBlind)
    val min = legal.minRaiseTo
    val max = legal.maxRaiseTo
    val isAllIn = amount >= max

    LaunchedEffect(armed) {
        if (armed) {
            delay(3_000)
            armed = false
        }
    }

    fun tick() {
        if (state.settings.haptics) haptics.performHapticFeedback(HapticFeedbackType.TextHandleMove)
    }

    fun set(value: Long, withTick: Boolean = false) {
        amount = value.coerceIn(min, max)
        armed = false
        if (withTick) tick()
    }

    // Header: back, and the amount you're about to bet, big.
    Row(verticalAlignment = Alignment.CenterVertically) {
        TextButton(onClick = onBack) { Text("‹ Back") }
        Spacer(Modifier.weight(1f))
        Column(horizontalAlignment = Alignment.End) {
            Text(
                when {
                    isAllIn -> "All-in ${state.amount(max)}"
                    legal.isBet -> "Bet ${state.amount(amount)}"
                    else -> "Raise to ${state.amount(amount)}"
                },
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold,
            )
            Text(sizeContext(state, legal, amount), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }

    // Presets.
    FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        presets.forEach { p ->
            FilterChip(
                selected = amount == p.value,
                onClick = { set(p.value, withTick = true) },
                label = { Text(p.label, fontSize = 14.sp) },
            )
        }
    }

    // Stepper + slider (snaps to presets).
    if (max > min) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            OutlinedButton(
                onClick = { set(amount - step, withTick = true) },
                enabled = amount > min,
                contentPadding = PaddingValues(0.dp),
                modifier = Modifier.size(48.dp),
            ) { Text("−", fontSize = 22.sp) }
            Slider(
                value = amount.toFloat(),
                onValueChange = { v ->
                    val raw = v.roundToLong()
                    val snapRange = (max - min) * 0.03
                    val snapped = presets.firstOrNull { abs(it.value - raw) <= snapRange }?.value
                    val value = snapped ?: ((raw.toDouble() / step).roundToLong() * step)
                    set(value)
                    if (snapped != null && snapped != lastTick) {
                        lastTick = snapped
                        tick()
                    }
                },
                valueRange = min.toFloat()..max.toFloat(),
                modifier = Modifier
                    .weight(1f)
                    .padding(horizontal = 8.dp),
            )
            OutlinedButton(
                onClick = { set(amount + step, withTick = true) },
                enabled = amount < max,
                contentPadding = PaddingValues(0.dp),
                modifier = Modifier.size(48.dp),
            ) { Text("+", fontSize = 22.sp) }
        }
        TextButton(onClick = { editing = true }) { Text("Type an amount") }
    }

    // Confirm.
    Button(
        onClick = {
            if (isAllIn && state.settings.confirmAllIn && !armed) {
                armed = true
                tick()
            } else {
                onConfirm(if (isAllIn) PlayerAction.AllIn else PlayerAction.BetOrRaise(amount))
            }
        },
        modifier = Modifier
            .fillMaxWidth()
            .height(60.dp),
        colors = if (isAllIn) ButtonDefaults.buttonColors(
            containerColor = MaterialTheme.colorScheme.error,
            contentColor = MaterialTheme.colorScheme.onError,
        ) else ButtonDefaults.buttonColors(),
    ) {
        Text(
            when {
                isAllIn && armed -> "Tap again to go all-in"
                isAllIn -> "All-in ${state.amount(max)}"
                legal.isBet -> "Bet ${state.amount(amount)}"
                else -> "Raise to ${state.amount(amount)}"
            },
            fontWeight = FontWeight.Bold,
            fontSize = 17.sp,
        )
    }

    if (editing) {
        AmountDialog(
            initial = amount,
            min = min,
            max = max,
            bigBlind = state.bigBlind,
            inBb = state.settings.amountsInBb,
            onConfirm = { set(it); editing = false },
            onDismiss = { editing = false },
        )
    }
}

/** "≈ 66% pot · 12% of your stack (6 BB)" */
private fun sizeContext(state: TableUiState, legal: LegalActions, amount: Long): String {
    val owed = (state.currentBet - state.heroStreetCommit).coerceAtLeast(0)
    val potPct = if (legal.isBet) {
        amount * 100.0 / state.pot.coerceAtLeast(1)
    } else {
        (amount - state.currentBet) * 100.0 / (state.pot + owed).coerceAtLeast(1)
    }
    val stackPct = amount * 100.0 / state.heroStack.coerceAtLeast(1)
    val inBb = if (!state.settings.amountsInBb) " · ${formatAmount(amount, state.bigBlind, true)}" else ""
    return "≈ ${potPct.roundToInt()}% pot · ${stackPct.roundToInt()}% of your stack$inBb"
}

@Composable
private fun AmountDialog(
    initial: Long,
    min: Long,
    max: Long,
    bigBlind: Long,
    inBb: Boolean,
    onConfirm: (Long) -> Unit,
    onDismiss: () -> Unit,
) {
    val initialText = if (inBb) formatAmount(initial, bigBlind, true).removeSuffix(" BB") else initial.toString()
    var text by remember { mutableStateOf(initialText) }
    val parsed: Long? = text.replace(',', '.').toDoubleOrNull()?.let { if (inBb) (it * bigBlind).roundToLong() else it.roundToLong() }
    val valid = parsed != null && parsed in min..max
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (inBb) "Amount in big blinds" else "Amount in chips") },
        text = {
            OutlinedTextField(
                value = text,
                onValueChange = { new -> text = new.filter { it.isDigit() || it == '.' || it == ',' }.take(10) },
                singleLine = true,
                isError = !valid,
                label = { Text("Total for this street") },
                supportingText = {
                    Text("Between ${formatAmount(min, bigBlind, inBb)} and ${formatAmount(max, bigBlind, inBb)}")
                },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
            )
        },
        confirmButton = {
            TextButton(onClick = { parsed?.let { onConfirm(it.coerceIn(min, max)) } }, enabled = parsed != null) { Text("OK") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } },
    )
}

@Composable
private fun CoachHintRow(hint: CoachHintUi) {
    val text = buildString {
        append("Coach · ")
        append(hint.equity?.let { "equity ≈ ${(it * 100).roundToInt()}% vs their likely hands" } ?: "estimating equity…")
        hint.needed?.let { append(" · need ${(it * 100).roundToInt()}% to call") }
    }
    Text(
        text,
        style = MaterialTheme.typography.bodySmall,
        fontWeight = FontWeight.Medium,
        color = MaterialTheme.colorScheme.onTertiaryContainer,
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(10.dp))
            .background(MaterialTheme.colorScheme.tertiaryContainer)
            .padding(horizontal = 12.dp, vertical = 6.dp),
    )
}

/** While bots act: queue Check/Fold, Check or Call any, like the big apps' pre-action boxes. */
@Composable
fun PreActionPanel(state: TableUiState, onPreAction: (PreAction) -> Unit, modifier: Modifier = Modifier) {
    Column(
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 12.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        Text(
            state.actingName?.let { "$it is thinking…" } ?: "Waiting…",
            style = MaterialTheme.typography.bodyLarge,
        )
        LinearProgressIndicator(Modifier.fillMaxWidth())
        Text("Pre-select your next action", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
            PreAction.entries.forEach { p ->
                FilterChip(
                    selected = state.preAction == p,
                    onClick = { onPreAction(p) },
                    label = { Text(p.label, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth()) },
                    modifier = Modifier
                        .weight(1f)
                        .height(48.dp),
                )
            }
        }
        Spacer(Modifier.width(1.dp))
    }
}
