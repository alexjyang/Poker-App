package com.pokercoach.app.ui.table

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.key
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.layout
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.pokercoach.app.ui.theme.TableColors
import kotlin.math.cos
import kotlin.math.sin

/** Places this element so that its center sits at ([x], [y]) inside the parent Box. */
private fun Modifier.centerAt(x: Dp, y: Dp): Modifier = layout { measurable, constraints ->
    val placeable = measurable.measure(constraints.copy(minWidth = 0, minHeight = 0))
    layout(placeable.width, placeable.height) {
        placeable.place(x.roundToPx() - placeable.width / 2, y.roundToPx() - placeable.height / 2)
    }
}

/** Like coerceIn, but never throws when the range is empty (very small layouts). */
private fun Dp.clampTo(lo: Dp, hi: Dp): Dp = if (hi < lo) (lo + hi) / 2 else coerceIn(lo, hi)

/**
 * The oval table with seats around it. The hero is always at the bottom center and seat order
 * runs clockwise (the direction of play), like PokerStars / GGPoker mobile tables.
 * Works in portrait and landscape: all positions are derived from the available size.
 */
@Composable
fun TableArea(state: TableUiState, modifier: Modifier = Modifier) {
    BoxWithConstraints(modifier) {
        val w = maxWidth
        val h = maxHeight
        val landscape = w > h
        val cardW: Dp = minOf(w / 8.5f, h / 7.5f, 54.dp)
        val cx = w / 2
        val cy = h / 2
        val rx = w * (if (landscape) 0.42f else 0.40f)
        val ry = h * (if (landscape) 0.36f else 0.40f)
        val n = state.tableSize.coerceAtLeast(2)

        // Felt + rail.
        Canvas(Modifier.fillMaxSize()) {
            val feltW = rx.toPx() * 2f
            val feltH = ry.toPx() * 2f
            val rail = 12.dp.toPx()
            val topLeft = Offset(center.x - feltW / 2f, center.y - feltH / 2f)
            drawOval(
                brush = Brush.verticalGradient(listOf(TableColors.RailHighlight, TableColors.Rail)),
                topLeft = Offset(topLeft.x - rail, topLeft.y - rail),
                size = Size(feltW + 2 * rail, feltH + 2 * rail),
            )
            drawOval(
                brush = Brush.radialGradient(
                    colors = listOf(TableColors.FeltCenter, TableColors.FeltEdge),
                    center = center,
                    radius = maxOf(feltW, feltH) * 0.6f,
                ),
                topLeft = topLeft,
                size = Size(feltW, feltH),
            )
            val inset = 14.dp.toPx()
            drawOval(
                color = Color.White.copy(alpha = 0.08f),
                topLeft = Offset(topLeft.x + inset, topLeft.y + inset),
                size = Size(feltW - 2 * inset, feltH - 2 * inset),
                style = Stroke(width = 1.5.dp.toPx()),
            )
        }

        // Board and pot.
        Column(
            modifier = Modifier.centerAt(cx, cy),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Box(Modifier.height(24.dp), contentAlignment = Alignment.Center) {
                if (state.pot > 0) {
                    Text(
                        text = "Pot ${state.amount(state.pot)}",
                        color = Color.White,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.SemiBold,
                        modifier = Modifier
                            .clip(RoundedCornerShape(50))
                            .background(TableColors.PotPill)
                            .padding(horizontal = 10.dp, vertical = 2.dp),
                    )
                }
            }
            Spacer(Modifier.height(6.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                for (i in 0 until 5) {
                    val card = state.board.getOrNull(i)
                    if (card != null) key(card) { PlayingCard(card, cardW) } else CardSlot(cardW)
                }
            }
        }

        // Seats, bets, dealer button.
        state.seats.forEach { seat ->
            val d = (seat.seat - state.heroSeat + n) % n
            val angle = Math.toRadians(90.0 + d * 360.0 / n)
            val ux = cos(angle).toFloat()
            val uy = sin(angle).toFloat()
            val sx = cx + rx * ux
            val sy = cy + ry * uy

            val seatW = if (seat.isHero) 124.dp else 86.dp
            val seatCardW = if (seat.isHero) cardW * 1.1f else cardW * 0.72f
            val seatH = seatCardW * 1.4f + 64.dp
            val clampedX = sx.clampTo(seatW / 2, w - seatW / 2)
            val clampedY = sy.clampTo(seatH / 2, h - seatH / 2)

            key(seat.seat) {
                SeatBadge(
                    seat = seat,
                    cardW = seatCardW,
                    width = seatW,
                    stackText = state.amount(seat.stack),
                    wonText = state.amount(seat.wonAmount),
                    modifier = Modifier.centerAt(clampedX, clampedY),
                )
                if (seat.bet > 0) {
                    val f = if (seat.isHero) 0.50f else 0.58f
                    BetChip(state.amount(seat.bet), Modifier.centerAt(cx + rx * ux * f, cy + ry * uy * f))
                }
                if (seat.isButton) {
                    val f = 0.74f
                    DealerButton(Modifier.centerAt(cx + rx * ux * f + 34.dp, cy + ry * uy * f))
                }
            }
        }
    }
}

@Composable
private fun SeatBadge(seat: SeatUi, cardW: Dp, width: Dp, stackText: String, wonText: String, modifier: Modifier = Modifier) {
    val borderColor = when {
        seat.wonAmount > 0 -> TableColors.Winner
        seat.isActing -> TableColors.Acting
        else -> Color.Transparent
    }
    val faded = seat.folded || seat.busted
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = modifier
            .width(width)
            .graphicsLayer { alpha = if (faded && !seat.isHero) 0.55f else 1f },
    ) {
        // Hole cards (folded opponents muck theirs).
        Box(Modifier.height(cardW * 1.4f), contentAlignment = Alignment.Center) {
            val showCards = seat.dealtIn && (!seat.folded || seat.isHero)
            if (showCards) {
                val spread = if (seat.isHero) cardW * 0.53f else cardW * 0.28f
                val tilt = if (seat.isHero) 0f else 5f
                PlayingCard(
                    card = seat.cards?.getOrNull(0),
                    width = cardW,
                    dimmed = seat.folded,
                    modifier = Modifier.offset(x = -spread).rotate(-tilt),
                )
                PlayingCard(
                    card = seat.cards?.getOrNull(1),
                    width = cardW,
                    dimmed = seat.folded,
                    modifier = Modifier.offset(x = spread).rotate(tilt),
                )
            }
        }
        Spacer(Modifier.height(2.dp))
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(12.dp))
                .background(TableColors.SeatPanel)
                .border(2.dp, borderColor, RoundedCornerShape(12.dp))
                .padding(horizontal = 6.dp, vertical = 4.dp),
        ) {
            Box(
                modifier = Modifier
                    .size(26.dp)
                    .clip(CircleShape)
                    .background(Color(seat.avatarColor)),
                contentAlignment = Alignment.Center,
            ) {
                Text(seat.name.take(1), color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold)
            }
            Spacer(Modifier.width(5.dp))
            Column {
                Text(
                    text = seat.name,
                    color = TableColors.SeatText,
                    fontSize = 12.sp,
                    lineHeight = 14.sp,
                    fontWeight = FontWeight.SemiBold,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
                Text(
                    text = when {
                        seat.busted -> "Out"
                        seat.allIn -> "All-in"
                        else -> stackText
                    },
                    color = if (seat.allIn) TableColors.Acting else TableColors.SeatSubtext,
                    fontSize = 12.sp,
                    lineHeight = 14.sp,
                    maxLines = 1,
                )
            }
        }
        val label = when {
            seat.wonAmount > 0 -> "+$wonText"
            seat.isActing && !seat.isHero -> "thinking…"
            seat.lastAction != null -> seat.lastAction
            else -> seat.style.takeUnless { seat.isHero }
        }
        Text(
            text = label ?: "",
            color = when {
                seat.wonAmount > 0 -> TableColors.Winner
                seat.lastAction != null || seat.isActing -> TableColors.Acting
                else -> TableColors.SeatSubtext
            },
            fontSize = 11.sp,
            lineHeight = 13.sp,
            fontWeight = FontWeight.Medium,
            maxLines = 1,
            modifier = Modifier.height(16.dp),
        )
    }
}

@Composable
private fun BetChip(text: String, modifier: Modifier = Modifier) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = modifier
            .clip(RoundedCornerShape(50))
            .background(TableColors.PotPill)
            .padding(horizontal = 6.dp, vertical = 2.dp),
    ) {
        Box(
            Modifier
                .size(11.dp)
                .clip(CircleShape)
                .background(TableColors.ChipGold)
                .border(1.5.dp, Color.White, CircleShape),
        )
        Spacer(Modifier.width(4.dp))
        Text(text, color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
    }
}

@Composable
private fun DealerButton(modifier: Modifier = Modifier) {
    Box(
        modifier = modifier
            .size(22.dp)
            .clip(CircleShape)
            .background(Color.White)
            .border(1.dp, Color(0xFF888888), CircleShape),
        contentAlignment = Alignment.Center,
    ) {
        Text("D", color = Color.Black, fontSize = 11.sp, fontWeight = FontWeight.Bold)
    }
}
