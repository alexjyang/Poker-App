package com.pokercoach.app.data

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

/** User preferences for the table and betting controls. */
data class Settings(
    val amountsInBb: Boolean = false,
    val confirmFoldWhenCheck: Boolean = true,
    val confirmAllIn: Boolean = true,
    val coachHints: Boolean = false,
    val haptics: Boolean = true,
    /** Opening raise sizes in big blinds. */
    val openSizes: List<Double> = listOf(2.5, 3.0, 4.0),
    /** Re-raise sizes as multiples of the bet faced. */
    val reraiseSizes: List<Double> = listOf(3.0, 4.0),
    /** Postflop sizes in % of the pot. */
    val postflopSizes: List<Int> = listOf(33, 50, 75, 100),
) {
    companion object {
        val OPEN_CHOICES = listOf(2.0, 2.2, 2.5, 3.0, 3.5, 4.0, 5.0)
        val RERAISE_CHOICES = listOf(2.5, 3.0, 3.5, 4.0, 5.0)
        val POSTFLOP_CHOICES = listOf(25, 33, 50, 66, 75, 100, 125, 150)
    }
}

private val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "settings")

/** Settings stored with Jetpack DataStore (Preferences). */
class SettingsRepository(private val context: Context) {
    private object Keys {
        val inBb = booleanPreferencesKey("amounts_in_bb")
        val confirmFold = booleanPreferencesKey("confirm_fold_when_check")
        val confirmAllIn = booleanPreferencesKey("confirm_all_in")
        val coach = booleanPreferencesKey("coach_hints")
        val haptics = booleanPreferencesKey("haptics")
        val open = stringPreferencesKey("open_sizes")
        val reraise = stringPreferencesKey("reraise_sizes")
        val postflop = stringPreferencesKey("postflop_sizes")
    }

    val settings: Flow<Settings> = context.dataStore.data.map { p ->
        val d = Settings()
        Settings(
            amountsInBb = p[Keys.inBb] ?: d.amountsInBb,
            confirmFoldWhenCheck = p[Keys.confirmFold] ?: d.confirmFoldWhenCheck,
            confirmAllIn = p[Keys.confirmAllIn] ?: d.confirmAllIn,
            coachHints = p[Keys.coach] ?: d.coachHints,
            haptics = p[Keys.haptics] ?: d.haptics,
            openSizes = p[Keys.open]?.split(",")?.mapNotNull { it.toDoubleOrNull() }?.takeIf { it.isNotEmpty() } ?: d.openSizes,
            reraiseSizes = p[Keys.reraise]?.split(",")?.mapNotNull { it.toDoubleOrNull() }?.takeIf { it.isNotEmpty() } ?: d.reraiseSizes,
            postflopSizes = p[Keys.postflop]?.split(",")?.mapNotNull { it.toIntOrNull() }?.takeIf { it.isNotEmpty() } ?: d.postflopSizes,
        )
    }

    suspend fun update(transform: (Settings) -> Settings) {
        context.dataStore.edit { p ->
            val d = Settings()
            val current = Settings(
                amountsInBb = p[Keys.inBb] ?: d.amountsInBb,
                confirmFoldWhenCheck = p[Keys.confirmFold] ?: d.confirmFoldWhenCheck,
                confirmAllIn = p[Keys.confirmAllIn] ?: d.confirmAllIn,
                coachHints = p[Keys.coach] ?: d.coachHints,
                haptics = p[Keys.haptics] ?: d.haptics,
                openSizes = p[Keys.open]?.split(",")?.mapNotNull { it.toDoubleOrNull() }?.takeIf { it.isNotEmpty() } ?: d.openSizes,
                reraiseSizes = p[Keys.reraise]?.split(",")?.mapNotNull { it.toDoubleOrNull() }?.takeIf { it.isNotEmpty() } ?: d.reraiseSizes,
                postflopSizes = p[Keys.postflop]?.split(",")?.mapNotNull { it.toIntOrNull() }?.takeIf { it.isNotEmpty() } ?: d.postflopSizes,
            )
            val n = transform(current)
            p[Keys.inBb] = n.amountsInBb
            p[Keys.confirmFold] = n.confirmFoldWhenCheck
            p[Keys.confirmAllIn] = n.confirmAllIn
            p[Keys.coach] = n.coachHints
            p[Keys.haptics] = n.haptics
            p[Keys.open] = n.openSizes.sorted().joinToString(",")
            p[Keys.reraise] = n.reraiseSizes.sorted().joinToString(",")
            p[Keys.postflop] = n.postflopSizes.sorted().joinToString(",")
        }
    }
}
