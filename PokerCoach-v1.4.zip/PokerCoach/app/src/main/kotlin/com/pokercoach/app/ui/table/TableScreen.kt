package com.pokercoach.app.ui.table

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawingPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import kotlinx.coroutines.delay

@Composable
fun TableScreen(
    viewModel: TableViewModel,
    onLeave: () -> Unit,
    onReview: (Long) -> Unit,
    onOpenStats: () -> Unit,
    onOpenSettings: () -> Unit,
    onOpenGlossary: () -> Unit = {},
) {
    val state by viewModel.state.collectAsStateWithLifecycle()
    var confirmLeave by remember { mutableStateOf(false) }
    var hudSeat by remember { mutableStateOf<Int?>(null) }
    val haptics = LocalHapticFeedback.current

    // The app was restarted by the system and the game is gone: go back to the lobby.
    LaunchedEffect(state.active) { if (!state.active) onLeave() }

    // Haptic nudge when it's your turn.
    val heroTurn = state.heroLegal != null
    LaunchedEffect(heroTurn) {
        if (heroTurn && state.settings.haptics) haptics.performHapticFeedback(HapticFeedbackType.LongPress)
    }
    // Haptics on big moments: someone goes all-in, you win a big pot.
    LaunchedEffect(state.allInPulse) {
        if (state.allInPulse > 0 && state.settings.haptics) haptics.performHapticFeedback(HapticFeedbackType.LongPress)
    }
    LaunchedEffect(state.bigWinPulse) {
        if (state.bigWinPulse > 0 && state.settings.haptics) {
            haptics.performHapticFeedback(HapticFeedbackType.LongPress)
            delay(140)
            haptics.performHapticFeedback(HapticFeedbackType.LongPress)
        }
    }

    val requestLeave: () -> Unit = {
        if (state.handInProgress) {
            confirmLeave = true
        } else {
            onLeave()
        }
    }
    BackHandler(onBack = requestLeave)

    BoxWithConstraints(
        Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .safeDrawingPadding(),
    ) {
        if (maxWidth > maxHeight) {
            // Landscape: table on the left, controls on the right.
            Row(Modifier.fillMaxSize()) {
                Column(
                    Modifier
                        .weight(1f)
                        .fillMaxHeight(),
                ) {
                    TopBar(
                        state,
                        onBack = requestLeave,
                        onToggleStyles = viewModel::toggleStyleLabels,
                        onToggleBb = { viewModel.setAmountsInBb(!state.settings.amountsInBb) },
                        onToggleHud = viewModel::toggleHud,
                        onOpenStats = onOpenStats,
                        onOpenSettings = onOpenSettings,
                        onOpenGlossary = onOpenGlossary,
                    )
                    TableArea(state, Modifier.weight(1f).fillMaxWidth(), onSeatClick = { hudSeat = it })
                }
                ControlPanel(
                    state = state,
                    viewModel = viewModel,
                    onReview = onReview,
                    modifier = Modifier
                        .width(320.dp)
                        .fillMaxHeight(),
                )
            }
        } else {
            // Portrait (default): controls at the bottom, within thumb reach.
            Column(Modifier.fillMaxSize()) {
                TopBar(
                        state,
                        onBack = requestLeave,
                        onToggleStyles = viewModel::toggleStyleLabels,
                        onToggleBb = { viewModel.setAmountsInBb(!state.settings.amountsInBb) },
                        onToggleHud = viewModel::toggleHud,
                        onOpenStats = onOpenStats,
                        onOpenSettings = onOpenSettings,
                        onOpenGlossary = onOpenGlossary,
                    )
                TableArea(state, Modifier.weight(1f).fillMaxWidth(), onSeatClick = { hudSeat = it })
                ControlPanel(state = state, viewModel = viewModel, onReview = onReview, modifier = Modifier.fillMaxWidth())
            }
        }
    }

    if (confirmLeave) {
        AlertDialog(
            onDismissRequest = { confirmLeave = false },
            title = { Text("Leave the table?") },
            text = { Text("A hand is in progress. If you leave now, this game ends.") },
            confirmButton = {
                TextButton(onClick = { confirmLeave = false; onLeave() }) { Text("Leave") }
            },
            dismissButton = {
                TextButton(onClick = { confirmLeave = false }) { Text("Keep playing") }
            },
        )
    }

    hudSeat?.let { seatNo ->
        val seat = state.seats.firstOrNull { it.seat == seatNo }
        if (seat != null) PlayerStatsDialog(seat, onDismiss = { hudSeat = null })
    }

    state.sessionOver?.let { over ->
        AlertDialog(
            onDismissRequest = {},
            title = { Text(over.title) },
            text = { if (over.message.isNotEmpty()) Text(over.message) },
            confirmButton = { TextButton(onClick = { viewModel.restart() }) { Text("Play again") } },
            dismissButton = { TextButton(onClick = onLeave) { Text("Lobby") } },
        )
    }
}

@Composable
private fun TopBar(
    state: TableUiState,
    onBack: () -> Unit,
    onToggleStyles: () -> Unit,
    onToggleBb: () -> Unit,
    onToggleHud: () -> Unit,
    onOpenStats: () -> Unit,
    onOpenSettings: () -> Unit,
    onOpenGlossary: () -> Unit,
) {
    var menu by remember { mutableStateOf(false) }
    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 4.dp),
    ) {
        TextButton(onClick = onBack) { Text("‹ Lobby") }
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier.weight(1f),
        ) {
            Text(
                "${state.modeLabel} · ${state.blindsLabel}",
                style = MaterialTheme.typography.labelLarge,
                fontWeight = FontWeight.SemiBold,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
            if (state.handNumber > 0) {
                Text(
                    "Hand #${state.handNumber}" + (state.sessionAccuracy?.let { " · Accuracy $it" } ?: ""),
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
        }
        Box {
            TextButton(onClick = { menu = true }) { Text("Menu") }
            DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                DropdownMenuItem(
                    text = { Text(if (state.settings.amountsInBb) "Show amounts in chips" else "Show amounts in big blinds") },
                    onClick = { menu = false; onToggleBb() },
                )
                DropdownMenuItem(
                    text = { Text(if (state.showStyles) "Hide bot styles" else "Show bot styles") },
                    onClick = { menu = false; onToggleStyles() },
                )
                DropdownMenuItem(
                    text = { Text(if (state.settings.showHud) "Hide player stats (HUD)" else "Show player stats (HUD)") },
                    onClick = { menu = false; onToggleHud() },
                )
                DropdownMenuItem(text = { Text("Stats & hand history") }, onClick = { menu = false; onOpenStats() })
                DropdownMenuItem(text = { Text("Settings") }, onClick = { menu = false; onOpenSettings() })
                DropdownMenuItem(text = { Text("Glossary (poker terms)") }, onClick = { menu = false; onOpenGlossary() })
            }
        }
    }
}

@Composable
private fun ControlPanel(
    state: TableUiState,
    viewModel: TableViewModel,
    onReview: (Long) -> Unit,
    modifier: Modifier = Modifier,
) {
    Surface(
        modifier = modifier,
        tonalElevation = 3.dp,
        shape = RoundedCornerShape(topStart = 20.dp, topEnd = 20.dp),
    ) {
        Box(
            Modifier
                .heightIn(min = 150.dp)
                .verticalScroll(rememberScrollState()),
            contentAlignment = Alignment.BottomCenter,
        ) {
            Column {
                state.error?.let { msg ->
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.padding(start = 16.dp, end = 4.dp, top = 8.dp),
                    ) {
                        Text(
                            msg,
                            color = MaterialTheme.colorScheme.error,
                            style = MaterialTheme.typography.bodySmall,
                            modifier = Modifier.weight(1f),
                        )
                        TextButton(onClick = viewModel::dismissError) { Text("OK") }
                    }
                }
                when {
                    state.heroLegal != null -> ActionBar(state, onAction = viewModel::act)
                    state.result != null -> ResultPanel(
                        result = state.result,
                        review = state.review,
                        onNext = viewModel::nextHand,
                        onReview = onReview,
                        format = { state.amount(it) },
                    )
                    state.canPreAct -> PreActionPanel(state, onPreAction = viewModel::setPreAction)
                    else -> WaitingPanel(state.actingName)
                }
            }
        }
    }
}

/** Everything the hero has observed about one opponent this session, explained. */
@Composable
private fun PlayerStatsDialog(seat: SeatUi, onDismiss: () -> Unit) {
    val hud = seat.hud
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(seat.name + (seat.style?.let { " · $it" } ?: "")) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                if (hud == null) {
                    Text("No hands seen yet (or player stats are hidden in the menu). Stats appear after the first hand with this player.")
                } else {
                    Text(
                        "Over ${hud.hands} hand${if (hud.hands == 1) "" else "s"} this session" + (hud.label?.let { ": $it" } ?: "") + ".",
                        fontWeight = FontWeight.SemiBold,
                    )
                    StatLine("VPIP ${hud.vpip}%", "How often they put money in preflop. Under 18% tight, 18–30% solid, over 40% loose.")
                    StatLine("PFR ${hud.pfr}%", "How often they raise preflop. Close to VPIP = aggressive; far below = they call and limp a lot.")
                    StatLine(
                        "Aggression ${hud.aggression?.let { "%.1f".format(it) } ?: "—"}",
                        "Bets and raises per call after the flop. Under 1 passive, 2–3 aggressive, over 4 very aggressive.",
                    )
                    StatLine(
                        "Fold to bet ${hud.foldToBet?.let { "$it%" } ?: "—"}" + if (hud.betsFaced > 0) " (${hud.betsFaced} bets)" else "",
                        "How often they fold when bet into after the flop. High = bluff them; low = value-bet them.",
                    )
                    if (hud.hands < 15) {
                        Text(
                            "Small sample: treat these as early hints.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                }
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("Close") } },
    )
}

@Composable
private fun StatLine(title: String, explanation: String) {
    Column {
        Text(title, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
        Text(explanation, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}
