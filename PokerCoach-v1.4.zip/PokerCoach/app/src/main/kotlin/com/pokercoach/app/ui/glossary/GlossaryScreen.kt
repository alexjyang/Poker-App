@file:OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)

package com.pokercoach.app.ui.glossary

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.AssistChip
import androidx.compose.material3.Card
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.pokercoach.engine.learn.Glossary
import com.pokercoach.engine.learn.GlossaryCategory
import com.pokercoach.engine.learn.GlossaryEntry

/**
 * Every poker term and abbreviation used in the app, explained for beginners. Search by name,
 * abbreviation (VPIP, OESD…) or any word; filter by category; tap a related term to jump to it.
 */
@Composable
fun GlossaryScreen(initialQuery: String = "", onBack: () -> Unit) {
    BackHandler(onBack = onBack)
    var query by rememberSaveable { mutableStateOf(initialQuery) }
    var categoryName by rememberSaveable { mutableStateOf<String?>(null) }
    val category = GlossaryCategory.entries.firstOrNull { it.name == categoryName }
    val results = Glossary.search(query, category)

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Glossary", fontWeight = FontWeight.Bold) },
                navigationIcon = { TextButton(onClick = onBack) { Text("‹ Back") } },
            )
        },
    ) { padding ->
        Column(Modifier.fillMaxSize().padding(padding)) {
            OutlinedTextField(
                value = query,
                onValueChange = { query = it },
                singleLine = true,
                placeholder = { Text("Search, e.g. VPIP, gutshot, pot odds") },
                trailingIcon = if (query.isNotEmpty()) ({ TextButton(onClick = { query = "" }) { Text("Clear") } }) else null,
                modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp),
            )
            Row(
                Modifier.horizontalScroll(rememberScrollState()).padding(horizontal = 16.dp),
                horizontalArrangement = Arrangement.spacedBy(6.dp),
            ) {
                FilterChip(selected = category == null, onClick = { categoryName = null }, label = { Text("All") })
                GlossaryCategory.entries.forEach { c ->
                    FilterChip(selected = category == c, onClick = { categoryName = if (category == c) null else c.name }, label = { Text(c.label) })
                }
            }
            Text(
                if (results.isEmpty()) "Nothing found. Try a shorter word." else "${results.size} term${if (results.size == 1) "" else "s"}",
                style = MaterialTheme.typography.labelMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.padding(horizontal = 16.dp, vertical = 6.dp),
            )
            LazyColumn(
                contentPadding = PaddingValues(start = 16.dp, end = 16.dp, bottom = 24.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp),
            ) {
                items(results, key = { it.term }) { e ->
                    GlossaryCard(e, onRelated = { name -> query = name; categoryName = null })
                }
            }
        }
    }
}

@Composable
fun GlossaryCard(e: GlossaryEntry, onRelated: ((String) -> Unit)? = null) {
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text(e.title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            Text(e.category.label, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary)
            Text(e.definition, style = MaterialTheme.typography.bodyMedium)
            e.example?.let {
                Text("Example: $it", style = MaterialTheme.typography.bodySmall, fontStyle = FontStyle.Italic,
                    color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            if (onRelated != null && e.related.isNotEmpty()) {
                FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    e.related.forEach { r -> AssistChip(onClick = { onRelated(r) }, label = { Text(r) }) }
                }
            }
        }
    }
}

/**
 * A glossary entry in a dialog (used by the coach's concept chips), with a way to open the full
 * glossary at that term.
 */
@Composable
fun GlossaryDialog(e: GlossaryEntry, onDismiss: () -> Unit, onOpenGlossary: ((String) -> Unit)?) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(e.title) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(e.definition)
                e.example?.let { Text("Example: $it", fontStyle = FontStyle.Italic, style = MaterialTheme.typography.bodySmall) }
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("Got it") } },
        dismissButton = if (onOpenGlossary != null) ({ TextButton(onClick = { onOpenGlossary(e.term) }) { Text("Glossary") } }) else null,
    )
}
