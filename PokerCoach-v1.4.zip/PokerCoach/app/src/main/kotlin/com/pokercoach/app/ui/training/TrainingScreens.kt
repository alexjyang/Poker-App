@file:OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)

package com.pokercoach.app.ui.training

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.AssistChip
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SegmentedButton
import androidx.compose.material3.SegmentedButtonDefaults
import androidx.compose.material3.SingleChoiceSegmentedButtonRow
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.pokercoach.app.data.TrainingStats
import com.pokercoach.app.ui.review.DecisionCard
import com.pokercoach.app.ui.table.ActionBar
import com.pokercoach.app.ui.table.PlayingCard
import com.pokercoach.app.ui.table.TableArea
import com.pokercoach.app.ui.table.gradeColor
import com.pokercoach.engine.analysis.Concept
import com.pokercoach.engine.bot.PreflopCharts
import com.pokercoach.engine.bot.PreflopCharts.Pos
import com.pokercoach.engine.range.HandClass
import com.pokercoach.engine.training.DrillType
import com.pokercoach.engine.training.QuizAnswer
import com.pokercoach.engine.training.QuizSpot
import kotlin.math.roundToInt

private val RAISE_COLOR = Color(0xFFD84315)
private val CALL_COLOR = Color(0xFF2E7D32)

// =====================================================================================
// Hub
// =====================================================================================

@Composable
fun TrainingHubScreen(
    stats: TrainingStats,
    rating: Int,
    ratingTitle: String,
    recommended: List<DrillType>,
    onDrill: (DrillType) -> Unit,
    onQuiz: () -> Unit,
    onCharts: () -> Unit,
    onGlossary: () -> Unit,
    onBack: () -> Unit,
) {
    BackHandler(onBack = onBack)
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Train", fontWeight = FontWeight.Bold) },
                navigationIcon = { TextButton(onClick = onBack) { Text("‹ Back") } },
            )
        },
    ) { padding ->
        LazyColumn(
            modifier = Modifier.fillMaxSize().padding(padding),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            item {
                Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer), modifier = Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(16.dp)) {
                        Text("Skill rating", style = MaterialTheme.typography.labelLarge)
                        Row(verticalAlignment = Alignment.Bottom) {
                            Text("$rating", style = MaterialTheme.typography.displaySmall, fontWeight = FontWeight.Bold)
                            Spacer(Modifier.width(10.dp))
                            Text(ratingTitle, style = MaterialTheme.typography.titleMedium, modifier = Modifier.padding(bottom = 6.dp))
                        }
                        Text(
                            "Your rating comes from the coach's grades at the table. Drills and the quiz are practice: they don't change it.",
                            style = MaterialTheme.typography.bodySmall,
                        )
                    }
                }
            }
            if (recommended.isNotEmpty()) {
                item { Text("Recommended for your leaks", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold) }
                item {
                    FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        recommended.forEach { t -> AssistChip(onClick = { onDrill(t) }, label = { Text(t.label) }) }
                    }
                }
            }
            item { Text("Preflop", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold) }
            item {
                HubRow(
                    "Preflop trainer",
                    "Raise, call or fold? Quiz on the solver charts, focused on close hands." +
                        if (stats.quizAnswered > 0) "  ·  ${100 * stats.quizCorrect / stats.quizAnswered}% correct, best streak ${stats.quizBestStreak}" else "",
                    onQuiz,
                )
            }
            item { HubRow("Chart browser", "Every opening and defending range as a 13×13 grid.", onCharts) }
            item { HubRow("Glossary", "Every poker term and abbreviation explained: VPIP, c-bet, gutshot, SPR…", onGlossary) }
            item { Text("Spot drills", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold) }
            DrillType.entries.forEach { t ->
                item {
                    val acc = stats.accuracy(t.name)
                    HubRow(t.label, t.description + (acc?.let { "  ·  ${stats.attempts(t.name)} played, accuracy $it" } ?: ""), { onDrill(t) })
                }
            }
        }
    }
}

@Composable
private fun HubRow(title: String, subtitle: String, onClick: () -> Unit) {
    Card(modifier = Modifier.fillMaxWidth().clickable(onClick = onClick)) {
        Column(Modifier.padding(14.dp)) {
            Text(title, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
            Text(subtitle, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

// =====================================================================================
// Drill
// =====================================================================================

@Composable
fun DrillScreen(viewModel: TrainingViewModel, onBack: () -> Unit, onOpenGlossary: ((String) -> Unit)? = null) {
    val state by viewModel.drill.collectAsStateWithLifecycle()
    var concept by remember { mutableStateOf<Concept?>(null) }
    BackHandler(onBack = onBack)
    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(state.type?.label ?: "Drill", fontWeight = FontWeight.Bold)
                        if (state.grades.isNotEmpty()) {
                            Text(
                                "${state.grades.size} played · accuracy ${state.accuracy}",
                                style = MaterialTheme.typography.labelMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                            )
                        }
                    }
                },
                navigationIcon = { TextButton(onClick = onBack) { Text("‹ Train") } },
            )
        },
    ) { padding ->
        Column(Modifier.fillMaxSize().padding(padding)) {
            val table = state.table
            when {
                state.loading -> Column(Modifier.fillMaxWidth().padding(24.dp)) {
                    Text("Dealing a spot…")
                    LinearProgressIndicator(Modifier.fillMaxWidth().padding(top = 8.dp))
                }
                state.failed || table == null -> Column(Modifier.padding(24.dp)) {
                    Text("Couldn't find this spot right now.")
                    Button(onClick = viewModel::nextDrill) { Text("Try again") }
                }
                state.result != null -> LazyColumn(
                    contentPadding = PaddingValues(12.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp),
                ) {
                    item { TableArea(table, Modifier.fillMaxWidth().height(300.dp)) }
                    item {
                        DecisionCard(state.result!!, null, state.names, advanced = false, onConcept = { concept = it })
                    }
                    item {
                        Button(onClick = viewModel::nextDrill, modifier = Modifier.fillMaxWidth().height(52.dp)) {
                            Text("Next spot", fontWeight = FontWeight.Bold)
                        }
                    }
                }
                else -> {
                    Text(
                        state.type?.description ?: "",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(horizontal = 16.dp),
                    )
                    TableArea(table, Modifier.weight(1f).fillMaxWidth())
                    if (state.analyzing) {
                        Column(Modifier.fillMaxWidth().padding(16.dp)) {
                            Text("The coach is checking your decision…")
                            LinearProgressIndicator(Modifier.fillMaxWidth().padding(top = 8.dp))
                        }
                    } else {
                        ActionBar(table, onAction = viewModel::answer)
                    }
                }
            }
        }
    }
    concept?.let { c ->
        com.pokercoach.app.ui.glossary.GlossaryDialog(
            e = com.pokercoach.engine.learn.Glossary.forConcept(c),
            onDismiss = { concept = null },
            onOpenGlossary = onOpenGlossary?.let { open -> { term: String -> concept = null; open(term) } },
        )
    }
}

// =====================================================================================
// Preflop quiz
// =====================================================================================

@Composable
fun QuizScreen(viewModel: TrainingViewModel, onBack: () -> Unit) {
    val state by viewModel.quiz.collectAsStateWithLifecycle()
    BackHandler(onBack = onBack)
    LaunchedEffect(Unit) { if (state.question == null) viewModel.nextQuestion() }
    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text("Preflop trainer", fontWeight = FontWeight.Bold)
                        if (state.answered > 0) {
                            Text(
                                "${state.correct}/${state.answered} correct · streak ${state.streak}",
                                style = MaterialTheme.typography.labelMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                            )
                        }
                    }
                },
                navigationIcon = { TextButton(onClick = onBack) { Text("‹ Train") } },
            )
        },
    ) { padding ->
        Column(
            Modifier.fillMaxSize().padding(padding).verticalScroll(rememberScrollState()).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                QuizSpot.entries.forEach { s ->
                    FilterChip(selected = s in state.spots, onClick = { viewModel.toggleQuizSpot(s) }, label = { Text(s.label) })
                }
            }
            val q = state.question ?: return@Column
            Text(q.situation, style = MaterialTheme.typography.titleMedium)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                q.cards.forEach { PlayingCard(it, 64.dp) }
            }
            Text("6-max, 100 big blinds.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)

            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                q.answers.forEach { a ->
                    val label = when (a) { QuizAnswer.FOLD -> "Fold"; QuizAnswer.CALL -> "Call"; QuizAnswer.RAISE -> q.raiseLabel() }
                    val picked = state.chosen == a
                    if (picked) {
                        Button(onClick = {}, modifier = Modifier.weight(1f).height(56.dp)) { Text(label, fontWeight = FontWeight.Bold) }
                    } else {
                        OutlinedButton(
                            onClick = { viewModel.answerQuiz(a) },
                            enabled = state.result == null,
                            modifier = Modifier.weight(1f).height(56.dp),
                        ) { Text(label, fontWeight = FontWeight.Bold) }
                    }
                }
            }

            val r = state.result
            if (r != null) {
                val (headline, color) = when {
                    r.correct -> "Correct!" to CALL_COLOR
                    r.acceptable -> "Fine — part of a mixed strategy" to Color(0xFFF9A825)
                    else -> "Not this time" to MaterialTheme.colorScheme.error
                }
                Text(headline, color = color, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                Text("With ${q.handLabel} the solver chart plays:", style = MaterialTheme.typography.bodyMedium)
                q.answers.forEach { a ->
                    val f = q.frequencies[a] ?: 0.0
                    val label = when (a) { QuizAnswer.FOLD -> "Fold"; QuizAnswer.CALL -> "Call"; QuizAnswer.RAISE -> q.raiseLabel() }
                    FreqBar(label, f, when (a) { QuizAnswer.RAISE -> RAISE_COLOR; QuizAnswer.CALL -> CALL_COLOR; else -> Color.Gray })
                }
                ChartGrid(q.spot, q.hero, q.villain, highlight = q.handClass)
                Button(onClick = viewModel::nextQuestion, modifier = Modifier.fillMaxWidth().height(52.dp)) {
                    Text("Next hand", fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

@Composable
private fun FreqBar(label: String, f: Double, color: Color) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Text(label, modifier = Modifier.width(64.dp), style = MaterialTheme.typography.bodySmall)
        Box(Modifier.weight(1f).height(12.dp).clip(RoundedCornerShape(6.dp)).background(MaterialTheme.colorScheme.surfaceVariant)) {
            if (f > 0.0) Box(Modifier.fillMaxWidth(f.toFloat().coerceIn(0.02f, 1f)).height(12.dp).background(color))
        }
        Text("${(f * 100).roundToInt()}%", modifier = Modifier.width(48.dp).padding(start = 6.dp), style = MaterialTheme.typography.bodySmall)
    }
}

// =====================================================================================
// Chart browser
// =====================================================================================

@Composable
fun ChartsScreen(onBack: () -> Unit) {
    BackHandler(onBack = onBack)
    var spot by rememberSaveable { mutableStateOf(QuizSpot.OPEN) }
    var hero by rememberSaveable { mutableStateOf(Pos.BTN) }
    var villain by rememberSaveable { mutableStateOf(Pos.UTG) }
    val order = Pos.entries
    // Keep the choices valid for the spot.
    val heroChoices = when (spot) {
        QuizSpot.OPEN, QuizSpot.VS_3BET -> listOf(Pos.UTG, Pos.HJ, Pos.CO, Pos.BTN, Pos.SB)
        QuizSpot.DEFEND -> listOf(Pos.HJ, Pos.CO, Pos.BTN, Pos.SB, Pos.BB)
    }
    if (hero !in heroChoices) hero = heroChoices.last()
    val villainChoices = when (spot) {
        QuizSpot.OPEN -> emptyList()
        QuizSpot.DEFEND -> order.filter { it.ordinal < hero.ordinal }
        QuizSpot.VS_3BET -> order.filter { it.ordinal > hero.ordinal }
    }
    if (villainChoices.isNotEmpty() && villain !in villainChoices) villain = villainChoices.first()

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Chart browser", fontWeight = FontWeight.Bold) },
                navigationIcon = { TextButton(onClick = onBack) { Text("‹ Train") } },
            )
        },
    ) { padding ->
        Column(
            Modifier.fillMaxSize().padding(padding).verticalScroll(rememberScrollState()).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            SingleChoiceSegmentedButtonRow(Modifier.fillMaxWidth()) {
                QuizSpot.entries.forEachIndexed { i, s ->
                    SegmentedButton(
                        selected = spot == s,
                        onClick = { spot = s },
                        shape = SegmentedButtonDefaults.itemShape(index = i, count = QuizSpot.entries.size),
                    ) { Text(s.label, fontSize = 12.sp, maxLines = 1) }
                }
            }
            Text(if (spot == QuizSpot.VS_3BET) "You opened from" else "You are", style = MaterialTheme.typography.labelLarge)
            FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                heroChoices.forEach { p -> FilterChip(selected = hero == p, onClick = { hero = p }, label = { Text(p.name) }) }
            }
            if (villainChoices.isNotEmpty()) {
                Text(if (spot == QuizSpot.DEFEND) "Raiser" else "3-bettor", style = MaterialTheme.typography.labelLarge)
                FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    villainChoices.forEach { p -> FilterChip(selected = villain == p, onClick = { villain = p }, label = { Text(p.name) }) }
                }
            }
            ChartGrid(spot, hero, if (spot == QuizSpot.OPEN) null else villain, highlight = null)
        }
    }
}

/**
 * 13×13 chart: each cell is split by how often the hand raises (red), calls (green) or folds
 * (grey). Pairs on the diagonal, suited hands above it, offsuit below.
 */
@Composable
fun ChartGrid(spot: QuizSpot, hero: Pos, villain: Pos?, highlight: Int?) {
    val ranks = HandClass.GRID_RANKS
    /** (raise frequency, call frequency) for a hand class. */
    fun freqs(cls: Int): Pair<Double, Double>? {
        return when (spot) {
            QuizSpot.OPEN -> PreflopCharts.open(hero, cls, false)?.let { it to 0.0 }
            QuizSpot.DEFEND -> PreflopCharts.vsOpen(hero, villain ?: return null, cls, false)?.let { (c, r) -> r to c }
            QuizSpot.VS_3BET -> PreflopCharts.vsThreeBet(hero, villain ?: return null, cls, false)?.let { (c, r) -> r to c }
        }
    }
    var raiseShare = 0.0
    var callShare = 0.0
    for (cls in 0 until 169) {
        val (r, c) = freqs(cls) ?: continue
        val n = HandClass.fromIndex(cls).comboCount / 1326.0
        raiseShare += r * n; callShare += c * n
    }
    val raiseWord = when (spot) { QuizSpot.OPEN -> "Raise"; QuizSpot.DEFEND -> "3-bet"; QuizSpot.VS_3BET -> "4-bet" }
    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Text(
            "$raiseWord ${(raiseShare * 100).roundToInt()}%" +
                (if (spot != QuizSpot.OPEN) " · Call ${(callShare * 100).roundToInt()}%" else "") +
                " · Fold ${((1 - raiseShare - callShare) * 100).roundToInt()}% of hands",
            style = MaterialTheme.typography.labelLarge,
            fontWeight = FontWeight.SemiBold,
        )
        Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(6.dp)).background(MaterialTheme.colorScheme.surfaceVariant)) {
            for (row in 0 until 13) {
                Row(Modifier.fillMaxWidth()) {
                    for (col in 0 until 13) {
                        val cls = row * 13 + col
                        val (r, c) = freqs(cls) ?: (0.0 to 0.0)
                        val f = (1 - r - c).coerceAtLeast(0.0)
                        val label = when {
                            row == col -> "${ranks[row]}${ranks[col]}"
                            row < col -> "${ranks[row]}${ranks[col]}s"
                            else -> "${ranks[col]}${ranks[row]}o"
                        }
                        Box(
                            Modifier
                                .weight(1f)
                                .height(26.dp)
                                .then(
                                    if (cls == highlight) Modifier.border(2.dp, Color(0xFFFFD54F))
                                    else Modifier.border(0.25.dp, Color(0x22000000)),
                                ),
                            contentAlignment = Alignment.Center,
                        ) {
                            Row(Modifier.fillMaxSize()) {
                                if (r > 0.001) Box(Modifier.weight(r.toFloat()).fillMaxSize().background(RAISE_COLOR.copy(alpha = 0.85f)))
                                if (c > 0.001) Box(Modifier.weight(c.toFloat()).fillMaxSize().background(CALL_COLOR.copy(alpha = 0.85f)))
                                if (f > 0.001) Box(Modifier.weight(f.toFloat()).fillMaxSize())
                            }
                            Text(label, fontSize = 7.sp, lineHeight = 8.sp, maxLines = 1, color = if (r + c > 0.5) Color.White else MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                }
            }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp), verticalAlignment = Alignment.CenterVertically) {
            Legend(RAISE_COLOR, raiseWord)
            if (spot != QuizSpot.OPEN) Legend(CALL_COLOR, "Call")
            Legend(MaterialTheme.colorScheme.surfaceVariant, "Fold")
        }
        Text(
            "Solved with CFR for 6-max at 100 big blinds (see the README for how).",
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
    }
}

@Composable
private fun Legend(color: Color, label: String) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(10.dp).clip(RoundedCornerShape(2.dp)).background(color).border(0.5.dp, Color(0x55000000), RoundedCornerShape(2.dp)))
        Spacer(Modifier.width(4.dp))
        Text(label, style = MaterialTheme.typography.labelSmall)
    }
}

/** Small grade dot, used in lists. */
@Composable
internal fun GradeDotSmall(g: com.pokercoach.engine.analysis.Grade) {
    Box(Modifier.size(10.dp).clip(RoundedCornerShape(50)).background(gradeColor(g)))
}
