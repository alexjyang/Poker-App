package com.pokercoach.engine.learn

import com.pokercoach.engine.analysis.Concept

enum class GlossaryCategory(val label: String) {
    BASICS("Basics"),
    HANDS("Hands & draws"),
    ACTIONS("Betting & actions"),
    POSITIONS("Positions"),
    MATH("Odds & math"),
    STRATEGY("Strategy"),
    PLAYERS("Player types"),
    STATS("Stats & HUD"),
    TOURNAMENTS("Game formats"),
    APP("Coach & app"),
}

/**
 * One glossary entry. [term] is the name shown; [abbreviation] is how it's often written
 * (VPIP, OESD...). [aliases] are other words people search for. [related] are other terms.
 */
data class GlossaryEntry(
    val term: String,
    val category: GlossaryCategory,
    val definition: String,
    val abbreviation: String? = null,
    val example: String? = null,
    val related: List<String> = emptyList(),
    val aliases: List<String> = emptyList(),
) {
    /** "Voluntarily put money in pot (VPIP)" style title. */
    val title: String get() = if (abbreviation != null) "$term ($abbreviation)" else term
}

/** Every poker term and abbreviation used in the app, explained for someone new to the game. */
object Glossary {

    /** Search by term, abbreviation, alias or words in the definition; best matches first. */
    fun search(query: String, category: GlossaryCategory? = null): List<GlossaryEntry> {
        val pool = if (category == null) entries else entries.filter { it.category == category }
        val q = query.trim().lowercase()
        if (q.isEmpty()) return pool.sortedBy { it.term.lowercase() }
        fun names(e: GlossaryEntry) = listOfNotNull(e.term, e.abbreviation) + e.aliases
        return pool.mapNotNull { e ->
            val n = names(e).map { it.lowercase() }
            val score = when {
                n.any { it == q } -> 0
                n.any { it.startsWith(q) } -> 1
                n.any { it.contains(q) } -> 2
                e.definition.lowercase().contains(q) -> 3
                (e.example ?: "").lowercase().contains(q) -> 4
                else -> null
            }
            score?.let { it to e }
        }.sortedWith(compareBy({ it.first }, { it.second.term.lowercase() })).map { it.second }
    }

    /** The entry for a term, abbreviation or alias (case-insensitive), if any. */
    fun find(name: String): GlossaryEntry? {
        val q = name.trim().lowercase()
        return entries.firstOrNull { e -> (listOfNotNull(e.term, e.abbreviation) + e.aliases).any { it.lowercase() == q } }
    }

    /** Glossary entry behind a review concept chip. */
    fun forConcept(c: Concept): GlossaryEntry = find(
        when (c) {
            Concept.EQUITY -> "Equity"
            Concept.POT_ODDS -> "Pot odds"
            Concept.EV -> "Expected value"
            Concept.FOLD_EQUITY -> "Fold equity"
            Concept.OUTS -> "Outs"
            Concept.IMPLIED_ODDS -> "Implied odds"
            Concept.SPR -> "Stack-to-pot ratio"
            Concept.MDF -> "Minimum defense frequency"
            Concept.RANGE -> "Range"
            Concept.BLOCKERS -> "Blockers"
            Concept.RANGE_ADVANTAGE -> "Range advantage"
            Concept.NUT_ADVANTAGE -> "Nut advantage"
            Concept.REALIZATION -> "Equity realization"
            Concept.GTO -> "Game theory optimal"
            Concept.POSITION -> "Position"
            Concept.VALUE_BET -> "Value bet"
            Concept.BLUFF -> "Bluff"
        },
    )!!

    private val B = GlossaryCategory.BASICS
    private val H = GlossaryCategory.HANDS
    private val A = GlossaryCategory.ACTIONS
    private val P = GlossaryCategory.POSITIONS
    private val M = GlossaryCategory.MATH
    private val S = GlossaryCategory.STRATEGY
    private val T = GlossaryCategory.PLAYERS
    private val ST = GlossaryCategory.STATS
    private val F = GlossaryCategory.TOURNAMENTS
    private val AP = GlossaryCategory.APP

    val entries: List<GlossaryEntry> = listOf(
        // ---------------------------------------------------------------- basics
        GlossaryEntry("No-Limit Texas Hold'em", B,
            "The most popular poker game. Everyone gets two private cards, five shared cards are dealt in the middle, and you make the best five-card hand from the seven. \"No-limit\" means you can bet any amount up to everything in front of you.",
            abbreviation = "NLHE", aliases = listOf("Hold'em", "Holdem", "NLH", "Texas Hold'em"), related = listOf("Hole cards", "Board", "Street")),
        GlossaryEntry("Hole cards", B, "Your two private cards. Only you see them unless the hand goes to showdown.",
            aliases = listOf("Pocket cards", "Starting hand"), related = listOf("Board", "Showdown")),
        GlossaryEntry("Board", B, "The shared cards in the middle that everyone uses: three on the flop, one on the turn, one on the river.",
            aliases = listOf("Community cards"), related = listOf("Flop", "Turn", "River")),
        GlossaryEntry("Street", B, "One round of betting. There are four: preflop, flop, turn and river.",
            related = listOf("Preflop", "Flop", "Turn", "River")),
        GlossaryEntry("Preflop", B, "The first betting round, after the hole cards are dealt and before any shared cards.",
            related = listOf("Street", "Flop")),
        GlossaryEntry("Flop", B, "The first three shared cards, dealt together, and the betting round that follows.",
            related = listOf("Turn", "River", "Board")),
        GlossaryEntry("Turn", B, "The fourth shared card and its betting round.", aliases = listOf("Fourth street"), related = listOf("Flop", "River")),
        GlossaryEntry("River", B, "The fifth and last shared card and the final betting round. After it, any remaining players show their hands.",
            aliases = listOf("Fifth street"), related = listOf("Turn", "Showdown")),
        GlossaryEntry("Showdown", B, "When the betting is over and two or more players are left, they reveal their cards and the best hand wins the pot.",
            related = listOf("WTSD", "W\$SD")),
        GlossaryEntry("Pot", B, "All the chips bet so far in a hand. The winner takes it.", related = listOf("Side pot", "Pot odds")),
        GlossaryEntry("Side pot", B, "When a player is all-in for less, a separate pot is made for the extra chips the others bet. The all-in player can only win the main pot.",
            example = "You're all-in for 50; two others each bet 200. The main pot has 150 (50 each); the side pot of 300 is only between the other two.",
            related = listOf("All-in", "Pot")),
        GlossaryEntry("Stack", B, "The chips a player has in front of them.", aliases = listOf("Chip stack"), related = listOf("Effective stack", "Stack-to-pot ratio")),
        GlossaryEntry("Effective stack", B, "The smaller of two players' stacks — the most either of them can win or lose against the other.",
            example = "You have 200, your opponent 80: the effective stack is 80.", related = listOf("Stack", "Stack-to-pot ratio")),
        GlossaryEntry("Blinds", B, "Forced bets that start the action. The small blind (SB) posts half a bet and the big blind (BB) a full bet, before the cards are dealt. They move one seat each hand.",
            related = listOf("Big blind", "Small blind", "Ante")),
        GlossaryEntry("Big blind", B, "The larger forced bet, and the standard unit for measuring amounts in poker: \"a 3 BB raise\" or \"you lost 12 BB\" works at any stakes.",
            abbreviation = "BB", related = listOf("Blinds", "bb/100")),
        GlossaryEntry("Small blind", B, "The smaller forced bet (half the big blind), posted by the player left of the button.",
            abbreviation = "SB", related = listOf("Blinds", "Big blind")),
        GlossaryEntry("Ante", B, "A small forced bet from every player (or, with a big-blind ante, paid by the big blind for everyone). Antes make the pot bigger, so it pays to play a bit looser.",
            aliases = listOf("Big blind ante", "BB ante"), related = listOf("Blinds", "Sit & Go")),
        GlossaryEntry("Kicker", B, "The extra card that decides between two hands of the same kind.",
            example = "You have A-K and your opponent A-Q on an A-7-2 board: both have a pair of aces, your king kicker wins.",
            related = listOf("Top pair")),
        GlossaryEntry("Split pot", B, "When two or more players have exactly the same best hand, they share the pot. Odd chips go to the first winner left of the button.",
            aliases = listOf("Chop", "Tie"), related = listOf("Showdown")),
        GlossaryEntry("Playing the board", B, "When the five shared cards are your best hand and your own cards don't improve it. Everyone still in has at least the same hand, so it's usually a split.",
            related = listOf("Split pot")),
        GlossaryEntry("Walk", B, "When everyone folds to the big blind, who wins the blinds without a fight.", related = listOf("Big blind")),
        GlossaryEntry("Heads-up", B, "Just two players — either a two-player table or two players left in a hand. Heads-up, the button posts the small blind.",
            abbreviation = "HU", related = listOf("6-max", "Full ring")),
        GlossaryEntry("6-max", B, "A table for up to six players. Ranges are wider than at a full table because there are fewer opponents to beat.",
            aliases = listOf("Six-max"), related = listOf("Full ring", "Heads-up")),
        GlossaryEntry("Full ring", B, "A table for nine (or ten) players. You need stronger hands to play, especially from early positions.",
            related = listOf("6-max")),

        // ---------------------------------------------------------------- hands & draws
        GlossaryEntry("Hand rankings", H,
            "From weakest to strongest: high card, one pair, two pair, three of a kind, straight, flush, full house, four of a kind, straight flush (a royal flush is the best straight flush).",
            related = listOf("Straight", "Flush", "Full house"), aliases = listOf("Hand ranks")),
        GlossaryEntry("Pocket pair", H, "Two hole cards of the same rank, like 7-7 or Q-Q.",
            example = "Pocket aces (A-A) is the best starting hand.", aliases = listOf("Pair in hand"), related = listOf("Set", "Overpair")),
        GlossaryEntry("Suited", H, "Two hole cards of the same suit, written with an \"s\" (AKs). Suited hands can make flushes, so they play better than the same cards offsuit.",
            abbreviation = "s", related = listOf("Offsuit", "Flush")),
        GlossaryEntry("Offsuit", H, "Two hole cards of different suits, written with an \"o\" (AKo).", abbreviation = "o", related = listOf("Suited")),
        GlossaryEntry("Connectors", H, "Hole cards next to each other in rank, like 8-7 or J-T. Suited connectors (like 7♠6♠) can make straights and flushes.",
            aliases = listOf("Suited connectors"), related = listOf("Straight", "Suited")),
        GlossaryEntry("Broadway", H, "The five highest ranks: A, K, Q, J and T (ten). \"Broadway cards\" are hands made of them; \"broadway\" is also the A-K-Q-J-T straight.",
            related = listOf("Straight")),
        GlossaryEntry("Top pair", H, "Pairing the highest card on the board with one of your hole cards. Often a good hand, but how good depends on your kicker.",
            example = "You hold K-J on K-8-3: top pair, jack kicker.", aliases = listOf("TP", "Second pair", "Bottom pair"), related = listOf("Kicker", "Overpair")),
        GlossaryEntry("Overpair", H, "A pocket pair higher than every card on the board.", example = "Q-Q on J-8-4.", related = listOf("Pocket pair", "Top pair")),
        GlossaryEntry("Set", H, "Three of a kind made with a pocket pair plus one matching card on the board. Very strong and hard for opponents to see coming.",
            example = "5-5 on K-5-2.", related = listOf("Trips", "Pocket pair")),
        GlossaryEntry("Trips", H, "Three of a kind made with one hole card plus a pair on the board. Easier for opponents to spot than a set.",
            example = "K-9 on 9-9-4.", related = listOf("Set")),
        GlossaryEntry("Straight", H, "Five cards in a row of any suits. A-2-3-4-5 (the \"wheel\") is the lowest; T-J-Q-K-A the highest.",
            related = listOf("Open-ended straight draw", "Gutshot", "Wheel")),
        GlossaryEntry("Wheel", H, "The lowest straight, A-2-3-4-5, where the ace counts as a one.", related = listOf("Straight")),
        GlossaryEntry("Flush", H, "Five cards of the same suit. The \"nut flush\" is the best possible one on that board, usually the ace-high flush.",
            related = listOf("Flush draw", "Nuts")),
        GlossaryEntry("Full house", H, "Three of a kind plus a pair, like 8-8-8-K-K. Written \"eights full of kings\".", aliases = listOf("Boat"), related = listOf("Hand rankings")),
        GlossaryEntry("Quads", H, "Four of a kind.", aliases = listOf("Four of a kind"), related = listOf("Hand rankings")),
        GlossaryEntry("Nuts", H, "The best possible hand on the current board. \"Near nuts\" means one of the very best.",
            example = "On A♥ 9♥ 4♥ T♠ 2♣ the nuts is the king-high flush (you hold K♥ with another heart) — the ace of hearts is on the board.",
            aliases = listOf("The nuts", "Nut", "Nut hand"), related = listOf("Nut advantage", "Flush")),
        GlossaryEntry("Made hand", H, "A hand that already has value now (a pair or better), as opposed to a draw that still needs help.",
            related = listOf("Draw")),
        GlossaryEntry("Draw", H, "A hand that isn't good yet but can become strong with the right card, like four cards to a flush.",
            aliases = listOf("Drawing hand"), related = listOf("Flush draw", "Open-ended straight draw", "Gutshot", "Outs")),
        GlossaryEntry("Flush draw", H, "Four cards of the same suit (your hole cards plus the board) waiting for a fifth. Nine cards of that suit are left, so you have 9 outs.",
            example = "A♥K♥ on Q♥7♥2♣: a nut flush draw, 9 outs.", abbreviation = "FD", aliases = listOf("Nut flush draw"), related = listOf("Outs", "Flush")),
        GlossaryEntry("Open-ended straight draw", H, "Four cards in a row that can be completed at either end — 8 outs.",
            example = "9-8 on T-7-2: any jack or six makes a straight.", abbreviation = "OESD", aliases = listOf("Open-ender"), related = listOf("Gutshot", "Outs")),
        GlossaryEntry("Gutshot", H, "A straight draw that needs one specific rank in the middle — 4 outs.",
            example = "J-9 on Q-8-2 needs a ten.", aliases = listOf("Inside straight draw", "Gutshot straight draw"), related = listOf("Open-ended straight draw", "Outs")),
        GlossaryEntry("Combo draw", H, "Two draws at once, typically a flush draw plus a straight draw. Often 12–15 outs — sometimes a favourite against a made hand.",
            related = listOf("Flush draw", "Open-ended straight draw")),
        GlossaryEntry("Backdoor draw", H, "A draw that needs both the turn and the river, like three cards to a flush on the flop. Worth a little extra equity (around 4%).",
            aliases = listOf("Backdoor flush draw", "Backdoor straight draw", "Runner-runner"), related = listOf("Draw")),
        GlossaryEntry("Overcards", H, "Hole cards higher than every card on the board. Pairing one often gives you the best hand (about 3 outs each).",
            example = "A-K on 9-6-2: two overcards, 6 outs.", related = listOf("Outs")),
        GlossaryEntry("Bluff-catcher", H, "A hand that beats only bluffs: if your opponent is betting for value, you lose. Calling with it is right only if they bluff often enough.",
            related = listOf("Bluff", "Minimum defense frequency")),

        // ---------------------------------------------------------------- actions
        GlossaryEntry("Check", A, "Passing without betting when nobody has bet yet on this street.", related = listOf("Bet", "Check-raise")),
        GlossaryEntry("Bet", A, "Putting chips in when nobody has bet yet on this street. Others must call, raise or fold.", related = listOf("Raise", "Bet sizing")),
        GlossaryEntry("Call", A, "Matching the current bet to stay in the hand.", related = listOf("Raise", "Fold")),
        GlossaryEntry("Raise", A, "Increasing the current bet. In no-limit a raise must be at least as big as the last bet or raise.",
            example = "Someone bets 10; a minimum raise is to 20.", aliases = listOf("Re-raise", "Min-raise"), related = listOf("3-bet", "Call")),
        GlossaryEntry("Fold", A, "Giving up your hand and any chips you've already put in.", related = listOf("Fold equity")),
        GlossaryEntry("All-in", A, "Betting everything you have left. You can't be forced out of the hand after that, but you can only win as much as you put in from each opponent.",
            aliases = listOf("Shove", "Jam", "Push"), related = listOf("Side pot", "Push/fold")),
        GlossaryEntry("Limp", A, "Just calling the big blind preflop instead of raising. Usually a weak play: you don't win the blinds right away and players behind can raise you.",
            aliases = listOf("Limper", "Open-limp"), related = listOf("Open", "Isolation raise")),
        GlossaryEntry("Open", A, "Being the first player to raise preflop (\"opening the pot\").",
            aliases = listOf("Open-raise", "Raise first in", "RFI"), related = listOf("Limp", "3-bet", "Preflop chart")),
        GlossaryEntry("3-bet", A, "The first re-raise preflop (the blinds count as the first bet and the open as the second). 3-betting builds a big pot with strong hands and takes pots away with some bluffs.",
            example = "Someone opens to 2.5 BB, you raise to 8 BB: that's a 3-bet.", aliases = listOf("Three-bet", "3bet"), related = listOf("4-bet", "Open")),
        GlossaryEntry("4-bet", A, "A re-raise of a 3-bet. Usually only the strongest hands (and a few bluffs).", aliases = listOf("Four-bet"), related = listOf("3-bet", "5-bet")),
        GlossaryEntry("5-bet", A, "A re-raise of a 4-bet; at 100 big blinds this is usually all-in.", related = listOf("4-bet", "All-in")),
        GlossaryEntry("Cold call", A, "Calling a raise when you haven't put any money in yet on this street.", related = listOf("Call", "Open")),
        GlossaryEntry("Isolation raise", A, "Raising after one or more players limped, to play the pot heads-up against a weak player with the initiative.",
            aliases = listOf("Iso-raise", "Isolate"), related = listOf("Limp", "Initiative")),
        GlossaryEntry("Continuation bet", A, "A bet on the flop by the player who raised preflop, \"continuing\" the aggression whether or not they hit.",
            abbreviation = "c-bet", aliases = listOf("Cbet", "C bet"), related = listOf("Fold to c-bet", "Barrel", "Range advantage")),
        GlossaryEntry("Barrel", A, "Betting again on a later street after betting the previous one. Betting flop, turn and river is a \"triple barrel\".",
            aliases = listOf("Double barrel", "Triple barrel", "Second barrel"), related = listOf("Continuation bet")),
        GlossaryEntry("Check-raise", A, "Checking, then raising after an opponent bets. A strong move used with very good hands and some draws or bluffs.",
            related = listOf("Check", "Raise")),
        GlossaryEntry("Donk bet", A, "Betting into the player who had the initiative (usually the preflop raiser) instead of checking to them.",
            aliases = listOf("Donk", "Lead"), related = listOf("Initiative", "Continuation bet")),
        GlossaryEntry("Overbet", A, "A bet bigger than the pot. Used with very strong hands and bluffs when you have the nut advantage.",
            related = listOf("Bet sizing", "Nut advantage")),
        GlossaryEntry("Bet sizing", A, "How big you bet, usually as a share of the pot (⅓ pot, ⅔ pot, pot). Small bets with a wide range on dry boards; bigger bets with strong hands, draws and on wet boards.",
            aliases = listOf("Sizing", "Pot-sized bet", "Half pot"), related = listOf("Board texture", "Overbet")),
        GlossaryEntry("Value bet", A, "A bet you make because worse hands will call it.", related = listOf("Thin value", "Bluff")),
        GlossaryEntry("Bluff", A, "A bet with a hand that's usually behind, hoping better hands fold.", related = listOf("Semi-bluff", "Fold equity", "Bluff-catcher")),
        GlossaryEntry("Semi-bluff", A, "A bluff with a draw: if they call, you can still hit and win.", example = "Betting a flush draw on the flop.", related = listOf("Bluff", "Draw")),
        GlossaryEntry("Slow-play", A, "Checking or calling with a very strong hand to keep weaker hands in and win more later. Risky: free cards can beat you.",
            aliases = listOf("Trap"), related = listOf("Value bet")),
        GlossaryEntry("Pre-action", A, "Choosing your move before it's your turn (Check/Fold, Check, Call any). The app does it automatically when your turn comes.",
            related = listOf("Check", "Fold")),
    ) + entries2()
}
