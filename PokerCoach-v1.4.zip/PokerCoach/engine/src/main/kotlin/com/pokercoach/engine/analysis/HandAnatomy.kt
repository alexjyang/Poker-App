package com.pokercoach.engine.analysis

import com.pokercoach.engine.card.Card
import com.pokercoach.engine.card.CardMask
import com.pokercoach.engine.card.Rank
import com.pokercoach.engine.card.Suit
import com.pokercoach.engine.eval.HandCategory
import com.pokercoach.engine.eval.HandEvaluator
import com.pokercoach.engine.range.Combos
import com.pokercoach.engine.range.Range
import com.pokercoach.engine.rng.SeededRandom
import kotlin.math.roundToInt

/** A draw: what it is, how many cards complete it, and which cards. */
data class Draw(val label: String, val outs: Int, val cards: List<Card>)

/** One slice of equity: how often you finish with [hand] and how much of your equity it brings. */
data class EquitySlice(val hand: String, val frequency: Double, val contribution: Double)

/**
 * The "anatomy" of a hand at a decision: what you have, what you can make, and why the equity
 * number is what it is.
 */
data class HandAnatomy(
    /** E.g. "Top pair, weak kicker", "Ace-high", "Nut flush", "Pocket jacks". */
    val madeHand: String,
    val draws: List<Draw>,
    /** Distinct cards that improve you (a card counted by two draws is counted once). */
    val outCards: List<Card>,
    /** Probability of hitting at least one out on the next card / by the river (exact, given the outs). */
    val hitNext: Double?,
    val hitByRiver: Double?,
    /** Equity split by the hand you finish with (sums to the equity). */
    val slices: List<EquitySlice>,
    /** Plain-language "why is my equity this number". */
    val explanation: String,
)

object HandAnatomyAnalyzer {

    private fun rankName(r: Rank) = r.displayName.lowercase()
    private fun plural(r: Rank) = r.pluralName.lowercase()
    private fun pct(x: Double) = "${(x * 100).roundToInt()}%"

    fun analyze(hole: List<Card>, board: List<Card>, villainRanges: List<Range>, equity: Double, rng: SeededRandom, samples: Int = 3_000): HandAnatomy {
        val made = describeMade(hole, board)
        val draws = if (board.size in 3..4) findDraws(hole, board) else emptyList()
        val outCards = draws.flatMap { it.cards }.distinct()
        val unseen = 52 - 2 - board.size
        val toCome = 5 - board.size
        val hitNext = if (board.size in 3..4 && outCards.isNotEmpty()) outCards.size.toDouble() / unseen else null
        val hitByRiver = if (board.size == 3 && outCards.isNotEmpty()) {
            val n = outCards.size.toDouble()
            1 - (unseen - n) * (unseen - n - 1) / (unseen.toDouble() * (unseen - 1))
        } else null
        val slices = breakdown(hole, board, villainRanges, equity, rng, samples)
        val text = explain(hole, board, made, draws, outCards, hitNext, hitByRiver, toCome, slices, equity)
        return HandAnatomy(made, draws, outCards.sortedDescending(), hitNext, hitByRiver, slices, text)
    }

    // ------------------------------------------------------------------ made hand

    fun describeMade(hole: List<Card>, board: List<Card>): String {
        val (a, b) = hole.sortedByDescending { it.rank.ordinal }
        if (board.isEmpty()) {
            return when {
                a.rank == b.rank -> "Pocket ${plural(a.rank)}"
                else -> "${a.rank.displayName}-${rankName(b.rank)} ${if (a.suit == b.suit) "suited" else "offsuit"}" +
                    (if (a.rank.ordinal - b.rank.ordinal == 1) " (connected)" else "")
            }
        }
        val all = hole + board
        val v = HandEvaluator.evaluate(all)
        if (board.size == 5 && HandEvaluator.evaluate(board).raw == v.raw) return "Playing the board (your cards don't improve it)"
        val boardRanks = board.map { it.rank }.distinct().sortedByDescending { it.ordinal }
        val top = boardRanks.first()
        return when (v.category) {
            HandCategory.HIGH_CARD -> {
                // (Overcards are listed with the draws, so they aren't repeated here.)
                "${a.rank.displayName}-high, no pair"
            }
            HandCategory.PAIR -> {
                val pocket = a.rank == b.rank
                val hit = hole.firstOrNull { h -> board.any { it.rank == h.rank } }
                when {
                    pocket && a.rank.ordinal > top.ordinal -> "Overpair (${plural(a.rank)})"
                    pocket -> "Pocket ${plural(a.rank)} below the top card"
                    hit == null -> "Only the board's pair — you play your ${rankName(a.rank)} kicker"
                    else -> {
                        val idx = boardRanks.indexOf(hit.rank)
                        val kicker = hole.first { it != hit }.rank
                        val which = when (idx) { 0 -> "Top pair"; 1 -> "Second pair"; else -> if (idx == boardRanks.lastIndex) "Bottom pair" else "Third pair" }
                        val kickerText = when {
                            idx != 0 -> ""
                            kicker == Rank.ACE || kicker == Rank.KING && hit.rank == Rank.ACE -> ", top kicker"
                            kicker.ordinal >= Rank.TEN.ordinal -> ", good kicker"
                            else -> ", weak kicker"
                        }
                        "$which (${plural(hit.rank)})$kickerText"
                    }
                }
            }
            HandCategory.TWO_PAIR -> {
                val both = hole.all { h -> board.any { it.rank == h.rank } } && a.rank != b.rank
                when {
                    both && boardRanks.take(2).containsAll(hole.map { it.rank }) -> "Two pair (top two)"
                    both -> "Two pair (both your cards paired)"
                    a.rank == b.rank -> "Two pair: your ${plural(a.rank)} plus the board's pair"
                    else -> "Two pair, one of them on the board"
                }
            }
            HandCategory.THREE_OF_A_KIND -> when {
                a.rank == b.rank -> "Set of ${plural(a.rank)} (very strong and well hidden)"
                hole.any { h -> board.count { it.rank == h.rank } == 2 } -> "Trips (${plural(hole.first { h -> board.count { it.rank == h.rank } == 2 }.rank)})"
                else -> "Three of a kind on the board"
            }
            HandCategory.STRAIGHT -> "Straight" + if (isNutStraight(hole, board)) " (the best possible straight)" else ""
            HandCategory.FLUSH -> {
                val suit = Suit.entries.first { s -> all.count { it.suit == s } >= 5 }
                val mine = hole.filter { it.suit == suit }.maxByOrNull { it.rank.ordinal }
                // The nut flush holds the highest card of the suit that isn't on the board.
                val highestOffBoard = Rank.entries.reversed().first { r -> board.none { it.suit == suit && it.rank == r } }
                when {
                    mine == null -> "A flush on the board"
                    mine.rank == highestOffBoard -> "Nut flush (${rankName(mine.rank)}-high)"
                    else -> "${mine.rank.displayName}-high flush"
                }
            }
            HandCategory.FULL_HOUSE -> "Full house"
            HandCategory.FOUR_OF_A_KIND -> "Four of a kind"
            HandCategory.STRAIGHT_FLUSH -> "Straight flush"
        }
    }

    private fun isNutStraight(hole: List<Card>, board: List<Card>): Boolean {
        val mine = HandEvaluator.straightHigh(rankMask(hole + board))
        val boardMask = rankMask(board)
        var best = -1
        for (x in 0 until 13) for (y in x until 13) best = maxOf(best, HandEvaluator.straightHigh(boardMask or (1 shl x) or (1 shl y)))
        return mine >= best
    }

    private fun rankMask(cards: List<Card>) = cards.fold(0) { m, c -> m or (1 shl c.rank.ordinal) }

    // ------------------------------------------------------------------ draws

    fun findDraws(hole: List<Card>, board: List<Card>): List<Draw> {
        val known = CardMask.of(hole + board)
        val unseen = Card.ALL.filter { it.mask and known == 0L }
        val all = hole + board
        val category = HandEvaluator.evaluate(all).category
        val draws = mutableListOf<Draw>()

        // Flush draw: four of a suit using at least one of your cards.
        if (category < HandCategory.FLUSH) {
            for (s in Suit.entries) {
                val mine = hole.count { it.suit == s }
                val total = all.count { it.suit == s }
                if (mine == 0) continue
                if (total == 4) {
                    val cards = unseen.filter { it.suit == s }
                    val highestMissing = Rank.entries.reversed().first { r -> board.none { it.suit == s && it.rank == r } }
                    val nut = hole.any { it.suit == s && it.rank == highestMissing }
                    draws += Draw((if (nut) "Nut flush draw" else "Flush draw") + " (${s.name.lowercase()})", cards.size, cards)
                } else if (total == 3 && board.size == 3) {
                    draws += Draw("Backdoor flush draw (needs two more ${s.name.lowercase()})", 0, emptyList())
                }
            }
        }

        // Straight draws: ranks that complete a straight using one of your cards.
        if (category < HandCategory.STRAIGHT) {
            val ranks = rankMask(all)
            val boardRanks = rankMask(board)
            val completing = (0 until 13).filter { r ->
                ranks and (1 shl r) == 0 &&
                    HandEvaluator.straightHigh(ranks or (1 shl r)) >= 0 &&
                    HandEvaluator.straightHigh(boardRanks or (1 shl r)) < 0
            }
            val cards = unseen.filter { it.rank.ordinal in completing }
            when {
                completing.size >= 2 -> draws += Draw("Open-ended straight draw", cards.size, cards)
                completing.size == 1 -> draws += Draw("Gutshot straight draw (needs a ${rankName(Rank.entries[completing[0]])})", cards.size, cards)
                board.size == 3 && hasBackdoorStraight(ranks, boardRanks) -> draws += Draw("Backdoor straight draw (needs two more cards)", 0, emptyList())
            }
        }

        // Overcards: with no pair yet, pairing a card above the board often takes the lead.
        if (category == HandCategory.HIGH_CARD) {
            val top = board.maxOf { it.rank.ordinal }
            val overs = hole.filter { it.rank.ordinal > top }
            if (overs.isNotEmpty()) {
                val cards = unseen.filter { u -> overs.any { it.rank == u.rank } }
                draws += Draw(if (overs.size == 2) "Two overcards (pairing either)" else "Overcard (pairing your ${rankName(overs[0].rank)})", cards.size, cards)
            }
        }
        return draws
    }

    private fun hasBackdoorStraight(ranks: Int, boardRanks: Int): Boolean {
        for (x in 0 until 13) for (y in x + 1 until 13) {
            if (ranks and (1 shl x) != 0 || ranks and (1 shl y) != 0) continue
            if (HandEvaluator.straightHigh(ranks or (1 shl x) or (1 shl y)) >= 0 &&
                HandEvaluator.straightHigh(boardRanks or (1 shl x) or (1 shl y)) < 0
            ) return true
        }
        return false
    }

    // ------------------------------------------------------------------ equity breakdown

    private fun bucket(cat: HandCategory): String = when (cat) {
        HandCategory.HIGH_CARD -> "High card"
        HandCategory.PAIR -> "One pair"
        HandCategory.TWO_PAIR -> "Two pair"
        HandCategory.THREE_OF_A_KIND -> "Three of a kind"
        HandCategory.STRAIGHT -> "Straight"
        HandCategory.FLUSH -> "Flush"
        else -> "Full house or better"
    }

    /**
     * Simulates run-outs against the same estimated ranges as the equity, and records which hand
     * hero finishes with and how much of the pot it wins. Scaled so the slices add up exactly to
     * the [equity] shown elsewhere in the review.
     */
    fun breakdown(hole: List<Card>, board: List<Card>, villains: List<Range>, equity: Double, rng: SeededRandom, samples: Int): List<EquitySlice> {
        val heroMask = CardMask.of(hole)
        val boardMask = CardMask.of(board)
        val samplers = (villains.ifEmpty { listOf(Range.full()) }).map { RangeSampler(it, heroMask or boardMask) }
        if (samplers.any { it.isEmpty }) return emptyList()
        val freq = HashMap<String, Int>()
        val won = HashMap<String, Double>()
        val opp = LongArray(samplers.size)
        var done = 0
        var attempts = 0
        while (done < samples && attempts < samples * 4) {
            attempts++
            var used = heroMask or boardMask
            var ok = true
            for (i in samplers.indices) {
                val m = Combos.mask[samplers[i].sample(rng)]
                if (m and used != 0L) { ok = false; break }
                opp[i] = m; used = used or m
            }
            if (!ok) continue
            val b5 = Showdown.completeBoard(boardMask, board.size, used, rng)
            val label = bucket(HandCategory.entries[HandEvaluator.evaluateMask(heroMask or b5) ushr 26])
            freq[label] = (freq[label] ?: 0) + 1
            won[label] = (won[label] ?: 0.0) + Showdown.heroShare(heroMask, b5, opp, samplers.size)
            done++
        }
        if (done == 0) return emptyList()
        val rawEquity = won.values.sum() / done
        val scale = if (rawEquity > 0) equity / rawEquity else 1.0
        return freq.keys.map { k -> EquitySlice(k, freq.getValue(k).toDouble() / done, (won[k] ?: 0.0) / done * scale) }
            .filter { it.frequency >= 0.01 || it.contribution >= 0.005 }
            .sortedByDescending { it.contribution }
    }

    // ------------------------------------------------------------------ explanation

    private fun madeWithArticle(made: String): String {
        val l = made.replaceFirstChar { it.lowercase() }
        return when {
            l.startsWith("nut ") -> "the $l"
            l.startsWith("overpair") -> "an $l"
            l.startsWith("set ") || l.startsWith("straight") || l.startsWith("full house") -> "a $l"
            l.endsWith("flush") && l.contains("-high") -> "a $l"
            l.startsWith("only the board") || l.startsWith("playing the board") -> l
            else -> l
        }
    }

    private fun explain(
        hole: List<Card>,
        board: List<Card>,
        made: String,
        draws: List<Draw>,
        outCards: List<Card>,
        hitNext: Double?,
        hitByRiver: Double?,
        toCome: Int,
        slices: List<EquitySlice>,
        equity: Double,
    ): String {
        val sb = StringBuilder()
        val realDraws = draws.filter { it.outs > 0 }
        val backdoors = draws.filter { it.outs == 0 }
        fun withArticle(label: String): String {
            val l = label.replaceFirstChar { it.lowercase() }
            return when {
                l.startsWith("two ") -> l
                l.first() in "aeiou" -> "an $l"
                else -> "a $l"
            }
        }
        sb.append("You have ${madeWithArticle(made)}")
        if (realDraws.isNotEmpty()) sb.append(", with ${realDraws.joinToString(" and ") { withArticle(it.label) }}")
        sb.append(". ")
        if (outCards.isNotEmpty() && hitNext != null) {
            sb.append("${outCards.size} cards improve you")
            if (realDraws.size > 1) sb.append(" (${realDraws.joinToString(", ") { "${it.outs} for the ${it.label.substringBefore(" (").lowercase()}" }}; cards that do both are counted once)")
            sb.append(": ${pct(hitNext)} chance on the next card")
            if (hitByRiver != null) sb.append(" and ${pct(hitByRiver)} by the river")
            sb.append(". ")
        }
        if (backdoors.isNotEmpty() && board.size == 3) {
            sb.append(
                if (backdoors.size == 1) "${withArticle(backdoors[0].label.substringBefore(" (")).replaceFirstChar { it.uppercase() }} adds a little: it needs both the turn and the river. "
                else "Backdoor draws add a little: they need both the turn and the river. ",
            )
        }

        if (slices.isNotEmpty()) {
            sb.append(if (board.isEmpty()) "By the river, your ${pct(equity)} equity comes from winning " else "Your ${pct(equity)} equity: ")
            fun phrase(hand: String) = when (hand) {
                "High card" -> "no pair (high card)"
                "One pair" -> "one pair"
                "Two pair" -> "two pair"
                "Three of a kind" -> "three of a kind"
                "Straight" -> "a straight"
                "Flush" -> "a flush"
                else -> "a full house or better"
            }
            val parts = slices.take(3).map { s ->
                if (board.isEmpty()) "${pct(s.contribution)} with ${phrase(s.hand)}"
                else "you win ${pct(s.contribution)} with ${phrase(s.hand)} (you end with it ${pct(s.frequency)} of the time)"
            }
            sb.append(parts.joinToString("; "))
            val rest = equity - slices.take(3).sumOf { it.contribution }
            if (rest >= 0.01) sb.append("; the rest ${pct(rest)}")
            sb.append(". ")
            // Draw-heavy hands: say how much hinges on hitting.
            val drawSlices = slices.filter { it.hand in setOf("Flush", "Straight") }
            if (realDraws.isNotEmpty() && drawSlices.isNotEmpty() && toCome > 0) {
                val fromDraws = drawSlices.sumOf { it.contribution }
                if (fromDraws > equity * 0.5) sb.append("Most of your equity depends on hitting your draw — when you miss, you rarely win. ")
            }
            val pairedBoard = board.map { it.rank }.distinct().size < board.size
            if (realDraws.any { it.label.contains("flush") || it.label.contains("straight") } && pairedBoard) {
                sb.append("The board is paired, so some of your outs can also give an opponent a full house. ")
            }
        }
        return sb.toString().trim()
    }
}
