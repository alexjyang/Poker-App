package com.pokercoach.engine

import com.pokercoach.engine.analysis.Concept
import com.pokercoach.engine.learn.Glossary
import com.pokercoach.engine.learn.GlossaryCategory
import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertNotNull
import kotlin.test.assertTrue

class GlossaryTest {
    @Test
    fun `every name is unique and every related term exists`() {
        val names = Glossary.entries.flatMap { e -> listOfNotNull(e.term, e.abbreviation) + e.aliases }.map { it.lowercase() }
        val dupes = names.groupBy { it }.filter { it.value.size > 1 }.keys
        assertTrue(dupes.isEmpty(), "duplicate names: $dupes")
        for (e in Glossary.entries) for (r in e.related) assertNotNull(Glossary.find(r), "${e.term} → missing related '$r'")
        GlossaryCategory.entries.forEach { c -> assertTrue(Glossary.entries.any { it.category == c }, "empty category $c") }
        assertTrue(Glossary.entries.size >= 100, "entries: ${Glossary.entries.size}")
    }

    @Test
    fun `every abbreviation the app shows is explained`() {
        val used = listOf(
            "VPIP", "PFR", "AF", "WTSD", "W\$SD", "SPR", "MDF", "EV", "BB", "SB", "BTN", "CO", "HJ", "UTG", "IP", "OOP",
            "GTO", "CFR", "SNG", "HU", "OESD", "c-bet", "3-bet", "4-bet", "bb/100", "HUD", "ICM", "TAG", "LAG", "FD",
        )
        used.forEach { assertNotNull(Glossary.find(it), "missing $it") }
    }

    @Test
    fun `search finds terms by abbreviation, alias and description`() {
        assertEquals("Voluntarily put money in pot", Glossary.search("vpip").first().term)
        assertEquals("Open-ended straight draw", Glossary.search("oesd").first().term)
        assertEquals("All-in", Glossary.search("shove").first().term)
        assertTrue(Glossary.search("gutshot").first().term == "Gutshot")
        assertTrue(Glossary.search("dealer").any { it.term == "Button" })
        assertTrue(Glossary.search("", GlossaryCategory.STATS).all { it.category == GlossaryCategory.STATS })
    }

    @Test
    fun `every review concept links to a glossary entry`() {
        Concept.entries.forEach { assertNotNull(Glossary.forConcept(it)) }
    }
}
