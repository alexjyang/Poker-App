package com.pokercoach.engine

import com.pokercoach.engine.analysis.EquityCalculator
import com.pokercoach.engine.analysis.HandAnalyzer
import com.pokercoach.engine.analysis.HandAnatomyAnalyzer
import com.pokercoach.engine.card.Card
import com.pokercoach.engine.game.Blinds
import com.pokercoach.engine.game.HandEngine
import com.pokercoach.engine.game.PlayerAction
import com.pokercoach.engine.game.SeatedPlayer
import com.pokercoach.engine.range.PreflopRanking
import com.pokercoach.engine.rng.SeededRandom
import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertNotNull
import kotlin.test.assertTrue

class AnatomyTest {
    private fun made(hole: String, board: String) = HandAnatomyAnalyzer.describeMade(Card.parseList(hole), Card.parseList(board))
    private fun draws(hole: String, board: String) = HandAnatomyAnalyzer.findDraws(Card.parseList(hole), Card.parseList(board))

    @Test
    fun `made hands are described relative to the board`() {
        assertEquals("Top pair (jacks), top kicker", made("AsJd", "Jc7h3s"))
        assertEquals("Second pair (sevens)", made("7dAs", "Jc7h3s").substringBefore(","))
        assertEquals("Overpair (queens)", made("QcQd", "Jh8s4d"))
        assertTrue(made("5c5d", "Kd5h2s").startsWith("Set of fives"))
        assertEquals("Nut flush (king-high)", made("KhQh", "Ah9h4hTs2c"))
        assertTrue(made("2c3d", "AsKsQsJsTs").startsWith("Playing the board"))
        assertEquals("Pocket aces", made("AhAd", ""))
        assertEquals("Ace-king suited (connected)", made("AhKh", ""))
    }

    @Test
    fun `draws and outs are counted exactly`() {
        val d = draws("9h8h", "Th7c2h")
        assertEquals(9, d.first { it.label.startsWith("Flush draw") }.outs)
        assertEquals(8, d.first { it.label.startsWith("Open-ended") }.outs)
        assertEquals(15, d.flatMap { it.cards }.distinct().size, "the 9h... overlap: J and 6 of hearts count once")
        assertTrue(draws("AhKh", "Qh7h2c").any { it.label.startsWith("Nut flush draw") })
        assertTrue(draws("8h7h", "Qh5h2c").none { it.label.startsWith("Nut") }, "an 8-high flush draw isn't the nuts")
        assertEquals(4, draws("Jc9d", "Qs8h2c").first { it.label.startsWith("Gutshot") }.outs)
        assertTrue(draws("AsKd", "7h5c2s").any { it.label.startsWith("Two overcards") && it.outs == 6 })
    }

    @Test
    fun `the equity breakdown adds up and hit odds are exact`() {
        val villain = PreflopRanking.top(0.25)
        val hole = Card.parseList("AhKh")
        val board = Card.parseList("Qh7h2c")
        val eq = EquityCalculator.vsRanges(hole, board, listOf(villain), 4000, SeededRandom(1)).equity
        val a = HandAnatomyAnalyzer.analyze(hole, board, listOf(villain), eq, SeededRandom(2))
        assertEquals(eq, a.slices.sumOf { it.contribution }, 0.01)
        assertTrue(a.slices.sumOf { it.frequency } in 0.97..1.0001)
        assertEquals(15, a.outCards.size)
        assertEquals(15.0 / 47, a.hitNext!!, 1e-12)
        assertEquals(1 - (32.0 * 31) / (47.0 * 46), a.hitByRiver!!, 1e-12)
        assertTrue(a.slices.first().hand == "Flush", "the flush is the biggest source of equity")
        assertTrue(a.explanation.contains("15 cards improve you"))
    }

    @Test
    fun `every reviewed decision explains the hand`() {
        val ps = listOf(SeatedPlayer(0, "h", "Hero", 1000), SeatedPlayer(1, "v", "Villain", 1000))
        val deck = riggedDeck(listOf("QcJc", "9h8h"), "Th7c2h5s4d")
        val h = HandEngine(ps, 0, Blinds(5, 10), seed = 1, presetDeck = deck)
        h.act(PlayerAction.BetOrRaise(25)); h.act(PlayerAction.Call)
        h.act(PlayerAction.BetOrRaise(30)) // villain leads the flop
        h.act(PlayerAction.Call)            // hero calls with the combo draw
        val d = HandAnalyzer(1500).analyze(h.events, 0, deck).decisions.last()
        val a = assertNotNull(d.anatomy)
        assertTrue(a.draws.size >= 2 && a.explanation.startsWith("You have nine-high"))
    }
}
