package com.pokercoach.engine.bot

import com.pokercoach.engine.card.Card
import com.pokercoach.engine.card.Rank
import com.pokercoach.engine.game.Chips
import com.pokercoach.engine.game.HandSnapshot
import com.pokercoach.engine.game.LegalActions
import com.pokercoach.engine.game.PlayerAction
import com.pokercoach.engine.game.Street
import com.pokercoach.engine.rng.SeededRandom
import kotlin.math.abs
import kotlin.math.ceil
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToLong

/** A bot sees only what a player at [seat] would see (see [com.pokercoach.engine.game.HandEngine.snapshotFor]). */
interface Bot {
    val styleLabel: String
    fun decide(view: HandSnapshot, seat: Int): PlayerAction
}

/**
 * A straightforward, reasonably solid bot for Stage 2. Stage 3 replaces the fixed constants
 * with personality profiles (Beginner → GTO-approx) and custom sliders.
 *
 * Preflop: Chen-formula hand score with position-dependent opening thresholds, 3-bets with
 * premiums, calls raises only with hands that play well for the price, push/fold when short.
 * Postflop: Monte Carlo equity vs. the live opponents, compared against pot odds; value bets
 * strong hands, occasionally bluffs, discounts its equity when facing aggression (a bettor's
 * range is stronger than a random hand).
 *
 * Randomness only mixes between close options; decisions are driven by the numbers.
 */
class BasicBot(seed: Long, private val iterations: Int = 600) : Bot {
    override val styleLabel = "Solid"
    private val rng = SeededRandom(seed)

    override fun decide(view: HandSnapshot, seat: Int): PlayerAction {
        val legal = requireNotNull(view.legalActions) { "Not this bot's turn" }
        require(legal.seat == seat) { "Seat $seat asked to act, but ${legal.seat} is to act" }
        val hole = requireNotNull(view.seat(seat).holeCards) { "Bot must see its own cards" }
        return if (view.street == Street.PREFLOP) preflop(view, seat, legal, hole)
        else postflop(view, seat, legal, hole)
    }

    // --------------------------------------------------------------- preflop

    private fun preflop(view: HandSnapshot, seat: Int, legal: LegalActions, hole: List<Card>): PlayerAction {
        val bb = view.blinds.bigBlind
        val me = view.seat(seat)
        val stackBb = (me.stack + me.streetCommit).toDouble() / bb
        val score = chenScore(hole)
        val lateness = lateness(view, seat) // 0 = first to act, 1 = button
        val facingRaise = view.currentBet > bb
        val raisers = if (facingRaise) (view.currentBet.toDouble() / bb) else 1.0

        // Short stack: push or fold.
        if (stackBb <= 12) {
            val pushAt = if (facingRaise) 9.5 else 8.0 - 2.5 * lateness
            return if (score >= pushAt) allInOrCall(legal) else checkOrFold(legal)
        }

        if (!facingRaise) {
            val base = when {
                view.seats.size >= 7 -> 8.5
                view.seats.size >= 4 -> 7.5
                else -> 6.0
            }
            val openAt = base - 3.0 * lateness
            return when {
                score >= openAt && legal.canRaise -> raiseTo(legal, (bb * (2.5 + if (lateness < 0.3) 0.5 else 0.0)).roundToLong() + limpersBonus(view, bb))
                legal.canCheck -> PlayerAction.Check            // big blind option
                score >= openAt - 1.5 && rng.nextDouble() < 0.15 -> PlayerAction.Call // occasional limp
                else -> PlayerAction.Fold
            }
        }

        // Facing a raise.
        val callCostBb = legal.toCall.toDouble() / bb
        val threeBetAt = if (raisers > 8) 13.0 else 11.0
        return when {
            score >= threeBetAt && legal.canRaise -> raiseTo(legal, view.currentBet * 3)
            score >= threeBetAt - 1 && legal.canRaise && rng.nextDouble() < 0.3 -> raiseTo(legal, view.currentBet * 3)
            score >= 7 && callCostBb <= stackBb * 0.12 -> PlayerAction.Call
            score >= 5 && callCostBb <= 3.0 && lateness > 0.5 -> PlayerAction.Call
            legal.canCheck -> PlayerAction.Check
            else -> PlayerAction.Fold
        }
    }

    private fun limpersBonus(view: HandSnapshot, bb: Chips): Chips {
        val limpers = view.seats.count { it.streetCommit == bb && it.seat != view.bigBlindSeat }
        return limpers * bb
    }

    // --------------------------------------------------------------- postflop

    private fun postflop(view: HandSnapshot, seat: Int, legal: LegalActions, hole: List<Card>): PlayerAction {
        val opponents = view.seats.count { !it.folded && it.seat != seat }
        val rawEquity = QuickEquity.vsRandom(hole, view.board, opponents, iterations, rng)
        val pot = view.pot
        val facingBet = legal.toCall > 0

        if (!facingBet) {
            val bluffChance = if (opponents == 1) 0.12 else 0.04
            return when {
                rawEquity > 0.70 && legal.canRaise -> raiseTo(legal, (pot * 0.66).roundToLong())
                rawEquity > 0.55 && legal.canRaise && rng.nextDouble() < 0.5 -> raiseTo(legal, (pot * 0.5).roundToLong())
                rawEquity < 0.30 && legal.canRaise && rng.nextDouble() < bluffChance -> raiseTo(legal, (pot * 0.5).roundToLong())
                else -> PlayerAction.Check
            }
        }

        // Facing a bet: a bettor's range beats random hands, so discount equity by bet size.
        val betFraction = legal.toCall.toDouble() / max(1, pot - legal.toCall)
        val equity = rawEquity - 0.08 - 0.08 * min(betFraction, 1.5)
        val required = legal.toCall.toDouble() / (pot + legal.toCall) // pot odds
        return when {
            equity > 0.72 && legal.canRaise && rng.nextDouble() < 0.6 ->
                raiseTo(legal, view.currentBet * 3)
            equity >= required -> PlayerAction.Call
            abs(equity - required) < 0.04 && rng.nextDouble() < 0.4 -> PlayerAction.Call // close: mix
            else -> PlayerAction.Fold
        }
    }

    // --------------------------------------------------------------- helpers

    /** 0.0 for the first player to act preflop, 1.0 for the button. */
    private fun lateness(view: HandSnapshot, seat: Int): Double {
        val seats = view.seats.map { it.seat }
        val n = seats.size
        if (n <= 2) return if (seat == view.buttonSeat) 0.8 else 0.5
        val btnIdx = seats.indexOf(view.buttonSeat)
        val myIdx = seats.indexOf(seat)
        // Distance clockwise from the first seat after the big blind (UTG) to me.
        val utgIdx = (btnIdx + 3) % n
        val dist = (myIdx - utgIdx + n) % n
        return (dist.toDouble() / (n - 1)).coerceIn(0.0, 1.0)
    }

    private fun raiseTo(legal: LegalActions, target: Chips): PlayerAction {
        if (!legal.canRaise) return if (legal.canCheck) PlayerAction.Check else PlayerAction.Call
        val to = target.coerceIn(legal.minRaiseTo, legal.maxRaiseTo)
        // Don't leave a silly sliver behind: jam if the raise commits most of the stack.
        return if (to >= legal.maxRaiseTo * 0.85) PlayerAction.BetOrRaise(legal.maxRaiseTo)
        else PlayerAction.BetOrRaise(to)
    }

    private fun allInOrCall(legal: LegalActions): PlayerAction = when {
        legal.canRaise -> PlayerAction.BetOrRaise(legal.maxRaiseTo)
        legal.canCall -> PlayerAction.Call
        else -> PlayerAction.Check
    }

    private fun checkOrFold(legal: LegalActions) = if (legal.canCheck) PlayerAction.Check else PlayerAction.Fold

    companion object {
        /**
         * Bill Chen's preflop hand score (roughly -1 to 20). AA = 20, AKs = 12, 72o = -1.
         */
        fun chenScore(hole: List<Card>): Double {
            require(hole.size == 2)
            val (hi, lo) = hole.sortedByDescending { it.rank.ordinal }
            fun points(r: Rank) = when (r) {
                Rank.ACE -> 10.0; Rank.KING -> 8.0; Rank.QUEEN -> 7.0; Rank.JACK -> 6.0
                else -> (r.ordinal + 2) / 2.0
            }
            if (hi.rank == lo.rank) return max(5.0, points(hi.rank) * 2)
            var score = points(hi.rank)
            if (hi.suit == lo.suit) score += 2
            val gap = hi.rank.ordinal - lo.rank.ordinal - 1
            score -= when (gap) { 0 -> 0.0; 1 -> 1.0; 2 -> 2.0; 3 -> 4.0; else -> 5.0 }
            if (gap <= 1 && hi.rank < Rank.QUEEN) score += 1
            return ceil(score)
        }
    }
}
