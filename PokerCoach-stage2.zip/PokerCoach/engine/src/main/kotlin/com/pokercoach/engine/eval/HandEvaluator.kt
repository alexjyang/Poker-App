package com.pokercoach.engine.eval

import com.pokercoach.engine.card.Card
import com.pokercoach.engine.card.CardMask
import com.pokercoach.engine.card.Rank

enum class HandCategory(val displayName: String) {
    HIGH_CARD("High Card"), PAIR("One Pair"), TWO_PAIR("Two Pair"), THREE_OF_A_KIND("Three of a Kind"),
    STRAIGHT("Straight"), FLUSH("Flush"), FULL_HOUSE("Full House"), FOUR_OF_A_KIND("Four of a Kind"),
    STRAIGHT_FLUSH("Straight Flush"),
}

/**
 * A totally ordered hand strength. Higher [raw] = stronger; equal [raw] = exact tie.
 *
 * Layout (30 bits): `category << 26 | primary << 13 | kickers`, where primary and kickers are
 * 13-bit rank masks. Comparing masks with the same number of bits set is equivalent to comparing
 * the ranks in descending order, so plain Int comparison gives correct poker ordering.
 */
@JvmInline
value class HandValue(val raw: Int) : Comparable<HandValue> {
    val category: HandCategory get() = HandCategory.entries[raw ushr 26]
    private val primary: Int get() = (raw ushr 13) and 0x1FFF
    private val kickers: Int get() = raw and 0x1FFF

    override fun compareTo(other: HandValue): Int = raw.compareTo(other.raw)

    /** Human-readable description, e.g. "Full House, Kings full of Sevens". */
    fun describe(): String {
        fun ranksOf(mask: Int): List<Rank> = (12 downTo 0).filter { mask and (1 shl it) != 0 }.map { Rank.entries[it] }
        val p = ranksOf(primary)
        val k = ranksOf(kickers)
        return when (category) {
            HandCategory.STRAIGHT_FLUSH ->
                if (p[0] == Rank.ACE) "Royal Flush" else "Straight Flush, ${p[0].displayName} high"
            HandCategory.FOUR_OF_A_KIND -> "Four of a Kind, ${p[0].pluralName}"
            HandCategory.FULL_HOUSE -> "Full House, ${p[0].pluralName} full of ${k[0].pluralName}"
            HandCategory.FLUSH -> "Flush, ${p[0].displayName} high"
            HandCategory.STRAIGHT -> "Straight, ${p[0].displayName} high"
            HandCategory.THREE_OF_A_KIND -> "Three of a Kind, ${p[0].pluralName}"
            HandCategory.TWO_PAIR -> "Two Pair, ${p[0].pluralName} and ${p[1].pluralName}"
            HandCategory.PAIR -> "Pair of ${p[0].pluralName}"
            HandCategory.HIGH_CARD -> "High Card, ${p[0].displayName}"
        }.let { base ->
            // Kickers matter for pair / two pair / trips / quads / high card ties; mention them.
            if (category in KICKER_CATEGORIES && k.isNotEmpty()) {
                val shown = if (category == HandCategory.HIGH_CARD) p.drop(1) + k else k
                if (shown.isEmpty()) base else "$base (${shown.joinToString("-") { it.symbol.toString() }} kicker)"
            } else base
        }
    }

    override fun toString(): String = describe()

    private companion object {
        val KICKER_CATEGORIES = setOf(
            HandCategory.HIGH_CARD, HandCategory.PAIR, HandCategory.TWO_PAIR,
            HandCategory.THREE_OF_A_KIND, HandCategory.FOUR_OF_A_KIND,
        )
    }
}

/**
 * Allocation-free bitwise evaluator for 5, 6 or 7 cards.
 *
 * Input is a 52-bit card mask (see [Card]). Work per call: four 13-bit suit masks, a handful of
 * AND/OR/XOR ops to find pairs/trips/quads, and one 8 KB lookup table for straights.
 * Typically 20–40 ns per 7-card hand on a mid-range phone — cheap enough for Monte Carlo.
 *
 * The early flush return is only valid for ≤ 7 cards: with 7 cards, a flush can never coexist
 * with quads or a full house, so the flush branch cannot hide a stronger hand.
 */
object HandEvaluator {
    private const val WHEEL = 0b1_0000_0000_1111 // A,5,4,3,2

    /** STRAIGHT_HIGH[rankMask] = rank index of the straight's top card, or -1. */
    private val STRAIGHT_HIGH = IntArray(1 shl 13) { m ->
        val runs = m and (m ushr 1) and (m ushr 2) and (m ushr 3) and (m ushr 4)
        when {
            runs != 0 -> 31 - Integer.numberOfLeadingZeros(runs) + 4
            m and WHEEL == WHEEL -> Rank.FIVE.ordinal
            else -> -1
        }
    }

    private fun make(cat: HandCategory, primary: Int, kickers: Int): Int =
        (cat.ordinal shl 26) or (primary shl 13) or kickers

    /** Keeps the [n] highest set bits of [mask]. */
    private fun top(mask: Int, n: Int): Int {
        var m = mask
        var out = 0
        repeat(n) {
            if (m == 0) return out
            val hb = Integer.highestOneBit(m)
            out = out or hb
            m = m xor hb
        }
        return out
    }

    /** Evaluates a 5–7 card mask. Hot path: no validation, no allocation. */
    fun evaluateMask(mask: Long): Int {
        val c = (mask and 0x1FFF).toInt()
        val d = ((mask ushr 13) and 0x1FFF).toInt()
        val h = ((mask ushr 26) and 0x1FFF).toInt()
        val s = ((mask ushr 39) and 0x1FFF).toInt()

        val flush = when {
            Integer.bitCount(c) >= 5 -> c
            Integer.bitCount(d) >= 5 -> d
            Integer.bitCount(h) >= 5 -> h
            Integer.bitCount(s) >= 5 -> s
            else -> 0
        }
        if (flush != 0) {
            val sf = STRAIGHT_HIGH[flush]
            return if (sf >= 0) make(HandCategory.STRAIGHT_FLUSH, 1 shl sf, 0)
            else make(HandCategory.FLUSH, top(flush, 5), 0)
        }

        val ranks = c or d or h or s
        val quads = c and d and h and s
        if (quads != 0) return make(HandCategory.FOUR_OF_A_KIND, quads, top(ranks and quads.inv(), 1))

        val atLeast3 = (c and d and h) or (c and d and s) or (c and h and s) or (d and h and s)
        val atLeast2 = (c and d) or (c and h) or (c and s) or (d and h) or (d and s) or (h and s)
        val trips = atLeast3
        val pairs = atLeast2 and atLeast3.inv()

        if (trips != 0) {
            val topTrip = Integer.highestOneBit(trips)
            val pairCandidates = pairs or (trips xor topTrip)
            if (pairCandidates != 0) {
                return make(HandCategory.FULL_HOUSE, topTrip, Integer.highestOneBit(pairCandidates))
            }
        }

        val st = STRAIGHT_HIGH[ranks]
        if (st >= 0) return make(HandCategory.STRAIGHT, 1 shl st, 0)

        if (trips != 0) return make(HandCategory.THREE_OF_A_KIND, trips, top(ranks and trips.inv(), 2))

        if (Integer.bitCount(pairs) >= 2) {
            val twoPairs = top(pairs, 2)
            return make(HandCategory.TWO_PAIR, twoPairs, top(ranks and twoPairs.inv(), 1))
        }
        if (pairs != 0) return make(HandCategory.PAIR, pairs, top(ranks and pairs.inv(), 3))

        val five = top(ranks, 5)
        val highest = Integer.highestOneBit(five)
        return make(HandCategory.HIGH_CARD, highest, five xor highest)
    }

    fun evaluate(mask: Long): HandValue {
        val n = CardMask.count(mask)
        require(n in 5..7) { "Evaluator needs 5-7 cards, got $n" }
        return HandValue(evaluateMask(mask))
    }

    fun evaluate(cards: Collection<Card>): HandValue {
        val mask = CardMask.of(cards)
        require(CardMask.count(mask) == cards.size) { "Duplicate cards in $cards" }
        return evaluate(mask)
    }

    fun evaluate(hole: Collection<Card>, board: Collection<Card>): HandValue = evaluate(hole + board)

    /** The five cards that make the hand (for highlighting at showdown). */
    fun bestFive(cards: List<Card>): List<Card> {
        require(cards.size in 5..7)
        val target = evaluate(cards).raw
        val n = cards.size
        for (a in 0 until n) for (b in a + 1 until n) for (c in b + 1 until n)
            for (d in c + 1 until n) for (e in d + 1 until n) {
                val five = listOf(cards[a], cards[b], cards[c], cards[d], cards[e])
                if (evaluateMask(CardMask.of(five)) == target) return five.sortedDescending()
            }
        error("unreachable")
    }
}
