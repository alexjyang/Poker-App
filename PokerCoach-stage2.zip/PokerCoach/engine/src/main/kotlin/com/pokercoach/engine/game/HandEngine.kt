package com.pokercoach.engine.game

import com.pokercoach.engine.card.Card
import com.pokercoach.engine.card.Deck
import com.pokercoach.engine.eval.HandEvaluator

class IllegalActionException(message: String) : IllegalArgumentException(message)

/**
 * Runs one hand of No-Limit Texas Hold'em as a deterministic state machine.
 *
 * Usage: construct it (blinds, antes and hole cards are dealt immediately), then repeatedly read
 * [legalActions] for [actorSeat] and call [act] until [isComplete]. Board run-outs, uncalled-bet
 * refunds, side pots and showdown happen automatically. Every step is appended to [events].
 *
 * Not thread-safe by design: one coroutine (the table's game loop) owns an engine instance.
 *
 * Rules implemented:
 *  - Heads-up: button posts the small blind, acts first preflop and last postflop.
 *  - Short blinds/antes are posted all-in; callers must still match the full big blind.
 *  - Per-player antes are posted before blinds; a big-blind ante is posted after the big blind.
 *  - Min raise = size of the last full bet/raise (at least one big blind).
 *  - An all-in raise smaller than a full raise does not reopen betting for players who already
 *    acted, unless the total increase they now face is at least a full raise (TDA-style).
 *  - Raising is disabled when every opponent is already all-in.
 *  - Odd chips go to the first winner left of the button.
 */
class HandEngine(
    players: List<SeatedPlayer>,
    val buttonSeat: Int,
    val blinds: Blinds,
    val seed: Long,
    val handNumber: Long = 1,
    /** Explicit deck order (tests, puzzles, imported hands). Defaults to shuffling from [seed]. */
    presetDeck: List<Card>? = null,
) {
    private class P(val info: SeatedPlayer) {
        val seat get() = info.seat
        var stack: Chips = info.stack
        var hole: List<Card> = emptyList()
        var folded = false
        var streetCommit: Chips = 0
        var totalCommit: Chips = 0
        var acted = false
        var betLevelWhenActed: Chips = 0
        var minRaiseWhenActed: Chips = 0
        val allIn get() = stack == 0L && !folded
        val canAct get() = !folded && stack > 0
    }

    private val ps: List<P>
    private val deck = presetDeck?.let { Deck.fromOrder(it, seed) } ?: Deck(seed)
    private val _board = mutableListOf<Card>()
    private val _events = mutableListOf<HandEvent>()
    private val revealed = mutableSetOf<Int>()

    var street: Street = Street.PREFLOP
        private set
    /** Highest street total anyone must match. */
    var currentBet: Chips = 0
        private set
    /** Size of the last full bet or raise; the next raise must add at least this much. */
    var minRaise: Chips = 0
        private set
    private var actorIdx: Int = -1
    var isComplete = false
        private set

    private val btnIdx: Int
    private val sbIdx: Int
    private val bbIdx: Int

    val board: List<Card> get() = _board.toList()
    val events: List<HandEvent> get() = _events.toList()
    val deckCommitment: String get() = deck.commitment
    val actorSeat: Int? get() = if (isComplete || actorIdx < 0) null else ps[actorIdx].seat
    val pot: Chips get() = ps.sumOf { it.totalCommit }

    init {
        require(players.size >= 2) { "Need at least 2 players" }
        require(players.size <= 9) { "At most 9 players" }
        require(players.map { it.seat }.toSet().size == players.size) { "Duplicate seats" }
        require(players.all { it.stack > 0 }) { "Players with no chips must not be dealt in" }
        ps = players.sortedBy { it.seat }.map(::P)
        btnIdx = ps.indexOfFirst { it.seat == buttonSeat }
        require(btnIdx >= 0) { "Button seat $buttonSeat is not dealt in" }
        val n = ps.size
        sbIdx = if (n == 2) btnIdx else (btnIdx + 1) % n
        bbIdx = (sbIdx + 1) % n

        _events += HandEvent.HandStarted(handNumber, seed, deck.commitment, buttonSeat, blinds, players.sortedBy { it.seat })
        postForcedBets()
        dealHoleCards()
        currentBet = blinds.bigBlind
        minRaise = blinds.bigBlind
        proceed(startIdx = (bbIdx + 1) % n)
    }

    // ---------------------------------------------------------------- setup

    private fun postForcedBets() {
        fun postAnte(p: P, amount: Chips) {
            val a = minOf(amount, p.stack)
            if (a <= 0) return
            p.stack -= a; p.totalCommit += a // dead money: not part of streetCommit
            _events += HandEvent.AntePosted(p.seat, a, p.stack == 0L)
        }
        fun postBlind(p: P, amount: Chips, big: Boolean) {
            val a = minOf(amount, p.stack)
            if (a <= 0) return
            p.stack -= a; p.streetCommit += a; p.totalCommit += a
            _events += HandEvent.BlindPosted(p.seat, a, big, p.stack == 0L)
        }
        if (blinds.ante > 0 && blinds.anteType == AnteType.EACH_PLAYER) {
            orderFrom((btnIdx + 1) % ps.size).forEach { postAnte(it, blinds.ante) }
        }
        postBlind(ps[sbIdx], blinds.smallBlind, big = false)
        postBlind(ps[bbIdx], blinds.bigBlind, big = true)
        if (blinds.ante > 0 && blinds.anteType == AnteType.BIG_BLIND_ANTE) {
            postAnte(ps[bbIdx], blinds.ante)
        }
    }

    private fun dealHoleCards() {
        val order = orderFrom((btnIdx + 1) % ps.size) // first card to the player left of the button
        val cards = order.associateWith { mutableListOf<Card>() }
        repeat(2) { order.forEach { cards.getValue(it) += deck.deal() } }
        order.forEach { p ->
            p.hole = cards.getValue(p).toList()
            _events += HandEvent.HoleCardsDealt(p.seat, p.hole)
        }
    }

    // ---------------------------------------------------------------- queries

    private fun orderFrom(start: Int): List<P> = List(ps.size) { ps[(start + it) % ps.size] }

    /** Seats in order starting left of the button (used for odd chips and reveal order). */
    val seatOrderFromButton: List<Int> get() = orderFrom((btnIdx + 1) % ps.size).map { it.seat }

    private fun needsAction(p: P) = p.canAct && (!p.acted || p.streetCommit < currentBet)

    private fun bettingClosed(): Boolean {
        val canAct = ps.filter { it.canAct }
        return if (canAct.size <= 1) canAct.none { it.streetCommit < currentBet }
        else canAct.none(::needsAction)
    }

    fun legalActions(): LegalActions? {
        if (isComplete || actorIdx < 0) return null
        val p = ps[actorIdx]
        val owed = (currentBet - p.streetCommit).coerceAtLeast(0)
        val toCall = minOf(owed, p.stack)
        val reopened = !p.acted ||
            p.betLevelWhenActed == 0L || // checked earlier; any bet now opens the action
            currentBet - p.betLevelWhenActed >= p.minRaiseWhenActed
        val opponentCanRespond = ps.any { it !== p && it.canAct }
        val maxTo = p.streetCommit + p.stack
        val canRaise = reopened && opponentCanRespond && p.stack > owed
        return LegalActions(
            seat = p.seat,
            canCheck = owed == 0L,
            toCall = toCall,
            callIsAllIn = owed > 0 && toCall == p.stack,
            canRaise = canRaise,
            isBet = currentBet == 0L,
            minRaiseTo = if (canRaise) minOf(currentBet + minRaise, maxTo) else 0,
            maxRaiseTo = if (canRaise) maxTo else 0,
        )
    }

    // ---------------------------------------------------------------- actions

    /** Applies [action] for the player to act. Throws [IllegalActionException] if not legal. */
    fun act(action: PlayerAction) {
        val legal = legalActions() ?: throw IllegalActionException("Hand is complete")
        val p = ps[actorIdx]
        val potBefore = pot
        val stackBefore = p.stack

        val resolved: PlayerAction = when (action) {
            PlayerAction.AllIn -> when {
                p.stack <= legal.toCall -> PlayerAction.Call
                legal.canRaise -> PlayerAction.BetOrRaise(legal.maxRaiseTo)
                else -> throw IllegalActionException("Cannot go all-in: betting was not reopened")
            }
            else -> action
        }

        val type: ActionType
        when (resolved) {
            PlayerAction.Fold -> { p.folded = true; type = ActionType.FOLD }
            PlayerAction.Check -> {
                if (!legal.canCheck) throw IllegalActionException("Cannot check facing ${legal.toCall}")
                type = ActionType.CHECK
            }
            PlayerAction.Call -> {
                if (!legal.canCall) throw IllegalActionException("Nothing to call; check instead")
                commit(p, legal.toCall); type = ActionType.CALL
            }
            is PlayerAction.BetOrRaise -> {
                val to = resolved.to
                if (!legal.canRaise) throw IllegalActionException("Raising is not allowed here")
                if (to > legal.maxRaiseTo) throw IllegalActionException("Raise to $to exceeds stack (max ${legal.maxRaiseTo})")
                if (to < legal.minRaiseTo) throw IllegalActionException("Raise to $to below minimum ${legal.minRaiseTo}")
                val increase = to - currentBet
                type = if (currentBet == 0L) ActionType.BET else ActionType.RAISE
                if (increase >= minRaise) minRaise = increase // full raise; short all-ins leave it unchanged
                currentBet = to
                commit(p, to - p.streetCommit)
            }
            PlayerAction.AllIn -> error("resolved above")
        }

        if (!p.folded) {
            p.acted = true
            p.betLevelWhenActed = currentBet
            p.minRaiseWhenActed = minRaise
        }
        _events += HandEvent.ActionTaken(
            seat = p.seat, street = street, type = type,
            amountAdded = stackBefore - p.stack, streetTotal = p.streetCommit, isAllIn = p.allIn,
            potBefore = potBefore, toCallBefore = legal.toCall, stackBefore = stackBefore,
        )
        proceed(startIdx = (actorIdx + 1) % ps.size)
    }

    private fun commit(p: P, amount: Chips) {
        require(amount in 0..p.stack)
        p.stack -= amount; p.streetCommit += amount; p.totalCommit += amount
    }

    // ---------------------------------------------------------------- flow

    private fun proceed(startIdx: Int) {
        var start = startIdx
        while (true) {
            if (ps.count { !it.folded } == 1) { finishUncontested(); return }
            if (bettingClosed()) {
                endStreet()
                if (isComplete) return
                start = (btnIdx + 1) % ps.size
                continue
            }
            actorIdx = (0 until ps.size).map { (start + it) % ps.size }.first { needsAction(ps[it]) }
            return
        }
    }

    private fun refundUncalled() {
        val refund = PotCalculator.uncalledBet(ps.map { Contribution(it.seat, it.totalCommit, it.folded) }) ?: return
        val p = ps.first { it.seat == refund.first }
        val amount = refund.second
        p.stack += amount
        p.totalCommit -= amount
        p.streetCommit = (p.streetCommit - amount).coerceAtLeast(0)
        _events += HandEvent.UncalledBetReturned(p.seat, amount)
    }

    private fun endStreet() {
        refundUncalled()
        ps.forEach { it.streetCommit = 0; it.acted = false; it.betLevelWhenActed = 0; it.minRaiseWhenActed = 0 }
        currentBet = 0
        minRaise = blinds.bigBlind
        actorIdx = -1
        when (street) {
            Street.PREFLOP -> dealBoard(Street.FLOP, 3)
            Street.FLOP -> dealBoard(Street.TURN, 1)
            Street.TURN -> dealBoard(Street.RIVER, 1)
            Street.RIVER -> showdown()
            Street.SHOWDOWN -> error("Hand already at showdown")
        }
    }

    private fun dealBoard(next: Street, count: Int) {
        deck.burn()
        val cards = List(count) { deck.deal() }
        _board += cards
        street = next
        _events += HandEvent.BoardDealt(next, cards)
    }

    private fun finishUncontested() {
        refundUncalled()
        val winner = ps.single { !it.folded }
        val amount = pot
        winner.stack += amount
        _events += HandEvent.PotAwarded(0, amount, listOf(winner.seat), mapOf(winner.seat to amount), false, null)
        finish()
    }

    private fun showdown() {
        street = Street.SHOWDOWN
        val order = orderFrom((btnIdx + 1) % ps.size).filterNot { it.folded }
        val values = order.associate { p ->
            val v = HandEvaluator.evaluate(p.hole + _board)
            revealed += p.seat
            _events += HandEvent.ShowdownHand(p.seat, p.hole, v.raw, v.describe())
            p.seat to v
        }
        val pots = PotCalculator.buildPots(ps.map { Contribution(it.seat, it.totalCommit, it.folded) })
        pots.forEachIndexed { i, pot ->
            val best = pot.eligibleSeats.maxOf { values.getValue(it).raw }
            val winners = pot.eligibleSeats.filter { values.getValue(it).raw == best }
            val shares = PotCalculator.split(pot.amount, winners, seatOrderFromButton)
            shares.forEach { (seat, chips) -> ps.first { it.seat == seat }.stack += chips }
            _events += HandEvent.PotAwarded(
                potIndex = i, amount = pot.amount, winners = shares.keys.toList(), shares = shares,
                wonAtShowdown = pot.eligibleSeats.size > 1,
                description = values.getValue(winners.first()).describe(),
            )
        }
        finish()
    }

    private fun finish() {
        isComplete = true
        actorIdx = -1
        ps.forEach { it.streetCommit = 0 }
        _events += HandEvent.HandEnded(
            finalStacks = ps.associate { it.seat to it.stack },
            netResults = ps.associate { it.seat to it.stack - it.info.stack },
        )
    }

    // ---------------------------------------------------------------- snapshots

    /**
     * Full-information snapshot. Use [snapshotFor] for anything shown to a player or bot, so
     * nobody can see cards they shouldn't (bots can't cheat by construction).
     */
    fun snapshot(): HandSnapshot = buildSnapshot(viewerSeat = null)

    fun snapshotFor(viewerSeat: Int): HandSnapshot = buildSnapshot(viewerSeat)

    private fun buildSnapshot(viewerSeat: Int?): HandSnapshot = HandSnapshot(
        handNumber = handNumber,
        street = street,
        board = board,
        pot = pot,
        currentBet = currentBet,
        minRaise = minRaise,
        buttonSeat = buttonSeat,
        smallBlindSeat = ps[sbIdx].seat,
        bigBlindSeat = ps[bbIdx].seat,
        blinds = blinds,
        actorSeat = actorSeat,
        legalActions = legalActions(),
        isComplete = isComplete,
        seats = ps.map { p ->
            val visible = viewerSeat == null || viewerSeat == p.seat || p.seat in revealed
            SeatView(
                seat = p.seat, playerId = p.info.playerId, name = p.info.name,
                stack = p.stack, streetCommit = p.streetCommit, totalCommit = p.totalCommit,
                folded = p.folded, allIn = p.allIn,
                holeCards = if (visible) p.hole else null,
            )
        },
    )
}

data class SeatView(
    val seat: Int,
    val playerId: String,
    val name: String,
    val stack: Chips,
    val streetCommit: Chips,
    val totalCommit: Chips,
    val folded: Boolean,
    val allIn: Boolean,
    /** Null when hidden from the viewer. */
    val holeCards: List<Card>?,
)

data class HandSnapshot(
    val handNumber: Long,
    val street: Street,
    val board: List<Card>,
    val pot: Chips,
    val currentBet: Chips,
    val minRaise: Chips,
    val buttonSeat: Int,
    val smallBlindSeat: Int,
    val bigBlindSeat: Int,
    val blinds: Blinds,
    val actorSeat: Int?,
    val legalActions: LegalActions?,
    val isComplete: Boolean,
    val seats: List<SeatView>,
) {
    fun seat(seat: Int): SeatView = seats.first { it.seat == seat }
}
