@file:OptIn(ExperimentalMaterial3Api::class)

package com.pokercoach.app.ui.home

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SegmentedButton
import androidx.compose.material3.SegmentedButtonDefaults
import androidx.compose.material3.SingleChoiceSegmentedButtonRow
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.pokercoach.app.game.BotSpeed
import com.pokercoach.app.game.GameConfig
import com.pokercoach.app.game.GameType
import kotlin.math.roundToInt

@Composable
fun HomeScreen(onStart: (GameConfig) -> Unit) {
    var type by rememberSaveable { mutableStateOf(GameType.CASH) }
    var players by rememberSaveable { mutableIntStateOf(6) }
    var stackBb by rememberSaveable { mutableIntStateOf(100) }
    var speed by rememberSaveable { mutableStateOf(BotSpeed.NORMAL) }

    Scaffold(
        topBar = { TopAppBar(title = { Text("PokerCoach", fontWeight = FontWeight.Bold) }) },
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 16.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(18.dp),
        ) {
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer),
                modifier = Modifier.fillMaxWidth(),
            ) {
                Column(Modifier.padding(16.dp)) {
                    Text("No-Limit Hold'em trainer", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(4.dp))
                    Text(
                        "Play against bots. Hand reviews with equity, pot odds and EV are coming in a later stage.",
                        style = MaterialTheme.typography.bodyMedium,
                    )
                }
            }

            Section("Game") {
                Choice(
                    options = GameType.entries,
                    selected = type,
                    label = { it.label },
                    onSelect = { type = it },
                )
            }

            Section("Players") {
                Choice(
                    options = listOf(2, 6, 9),
                    selected = players,
                    label = { n -> when (n) { 2 -> "Heads-up"; 6 -> "6-max"; else -> "Full ring" } },
                    onSelect = { players = it },
                )
            }

            if (type == GameType.CASH) {
                Section("Buy-in: $stackBb big blinds (${stackBb * GameConfig.CASH_BIG_BLIND} chips at 1/2)") {
                    Slider(
                        value = stackBb.toFloat(),
                        onValueChange = { stackBb = ((it / 10f).roundToInt() * 10).coerceIn(20, 200) },
                        valueRange = 20f..200f,
                        steps = 17,
                    )
                }
            } else {
                Text(
                    "Everyone starts with 1,500 chips. Blinds rise every ${GameConfig.SNG_HANDS_PER_LEVEL} hands; " +
                        "big-blind antes from level 5. Last player standing wins.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }

            Section("Bot speed") {
                Choice(
                    options = BotSpeed.entries,
                    selected = speed,
                    label = { it.label },
                    onSelect = { speed = it },
                )
            }

            Button(
                onClick = { onStart(GameConfig(type = type, players = players, startingBb = stackBb, speed = speed)) },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(56.dp),
            ) {
                Text("Take a seat", fontSize = 17.sp, fontWeight = FontWeight.Bold)
            }

            Text(
                "Preview build · Stage 2 of 6 · bots: Solid",
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            Spacer(Modifier.height(8.dp))
        }
    }
}

@Composable
private fun Section(title: String, content: @Composable () -> Unit) {
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text(title, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold)
        content()
    }
}

@Composable
private fun <T> Choice(options: List<T>, selected: T, label: (T) -> String, onSelect: (T) -> Unit) {
    SingleChoiceSegmentedButtonRow(Modifier.fillMaxWidth()) {
        options.forEachIndexed { index, option ->
            SegmentedButton(
                selected = option == selected,
                onClick = { onSelect(option) },
                shape = SegmentedButtonDefaults.itemShape(index = index, count = options.size),
            ) {
                Text(label(option), maxLines = 1)
            }
        }
    }
}
