package com.pokercoach.app.ui.table

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.pokercoach.app.game.BotIdentity
import com.pokercoach.app.game.BotRoster
import com.pokercoach.app.game.GameConfig
import com.pokercoach.app.game.GameType
import com.pokercoach.engine.bot.BasicBot
import com.pokercoach.engine.bot.Bot
import com.pokercoach.engine.game.ActionType
import com.pokercoach.engine.game.Blinds
import com.pokercoach.engine.game.HandEngine
import com.pokercoach.engine.game.HandEvent
import com.pokercoach.engine.game.IllegalActionException
import com.pokercoach.engine.game.PlayerAction
import com.pokercoach.engine.rng.SeededRandom
import com.pokercoach.engine.session.BlindSchedule
import com.pokercoach.engine.session.GameMode
import com.pokercoach.engine.session.PlayerProfile
import com.pokercoach.engine.session.TableSession
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.security.SecureRandom

/**
 * Owns the table: a [TableSession] from the engine, the bots, and the game loop.
 *
 * Threading: the loop runs in [viewModelScope] (main thread) and is the only code that touches
 * the engine, so no locking is needed. Bot thinking (Monte Carlo equity) runs on
 * [Dispatchers.Default] and only receives an immutable, card-hiding snapshot.
 *
 * The UI talks to the loop through two channels: hero actions and "deal next hand".
 */
class TableViewModel : ViewModel() {

    companion object {
        const val HERO_SEAT = 0
        private const val HERO_ID = "hero"
    }

    private val _state = MutableStateFlow(TableUiState())
    val state: StateFlow<TableUiState> = _state.asStateFlow()

    private var config = GameConfig()
    private var session: TableSession? = null
    private var schedule: BlindSchedule? = null
    private var engine: HandEngine? = null
    private var bots: Map<Int, Bot> = emptyMap()
    private var identities: Map<Int, BotIdentity> = emptyMap()
    private var gameJob: Job? = null

    private val heroActions = Channel<PlayerAction>(Channel.CONFLATED)
    private val dealNext = Channel<Unit>(Channel.CONFLATED)

    // Presentation-only state (never affects the game).
    private val lastActions = mutableMapOf<Int, String>()
    private var shownBoard = 0
    private var revealing = false
    private var pendingWinnings: Map<Int, Long> = emptyMap()
    private var winnings: Map<Int, Long> = emptyMap()
    private var result: HandResultUi? = null
    private var sessionOver: SessionOverUi? = null
    private var error: String? = null

    // ------------------------------------------------------------------ UI entry points

    fun start(newConfig: GameConfig) {
        gameJob?.cancel()
        config = newConfig
        val seed = SecureRandom().nextLong()

        val roster = BotRoster.pick(newConfig.players - 1, seed)
        identities = (1 until newConfig.players).associateWith { roster[it - 1] }
        val seating = buildMap {
            put(HERO_SEAT, PlayerProfile(HERO_ID, "You"))
            identities.forEach { (seat, id) -> put(seat, PlayerProfile(id.id, id.name)) }
        }
        val mode = when (newConfig.type) {
            GameType.CASH -> GameMode.Cash(
                blinds = Blinds(GameConfig.CASH_SMALL_BLIND, GameConfig.CASH_BIG_BLIND),
                buyIn = newConfig.startingBb * GameConfig.CASH_BIG_BLIND,
                autoRebuy = true,
            )
            GameType.SIT_AND_GO -> GameMode.SitAndGo(
                startingStack = GameConfig.SNG_STACK,
                schedule = BlindSchedule.turbo(GameConfig.SNG_HANDS_PER_LEVEL),
            ).also { schedule = it.schedule }
        }
        if (newConfig.type == GameType.CASH) schedule = null

        val s = TableSession(newConfig.players, mode, seating, seed)
        session = s
        bots = identities.keys.associateWith { seat -> BasicBot(seed = SeededRandom.derive(seed, 10_000L + seat)) }
        engine = null
        resetHandPresentation()
        sessionOver = null
        drain(heroActions)
        drain(dealNext)
        publish()
        gameJob = viewModelScope.launch {
            try {
                runSession(s)
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                // Should never happen (the engine is fuzz-tested), but never crash the app over it.
                error = "Something went wrong: ${e.message}. Please start a new game."
                publish()
            }
        }
    }

    /** Same settings, fresh seats and seed. */
    fun restart() = start(config)

    fun act(action: PlayerAction) {
        heroActions.trySend(action)
    }

    fun nextHand() {
        dealNext.trySend(Unit)
    }

    fun leave() {
        gameJob?.cancel()
        gameJob = null
        session = null
        engine = null
        _state.value = TableUiState()
    }

    fun dismissError() {
        error = null
        publish()
    }

    // ------------------------------------------------------------------ game loop

    private suspend fun runSession(s: TableSession) {
        while (true) {
            if (s.isFinished || heroEliminated(s)) {
                finishSession(s)
                return
            }
            val h = s.nextHand()
            engine = h
            resetHandPresentation()
            publish()
            delay(config.speed.pauseMs / 2)

            playHand(h)
            s.completeHand(h)
            revealRunout(h)
            announce(h, s)

            if (s.isFinished || heroEliminated(s)) {
                finishSession(s)
                return
            }
            drain(dealNext)
            dealNext.receive()
        }
    }

    private suspend fun playHand(h: HandEngine) {
        while (!h.isComplete) {
            val seat = h.actorSeat ?: break
            shownBoard = h.board.size
            publish()

            if (seat == HERO_SEAT) {
                drain(heroActions)
                val action = heroActions.receive()
                try {
                    h.act(action)
                    error = null
                } catch (e: IllegalActionException) {
                    error = e.message
                    continue
                }
            } else {
                val heroOut = h.snapshot().seats.firstOrNull { it.seat == HERO_SEAT }?.folded ?: true
                delay(if (heroOut) config.speed.thinkMs / 3 else config.speed.thinkMs)
                val view = h.snapshotFor(seat)
                val bot = bots.getValue(seat)
                val action = withContext(Dispatchers.Default) { bot.decide(view, seat) }
                h.act(action)
            }
            recordLastAction(h)

            if (h.isComplete) break
            publish()
            if (h.board.size > shownBoard) {
                // New street: let the player see the final action, then clear labels and deal.
                delay(config.speed.pauseMs)
                lastActions.clear()
                shownBoard = h.board.size
            }
        }
        pendingWinnings = winningsOf(h)
        revealing = true
    }

    /** After an all-in, deal the remaining board one street at a time for drama. */
    private suspend fun revealRunout(h: HandEngine) {
        publish()
        if (h.board.size > shownBoard) {
            delay(config.speed.pauseMs)
            while (shownBoard < h.board.size) {
                shownBoard = if (shownBoard < 3) 3 else shownBoard + 1
                publish()
                delay(config.speed.pauseMs + 250)
            }
        } else {
            delay(config.speed.pauseMs / 2)
        }
    }

    private fun announce(h: HandEngine, s: TableSession) {
        val awards = h.events.filterIsInstance<HandEvent.PotAwarded>()
        val ended = h.events.last() as HandEvent.HandEnded
        winnings = pendingWinnings
        revealing = false

        val heroNet = ended.netResults[HERO_SEAT] ?: 0L
        val heroWon = winnings[HERO_SEAT] ?: 0L
        val headline = when {
            heroWon > 0 && awards.all { HERO_SEAT in it.winners && it.winners.size == 1 } -> "You win ${chips(heroWon)}"
            heroWon > 0 -> "You collect ${chips(heroWon)}"
            else -> {
                val top = winnings.maxByOrNull { it.value }
                if (top == null) "Hand over" else "${nameOf(s, top.key)} wins ${chips(top.value)}"
            }
        }
        val details = awards.map { a ->
            val potName = when {
                awards.size == 1 -> "Pot"
                a.potIndex == 0 -> "Main pot"
                else -> "Side pot ${a.potIndex}"
            }
            val who = a.winners.joinToString(" & ") { nameOf(s, it) }
            val how = when {
                a.winners.size > 1 -> " split · ${a.description}"
                a.description != null && a.wonAtShowdown -> " · ${a.description}"
                else -> " · uncontested"
            }
            "$potName ${chips(a.amount)} → $who$how"
        }
        val rebought = config.type == GameType.CASH &&
            ended.finalStacks[HERO_SEAT] == 0L && s.stackOf(HERO_SEAT) > 0
        val footer = buildString {
            append("Hand #${h.handNumber} · seed ${java.lang.Long.toHexString(h.seed)}")
            if (rebought) append(" · auto-rebuy ${chips(s.stackOf(HERO_SEAT))}")
        }
        result = HandResultUi(headline, details, heroNet, footer)
        publish()
    }

    private fun finishSession(s: TableSession) {
        val place = s.finishes.firstOrNull { it.playerId == HERO_ID }?.place
        sessionOver = when {
            config.type != GameType.SIT_AND_GO -> SessionOverUi("Session over", "The table has broken up.")
            place == 1 -> SessionOverUi("You won the Sit & Go!", "First place out of ${config.players}. Well played.")
            place != null -> SessionOverUi("You finished ${ordinal(place)}", "Out of ${config.players} players. Try again?")
            else -> SessionOverUi("Game over", "")
        }
        publish()
    }

    // ------------------------------------------------------------------ helpers

    private fun heroEliminated(s: TableSession) =
        config.type == GameType.SIT_AND_GO && s.stackOf(HERO_SEAT) == 0L

    private fun resetHandPresentation() {
        lastActions.clear()
        shownBoard = 0
        revealing = false
        pendingWinnings = emptyMap()
        winnings = emptyMap()
        result = null
        error = null
    }

    private fun winningsOf(h: HandEngine): Map<Int, Long> {
        val out = mutableMapOf<Int, Long>()
        h.events.filterIsInstance<HandEvent.PotAwarded>().forEach { a ->
            a.shares.forEach { (seat, amount) -> out[seat] = (out[seat] ?: 0L) + amount }
        }
        return out
    }

    private fun recordLastAction(h: HandEngine) {
        val e = h.events.lastOrNull { it is HandEvent.ActionTaken } as? HandEvent.ActionTaken ?: return
        lastActions[e.seat] = when {
            e.type == ActionType.FOLD -> "Fold"
            e.type == ActionType.CHECK -> "Check"
            e.isAllIn -> "All-in ${chips(e.streetTotal)}"
            e.type == ActionType.CALL -> "Call ${chips(e.amountAdded)}"
            e.type == ActionType.BET -> "Bet ${chips(e.streetTotal)}"
            else -> "Raise to ${chips(e.streetTotal)}"
        }
    }

    private fun nameOf(s: TableSession, seat: Int): String =
        if (seat == HERO_SEAT) "You" else s.profileAt(seat)?.name ?: "Seat ${seat + 1}"

    private fun ordinal(n: Int): String {
        val suffix = if (n % 100 in 11..13) "th" else when (n % 10) { 1 -> "st"; 2 -> "nd"; 3 -> "rd"; else -> "th" }
        return "$n$suffix"
    }

    private fun <T> drain(channel: Channel<T>) {
        while (channel.tryReceive().isSuccess) { /* discard stale input */ }
    }

    private fun publish() {
        val s = session ?: return
        val h = engine
        val snap = h?.snapshotFor(HERO_SEAT)
        val heroTurn = snap != null && !snap.isComplete && snap.actorSeat == HERO_SEAT

        val seats = s.occupiedSeats.map { seat ->
            val sv = snap?.seats?.firstOrNull { it.seat == seat }
            val identity = identities[seat]
            val engineStack = sv?.stack ?: s.stackOf(seat)
            SeatUi(
                seat = seat,
                name = nameOf(s, seat),
                style = bots[seat]?.styleLabel,
                avatarColor = identity?.color ?: 0xFF1B6B3A,
                stack = if (revealing) engineStack - (pendingWinnings[seat] ?: 0L) else engineStack,
                bet = if (revealing || snap?.isComplete == true) 0L else sv?.streetCommit ?: 0L,
                cards = sv?.holeCards,
                dealtIn = sv != null,
                folded = sv?.folded ?: false,
                allIn = sv?.allIn ?: false,
                isHero = seat == HERO_SEAT,
                isButton = snap?.buttonSeat == seat,
                isActing = snap != null && !snap.isComplete && snap.actorSeat == seat,
                lastAction = lastActions[seat],
                wonAmount = winnings[seat] ?: 0L,
                busted = sv == null && s.stackOf(seat) == 0L,
            )
        }

        val blinds = snap?.blinds ?: s.currentBlinds
        val modeLabel = when (config.type) {
            GameType.CASH -> "Cash"
            GameType.SIT_AND_GO -> {
                val level = schedule?.levelIndexForHand(s.handNumber.coerceAtLeast(1))?.plus(1) ?: 1
                "Sit & Go · Level $level"
            }
        }

        _state.value = TableUiState(
            active = true,
            tableSize = s.tableSize,
            heroSeat = HERO_SEAT,
            seats = seats,
            board = h?.board?.take(shownBoard) ?: emptyList(),
            pot = when {
                revealing -> pendingWinnings.values.sum()
                snap == null || snap.isComplete -> 0L
                else -> snap.pot
            },
            street = snap?.street,
            currentBet = snap?.currentBet ?: 0L,
            heroStreetCommit = snap?.seats?.firstOrNull { it.seat == HERO_SEAT }?.streetCommit ?: 0L,
            heroLegal = if (heroTurn) snap?.legalActions else null,
            bigBlind = blinds.bigBlind,
            modeLabel = modeLabel,
            blindsLabel = blinds.toString(),
            handNumber = s.handNumber,
            handInProgress = h != null && !h.isComplete,
            actingName = if (snap != null && !snap.isComplete) snap.actorSeat?.let { nameOf(s, it) } else null,
            result = result,
            sessionOver = sessionOver,
            error = error,
        )
    }
}
