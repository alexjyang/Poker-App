package com.pokercoach.app.ui

import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.lifecycle.viewmodel.compose.viewModel
import com.pokercoach.app.ui.home.HomeScreen
import com.pokercoach.app.ui.table.TableScreen
import com.pokercoach.app.ui.table.TableViewModel

/**
 * Two screens for now (lobby and table), so a simple saveable flag is enough.
 * Stage 5 (stats, hand history, replayer) introduces proper Navigation.
 */
@Composable
fun PokerCoachApp() {
    val tableViewModel: TableViewModel = viewModel()
    var atTable by rememberSaveable { mutableStateOf(false) }

    if (atTable) {
        TableScreen(
            viewModel = tableViewModel,
            onLeave = {
                tableViewModel.leave()
                atTable = false
            },
        )
    } else {
        HomeScreen(
            onStart = { config ->
                tableViewModel.start(config)
                atTable = true
            },
        )
    }
}
