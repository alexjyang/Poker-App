package com.pokercoach.app.game

import com.pokercoach.engine.rng.SeededRandom

enum class GameType(val label: String) { CASH("Cash game"), SIT_AND_GO("Sit & Go") }

enum class BotSpeed(val label: String, val thinkMs: Long, val pauseMs: Long) {
    RELAXED("Relaxed", 1_100, 900),
    NORMAL("Normal", 650, 650),
    FAST("Fast", 220, 300),
}

data class GameConfig(
    val type: GameType = GameType.CASH,
    val players: Int = 6,
    /** Cash games only: buy-in in big blinds. Sit & Go always starts at 1,500 chips. */
    val startingBb: Int = 100,
    val speed: BotSpeed = BotSpeed.NORMAL,
) {
    companion object {
        const val CASH_SMALL_BLIND = 1L
        const val CASH_BIG_BLIND = 2L
        const val SNG_STACK = 1_500L
        const val SNG_HANDS_PER_LEVEL = 10
    }
}

data class BotIdentity(val id: String, val name: String, val color: Long)

object BotRoster {
    private val names = listOf(
        "Ava", "Bruno", "Chen", "Dara", "Emeka", "Freya", "Gus", "Hana", "Ivan",
        "Jade", "Kofi", "Lena", "Mateo", "Nia", "Oskar", "Priya", "Quinn", "Rosa",
    )
    private val colors = listOf(
        0xFF8E44AD, 0xFFD35400, 0xFF2980B9, 0xFFC0392B, 0xFF16A085,
        0xFF7F8C8D, 0xFFB7950B, 0xFF1ABC9C, 0xFF34495E, 0xFFAD1457,
    )

    /** [count] distinct bots, chosen deterministically from [seed]. */
    fun pick(count: Int, seed: Long): List<BotIdentity> {
        val rng = SeededRandom(seed)
        val pool = names.toMutableList()
        return List(count) { i ->
            val name = pool.removeAt(rng.nextInt(pool.size))
            BotIdentity(id = "bot-${name.lowercase()}", name = name, color = colors[(i + rng.nextInt(colors.size)) % colors.size])
        }
    }
}
