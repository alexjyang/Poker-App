package com.pokercoach.app

import androidx.compose.ui.test.assertIsDisplayed
import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.test.onNodeWithTag
import androidx.compose.ui.test.onNodeWithText
import androidx.compose.ui.test.performClick
import androidx.test.ext.junit.runners.AndroidJUnit4
import com.pokercoach.app.ui.table.ActionBar
import com.pokercoach.app.ui.table.TableUiState
import com.pokercoach.app.ui.table.TestTags
import com.pokercoach.app.ui.theme.PokerCoachTheme
import com.pokercoach.engine.game.LegalActions
import com.pokercoach.engine.game.PlayerAction
import com.pokercoach.engine.game.Street
import org.junit.Assert.assertEquals
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith

/** The betting controls on their own, with a fixed game state. */
@RunWith(AndroidJUnit4::class)
class BettingControlsTest {
    @get:Rule val rule = createComposeRule()

    private fun state(canCheck: Boolean) = TableUiState(
        active = true,
        street = Street.FLOP,
        pot = 60,
        currentBet = if (canCheck) 0 else 20,
        bigBlind = 2,
        heroStack = 200,
        heroLegal = LegalActions(
            seat = 0,
            canCheck = canCheck,
            toCall = if (canCheck) 0 else 20,
            callIsAllIn = false,
            canRaise = true,
            isBet = canCheck,
            minRaiseTo = if (canCheck) 2 else 40,
            maxRaiseTo = 200,
        ),
    )

    private fun show(state: TableUiState, actions: MutableList<PlayerAction>) {
        rule.setContent { PokerCoachTheme { ActionBar(state, onAction = { actions += it }) } }
    }

    @Test
    fun checkAndCallSendTheRightAction() {
        val actions = mutableListOf<PlayerAction>()
        show(state(canCheck = false), actions)
        rule.onNodeWithTag(TestTags.CHECK_CALL).performClick()
        assertEquals(listOf<PlayerAction>(PlayerAction.Call), actions)
    }

    @Test
    fun foldingWhenCheckIsFreeAsksFirst() {
        val actions = mutableListOf<PlayerAction>()
        show(state(canCheck = true), actions)
        rule.onNodeWithTag(TestTags.FOLD).performClick()
        rule.onNodeWithText("Checking is free").assertIsDisplayed()
        assertEquals(emptyList<PlayerAction>(), actions)
        rule.onNodeWithText("Check instead").performClick()
        assertEquals(listOf<PlayerAction>(PlayerAction.Check), actions)
    }

    @Test
    fun betOpensTheSizingSheetAndConfirmsTheAmount() {
        val actions = mutableListOf<PlayerAction>()
        show(state(canCheck = true), actions)
        rule.onNodeWithTag(TestTags.RAISE).performClick()
        rule.onNodeWithText("50%").performClick() // half pot of 60 = 30
        rule.onNodeWithTag(TestTags.CONFIRM_BET).performClick()
        assertEquals(listOf<PlayerAction>(PlayerAction.BetOrRaise(30)), actions)
    }

    @Test
    fun allInNeedsASecondTap() {
        val actions = mutableListOf<PlayerAction>()
        show(state(canCheck = false), actions)
        rule.onNodeWithTag(TestTags.RAISE).performClick()
        rule.onNodeWithText("All-in").performClick()
        rule.onNodeWithTag(TestTags.CONFIRM_BET).performClick()
        rule.onNodeWithText("Tap again to go all-in").assertIsDisplayed()
        assertEquals(emptyList<PlayerAction>(), actions)
        rule.onNodeWithTag(TestTags.CONFIRM_BET).performClick()
        assertEquals(listOf<PlayerAction>(PlayerAction.AllIn), actions)
    }
}
