package com.pokercoach.app

import androidx.compose.ui.test.ExperimentalTestApi
import androidx.compose.ui.test.hasTestTag
import androidx.compose.ui.test.junit4.createAndroidComposeRule
import androidx.compose.ui.test.onNodeWithTag
import androidx.compose.ui.test.onNodeWithText
import androidx.compose.ui.test.performClick
import androidx.compose.ui.test.performScrollTo
import androidx.test.ext.junit.runners.AndroidJUnit4
import com.pokercoach.app.ui.table.TestTags
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith

/**
 * The main flow end to end: lobby → take a seat → act until a hand finishes → next hand.
 * Uses the real engine and bots, so it also checks nothing crashes during play.
 */
@OptIn(ExperimentalTestApi::class)
@RunWith(AndroidJUnit4::class)
class TableFlowTest {
    @get:Rule val rule = createAndroidComposeRule<MainActivity>()

    private fun exists(tag: String) = rule.onAllNodes(hasTestTag(tag)).fetchSemanticsNodes().isNotEmpty()

    @Test
    fun playTwoHandsFromTheLobby() {
        rule.onNodeWithText("Fast").performScrollTo().performClick() // bot speed
        rule.onNodeWithTag(TestTags.TAKE_SEAT).performScrollTo().performClick()

        var handsFinished = 0
        val deadline = System.currentTimeMillis() + 90_000
        while (handsFinished < 2 && System.currentTimeMillis() < deadline) {
            rule.waitUntil(30_000) { exists(TestTags.CHECK_CALL) || exists(TestTags.NEXT_HAND) }
            if (exists(TestTags.NEXT_HAND)) {
                handsFinished++
                rule.onNodeWithTag(TestTags.NEXT_HAND).performClick()
            } else {
                rule.onNodeWithTag(TestTags.CHECK_CALL).performClick()
            }
            rule.waitForIdle()
        }
        check(handsFinished >= 2) { "Expected to finish two hands, finished $handsFinished" }
    }
}
