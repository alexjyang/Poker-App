package com.pokercoach.app.ui.table

import com.pokercoach.app.data.Settings
import com.pokercoach.engine.analysis.Grade
import com.pokercoach.engine.card.Card
import com.pokercoach.engine.game.LegalActions
import com.pokercoach.engine.game.Street

/** Everything the table screen draws. Built by [TableViewModel] from engine snapshots. */
data class TableUiState(
    val active: Boolean = false,
    val tableSize: Int = 6,
    val heroSeat: Int = 0,
    val seats: List<SeatUi> = emptyList(),
    val board: List<Card> = emptyList(),
    val pot: Long = 0,
    val street: Street? = null,
    val currentBet: Long = 0,
    val heroStreetCommit: Long = 0,
    val heroLegal: LegalActions? = null,
    val bigBlind: Long = 2,
    val modeLabel: String = "",
    val blindsLabel: String = "",
    val handNumber: Long = 0,
    val handInProgress: Boolean = false,
    val showStyles: Boolean = true,
    val settings: Settings = Settings(),
    /** Hero's total chips this street (stack behind + already bet), for sizing context. */
    val heroStack: Long = 0,
    val preAction: PreAction? = null,
    /** True while bots act and the hero is still in the hand with chips: pre-actions allowed. */
    val canPreAct: Boolean = false,
    val coachHint: CoachHintUi? = null,
    val actingName: String? = null,
    val result: HandResultUi? = null,
    val review: ReviewSummaryUi? = null,
    val sessionOver: SessionOverUi? = null,
    val error: String? = null,
    /** Bets sliding into the pot at the end of a street (animation only). */
    val collect: CollectUi? = null,
    /** Incremented on events that deserve a haptic pulse. */
    val allInPulse: Int = 0,
    val bigWinPulse: Int = 0,
)

/** Chips moving from each seat's bet spot to the pot. [key] restarts the animation. */
data class CollectUi(val key: Int, val bets: Map<Int, Long>)

data class SeatUi(
    val seat: Int,
    val name: String,
    val style: String?,
    val avatarColor: Long,
    val stack: Long,
    val bet: Long,
    /** Visible hole cards, or null when face down / not shown. */
    val cards: List<Card>?,
    val dealtIn: Boolean,
    val folded: Boolean,
    val allIn: Boolean,
    val isHero: Boolean,
    val isButton: Boolean,
    val isActing: Boolean,
    val lastAction: String?,
    val wonAmount: Long,
    val busted: Boolean,
)

data class HandResultUi(
    val headline: String,
    val details: List<String>,
    val heroNet: Long,
    val footer: String,
)

/** Short verdict shown under the hand result, with a link to the full review. */
data class ReviewSummaryUi(
    val handNumber: Long,
    val analyzing: Boolean,
    val decisions: Int,
    val evLostBb: Double,
    /** The costliest decision graded Inaccuracy or worse, e.g. "Turn call"; null if all were fine. */
    val worstMove: String? = null,
    val worstBest: String? = null,
    val worstGrade: Grade? = null,
    val worstLossBb: Double = 0.0,
)

data class SessionOverUi(val title: String, val message: String)

/** Actions the hero can queue while waiting for their turn (like GGPoker/PokerStars). */
enum class PreAction(val label: String) { CHECK_FOLD("Check/Fold"), CHECK("Check"), CALL_ANY("Call any") }

/** Optional real-time coach overlay: estimated equity (null while computing) and pot odds. */
data class CoachHintUi(val equity: Double?, val needed: Double?)

fun chips(n: Long): String = "%,d".format(n)

/** Formats an amount as chips or big blinds depending on the user's setting. */
fun formatAmount(amount: Long, bigBlind: Long, inBb: Boolean): String {
    if (!inBb || bigBlind <= 0) return chips(amount)
    val v = amount.toDouble() / bigBlind
    return if (v == Math.floor(v) && v < 10_000) "${v.toLong()} BB" else "%.1f BB".format(v)
}

/** Formats with this state's big blind and BB setting. */
fun TableUiState.amount(n: Long): String = formatAmount(n, bigBlind, settings.amountsInBb)
