package com.pokercoach.app.ui.replay

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawingPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.pokercoach.app.data.Settings
import com.pokercoach.app.ui.stats.ReplayUi
import com.pokercoach.app.ui.table.SeatUi
import com.pokercoach.app.ui.table.TableArea
import com.pokercoach.app.ui.table.TableUiState
import com.pokercoach.app.ui.table.TableViewModel
import com.pokercoach.engine.replay.ReplayFrame
import kotlinx.coroutines.delay

private val SEAT_COLORS = listOf(
    0xFF1B6B3A, 0xFF8E44AD, 0xFFD35400, 0xFF2980B9, 0xFFC0392B,
    0xFF16A085, 0xFF7F8C8D, 0xFFB7950B, 0xFF34495E,
)

/**
 * Step-by-step replayer: the same table view as live play, with ⏮ ◀ ▶ ⏭, autoplay and a
 * scrubber. By default only cards that were really shown (yours, showdown) are visible;
 * "Show all cards" reveals everything for study.
 */
@Composable
fun ReplayScreen(replay: ReplayUi?, settings: Settings, onBack: () -> Unit, onReview: (Long) -> Unit) {
    BackHandler(onBack = onBack)
    if (replay == null) {
        Box(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background), contentAlignment = Alignment.Center) {
            CircularProgressIndicator()
        }
        return
    }
    var index by rememberSaveable(replay.handId) { mutableIntStateOf(0) }
    var playing by remember { mutableStateOf(false) }
    var showAll by rememberSaveable { mutableStateOf(false) }
    val last = replay.frames.lastIndex
    val frame = replay.frames[index.coerceIn(0, last)]

    LaunchedEffect(playing, index) {
        if (playing) {
            delay(1_100)
            if (index < last) index++ else playing = false
        }
    }

    Column(
        Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .safeDrawingPadding(),
    ) {
        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth().padding(horizontal = 4.dp)) {
            TextButton(onClick = onBack) { Text("‹ Back") }
            Text(
                "Replay · Hand #${replay.handId}",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.weight(1f),
            )
            TextButton(onClick = { onReview(replay.handId) }) { Text("Review") }
        }

        TableArea(frameState(replay, frame, showAll, settings), Modifier.weight(1f).fillMaxWidth())

        Surface(tonalElevation = 3.dp, shape = RoundedCornerShape(topStart = 20.dp, topEnd = 20.dp)) {
            Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(frame.description, style = MaterialTheme.typography.bodyLarge, fontWeight = FontWeight.Medium)
                Text(
                    "Step ${index + 1} of ${last + 1}",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
                if (last > 0) {
                    Slider(
                        value = index.toFloat(),
                        onValueChange = { index = it.toInt().coerceIn(0, last); playing = false },
                        valueRange = 0f..last.toFloat(),
                        steps = (last - 1).coerceAtLeast(0),
                    )
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                    val m = Modifier.weight(1f).height(52.dp)
                    OutlinedButton(onClick = { index = 0; playing = false }, modifier = m) { Text("⏮") }
                    OutlinedButton(onClick = { if (index > 0) index--; playing = false }, enabled = index > 0, modifier = m) { Text("◀") }
                    Button(onClick = { if (index >= last) index = 0; playing = !playing }, modifier = m) {
                        Text(if (playing) "Pause" else "Play")
                    }
                    OutlinedButton(onClick = { if (index < last) index++; playing = false }, enabled = index < last, modifier = m) { Text("▶") }
                    OutlinedButton(onClick = { index = last; playing = false }, modifier = m) { Text("⏭") }
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Show all cards", style = MaterialTheme.typography.bodyMedium, modifier = Modifier.weight(1f))
                    Switch(checked = showAll, onCheckedChange = { showAll = it })
                }
                FilledTonalButton(onClick = { onReview(replay.handId) }, modifier = Modifier.fillMaxWidth()) {
                    Text("Open the coach's review")
                }
                Spacer(Modifier.width(1.dp))
            }
        }
    }
}

private fun frameState(r: ReplayUi, f: ReplayFrame, showAll: Boolean, settings: Settings): TableUiState {
    val snap = f.snapshot
    val streetClosed = f.boardCount != snap.board.size
    return TableUiState(
        active = true,
        tableSize = r.tableSize,
        heroSeat = TableViewModel.HERO_SEAT,
        seats = snap.seats.map { sv ->
            SeatUi(
                seat = sv.seat,
                name = r.names[sv.seat] ?: "Seat ${sv.seat + 1}",
                style = null,
                avatarColor = SEAT_COLORS[sv.seat % SEAT_COLORS.size],
                stack = sv.stack,
                bet = if (streetClosed || snap.isComplete) 0L else sv.streetCommit,
                cards = if (showAll || sv.seat in f.revealedSeats) sv.holeCards else null,
                dealtIn = true,
                folded = sv.folded,
                allIn = sv.allIn,
                isHero = sv.seat == TableViewModel.HERO_SEAT,
                isButton = snap.buttonSeat == sv.seat,
                isActing = f.actorSeat == sv.seat,
                lastAction = if (f.actorSeat == sv.seat) f.actionLabel else null,
                wonAmount = 0L,
                busted = false,
            )
        },
        board = snap.board.take(f.boardCount),
        pot = snap.pot,
        bigBlind = snap.blinds.bigBlind,
        settings = settings,
    )
}
