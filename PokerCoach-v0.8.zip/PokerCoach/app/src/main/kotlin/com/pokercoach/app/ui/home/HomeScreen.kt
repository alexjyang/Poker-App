@file:OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)

package com.pokercoach.app.ui.home

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.AssistChip
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SegmentedButton
import androidx.compose.material3.SegmentedButtonDefaults
import androidx.compose.material3.SingleChoiceSegmentedButtonRow
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.pokercoach.app.game.BotSpeed
import com.pokercoach.app.game.GameConfig
import com.pokercoach.app.game.GameType
import com.pokercoach.app.game.OpponentMix
import com.pokercoach.engine.bot.BotStyle
import com.pokercoach.engine.bot.CustomSettings
import kotlin.math.roundToInt

@Composable
fun HomeScreen(onStart: (GameConfig) -> Unit, onOpenStats: () -> Unit, onOpenSettings: () -> Unit) {
    var type by rememberSaveable { mutableStateOf(GameType.CASH) }
    var players by rememberSaveable { mutableIntStateOf(6) }
    var stackBb by rememberSaveable { mutableIntStateOf(100) }
    var speed by rememberSaveable { mutableStateOf(BotSpeed.NORMAL) }
    var mix by rememberSaveable { mutableStateOf(OpponentMix.MIXED) }
    var showStyles by rememberSaveable { mutableStateOf(true) }
    var editSeats by rememberSaveable { mutableStateOf(false) }
    // Per-seat overrides, stored as a comma-separated list of style names ("" = use the preset).
    var overridesText by rememberSaveable { mutableStateOf("") }
    var editingSeat by rememberSaveable { mutableIntStateOf(-1) }

    var looseness by rememberSaveable { mutableFloatStateOf(0.28f) }
    var aggression by rememberSaveable { mutableFloatStateOf(0.5f) }
    var bluffing by rememberSaveable { mutableFloatStateOf(0.10f) }
    var tilt by rememberSaveable { mutableFloatStateOf(0.2f) }
    var adaptiveness by rememberSaveable { mutableFloatStateOf(0.3f) }

    val botCount = players - 1
    val overrides = parseOverrides(overridesText)
    val lineup = mix.lineup(botCount).mapIndexed { i, style -> overrides.getOrNull(i) ?: style }
    val usesCustom = lineup.any { it == BotStyle.CUSTOM }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("PokerCoach", fontWeight = FontWeight.Bold) },
                actions = {
                    TextButton(onClick = onOpenStats) { Text("Stats") }
                    TextButton(onClick = onOpenSettings) { Text("Settings") }
                },
            )
        },
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 16.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(18.dp),
        ) {
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer),
                modifier = Modifier.fillMaxWidth(),
            ) {
                Column(Modifier.padding(16.dp)) {
                    Text("No-Limit Hold'em trainer", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(4.dp))
                    Text(
                        "Play against bots of different skill. After every hand, the coach grades each decision with equity, pot odds, EV and a plain-language explanation.",
                        style = MaterialTheme.typography.bodyMedium,
                    )
                }
            }

            Section("Game") {
                Choice(GameType.entries, type, { it.label }) { type = it }
            }

            Section("Players") {
                Choice(listOf(2, 6, 9), players, { n -> when (n) { 2 -> "Heads-up"; 6 -> "6-max"; else -> "Full ring" } }) {
                    players = it
                }
            }

            Section("Opponents") {
                FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OpponentMix.entries.forEach { m ->
                        FilterChip(
                            selected = mix == m,
                            onClick = { mix = m; overridesText = "" },
                            label = { Text(m.label) },
                        )
                    }
                }
                Text(mix.description, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)

                TextButton(onClick = { editSeats = !editSeats }) {
                    Text(if (editSeats) "Hide seat-by-seat setup" else "Customize each seat")
                }
                if (editSeats) {
                    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        lineup.forEachIndexed { i, style ->
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable { editingSeat = i },
                            ) {
                                Text("Seat ${i + 2}", style = MaterialTheme.typography.bodyMedium, modifier = Modifier.weight(1f))
                                AssistChip(onClick = { editingSeat = i }, label = { Text(style.label) })
                            }
                        }
                    }
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Show bot style labels at the table", style = MaterialTheme.typography.bodyMedium, modifier = Modifier.weight(1f))
                    Switch(checked = showStyles, onCheckedChange = { showStyles = it })
                }
            }

            if (usesCustom) {
                Section("Custom bot") {
                    LabeledSlider("Looseness (hands played)", looseness, 0.08f..0.70f, "${(looseness * 100).roundToInt()}% VPIP") { looseness = it }
                    LabeledSlider("Aggression", aggression, 0f..1f, sliderWord(aggression, "Passive", "Balanced", "Aggressive")) { aggression = it }
                    LabeledSlider("Bluffing", bluffing, 0f..0.4f, sliderWord(bluffing / 0.4f, "Rarely", "Sometimes", "Often")) { bluffing = it }
                    LabeledSlider("Tilt after big losses", tilt, 0f..1f, sliderWord(tilt, "Never", "Some", "Steams")) { tilt = it }
                    LabeledSlider("Adapts to your play", adaptiveness, 0f..1f, sliderWord(adaptiveness, "Not at all", "Somewhat", "Strongly")) { adaptiveness = it }
                }
            }

            if (type == GameType.CASH) {
                Section("Buy-in: $stackBb big blinds (${stackBb * GameConfig.CASH_BIG_BLIND} chips at 1/2)") {
                    Slider(
                        value = stackBb.toFloat(),
                        onValueChange = { stackBb = ((it / 10f).roundToInt() * 10).coerceIn(20, 200) },
                        valueRange = 20f..200f,
                        steps = 17,
                    )
                }
            } else {
                Text(
                    "Everyone starts with 1,500 chips. Blinds rise every ${GameConfig.SNG_HANDS_PER_LEVEL} hands; " +
                        "big-blind antes from level 5. Last player standing wins.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }

            Section("Bot speed") {
                Choice(BotSpeed.entries, speed, { it.label }) { speed = it }
            }

            Button(
                onClick = {
                    onStart(
                        GameConfig(
                            type = type,
                            players = players,
                            startingBb = stackBb,
                            speed = speed,
                            lineup = lineup,
                            custom = CustomSettings(
                                looseness = looseness.toDouble(),
                                aggression = aggression.toDouble(),
                                bluffing = bluffing.toDouble(),
                                tilt = tilt.toDouble(),
                                adaptiveness = adaptiveness.toDouble(),
                            ),
                            showStyles = showStyles,
                        ),
                    )
                },
                modifier = Modifier
                    .testTag(com.pokercoach.app.ui.table.TestTags.TAKE_SEAT)
                    .fillMaxWidth()
                    .height(56.dp),
            ) {
                Text("Take a seat", fontSize = 17.sp, fontWeight = FontWeight.Bold)
            }

            Text(
                "Preview build · betting controls, stats, leaks & replayer",
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            Spacer(Modifier.height(8.dp))
        }
    }

    if (editingSeat in lineup.indices) {
        val seatIndex = editingSeat
        AlertDialog(
            onDismissRequest = { editingSeat = -1 },
            title = { Text("Seat ${seatIndex + 2}") },
            text = {
                Column {
                    BotStyle.entries.forEach { style ->
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    overridesText = setOverride(overridesText, seatIndex, style, botCount)
                                    editingSeat = -1
                                },
                        ) {
                            RadioButton(
                                selected = lineup[seatIndex] == style,
                                onClick = {
                                    overridesText = setOverride(overridesText, seatIndex, style, botCount)
                                    editingSeat = -1
                                },
                            )
                            Column(Modifier.padding(vertical = 4.dp)) {
                                Text(style.label, style = MaterialTheme.typography.bodyLarge)
                                Text(style.description, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                        }
                    }
                }
            },
            confirmButton = { TextButton(onClick = { editingSeat = -1 }) { Text("Close") } },
        )
    }
}

private fun parseOverrides(text: String): List<BotStyle?> =
    if (text.isEmpty()) emptyList() else text.split(",").map { name -> BotStyle.entries.firstOrNull { it.name == name } }

private fun setOverride(text: String, index: Int, style: BotStyle, count: Int): String {
    val list = parseOverrides(text).toMutableList()
    while (list.size < count) list += null
    list[index] = style
    return list.joinToString(",") { it?.name ?: "" }
}

private fun sliderWord(v: Float, low: String, mid: String, high: String) = when {
    v < 0.34f -> low
    v < 0.67f -> mid
    else -> high
}

@Composable
private fun LabeledSlider(
    title: String,
    value: Float,
    range: ClosedFloatingPointRange<Float>,
    valueText: String,
    onChange: (Float) -> Unit,
) {
    Column {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(title, style = MaterialTheme.typography.bodyMedium, modifier = Modifier.weight(1f))
            Text(valueText, style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.primary)
        }
        Slider(value = value, onValueChange = onChange, valueRange = range)
    }
}

@Composable
private fun Section(title: String, content: @Composable () -> Unit) {
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text(title, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold)
        content()
    }
}

@Composable
private fun <T> Choice(options: List<T>, selected: T, label: (T) -> String, onSelect: (T) -> Unit) {
    SingleChoiceSegmentedButtonRow(Modifier.fillMaxWidth()) {
        options.forEachIndexed { index, option ->
            SegmentedButton(
                selected = option == selected,
                onClick = { onSelect(option) },
                shape = SegmentedButtonDefaults.itemShape(index = index, count = options.size),
            ) {
                Text(label(option), maxLines = 1)
            }
        }
    }
}
