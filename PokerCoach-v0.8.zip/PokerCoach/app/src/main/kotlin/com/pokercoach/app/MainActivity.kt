package com.pokercoach.app

import android.graphics.Color
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.pokercoach.app.data.Settings
import com.pokercoach.app.data.ThemeMode
import com.pokercoach.app.ui.PokerCoachApp
import com.pokercoach.app.ui.theme.CardStyle
import com.pokercoach.app.ui.theme.LocalAnimationSpeed
import com.pokercoach.app.ui.theme.LocalCardStyle
import com.pokercoach.app.ui.theme.PokerCoachTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        enableEdgeToEdge()
        super.onCreate(savedInstanceState)
        val app = application as PokerCoachApplication
        setContent {
            val settings by app.settings.settings.collectAsStateWithLifecycle(initialValue = Settings())
            val dark = when (settings.themeMode) {
                ThemeMode.SYSTEM -> isSystemInDarkTheme()
                ThemeMode.LIGHT -> false
                ThemeMode.DARK -> true
            }
            // Keep status/navigation bar icons readable when the app theme differs from the system's.
            DisposableEffect(dark) {
                enableEdgeToEdge(
                    statusBarStyle = SystemBarStyle.auto(Color.TRANSPARENT, Color.TRANSPARENT) { dark },
                    navigationBarStyle = SystemBarStyle.auto(
                        Color.argb(0xE6, 0xFF, 0xFF, 0xFF),
                        Color.argb(0x80, 0x1B, 0x1B, 0x1B),
                    ) { dark },
                )
                onDispose {}
            }
            PokerCoachTheme(darkTheme = dark, dynamicColor = settings.dynamicColor) {
                CompositionLocalProvider(
                    LocalCardStyle provides CardStyle(settings.fourColorDeck, settings.cardFace, settings.cardBack),
                    LocalAnimationSpeed provides settings.animationSpeed.factor,
                ) {
                    PokerCoachApp()
                }
            }
        }
    }
}
