@file:OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)

package com.pokercoach.app.ui.stats

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.AssistChip
import androidx.compose.material3.Card
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SegmentedButton
import androidx.compose.material3.SegmentedButtonDefaults
import androidx.compose.material3.SingleChoiceSegmentedButtonRow
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.pokercoach.app.ui.table.PlayingCard
import com.pokercoach.app.ui.table.gradeColor
import com.pokercoach.engine.stats.Leak
import com.pokercoach.engine.stats.Rate
import kotlin.math.abs
import kotlin.math.roundToInt

@Composable
fun StatsScreen(
    viewModel: StatsViewModel,
    onBack: () -> Unit,
    onReplay: (Long) -> Unit,
    onReview: (Long) -> Unit,
) {
    val state by viewModel.state.collectAsStateWithLifecycle()
    var tab by rememberSaveable { mutableIntStateOf(0) }
    var confirmClear by remember { mutableStateOf(false) }
    var explain by remember { mutableStateOf<Pair<String, String>?>(null) }
    BackHandler(onBack = onBack)

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Stats & history", fontWeight = FontWeight.Bold) },
                navigationIcon = { TextButton(onClick = onBack) { Text("‹ Back") } },
                actions = { TextButton(onClick = { confirmClear = true }) { Text("Clear") } },
            )
        },
    ) { padding ->
        Column(
            Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(horizontal = 12.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            SingleChoiceSegmentedButtonRow(Modifier.fillMaxWidth()) {
                listOf("Overview", "Leaks", "Hands").forEachIndexed { i, label ->
                    SegmentedButton(
                        selected = tab == i,
                        onClick = { tab = i },
                        shape = SegmentedButtonDefaults.itemShape(index = i, count = 3),
                    ) { Text(label) }
                }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilterChip(selected = !state.lifetime, onClick = { viewModel.setLifetime(false) }, label = { Text("This session") })
                FilterChip(selected = state.lifetime, onClick = { viewModel.setLifetime(true) }, label = { Text("All time") })
            }
            when {
                state.loading -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator() }
                state.summary.hands == 0 -> EmptyState()
                tab == 0 -> Overview(state, onExplain = { explain = it })
                tab == 1 -> Leaks(state.leaks, onReview, onReplay)
                else -> HandList(state.rows, onReview, onReplay)
            }
        }
    }

    if (confirmClear) {
        AlertDialog(
            onDismissRequest = { confirmClear = false },
            title = { Text("Clear all hand history?") },
            text = { Text("This deletes every saved hand, review and stat. It can't be undone.") },
            confirmButton = { TextButton(onClick = { confirmClear = false; viewModel.clearHistory() }) { Text("Delete") } },
            dismissButton = { TextButton(onClick = { confirmClear = false }) { Text("Cancel") } },
        )
    }
    explain?.let { (title, text) ->
        AlertDialog(
            onDismissRequest = { explain = null },
            title = { Text(title) },
            text = { Text(text) },
            confirmButton = { TextButton(onClick = { explain = null }) { Text("Got it") } },
        )
    }
}

@Composable
private fun EmptyState() {
    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        Text(
            "No hands yet. Play a few and your stats, leaks and hand history appear here.",
            style = MaterialTheme.typography.bodyLarge,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.padding(24.dp),
        )
    }
}

private val STAT_HELP = mapOf(
    "bb/100" to "Win rate: big blinds won per 100 hands. Winning players at these stakes often reach +5 to +20.",
    "VPIP" to "Voluntarily Put money In Pot: how often you call or raise preflop (not counting blinds you posted). Solid 6-max: about 20–30%.",
    "PFR" to "Preflop raise: how often you raise preflop. Close to VPIP means you raise instead of calling; a gap over ~8% means lots of limping/calling.",
    "3-bet" to "How often you re-raise when facing exactly one raise preflop. About 6–10% is typical.",
    "AF" to "Aggression factor: postflop (bets + raises) ÷ calls. Below 1.5 is passive; winning players are usually 2–3.",
    "WTSD" to "Went to showdown: how often you reach showdown after seeing the flop. About 25–32% is typical.",
    "W\$SD" to "Won money at showdown: how often you win when you get there. About 50–55% is healthy.",
    "C-bet" to "Continuation bet: how often you bet the flop after raising preflop. About 50–70%.",
    "Fold to c-bet" to "How often you fold to the preflop raiser's flop bet. Above ~60% is easy to exploit.",
    "Accuracy" to "Share of your analyzed decisions graded Best or Good by the coach.",
)

@Composable
private fun Overview(state: StatsUiState, onExplain: (Pair<String, String>) -> Unit) {
    val s = state.summary
    LazyColumn(verticalArrangement = Arrangement.spacedBy(12.dp), contentPadding = PaddingValues(bottom = 24.dp)) {
        item {
            FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Tile("Hands", "${s.hands}", null, onExplain)
                Tile("Result", signed(s.netBb) + " BB", null, onExplain)
                Tile("bb/100", s.bbPer100?.let { signed(it) } ?: "—", null, onExplain)
                Tile("Accuracy", state.accuracy?.let { "${(it * 100).roundToInt()}%" } ?: "—", "${state.analyzedDecisions} decisions", onExplain)
                RateTile("VPIP", s.vpip, onExplain)
                RateTile("PFR", s.pfr, onExplain)
                RateTile("3-bet", s.threeBet, onExplain)
                Tile("AF", s.aggressionFactor?.let { "%.1f".format(it) } ?: "—", "${s.postflopActions} actions", onExplain)
                RateTile("WTSD", s.wtsd, onExplain)
                RateTile("W\$SD", s.wsd, onExplain)
                RateTile("C-bet", s.cbet, onExplain)
                RateTile("Fold to c-bet", s.foldToCbet, onExplain)
            }
        }
        item {
            ChartCard("Results (big blinds)", state.resultsCurve, Color(0xFF2E7D32), zeroLine = true, fixedRange = null, suffix = " BB")
        }
        item {
            if (state.accuracyCurve.size >= 2) {
                ChartCard(
                    "Decision accuracy (% Best/Good, last 20 decisions)",
                    state.accuracyCurve, Color(0xFF1565C0), zeroLine = false, fixedRange = 0f to 100f, suffix = "%",
                )
            } else {
                Text(
                    "The accuracy graph appears after 20 analyzed decisions.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
        }
    }
}

@Composable
private fun RateTile(title: String, rate: Rate, onExplain: (Pair<String, String>) -> Unit) =
    Tile(title, rate.toString(), "${rate.hits}/${rate.chances}", onExplain)

@Composable
private fun Tile(title: String, value: String, note: String?, onExplain: (Pair<String, String>) -> Unit) {
    val help = STAT_HELP[title]
    Column(
        Modifier
            .width(104.dp)
            .clip(RoundedCornerShape(12.dp))
            .background(MaterialTheme.colorScheme.surfaceVariant)
            .clickable(enabled = help != null) { help?.let { onExplain(title to it) } }
            .padding(horizontal = 10.dp, vertical = 8.dp),
    ) {
        Text(title + if (help != null) " ⓘ" else "", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Text(value, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
        if (note != null) Text(note, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable
private fun ChartCard(
    title: String,
    values: List<Float>,
    color: Color,
    zeroLine: Boolean,
    fixedRange: Pair<Float, Float>?,
    suffix: String,
) {
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text(title, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold)
            if (values.size < 2) {
                Text("Play more hands to see this graph.", style = MaterialTheme.typography.bodySmall)
            } else {
            val lo = fixedRange?.first ?: minOf(values.min(), 0f)
            val hi = fixedRange?.second ?: maxOf(values.max(), 0f)
            val span = (hi - lo).takeIf { it > 0f } ?: 1f
            val gridColor = MaterialTheme.colorScheme.outlineVariant
            Row {
                Column(Modifier.height(150.dp), verticalArrangement = Arrangement.SpaceBetween) {
                    Text("${hi.roundToInt()}$suffix", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Text("${lo.roundToInt()}$suffix", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                Spacer(Modifier.width(6.dp))
                Canvas(
                    Modifier
                        .weight(1f)
                        .height(150.dp),
                ) {
                    fun y(v: Float) = size.height - (v - lo) / span * size.height
                    if (zeroLine && lo < 0f && hi > 0f) {
                        drawLine(
                            gridColor, Offset(0f, y(0f)), Offset(size.width, y(0f)),
                            strokeWidth = 1.dp.toPx(), pathEffect = PathEffect.dashPathEffect(floatArrayOf(8f, 8f)),
                        )
                    }
                    val path = Path()
                    values.forEachIndexed { i, v ->
                        val x = i * size.width / (values.size - 1)
                        if (i == 0) path.moveTo(x, y(v)) else path.lineTo(x, y(v))
                    }
                    drawPath(path, color, style = Stroke(width = 2.dp.toPx()))
                }
            }
            Text("Latest: ${"%.1f".format(values.last())}$suffix", style = MaterialTheme.typography.labelSmall)
            }
        }
    }
}

@Composable
private fun Leaks(leaks: List<Leak>, onReview: (Long) -> Unit, onReplay: (Long) -> Unit) {
    if (leaks.isEmpty()) {
        Text(
            "No clear leaks yet. The leak finder needs repeated mistakes in the same kind of spot, " +
                "or enough hands for a stat to be reliable (for example 50 hands for VPIP).",
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.padding(8.dp),
        )
        return
    }
    LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp), contentPadding = PaddingValues(bottom = 24.dp)) {
        items(leaks, key = { it.title }) { leak ->
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(leak.title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                        if (!leak.fromStats) {
                            Text("−${"%.1f".format(leak.costBb)} BB", color = MaterialTheme.colorScheme.error, fontWeight = FontWeight.Bold)
                        }
                    }
                    Text(leak.detail, style = MaterialTheme.typography.bodyMedium)
                    Text("Fix: ${leak.advice}", style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Medium)
                    if (leak.exampleHands.isNotEmpty()) {
                        Text("Example hands", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            leak.exampleHands.forEach { id ->
                                AssistChip(onClick = { onReview(id) }, label = { Text("Review #$id") })
                                AssistChip(onClick = { onReplay(id) }, label = { Text("Replay #$id") })
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun HandList(rows: List<HandRowUi>, onReview: (Long) -> Unit, onReplay: (Long) -> Unit) {
    LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp), contentPadding = PaddingValues(bottom = 24.dp)) {
        items(rows, key = { it.id }) { r ->
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(r.title, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                        Spacer(Modifier.width(8.dp))
                        r.worstGrade?.let { g ->
                            Text(
                                g.label,
                                color = Color.White,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier
                                    .clip(RoundedCornerShape(50))
                                    .background(gradeColor(g))
                                    .padding(horizontal = 8.dp, vertical = 2.dp),
                            )
                        }
                        Spacer(Modifier.weight(1f))
                        Text(
                            signed(r.netBb) + " BB",
                            fontWeight = FontWeight.Bold,
                            color = when {
                                r.netBb > 0 -> Color(0xFF2E7D32)
                                r.netBb < 0 -> MaterialTheme.colorScheme.error
                                else -> MaterialTheme.colorScheme.onSurface
                            },
                        )
                    }
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        r.heroCards.forEach { PlayingCard(it, 24.dp, Modifier.padding(end = 2.dp)) }
                        if (r.board.isNotEmpty()) {
                            Spacer(Modifier.width(8.dp))
                            r.board.forEach { PlayingCard(it, 20.dp, Modifier.padding(end = 2.dp)) }
                        }
                    }
                    Text(
                        r.summary + if (r.analyzed && r.evLostBb > 0.005) " · EV lost ${"%.2f".format(r.evLostBb)} BB" else "",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(onClick = { onReplay(r.id) }) { Text("Replay") }
                        if (r.analyzed) OutlinedButton(onClick = { onReview(r.id) }) { Text("Review") }
                    }
                }
            }
        }
    }
}

private fun signed(x: Double) = (if (x >= 0) "+" else "−") + "%.1f".format(abs(x))
