package com.pokercoach.app.ui.table

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.background
import androidx.compose.ui.draw.clip
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.pokercoach.engine.analysis.Grade
import com.pokercoach.engine.game.LegalActions
import com.pokercoach.engine.game.PlayerAction
import com.pokercoach.engine.game.Street
import kotlin.math.roundToLong

@Composable
fun ResultPanel(
    result: HandResultUi,
    review: ReviewSummaryUi?,
    onNext: () -> Unit,
    onReview: (Long) -> Unit,
    modifier: Modifier = Modifier,
    format: (Long) -> String = { chips(it) },
) {
    Column(
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(3.dp),
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(
                result.headline,
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.weight(1f),
            )
            if (result.heroNet != 0L) {
                Text(
                    text = (if (result.heroNet > 0) "+" else "−") + format(kotlin.math.abs(result.heroNet)),
                    color = if (result.heroNet > 0) Color(0xFF2E9E55) else MaterialTheme.colorScheme.error,
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                )
            }
        }
        result.details.forEach {
            Text(it, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Text(
            result.footer,
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f),
        )
        if (review != null) {
            Spacer(Modifier.height(4.dp))
            ReviewVerdict(review)
        }
        Spacer(Modifier.height(6.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            if (review != null && review.decisions > 0) {
                OutlinedButton(
                    onClick = { onReview(review.handNumber) },
                    modifier = Modifier
                        .weight(1f)
                        .height(52.dp),
                ) { Text("Review hand", fontWeight = FontWeight.SemiBold) }
            }
            Button(
                onClick = onNext,
                modifier = Modifier
                    .testTag(TestTags.NEXT_HAND)
                    .weight(1f)
                    .height(52.dp),
            ) { Text("Next hand", fontWeight = FontWeight.Bold, fontSize = 16.sp) }
        }
    }
}

@Composable
private fun ReviewVerdict(review: ReviewSummaryUi) {
    val grade = review.worstGrade
    val move = review.worstMove
    Row(verticalAlignment = Alignment.CenterVertically) {
        if (grade != null && !review.analyzing) {
            GradeDot(grade)
            Spacer(Modifier.width(6.dp))
        }
        Column {
            when {
                review.analyzing -> Text("Analyzing your decisions…", style = MaterialTheme.typography.bodyMedium)
                review.decisions == 0 -> Text("No decisions to review.", style = MaterialTheme.typography.bodyMedium)
                move == null || grade == null -> Text(
                    "Coach: well played — every decision was close to the best option " +
                        "(EV lost ${"%.2f".format(review.evLostBb)} BB).",
                    style = MaterialTheme.typography.bodyMedium,
                    fontWeight = FontWeight.Medium,
                )
                else -> {
                    Text(
                        "Worst move: $move (${grade.label}, −${"%.2f".format(review.worstLossBb)} BB)",
                        style = MaterialTheme.typography.bodyMedium,
                        fontWeight = FontWeight.SemiBold,
                    )
                    Text(
                        "Better: ${review.worstBest ?: "—"} · EV lost this hand ${"%.2f".format(review.evLostBb)} BB",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            }
        }
    }
    if (review.analyzing) LinearProgressIndicator(Modifier.fillMaxWidth().padding(top = 4.dp))
}

@Composable
fun GradeDot(grade: Grade) {
    androidx.compose.foundation.layout.Box(
        Modifier
            .size(12.dp)
            .clip(androidx.compose.foundation.shape.CircleShape)
            .background(gradeColor(grade)),
    )
}

fun gradeColor(grade: Grade): Color = when (grade) {
    Grade.BEST -> Color(0xFF2E7D32)
    Grade.GOOD -> Color(0xFF7CB342)
    Grade.INACCURACY -> Color(0xFFF9A825)
    Grade.MISTAKE -> Color(0xFFEF6C00)
    Grade.BLUNDER -> Color(0xFFC62828)
}

@Composable
fun WaitingPanel(actingName: String?, modifier: Modifier = Modifier) {
    Column(
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 20.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        Text(
            text = actingName?.let { "$it is thinking…" } ?: "Dealing…",
            style = MaterialTheme.typography.bodyLarge,
            textAlign = TextAlign.Start,
        )
        LinearProgressIndicator(Modifier.fillMaxWidth())
    }
}
