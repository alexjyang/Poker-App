package com.pokercoach.app.ui.table

/** Stable handles for UI tests (Modifier.testTag). */
object TestTags {
    const val TAKE_SEAT = "take_seat"
    const val FOLD = "action_fold"
    const val CHECK_CALL = "action_check_call"
    const val RAISE = "action_raise"
    const val CONFIRM_BET = "action_confirm_bet"
    const val NEXT_HAND = "next_hand"
}
