@file:OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)

package com.pokercoach.app.ui.settings

import android.os.Build
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.SegmentedButton
import androidx.compose.material3.SegmentedButtonDefaults
import androidx.compose.material3.SingleChoiceSegmentedButtonRow
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.draw.clip
import com.pokercoach.app.data.AnimationSpeed
import com.pokercoach.app.data.CardBackStyle
import com.pokercoach.app.data.CardFaceStyle
import com.pokercoach.app.data.ThemeMode
import com.pokercoach.app.ui.table.PlayingCard
import com.pokercoach.app.ui.theme.CardStyle
import com.pokercoach.app.ui.theme.LocalCardStyle
import com.pokercoach.app.ui.theme.TableColors
import com.pokercoach.engine.card.Card
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.pokercoach.app.data.Settings

@Composable
fun SettingsScreen(settings: Settings, onUpdate: ((Settings) -> Settings) -> Unit, onBack: () -> Unit) {
    BackHandler(onBack = onBack)
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Settings", fontWeight = FontWeight.Bold) },
                navigationIcon = { TextButton(onClick = onBack) { Text("‹ Back") } },
            )
        },
    ) { padding ->
        Column(
            Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 16.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp),
        ) {
            Header("Appearance")
            Text("Theme", style = MaterialTheme.typography.bodyLarge)
            Segmented(ThemeMode.entries, settings.themeMode, { it.label }) { v -> onUpdate { it.copy(themeMode = v) } }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                Toggle("Material You colors", "Use colors from your wallpaper for menus and screens.", settings.dynamicColor) { v ->
                    onUpdate { it.copy(dynamicColor = v) }
                }
            }
            Toggle("Four-color deck", "Clubs green, diamonds blue: easier to tell suits apart on a small screen.", settings.fourColorDeck) { v ->
                onUpdate { it.copy(fourColorDeck = v) }
            }
            Text("Card face", style = MaterialTheme.typography.bodyLarge)
            Segmented(CardFaceStyle.entries, settings.cardFace, { it.label }) { v -> onUpdate { it.copy(cardFace = v) } }
            Text("Card back", style = MaterialTheme.typography.bodyLarge)
            Segmented(CardBackStyle.entries, settings.cardBack, { it.label }) { v -> onUpdate { it.copy(cardBack = v) } }
            // Live preview with the chosen style.
            CompositionLocalProvider(LocalCardStyle provides CardStyle(settings.fourColorDeck, settings.cardFace, settings.cardBack)) {
                Row(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp))
                        .background(TableColors.FeltCenter)
                        .padding(12.dp),
                ) {
                    PREVIEW.forEach { PlayingCard(it, 44.dp) }
                    PlayingCard(null, 44.dp)
                }
            }

            HorizontalDivider()
            Header("Sound & feel")
            Toggle("Sound effects", "Cards, chips, your turn and wins.", settings.sound) { v ->
                onUpdate { it.copy(sound = v) }
            }
            Text("Animation speed", style = MaterialTheme.typography.bodyLarge)
            Segmented(AnimationSpeed.entries, settings.animationSpeed, { it.label }) { v -> onUpdate { it.copy(animationSpeed = v) } }
            Text(
                "Dealing, card flips and chip movement. Off also saves a little battery.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )

            HorizontalDivider()
            Header("Table")
            Toggle("Show amounts in big blinds", "Stacks, bets and the pot in BB instead of chips.", settings.amountsInBb) { v ->
                onUpdate { it.copy(amountsInBb = v) }
            }
            Toggle("Haptic feedback", "Vibrate on your turn, all-ins, big wins and bet-size presets.", settings.haptics) { v ->
                onUpdate { it.copy(haptics = v) }
            }
            Toggle("Coach hints while playing", "Show your estimated equity and the equity you need to call. Off by default so you can practise without help.", settings.coachHints) { v ->
                onUpdate { it.copy(coachHints = v) }
            }

            HorizontalDivider()
            Header("Misclick protection")
            Toggle("Confirm folding when you could check", "Asks before you give up a free card.", settings.confirmFoldWhenCheck) { v ->
                onUpdate { it.copy(confirmFoldWhenCheck = v) }
            }
            Toggle("Tap twice to go all-in", "The all-in button needs a second tap within 3 seconds.", settings.confirmAllIn) { v ->
                onUpdate { it.copy(confirmAllIn = v) }
            }

            HorizontalDivider()
            Header("Bet-size presets")
            PresetPicker(
                title = "Opening raise (big blinds), up to 3",
                choices = Settings.OPEN_CHOICES,
                selected = settings.openSizes,
                label = { if (it == Math.floor(it)) "${it.toLong()} BB" else "$it BB" },
                max = 3,
            ) { list -> onUpdate { it.copy(openSizes = list) } }
            PresetPicker(
                title = "Re-raise (× the bet), up to 3",
                choices = Settings.RERAISE_CHOICES,
                selected = settings.reraiseSizes,
                label = { if (it == Math.floor(it)) "${it.toLong()}x" else "${it}x" },
                max = 3,
            ) { list -> onUpdate { it.copy(reraiseSizes = list) } }
            PresetPicker(
                title = "After the flop (% of pot), up to 4",
                choices = Settings.POSTFLOP_CHOICES,
                selected = settings.postflopSizes,
                label = { "$it%" },
                max = 4,
            ) { list -> onUpdate { it.copy(postflopSizes = list) } }
            Text(
                "All-in is always available as the last preset.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            Spacer(Modifier.height(24.dp))
        }
    }
}

private val PREVIEW = Card.parseList("AsKhQdJc")

@Composable
private fun <T> Segmented(options: List<T>, selected: T, label: (T) -> String, onSelect: (T) -> Unit) {
    SingleChoiceSegmentedButtonRow(Modifier.fillMaxWidth()) {
        options.forEachIndexed { i, o ->
            SegmentedButton(
                selected = o == selected,
                onClick = { onSelect(o) },
                shape = SegmentedButtonDefaults.itemShape(index = i, count = options.size),
            ) { Text(label(o), maxLines = 1) }
        }
    }
}

@Composable
private fun Header(text: String) {
    Text(text, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
}

@Composable
private fun Toggle(title: String, subtitle: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.weight(1f).padding(end = 12.dp)) {
            Text(title, style = MaterialTheme.typography.bodyLarge)
            Text(subtitle, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Switch(checked = checked, onCheckedChange = onChange)
    }
}

@Composable
private fun <T : Comparable<T>> PresetPicker(
    title: String,
    choices: List<T>,
    selected: List<T>,
    label: (T) -> String,
    max: Int,
    onChange: (List<T>) -> Unit,
) {
    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Text(title, style = MaterialTheme.typography.bodyMedium)
        FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            choices.forEach { c ->
                val on = c in selected
                FilterChip(
                    selected = on,
                    onClick = {
                        val next = when {
                            on && selected.size > 1 -> selected - c
                            on -> selected                           // keep at least one
                            selected.size >= max -> (selected.drop(1) + c)
                            else -> selected + c
                        }
                        onChange(next.sorted())
                    },
                    label = { Text(label(c)) },
                )
            }
        }
    }
}
