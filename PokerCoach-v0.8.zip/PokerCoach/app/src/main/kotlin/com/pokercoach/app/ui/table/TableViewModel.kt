package com.pokercoach.app.ui.table

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.pokercoach.app.PokerCoachApplication
import com.pokercoach.app.audio.Sfx
import com.pokercoach.app.data.Settings
import com.pokercoach.app.game.BotIdentity
import com.pokercoach.app.game.BotRoster
import com.pokercoach.app.game.GameConfig
import com.pokercoach.app.game.GameType
import com.pokercoach.engine.analysis.EquityCalculator
import com.pokercoach.engine.analysis.Grade
import com.pokercoach.engine.analysis.HandAnalyzer
import com.pokercoach.engine.analysis.HandReview
import com.pokercoach.engine.analysis.OpponentProfile
import com.pokercoach.engine.bot.OpponentStats
import com.pokercoach.engine.analysis.RangeEstimator
import com.pokercoach.engine.card.CardMask
import com.pokercoach.engine.range.Range
import com.pokercoach.engine.bot.BotProfile
import com.pokercoach.engine.bot.BotStyle
import com.pokercoach.engine.bot.ProfileBot
import com.pokercoach.engine.game.ActionType
import com.pokercoach.engine.game.Blinds
import com.pokercoach.engine.game.HandEngine
import com.pokercoach.engine.game.HandEvent
import com.pokercoach.engine.game.IllegalActionException
import com.pokercoach.engine.game.PlayerAction
import com.pokercoach.engine.rng.SeededRandom
import com.pokercoach.engine.session.BlindSchedule
import com.pokercoach.engine.session.GameMode
import com.pokercoach.engine.session.PlayerProfile
import com.pokercoach.engine.session.TableSession
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.security.SecureRandom

/**
 * Owns the table: a [TableSession] from the engine, the bots, and the game loop.
 *
 * Threading: the loop runs in [viewModelScope] (main thread) and is the only code that touches
 * the engine, so no locking is needed. Bot thinking (Monte Carlo equity) runs on
 * [Dispatchers.Default] and only receives an immutable, card-hiding snapshot.
 *
 * The UI talks to the loop through two channels: hero actions and "deal next hand".
 * Finished hands are saved to Room (with their review) for stats, leaks and the replayer.
 */
class TableViewModel(application: Application) : AndroidViewModel(application) {

    companion object {
        const val HERO_SEAT = 0
        private const val HERO_ID = "hero"
    }

    private val _state = MutableStateFlow(TableUiState())
    val state: StateFlow<TableUiState> = _state.asStateFlow()

    private var config = GameConfig()
    private var session: TableSession? = null
    private var schedule: BlindSchedule? = null
    private var engine: HandEngine? = null
    private var bots: Map<Int, ProfileBot> = emptyMap()
    private var showStyles = true
    private var identities: Map<Int, BotIdentity> = emptyMap()
    /** What the hero has seen each opponent do this session (public actions only). */
    private var observed = OpponentStats()
    private var gameJob: Job? = null

    private val app = application as PokerCoachApplication
    private val repository = app.repository
    private var settings = Settings()
    private var sessionId: Long? = null
    private var preAction: PreAction? = null
    private var coachHint: CoachHintUi? = null
    private var hintJob: Job? = null

    // Post-hand reviews: the last 30 in memory for instant access; all of them in Room.
    private val analyzer = HandAnalyzer(iterations = 6_000)
    private val reviews = LinkedHashMap<Long, HandReview>()
    private val analyzing = mutableSetOf<Long>()

    private val heroActions = Channel<PlayerAction>(Channel.CONFLATED)
    private val dealNext = Channel<Unit>(Channel.CONFLATED)

    // Presentation-only state (never affects the game).
    private val lastActions = mutableMapOf<Int, String>()
    private var shownBoard = 0
    private var revealing = false
    private var pendingWinnings: Map<Int, Long> = emptyMap()
    private var winnings: Map<Int, Long> = emptyMap()
    private var result: HandResultUi? = null
    private var sessionOver: SessionOverUi? = null
    private var error: String? = null
    private var collect: CollectUi? = null
    private var collectKey = 0
    private var allInPulse = 0
    private var bigWinPulse = 0

    // Declared after every property so publish() never sees an uninitialized field.
    init {
        viewModelScope.launch {
            app.settings.settings.collect {
                settings = it
                publish()
            }
        }
    }

    // ------------------------------------------------------------------ UI entry points

    fun start(newConfig: GameConfig) {
        gameJob?.cancel()
        config = newConfig
        val seed = SecureRandom().nextLong()

        val roster = BotRoster.pick(newConfig.players - 1, seed)
        identities = (1 until newConfig.players).associateWith { roster[it - 1] }
        val seating = buildMap {
            put(HERO_SEAT, PlayerProfile(HERO_ID, "You"))
            identities.forEach { (seat, id) -> put(seat, PlayerProfile(id.id, id.name)) }
        }
        val mode = when (newConfig.type) {
            GameType.CASH -> GameMode.Cash(
                blinds = Blinds(GameConfig.CASH_SMALL_BLIND, GameConfig.CASH_BIG_BLIND),
                buyIn = newConfig.startingBb * GameConfig.CASH_BIG_BLIND,
                autoRebuy = true,
            )
            GameType.SIT_AND_GO -> GameMode.SitAndGo(
                startingStack = GameConfig.SNG_STACK,
                schedule = BlindSchedule.turbo(GameConfig.SNG_HANDS_PER_LEVEL),
            ).also { schedule = it.schedule }
        }
        if (newConfig.type == GameType.CASH) schedule = null

        val s = TableSession(newConfig.players, mode, seating, seed)
        session = s
        showStyles = newConfig.showStyles
        bots = identities.keys.associateWith { seat ->
            val style = newConfig.lineup.getOrElse(seat - 1) { BotStyle.REGULAR }
            val profile = if (style == BotStyle.CUSTOM) BotProfile.custom(newConfig.custom) else BotProfile.preset(style)
            ProfileBot(profile, seed = SeededRandom.derive(seed, 10_000L + seat))
        }
        engine = null
        reviews.clear()
        observed = OpponentStats()
        analyzing.clear()
        resetHandPresentation()
        sessionOver = null
        drain(heroActions)
        drain(dealNext)
        publish()
        sessionId = null
        preAction = null
        gameJob = viewModelScope.launch {
            try {
                sessionId = try {
                    repository.startSession(newConfig.type.name, newConfig.players, newConfig.lineup.joinToString(",") { it.name })
                } catch (e: CancellationException) {
                    throw e
                } catch (e: Exception) {
                    null // history is a bonus; never block play on storage problems
                }
                runSession(s)
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                // Should never happen (the engine is fuzz-tested), but never crash the app over it.
                error = "Something went wrong: ${e.message}. Please start a new game."
                publish()
            }
        }
    }

    /** Same settings, fresh seats and seed. */
    fun restart() = start(config)

    fun act(action: PlayerAction) {
        heroActions.trySend(action)
    }

    fun nextHand() {
        dealNext.trySend(Unit)
    }

    /** Queue (or clear, when tapped again) a pre-action for the hero's next turn. */
    fun setPreAction(action: PreAction?) {
        preAction = if (preAction == action) null else action
        publish()
    }

    fun setAmountsInBb(inBb: Boolean) {
        viewModelScope.launch { app.settings.update { it.copy(amountsInBb = inBb) } }
    }

    fun leave() {
        gameJob?.cancel()
        gameJob = null
        session = null
        engine = null
        _state.value = TableUiState()
    }

    fun toggleStyleLabels() {
        showStyles = !showStyles
        publish()
    }

    fun reviewFor(handNumber: Long): HandReview? = reviews[handNumber]

    /** Display names by seat, for labelling opponents in the review. */
    fun seatNames(): Map<Int, String> {
        val s = session ?: return emptyMap()
        return s.occupiedSeats.associateWith { nameOf(s, it) }
    }

    fun dismissError() {
        error = null
        publish()
    }

    // ------------------------------------------------------------------ game loop

    private suspend fun runSession(s: TableSession) {
        while (true) {
            if (s.isFinished || heroEliminated(s)) {
                finishSession(s)
                return
            }
            val h = s.nextHand()
            engine = h
            resetHandPresentation()
            publish()
            sfx(Sfx.CARD)
            delay(config.speed.pauseMs / 2)

            playHand(h)
            s.completeHand(h)
            bots.forEach { (seat, bot) -> bot.onHandComplete(h.publicHistory(seat), seat) }
            revealRunout(h)
            announce(h, s)

            if (s.isFinished || heroEliminated(s)) {
                finishSession(s)
                return
            }
            drain(dealNext)
            dealNext.receive()
        }
    }

    private suspend fun playHand(h: HandEngine) {
        while (!h.isComplete) {
            val seat = h.actorSeat ?: break
            shownBoard = h.board.size
            publish()
            val commitsBefore = h.snapshot().seats.associate { it.seat to it.streetCommit }

            if (seat == HERO_SEAT) {
                val legal = h.legalActions()!!
                val queued = when (preAction) {
                    PreAction.CHECK_FOLD -> if (legal.canCheck) PlayerAction.Check else PlayerAction.Fold
                    PreAction.CHECK -> if (legal.canCheck) PlayerAction.Check else null
                    PreAction.CALL_ANY -> if (legal.canCheck) PlayerAction.Check else PlayerAction.Call
                    null -> null
                }
                preAction = null
                val action = if (queued != null) {
                    delay(250)
                    queued
                } else {
                    startCoachHint(h)
                    publish()
                    sfx(Sfx.YOUR_TURN, 0.5f)
                    drain(heroActions)
                    heroActions.receive()
                }
                hintJob?.cancel()
                coachHint = null
                try {
                    h.act(action)
                    error = null
                } catch (e: IllegalActionException) {
                    error = e.message
                    continue
                }
            } else {
                val heroOut = h.snapshot().seats.firstOrNull { it.seat == HERO_SEAT }?.folded ?: true
                delay(if (heroOut) config.speed.thinkMs / 3 else config.speed.thinkMs)
                val view = h.snapshotFor(seat)
                val history = h.publicHistory(seat)
                val bot = bots.getValue(seat)
                val action = withContext(Dispatchers.Default) { bot.decide(view, seat, history) }
                h.act(action)
            }
            recordLastAction(h)
            actionFeedback(h)
            val streetClosed = h.isComplete || h.board.size > shownBoard
            if (streetClosed) {
                // The street's bets slide into the pot.
                val last = h.events.lastOrNull { it is HandEvent.ActionTaken } as? HandEvent.ActionTaken
                val bets = commitsBefore.toMutableMap()
                if (last != null) bets[last.seat] = last.streetTotal
                val moving = bets.filterValues { it > 0 }
                collect = if (moving.isEmpty()) null else CollectUi(++collectKey, moving)
            }

            if (h.isComplete) break
            publish()
            if (h.board.size > shownBoard) {
                // New street: let the player see the final action, then clear labels and deal.
                delay(config.speed.pauseMs)
                collect = null
                lastActions.clear()
                shownBoard = h.board.size
                preAction = null // pre-actions apply to one street, as in most apps
                sfx(Sfx.CARD)
            }
        }
        pendingWinnings = winningsOf(h)
        revealing = true
        preAction = null
    }

    /** Coach overlay: equity vs. the opponents' estimated ranges, computed off the main thread. */
    private fun startCoachHint(h: HandEngine) {
        hintJob?.cancel()
        coachHint = null
        if (!settings.coachHints) return
        val snap = h.snapshotFor(HERO_SEAT)
        val legal = snap.legalActions ?: return
        val hole = snap.seats.firstOrNull { it.seat == HERO_SEAT }?.holeCards ?: return
        val board = snap.board
        val history = h.publicHistory(HERO_SEAT)
        val opponents = snap.seats.filter { it.seat != HERO_SEAT && !it.folded }.map { it.seat }
        val needed = if (legal.toCall > 0) legal.toCall.toDouble() / (snap.pot + legal.toCall) else null
        val seed = h.handNumber * 131 + board.size
        coachHint = CoachHintUi(null, needed)
        hintJob = viewModelScope.launch {
            val eq = withContext(Dispatchers.Default) {
                val est = RangeEstimator().estimate(history)
                val dead = CardMask.of(hole + board)
                val ranges = opponents.mapNotNull { est.ranges[it] }
                    .map { r -> if (r.totalWeight(dead) > 1e-9) r else Range.full() }
                    .ifEmpty { listOf(Range.full()) }
                EquityCalculator.vsRanges(hole, board, ranges, 2_000, SeededRandom(seed)).equity
            }
            coachHint = CoachHintUi(eq, needed)
            publish()
        }
    }

    /** After an all-in, deal the remaining board one street at a time for drama. */
    private suspend fun revealRunout(h: HandEngine) {
        publish()
        if (h.board.size > shownBoard) {
            delay(config.speed.pauseMs)
            collect = null
            while (shownBoard < h.board.size) {
                shownBoard = if (shownBoard < 3) 3 else shownBoard + 1
                publish()
                sfx(Sfx.CARD)
                delay(config.speed.pauseMs + 250)
            }
        } else {
            delay(config.speed.pauseMs / 2)
            collect = null
        }
    }

    /** Sound and haptics for the action just taken. */
    private fun actionFeedback(h: HandEngine) {
        val e = h.events.lastOrNull { it is HandEvent.ActionTaken } as? HandEvent.ActionTaken ?: return
        when {
            e.isAllIn -> { sfx(Sfx.ALL_IN); allInPulse++ }
            e.type == ActionType.FOLD -> sfx(Sfx.CARD, 0.35f)
            e.type == ActionType.CHECK -> sfx(Sfx.CHECK, 0.6f)
            else -> sfx(Sfx.CHIPS)
        }
    }

    private fun sfx(effect: Sfx, volume: Float = 0.8f) {
        if (settings.sound) app.sounds.play(effect, volume)
    }

    private fun announce(h: HandEngine, s: TableSession) {
        val awards = h.events.filterIsInstance<HandEvent.PotAwarded>()
        val ended = h.events.last() as HandEvent.HandEnded
        winnings = pendingWinnings
        revealing = false

        val heroNet = ended.netResults[HERO_SEAT] ?: 0L
        val heroWon = winnings[HERO_SEAT] ?: 0L
        val headline = when {
            heroWon > 0 && awards.all { HERO_SEAT in it.winners && it.winners.size == 1 } -> "You win ${fmt(heroWon)}"
            heroWon > 0 -> "You collect ${fmt(heroWon)}"
            else -> {
                val top = winnings.maxByOrNull { it.value }
                if (top == null) "Hand over" else "${nameOf(s, top.key)} wins ${fmt(top.value)}"
            }
        }
        val details = awards.map { a ->
            val potName = when {
                awards.size == 1 -> "Pot"
                a.potIndex == 0 -> "Main pot"
                else -> "Side pot ${a.potIndex}"
            }
            val who = a.winners.joinToString(" & ") { nameOf(s, it) }
            val how = when {
                a.winners.size > 1 -> " split · ${a.description}"
                a.description != null && a.wonAtShowdown -> " · ${a.description}"
                else -> " · uncontested"
            }
            "$potName ${fmt(a.amount)} → $who$how"
        }
        val rebought = config.type == GameType.CASH &&
            ended.finalStacks[HERO_SEAT] == 0L && s.stackOf(HERO_SEAT) > 0
        val footer = buildString {
            append("Hand #${h.handNumber} · seed ${java.lang.Long.toHexString(h.seed)}")
            if (rebought) append(" · auto-rebuy ${fmt(s.stackOf(HERO_SEAT))}")
        }
        result = HandResultUi(headline, details, heroNet, footer)
        val bb = h.blinds.bigBlind
        if (heroWon > 0) {
            sfx(Sfx.WIN, 0.6f)
            if (heroWon >= 20 * bb) bigWinPulse++
        } else {
            sfx(Sfx.CHIPS, 0.5f)
        }
        publish()
        startReview(h, headline)
    }

    /**
     * Saves the finished hand to the history database and analyzes it in the background; the
     * table keeps running meanwhile.
     */
    /**
     * The coach's read on each bot: its style label (if labels are shown, like a HUD note) refined
     * by what the hero has observed this session. With labels hidden, only observations count.
     */
    private fun currentReads(): Map<Int, OpponentProfile> {
        val s = session ?: return emptyMap()
        return bots.mapValues { (seat, bot) ->
            val name = nameOf(s, seat)
            val prior = if (showStyles) {
                OpponentProfile.fromBot(bot.profile).copy(label = "$name (${bot.profile.label})")
            } else {
                OpponentProfile.BALANCED.copy(label = name, source = "no style label")
            }
            OpponentProfile.withObservations(prior, observed.of(s.profileAt(seat)?.id ?: ""))
        }
    }

    private fun startReview(h: HandEngine, summary: String) {
        val events = h.events
        val handNo = h.handNumber
        val sid = sessionId
        // Reads are what the hero knew *before* this hand; then this hand is added to the notes.
        val reads = currentReads()
        observed.record(events, HERO_SEAT)
        val heroActed = events.any { it is HandEvent.ActionTaken && it.seat == HERO_SEAT }
        if (heroActed) analyzing += handNo
        viewModelScope.launch {
            val handId = try {
                if (sid != null) repository.saveHand(sid, events, HERO_SEAT, summary, OpponentProfile.encodeAll(reads)) else null
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                null
            }
            if (!heroActed) return@launch
            val review = try {
                withContext(Dispatchers.Default) { analyzer.analyze(events, HERO_SEAT, reads = reads) }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                null
            }
            analyzing -= handNo
            if (review != null) {
                reviews[handNo] = review
                while (reviews.size > 30) reviews.remove(reviews.keys.first())
                if (handId != null) {
                    try {
                        repository.saveReview(handId, review)
                    } catch (e: CancellationException) {
                        throw e
                    } catch (e: Exception) {
                        // keep playing even if the write fails
                    }
                }
            }
            publish()
        }
    }

    private fun reviewSummary(handNo: Long): ReviewSummaryUi? {
        val r = reviews[handNo]
        return when {
            r != null -> {
                val worst = r.decisions.filter { it.grade >= Grade.INACCURACY }.maxByOrNull { it.evLossBb }
                ReviewSummaryUi(
                    handNumber = handNo,
                    analyzing = false,
                    decisions = r.decisions.size,
                    evLostBb = r.totalEvLossBb,
                    worstMove = worst?.let { "${streetLabel(it.street)} ${it.chosen.label.lowercase()}" },
                    worstBest = worst?.best?.label,
                    worstGrade = worst?.grade,
                    worstLossBb = worst?.evLossBb ?: 0.0,
                )
            }
            handNo in analyzing -> ReviewSummaryUi(handNo, analyzing = true, decisions = 0, evLostBb = 0.0)
            else -> null
        }
    }

    private fun streetLabel(street: com.pokercoach.engine.game.Street) = when (street) {
        com.pokercoach.engine.game.Street.PREFLOP -> "Preflop"
        com.pokercoach.engine.game.Street.FLOP -> "Flop"
        com.pokercoach.engine.game.Street.TURN -> "Turn"
        com.pokercoach.engine.game.Street.RIVER -> "River"
        com.pokercoach.engine.game.Street.SHOWDOWN -> "Showdown"
    }

    private fun finishSession(s: TableSession) {
        val place = s.finishes.firstOrNull { it.playerId == HERO_ID }?.place
        sessionOver = when {
            config.type != GameType.SIT_AND_GO -> SessionOverUi("Session over", "The table has broken up.")
            place == 1 -> SessionOverUi("You won the Sit & Go!", "First place out of ${config.players}. Well played.")
            place != null -> SessionOverUi("You finished ${ordinal(place)}", "Out of ${config.players} players. Try again?")
            else -> SessionOverUi("Game over", "")
        }
        publish()
    }

    // ------------------------------------------------------------------ helpers

    private fun heroEliminated(s: TableSession) =
        config.type == GameType.SIT_AND_GO && s.stackOf(HERO_SEAT) == 0L

    private fun resetHandPresentation() {
        collect = null
        lastActions.clear()
        shownBoard = 0
        revealing = false
        pendingWinnings = emptyMap()
        winnings = emptyMap()
        result = null
        error = null
    }

    private fun winningsOf(h: HandEngine): Map<Int, Long> {
        val out = mutableMapOf<Int, Long>()
        h.events.filterIsInstance<HandEvent.PotAwarded>().forEach { a ->
            a.shares.forEach { (seat, amount) -> out[seat] = (out[seat] ?: 0L) + amount }
        }
        return out
    }

    private fun recordLastAction(h: HandEngine) {
        val e = h.events.lastOrNull { it is HandEvent.ActionTaken } as? HandEvent.ActionTaken ?: return
        lastActions[e.seat] = when {
            e.type == ActionType.FOLD -> "Fold"
            e.type == ActionType.CHECK -> "Check"
            e.isAllIn -> "All-in ${fmt(e.streetTotal)}"
            e.type == ActionType.CALL -> "Call ${fmt(e.amountAdded)}"
            e.type == ActionType.BET -> "Bet ${fmt(e.streetTotal)}"
            else -> "Raise to ${fmt(e.streetTotal)}"
        }
    }

    private fun fmt(n: Long): String {
        val bb = engine?.blinds?.bigBlind ?: session?.currentBlinds?.bigBlind ?: 1L
        return formatAmount(n, bb, settings.amountsInBb)
    }

    private fun nameOf(s: TableSession, seat: Int): String =
        if (seat == HERO_SEAT) "You" else s.profileAt(seat)?.name ?: "Seat ${seat + 1}"

    private fun ordinal(n: Int): String {
        val suffix = if (n % 100 in 11..13) "th" else when (n % 10) { 1 -> "st"; 2 -> "nd"; 3 -> "rd"; else -> "th" }
        return "$n$suffix"
    }

    private fun <T> drain(channel: Channel<T>) {
        while (channel.tryReceive().isSuccess) { /* discard stale input */ }
    }

    private fun publish() {
        val s = session ?: return
        val h = engine
        val snap = h?.snapshotFor(HERO_SEAT)
        val heroTurn = snap != null && !snap.isComplete && snap.actorSeat == HERO_SEAT

        val seats = s.occupiedSeats.map { seat ->
            val sv = snap?.seats?.firstOrNull { it.seat == seat }
            val identity = identities[seat]
            val engineStack = sv?.stack ?: s.stackOf(seat)
            SeatUi(
                seat = seat,
                name = nameOf(s, seat),
                style = bots[seat]?.takeIf { showStyles }?.let { b ->
                    b.styleLabel + if (b.tilt > 0.35) " · tilted" else ""
                },
                avatarColor = identity?.color ?: 0xFF1B6B3A,
                stack = if (revealing) engineStack - (pendingWinnings[seat] ?: 0L) else engineStack,
                bet = if (revealing || snap?.isComplete == true) 0L else sv?.streetCommit ?: 0L,
                cards = sv?.holeCards,
                dealtIn = sv != null,
                folded = sv?.folded ?: false,
                allIn = sv?.allIn ?: false,
                isHero = seat == HERO_SEAT,
                isButton = snap?.buttonSeat == seat,
                isActing = snap != null && !snap.isComplete && snap.actorSeat == seat,
                lastAction = lastActions[seat],
                wonAmount = winnings[seat] ?: 0L,
                busted = sv == null && s.stackOf(seat) == 0L,
            )
        }

        val blinds = snap?.blinds ?: s.currentBlinds
        val modeLabel = when (config.type) {
            GameType.CASH -> "Cash"
            GameType.SIT_AND_GO -> {
                val level = schedule?.levelIndexForHand(s.handNumber.coerceAtLeast(1))?.plus(1) ?: 1
                "Sit & Go · Level $level"
            }
        }

        _state.value = TableUiState(
            active = true,
            tableSize = s.tableSize,
            heroSeat = HERO_SEAT,
            seats = seats,
            board = h?.board?.take(shownBoard) ?: emptyList(),
            pot = when {
                revealing -> pendingWinnings.values.sum()
                snap == null || snap.isComplete -> 0L
                else -> snap.pot
            },
            street = snap?.street,
            currentBet = snap?.currentBet ?: 0L,
            heroStreetCommit = snap?.seats?.firstOrNull { it.seat == HERO_SEAT }?.streetCommit ?: 0L,
            heroLegal = if (heroTurn) snap?.legalActions else null,
            bigBlind = blinds.bigBlind,
            modeLabel = modeLabel,
            blindsLabel = blinds.toString(),
            handNumber = s.handNumber,
            handInProgress = h != null && !h.isComplete,
            showStyles = showStyles,
            settings = settings,
            heroStack = snap?.seats?.firstOrNull { it.seat == HERO_SEAT }?.let { it.stack + it.streetCommit } ?: 0L,
            preAction = preAction,
            canPreAct = snap != null && !snap.isComplete && !heroTurn &&
                snap.seats.firstOrNull { it.seat == HERO_SEAT }?.let { !it.folded && !it.allIn } == true,
            coachHint = if (heroTurn) coachHint else null,
            actingName = if (snap != null && !snap.isComplete) snap.actorSeat?.let { nameOf(s, it) } else null,
            result = result,
            review = if (result != null && h != null) reviewSummary(h.handNumber) else null,
            sessionOver = sessionOver,
            error = error,
            collect = collect,
            allInPulse = allInPulse,
            bigWinPulse = bigWinPulse,
        )
    }
}
