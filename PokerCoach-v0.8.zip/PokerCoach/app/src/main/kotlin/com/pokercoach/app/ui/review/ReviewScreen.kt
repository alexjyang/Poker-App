@file:OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)

package com.pokercoach.app.ui.review

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.AssistChip
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SegmentedButton
import androidx.compose.material3.SegmentedButtonDefaults
import androidx.compose.material3.SingleChoiceSegmentedButtonRow
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.pokercoach.app.ui.table.PlayingCard
import com.pokercoach.app.ui.table.gradeColor
import com.pokercoach.engine.analysis.Concept
import com.pokercoach.engine.analysis.Decision
import com.pokercoach.engine.analysis.Grade
import com.pokercoach.engine.analysis.HandReview
import com.pokercoach.engine.analysis.OptionEval
import com.pokercoach.engine.game.Street
import kotlin.math.abs
import kotlin.math.roundToInt

/**
 * Post-hand review, styled after chess/solver analysis apps: a summary card, then one card per
 * decision with a color-coded grade, the key numbers, EV bars for each option, a plain-language
 * explanation and — in Advanced mode — range breakdowns, grids, blockers and GTO notes.
 */
@Composable
fun ReviewScreen(review: HandReview, seatNames: Map<Int, String>, onBack: () -> Unit) {
    var advanced by rememberSaveable { mutableStateOf(false) }
    var concept by remember { mutableStateOf<Concept?>(null) }
    BackHandler(onBack = onBack)

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Hand #${review.handNumber} review", fontWeight = FontWeight.Bold) },
                navigationIcon = { TextButton(onClick = onBack) { Text("‹ Table") } },
            )
        },
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding),
            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            item {
                SingleChoiceSegmentedButtonRow(Modifier.fillMaxWidth()) {
                    SegmentedButton(
                        selected = !advanced,
                        onClick = { advanced = false },
                        shape = SegmentedButtonDefaults.itemShape(index = 0, count = 2),
                    ) { Text("Beginner") }
                    SegmentedButton(
                        selected = advanced,
                        onClick = { advanced = true },
                        shape = SegmentedButtonDefaults.itemShape(index = 1, count = 2),
                    ) { Text("Advanced") }
                }
            }
            item { SummaryCard(review) }
            items(review.decisions, key = { it.index }) { d ->
                DecisionCard(d, review, seatNames, advanced, onConcept = { concept = it })
            }
            item {
                Text(
                    HandReview.DISCLAIMER,
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(vertical = 8.dp),
                )
            }
        }
    }

    concept?.let { c ->
        AlertDialog(
            onDismissRequest = { concept = null },
            title = { Text(c.title) },
            text = { Text(c.definition) },
            confirmButton = { TextButton(onClick = { concept = null }) { Text("Got it") } },
        )
    }
}

@Composable
private fun SummaryCard(review: HandReview) {
    Card(
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer),
        modifier = Modifier.fillMaxWidth(),
    ) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Summary", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                Text(
                    "Result ${signedBb(review.heroNetBb)}",
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.SemiBold,
                )
            }
            Text(
                "EV lost this hand: ${"%.2f".format(review.totalEvLossBb)} BB over ${review.decisions.size} decision${if (review.decisions.size == 1) "" else "s"}",
                style = MaterialTheme.typography.bodyMedium,
            )
            FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Grade.entries.forEach { g ->
                    val n = review.decisions.count { it.grade == g }
                    if (n > 0) GradePill(g, "$n ${g.label}")
                }
            }
            review.biggestMistake?.let { m ->
                Text(
                    "Worst move: ${streetName(m.street)} — ${m.chosen.label} (best: ${m.best.label}, −${"%.2f".format(m.evLossBb)} BB)",
                    style = MaterialTheme.typography.bodyMedium,
                    fontWeight = FontWeight.Medium,
                )
            }
            HorizontalDivider(Modifier.padding(vertical = 2.dp))
            Text("Key takeaway", style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.Bold)
            Text(review.takeaway, style = MaterialTheme.typography.bodyMedium)
        }
    }
}

@Composable
private fun DecisionCard(
    d: Decision,
    review: HandReview,
    seatNames: Map<Int, String>,
    advanced: Boolean,
    onConcept: (Concept) -> Unit,
) {
    var showRanges by rememberSaveable(d.index) { mutableStateOf(false) }
    var balancedView by rememberSaveable(d.index) { mutableStateOf(false) }
    Card(modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            if (review.biggestMistake?.index == d.index) {
                Text(
                    "WORST MOVE THIS HAND",
                    style = MaterialTheme.typography.labelSmall,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.error,
                )
            }
            // Header: street, grade.
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(streetName(d.street), style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                Spacer(Modifier.width(8.dp))
                Text(
                    "Pot ${"%.1f".format(d.potBb)} BB" + if (d.toCallBb > 0) " · to call ${"%.1f".format(d.toCallBb)}" else "",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.weight(1f),
                )
                GradePill(d.grade, d.grade.label)
            }

            // Cards.
            Row(verticalAlignment = Alignment.CenterVertically) {
                d.heroCards.forEach { PlayingCard(it, 30.dp, Modifier.padding(end = 3.dp)) }
                if (d.board.isNotEmpty()) {
                    Spacer(Modifier.width(10.dp))
                    d.board.forEach { PlayingCard(it, 26.dp, Modifier.padding(end = 3.dp)) }
                }
            }

            // What you did vs best.
            Text(
                buildString {
                    append("You: ${d.chosen.label}")
                    if (!d.chosen.isBest) append("   ·   Best: ${d.best.label}")
                },
                style = MaterialTheme.typography.bodyLarge,
                fontWeight = FontWeight.SemiBold,
            )
            // Two verdicts when the opponent's tendencies change the answer.
            d.balancedBest?.let { bal ->
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    VerdictChip("Vs this player", d.best.label, MaterialTheme.colorScheme.primaryContainer)
                    VerdictChip("Vs balanced", bal.label, MaterialTheme.colorScheme.surfaceVariant)
                }
            }
            if (d.closeOptions.size >= 2 && d.grade == Grade.BEST) {
                Text(
                    "Close spot: ${d.closeOptions.take(3).joinToString(" / ")} are all fine here.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.primary,
                    fontWeight = FontWeight.Medium,
                )
            }
            d.read?.let { r ->
                Text(
                    "Read on $r",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }

            // Key numbers.
            FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Stat("Equity", pct(d.equity.equity), if (d.equity.exact) "exact" else "est.")
                d.requiredEquity?.let { Stat("Need", pct(it), "pot odds") }
                if (advanced) {
                    d.mdf?.let { Stat("MDF", pct(it), null) }
                    d.spr?.let { Stat("SPR", "%.1f".format(it), null) }
                    d.outs?.let { Stat("Outs", "${it.count}", pct(it.nextCard) + " next") }
                }
            }

            // EV bars: against this player, or (with a read) against a balanced player.
            val balancedOpts = d.balancedOptions
            if (balancedOpts != null && advanced) {
                SingleChoiceSegmentedButtonRow(Modifier.fillMaxWidth()) {
                    SegmentedButton(
                        selected = !balancedView,
                        onClick = { balancedView = false },
                        shape = SegmentedButtonDefaults.itemShape(index = 0, count = 2),
                    ) { Text("Vs this player", fontSize = 12.sp) }
                    SegmentedButton(
                        selected = balancedView,
                        onClick = { balancedView = true },
                        shape = SegmentedButtonDefaults.itemShape(index = 1, count = 2),
                    ) { Text("Vs balanced", fontSize = 12.sp) }
                }
            }
            EvBars(if (balancedView && balancedOpts != null && advanced) balancedOpts else d.options)

            // Explanation.
            Text(d.beginnerText, style = MaterialTheme.typography.bodyMedium)

            // Things a strong player would notice here.
            val shownHints = if (advanced) d.hints else d.hints.take(2)
            if (shownHints.isNotEmpty()) {
                Column(
                    Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(10.dp))
                        .background(MaterialTheme.colorScheme.secondaryContainer.copy(alpha = 0.5f))
                        .padding(10.dp),
                    verticalArrangement = Arrangement.spacedBy(4.dp),
                ) {
                    Text("Spots to notice", style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.Bold)
                    shownHints.forEach { h ->
                        Row {
                            Text("•  ", style = MaterialTheme.typography.bodySmall)
                            Text(h, style = MaterialTheme.typography.bodySmall)
                        }
                    }
                }
            }

            if (!advanced) {
                d.outs?.let { o ->
                    Text(
                        "You have ${o.count} outs: ${pct(o.nextCard)} to hit next card" +
                            (o.byRiver?.let { ", ${pct(it)} by the river" } ?: "") + ".",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
                if (d.concepts.isNotEmpty()) {
                    FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        d.concepts.take(4).forEach { c ->
                            AssistChip(onClick = { onConcept(c) }, label = { Text(c.title, fontSize = 12.sp) })
                        }
                    }
                }
            } else {
                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    d.advancedPoints.forEach { p ->
                        Row {
                            Text("•  ", style = MaterialTheme.typography.bodySmall)
                            Text(p, style = MaterialTheme.typography.bodySmall)
                        }
                    }
                }
                if (d.villains.isNotEmpty() || d.heroRange != null) {
                    TextButton(onClick = { showRanges = !showRanges }) {
                        Text(if (showRanges) "Hide range grids" else "Show range grids")
                    }
                }
                if (showRanges) {
                    d.villains.forEach { v ->
                        val name = seatNames[v.seat] ?: "Seat ${v.seat + 1}"
                        RangeGrid(
                            title = "$name — estimated range (~${pct(v.rangeSize)} of hands)",
                            weights = v.range.classWeights(),
                            color = Color(0xFFD84315),
                        )
                    }
                    d.heroRange?.let { hr ->
                        RangeGrid(
                            title = "Your range as opponents see it",
                            weights = hr.classWeights(),
                            color = Color(0xFF1565C0),
                            highlight = com.pokercoach.engine.range.HandClass.of(d.heroCards[0], d.heroCards[1]).index,
                        )
                    }
                }
                FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    d.concepts.forEach { c ->
                        AssistChip(onClick = { onConcept(c) }, label = { Text(c.title, fontSize = 12.sp) })
                    }
                }
            }
        }
    }
}

@Composable
private fun VerdictChip(title: String, value: String, color: Color) {
    Column(
        Modifier
            .clip(RoundedCornerShape(10.dp))
            .background(color)
            .padding(horizontal = 10.dp, vertical = 5.dp),
    ) {
        Text(title, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Text(value, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
    }
}

@Composable
private fun EvBars(options: List<OptionEval>) {
    val sorted = options.sortedByDescending { it.evBb }
    val maxAbs = sorted.maxOf { abs(it.evBb) }.coerceAtLeast(0.01)
    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
        sorted.forEach { o ->
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    o.label + if (o.isChosen) " (you)" else "",
                    style = MaterialTheme.typography.bodySmall,
                    fontWeight = if (o.isChosen || o.isBest) FontWeight.Bold else FontWeight.Normal,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.width(118.dp),
                )
                Box(
                    Modifier
                        .weight(1f)
                        .height(14.dp),
                ) {
                    val frac = (abs(o.evBb) / maxAbs).toFloat().coerceIn(0.02f, 1f)
                    val barColor = when {
                        o.isBest -> Color(0xFF2E7D32)
                        o.evBb < 0 -> Color(0xFFC62828)
                        else -> Color(0xFF78909C)
                    }
                    Box(
                        Modifier
                            .fillMaxWidth(frac)
                            .height(14.dp)
                            .clip(RoundedCornerShape(4.dp))
                            .background(barColor.copy(alpha = if (o.isChosen || o.isBest) 1f else 0.6f))
                            .then(
                                if (o.isChosen) Modifier.border(1.5.dp, MaterialTheme.colorScheme.onSurface, RoundedCornerShape(4.dp))
                                else Modifier,
                            ),
                    )
                }
                Text(
                    signedBb(o.evBb),
                    style = MaterialTheme.typography.bodySmall,
                    fontWeight = FontWeight.SemiBold,
                    modifier = Modifier
                        .width(78.dp)
                        .padding(start = 6.dp),
                )
            }
        }
        val fe = options.filter { it.foldEquity != null }
        if (fe.isNotEmpty()) {
            Text(
                "Fold equity: " + fe.joinToString(" · ") { "${it.label} ${pct(it.foldEquity!!)}" },
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
        Text(
            "EV vs folding, in big blinds (estimate).",
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
    }
}

/** 13x13 hand matrix: pairs on the diagonal, suited above, offsuit below. */
@Composable
private fun RangeGrid(title: String, weights: DoubleArray, color: Color, highlight: Int? = null) {
    val ranks = "AKQJT98765432"
    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
        Text(title, style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.SemiBold)
        Column(
            Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(6.dp))
                .background(MaterialTheme.colorScheme.surfaceVariant),
        ) {
            for (row in 0 until 13) {
                Row(Modifier.fillMaxWidth()) {
                    for (col in 0 until 13) {
                        val idx = row * 13 + col
                        val w = weights[idx].toFloat().coerceIn(0f, 1f)
                        val label = when {
                            row == col -> "${ranks[row]}${ranks[col]}"
                            row < col -> "${ranks[row]}${ranks[col]}s"
                            else -> "${ranks[col]}${ranks[row]}o"
                        }
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .height(24.dp)
                                .background(color.copy(alpha = 0.08f + 0.85f * w))
                                .then(
                                    if (idx == highlight) Modifier.border(2.dp, Color(0xFFFFD54F))
                                    else Modifier.border(0.25.dp, Color(0x22000000)),
                                ),
                            contentAlignment = Alignment.Center,
                        ) {
                            Text(
                                label,
                                fontSize = 7.sp,
                                lineHeight = 8.sp,
                                maxLines = 1,
                                color = if (w > 0.55f) Color.White else MaterialTheme.colorScheme.onSurfaceVariant,
                            )
                        }
                    }
                }
            }
        }
        Text(
            "Darker = more likely. Estimated from actions, not the real cards.",
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
    }
}

@Composable
private fun GradePill(grade: Grade, text: String) {
    Text(
        text,
        color = Color.White,
        fontSize = 12.sp,
        fontWeight = FontWeight.Bold,
        modifier = Modifier
            .clip(RoundedCornerShape(50))
            .background(gradeColor(grade))
            .padding(horizontal = 10.dp, vertical = 3.dp),
    )
}

@Composable
private fun Stat(label: String, value: String, note: String?) {
    Column(
        Modifier
            .clip(RoundedCornerShape(10.dp))
            .background(MaterialTheme.colorScheme.surfaceVariant)
            .padding(horizontal = 10.dp, vertical = 5.dp),
    ) {
        Text(label, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Row(verticalAlignment = Alignment.Bottom) {
            Text(value, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
            if (note != null) {
                Spacer(Modifier.width(4.dp))
                Text(note, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
    }
}

private fun streetName(s: Street) = when (s) {
    Street.PREFLOP -> "Preflop"
    Street.FLOP -> "Flop"
    Street.TURN -> "Turn"
    Street.RIVER -> "River"
    Street.SHOWDOWN -> "Showdown"
}

private fun pct(x: Double) = "${(x * 100).roundToInt()}%"
private fun signedBb(x: Double) = (if (x >= 0) "+" else "−") + "%.2f BB".format(abs(x))
