package com.pokercoach.app.ui.table

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.DpOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.pokercoach.app.data.CardFaceStyle
import com.pokercoach.app.ui.theme.CardStyle
import com.pokercoach.app.ui.theme.LocalAnimationSpeed
import com.pokercoach.app.ui.theme.LocalCardStyle
import com.pokercoach.engine.card.Card
import com.pokercoach.engine.card.Rank
import kotlinx.coroutines.delay
import kotlin.math.min

/**
 * A single card. Face up when [card] is non-null, otherwise the back is drawn.
 *
 * Animations (scaled by the Animation speed setting, skipped when it's Off):
 *  - deal: the card slides in from [dealFrom] (an offset from its final spot, e.g. the dealer)
 *    after [delayMs], fading and growing into place;
 *  - flip: whenever a face becomes visible (hero's cards, board cards, showdown reveals) the card
 *    turns over around its vertical axis.
 * [animKey] restarts the deal animation (e.g. a new hand); it defaults to the card itself.
 */
@Composable
fun PlayingCard(
    card: Card?,
    width: Dp,
    modifier: Modifier = Modifier,
    dimmed: Boolean = false,
    dealFrom: DpOffset = DpOffset.Zero,
    delayMs: Int = 0,
    animKey: Any? = card,
) {
    val speed = LocalAnimationSpeed.current
    val style = LocalCardStyle.current
    val animate = speed > 0f
    val height = width * 1.4f
    val corner = RoundedCornerShape(width * 0.14f)

    val deal = remember(animKey) { Animatable(if (animate) 0f else 1f) }
    val flip = remember(animKey, card != null) { Animatable(if (animate && card != null) 0f else 1f) }
    LaunchedEffect(animKey) {
        if (animate && deal.value < 1f) {
            delay((delayMs * speed).toLong())
            deal.animateTo(1f, tween((280 * speed).toInt().coerceAtLeast(1), easing = FastOutSlowInEasing))
        }
    }
    LaunchedEffect(animKey, card != null) {
        if (animate && card != null && flip.value < 1f) {
            delay((delayMs * speed).toLong())
            flip.animateTo(1f, tween((320 * speed).toInt().coerceAtLeast(1), easing = FastOutSlowInEasing))
        }
    }

    Box(
        modifier
            .size(width, height)
            .semantics { contentDescription = card?.let(::spoken) ?: "Face-down card" }
            .graphicsLayer {
                val p = deal.value
                translationX = (1 - p) * dealFrom.x.toPx()
                translationY = (1 - p) * dealFrom.y.toPx()
                val s = 0.8f + 0.2f * p
                scaleX = s
                scaleY = s
                rotationY = (1 - flip.value) * 90f
                cameraDistance = 12f * density
                alpha = min(1f, p * 2f) * (if (dimmed) 0.45f else 1f)
            }
            .shadow(3.dp, corner)
            .clip(corner),
    ) {
        if (card != null && flip.value > 0.5f || card != null && !animate) CardFace(card, width, style) else CardBack(width, style)
    }
}

private fun spoken(card: Card): String {
    val suit = card.suit.name.lowercase()
    return "${card.rank.displayName} of $suit"
}

@Composable
private fun CardFace(card: Card, width: Dp, style: CardStyle) {
    val color = style.suitColor(card.suit)
    val rankText = if (card.rank == Rank.TEN) "10" else card.rank.symbol.toString()
    // U+FE0E forces the text (not emoji) presentation of the suit symbol.
    val suitText = "${card.suit.glyph}\uFE0E"
    Box(
        Modifier
            .size(width, width * 1.4f)
            .background(Color.White)
            .border(0.5.dp, Color(0x33000000), RoundedCornerShape(width * 0.14f)),
    ) {
        when (style.face) {
            CardFaceStyle.CLASSIC -> {
                val rankSize = (width.value * 0.44f).sp
                val suitSize = (width.value * 0.52f).sp
                Text(
                    text = rankText,
                    color = color,
                    fontSize = rankSize,
                    lineHeight = rankSize,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = if (rankText.length > 1) (-1).sp else 0.sp,
                    modifier = Modifier
                        .align(Alignment.TopStart)
                        .padding(start = width * 0.08f, top = width * 0.04f),
                )
                Text(
                    text = suitText,
                    color = color,
                    fontSize = suitSize,
                    lineHeight = suitSize,
                    modifier = Modifier
                        .align(Alignment.BottomEnd)
                        .padding(end = width * 0.08f, bottom = width * 0.04f),
                )
            }
            CardFaceStyle.LARGE -> {
                // Big centered index for small screens: readable at a glance.
                val rankSize = (width.value * (if (rankText.length > 1) 0.52f else 0.62f)).sp
                val suitSize = (width.value * 0.46f).sp
                Column(Modifier.align(Alignment.Center), horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(
                        rankText,
                        color = color,
                        fontSize = rankSize,
                        lineHeight = rankSize,
                        fontWeight = FontWeight.ExtraBold,
                        letterSpacing = if (rankText.length > 1) (-1.5).sp else 0.sp,
                    )
                    Text(suitText, color = color, fontSize = suitSize, lineHeight = suitSize)
                }
            }
        }
    }
}

@Composable
private fun CardBack(width: Dp, style: CardStyle) {
    Box(
        Modifier
            .size(width, width * 1.4f)
            .background(Brush.linearGradient(listOf(Color(style.back.top), Color(style.back.bottom))))
            .padding(width * 0.1f)
            .border(1.dp, Color(0x66FFFFFF), RoundedCornerShape(width * 0.08f)),
    )
}

/** An empty board slot outline. */
@Composable
fun CardSlot(width: Dp, modifier: Modifier = Modifier) {
    Box(
        modifier
            .size(width, width * 1.4f)
            .border(1.dp, Color(0x33FFFFFF), RoundedCornerShape(width * 0.14f)),
    )
}
