package com.pokercoach.app

import android.app.Application
import com.pokercoach.app.audio.SoundPlayer
import com.pokercoach.app.data.PokerDatabase
import com.pokercoach.app.data.PokerRepository
import com.pokercoach.app.data.SettingsRepository

/** Holds app-wide singletons (a tiny manual dependency container; no DI framework needed). */
class PokerCoachApplication : Application() {
    val database: PokerDatabase by lazy { PokerDatabase.create(this) }
    val repository: PokerRepository by lazy { PokerRepository(database.dao()) }
    val settings: SettingsRepository by lazy { SettingsRepository(this) }
    val sounds: SoundPlayer by lazy { SoundPlayer(this) }
}
