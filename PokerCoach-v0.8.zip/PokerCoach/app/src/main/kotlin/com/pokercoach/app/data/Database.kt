package com.pokercoach.app.data

import android.content.Context
import androidx.room.ColumnInfo
import androidx.room.Dao
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase
import androidx.room.Database
import androidx.room.Entity
import androidx.room.Index
import androidx.room.Insert
import androidx.room.PrimaryKey
import androidx.room.Query
import androidx.room.Room
import androidx.room.RoomDatabase
import kotlinx.coroutines.flow.Flow

@Entity(tableName = "sessions")
data class SessionEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val startedAt: Long,
    val mode: String,
    val players: Int,
    val lineup: String,
)

/**
 * One played hand: a light summary row used by lists and stats. The full event log lives in
 * [HandEventsEntity] so loading the history list never pulls kilobytes per hand.
 */
@Entity(tableName = "hands", indices = [Index("sessionId")])
data class HandEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val sessionId: Long,
    val handNumber: Long,
    val playedAt: Long,
    val bigBlind: Long,
    val players: Int,
    val heroNet: Long,
    val heroCards: String,
    val board: String,
    val summary: String,
    // Tracker stats (see engine HandStats).
    val vpip: Boolean,
    val pfr: Boolean,
    val threeBetOpp: Boolean,
    val threeBet: Boolean,
    val sawFlop: Boolean,
    val wentToShowdown: Boolean,
    val wonAtShowdown: Boolean,
    val cbetOpp: Boolean,
    val cbet: Boolean,
    val foldToCbetOpp: Boolean,
    val foldToCbet: Boolean,
    val postflopAggressive: Int,
    val postflopCalls: Int,
    // Review summary, filled in when analysis finishes.
    val analyzed: Boolean = false,
    val decisions: Int = 0,
    val goodDecisions: Int = 0,
    val evLostBb: Double = 0.0,
    /** Grade ordinal of the worst decision, -1 if none. */
    val worstGrade: Int = -1,
)

@Entity(tableName = "hand_events")
data class HandEventsEntity(
    @PrimaryKey val handId: Long,
    /** Encoded with the engine's HandHistoryCodec (lossless, replayable). */
    val events: String,
    /** The coach's reads on each opponent when the hand was played (OpponentProfile.encodeAll). */
    @ColumnInfo(defaultValue = "")
    val reads: String = "",
)

@Entity(tableName = "decisions", indices = [Index("handId")])
data class DecisionEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val handId: Long,
    val idx: Int,
    val street: String,
    val spot: String,
    val chosen: String,
    val best: String,
    val grade: Int,
    val evLossBb: Double,
    val label: String,
)

@Dao
interface PokerDao {
    @Insert
    suspend fun insertSession(session: SessionEntity): Long

    @Insert
    suspend fun insertHand(hand: HandEntity): Long

    @Insert
    suspend fun insertEvents(events: HandEventsEntity)

    @Query("SELECT reads FROM hand_events WHERE handId = :handId")
    suspend fun reads(handId: Long): String?

    @Insert
    suspend fun insertDecisions(decisions: List<DecisionEntity>)

    @Query(
        "UPDATE hands SET analyzed = 1, decisions = :decisions, goodDecisions = :good, " +
            "evLostBb = :evLost, worstGrade = :worst WHERE id = :handId",
    )
    suspend fun markAnalyzed(handId: Long, decisions: Int, good: Int, evLost: Double, worst: Int)

    @Query("SELECT * FROM hands ORDER BY id DESC")
    fun observeHands(): Flow<List<HandEntity>>

    @Query("SELECT * FROM decisions ORDER BY id ASC")
    fun observeDecisions(): Flow<List<DecisionEntity>>

    @Query("SELECT * FROM hands WHERE id = :handId")
    suspend fun hand(handId: Long): HandEntity?

    @Query("SELECT events FROM hand_events WHERE handId = :handId")
    suspend fun events(handId: Long): String?

    @Query("SELECT MAX(id) FROM sessions")
    fun observeLatestSessionId(): Flow<Long?>

    @Query("DELETE FROM hands")
    suspend fun clearHands()

    @Query("DELETE FROM hand_events")
    suspend fun clearEvents()

    @Query("DELETE FROM decisions")
    suspend fun clearDecisions()

    @Query("DELETE FROM sessions")
    suspend fun clearSessions()
}

@Database(
    entities = [SessionEntity::class, HandEntity::class, HandEventsEntity::class, DecisionEntity::class],
    version = 2,
    exportSchema = false,
)
abstract class PokerDatabase : RoomDatabase() {
    abstract fun dao(): PokerDao

    companion object {
        fun create(context: Context): PokerDatabase =
            Room.databaseBuilder(context.applicationContext, PokerDatabase::class.java, "pokercoach.db")
                .addMigrations(MIGRATION_1_2)
                .build()

        /** v2 stores the coach's opponent reads with each hand; existing history is kept. */
        val MIGRATION_1_2 = object : Migration(1, 2) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("ALTER TABLE hand_events ADD COLUMN reads TEXT NOT NULL DEFAULT ''")
            }
        }
    }
}
