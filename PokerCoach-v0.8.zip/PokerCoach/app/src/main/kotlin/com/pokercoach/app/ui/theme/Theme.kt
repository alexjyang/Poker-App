package com.pokercoach.app.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import com.pokercoach.app.data.CardBackStyle
import com.pokercoach.app.data.CardFaceStyle
import com.pokercoach.engine.card.Suit

private val LightColors = lightColorScheme(
    primary = Color(0xFF1B6B3A),
    onPrimary = Color(0xFFFFFFFF),
    primaryContainer = Color(0xFFA6F2B5),
    onPrimaryContainer = Color(0xFF00210B),
    secondary = Color(0xFF7A5900),
    onSecondary = Color(0xFFFFFFFF),
    secondaryContainer = Color(0xFFFFDEA6),
    onSecondaryContainer = Color(0xFF261900),
    tertiary = Color(0xFF3B6470),
    background = Color(0xFFF6FAF6),
    onBackground = Color(0xFF171D18),
    surface = Color(0xFFF6FAF6),
    onSurface = Color(0xFF171D18),
    surfaceVariant = Color(0xFFDDE5DB),
    onSurfaceVariant = Color(0xFF414941),
    error = Color(0xFFBA1A1A),
    errorContainer = Color(0xFFFFDAD6),
    onErrorContainer = Color(0xFF410002),
)

private val DarkColors = darkColorScheme(
    primary = Color(0xFF8BD69B),
    onPrimary = Color(0xFF003918),
    primaryContainer = Color(0xFF00522A),
    onPrimaryContainer = Color(0xFFA6F2B5),
    secondary = Color(0xFFF1BF48),
    onSecondary = Color(0xFF402D00),
    secondaryContainer = Color(0xFF5C4200),
    onSecondaryContainer = Color(0xFFFFDEA6),
    tertiary = Color(0xFFA3CDDB),
    background = Color(0xFF101512),
    onBackground = Color(0xFFDFE4DD),
    surface = Color(0xFF101512),
    onSurface = Color(0xFFDFE4DD),
    surfaceVariant = Color(0xFF414941),
    onSurfaceVariant = Color(0xFFC1C9BF),
    error = Color(0xFFFFB4AB),
    errorContainer = Color(0xFF93000A),
    onErrorContainer = Color(0xFFFFDAD6),
)

/** Colors of the table itself: the same in light and dark themes, like a real felt. */
object TableColors {
    val FeltCenter = Color(0xFF2A7F48)
    val FeltEdge = Color(0xFF0F4424)
    val Rail = Color(0xFF3A2618)
    val RailHighlight = Color(0xFF5C3D27)
    val SeatPanel = Color(0xE6131A16)
    val SeatText = Color(0xFFF2F5F2)
    val SeatSubtext = Color(0xFFB9C4BC)
    val Acting = Color(0xFFF5C542)
    val Winner = Color(0xFF6BE38C)
    val ChipGold = Color(0xFFE8B730)
    val PotPill = Color(0x99000000)
    val CardRed = Color(0xFFD32F2F)
    val CardBlack = Color(0xFF1B1B1B)
    val CardBackTop = Color(0xFF2E55A8)
    val CardBackBottom = Color(0xFF15295E)
    val HeroAvatar = Color(0xFF1B6B3A)
}

/** How cards are drawn everywhere (table, review, replayer). */
data class CardStyle(
    val fourColor: Boolean = false,
    val face: CardFaceStyle = CardFaceStyle.CLASSIC,
    val back: CardBackStyle = CardBackStyle.BLUE,
) {
    fun suitColor(suit: Suit): Color = if (!fourColor) {
        if (suit == Suit.HEARTS || suit == Suit.DIAMONDS) TableColors.CardRed else TableColors.CardBlack
    } else when (suit) {
        Suit.SPADES -> TableColors.CardBlack
        Suit.HEARTS -> TableColors.CardRed
        Suit.DIAMONDS -> Color(0xFF1565C0)
        Suit.CLUBS -> Color(0xFF1E8C3A)
    }
}

val LocalCardStyle = staticCompositionLocalOf { CardStyle() }

/** Animation duration multiplier: 1 = normal, 0.5 = fast, 0 = animations off. */
val LocalAnimationSpeed = staticCompositionLocalOf { 1f }

@Composable
fun PokerCoachTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    dynamicColor: Boolean = false,
    content: @Composable () -> Unit,
) {
    val scheme = when {
        dynamicColor && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S -> {
            val context = LocalContext.current
            if (darkTheme) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
        }
        darkTheme -> DarkColors
        else -> LightColors
    }
    MaterialTheme(colorScheme = scheme, content = content)
}
