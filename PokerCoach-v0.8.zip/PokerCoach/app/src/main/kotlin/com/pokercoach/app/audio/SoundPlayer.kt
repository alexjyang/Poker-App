package com.pokercoach.app.audio

import android.content.Context
import android.media.AudioAttributes
import android.media.SoundPool
import com.pokercoach.app.R

enum class Sfx { CARD, CHIPS, ALL_IN, CHECK, YOUR_TURN, WIN }

/**
 * Short table sounds via SoundPool (low latency, preloaded). The sounds are synthesized for
 * this app (no third-party audio). Callers check the user's Sound setting.
 */
class SoundPlayer(context: Context) {
    private val pool: SoundPool = SoundPool.Builder()
        .setMaxStreams(4)
        .setAudioAttributes(
            AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_GAME)
                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                .build(),
        )
        .build()

    private val loaded = mutableSetOf<Int>()
    private val ids: Map<Sfx, Int>

    init {
        pool.setOnLoadCompleteListener { _, sampleId, status -> if (status == 0) synchronized(loaded) { loaded += sampleId } }
        ids = mapOf(
            Sfx.CARD to pool.load(context, R.raw.card, 1),
            Sfx.CHIPS to pool.load(context, R.raw.chips, 1),
            Sfx.ALL_IN to pool.load(context, R.raw.allin, 1),
            Sfx.CHECK to pool.load(context, R.raw.check, 1),
            Sfx.YOUR_TURN to pool.load(context, R.raw.turn, 1),
            Sfx.WIN to pool.load(context, R.raw.win, 1),
        )
    }

    fun play(sfx: Sfx, volume: Float = 0.8f) {
        val id = ids[sfx] ?: return
        if (synchronized(loaded) { id !in loaded }) return
        pool.play(id, volume, volume, 1, 0, 1f)
    }
}
