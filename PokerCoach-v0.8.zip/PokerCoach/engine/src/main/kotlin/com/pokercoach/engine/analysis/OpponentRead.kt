package com.pokercoach.engine.analysis

import com.pokercoach.engine.bot.BotProfile
import com.pokercoach.engine.bot.OpponentStats

/**
 * What the coach believes about one opponent's tendencies, relative to a balanced regular
 * (every factor 1.0 = balanced):
 *
 *  - [looseness]: how many hands they play (2.0 = twice as many as a regular).
 *  - [foldToBet]: how often they fold when bet into (0.6 = folds 40% less often: a calling station).
 *  - [bluffiness]: how many bluffs hide in their bets (2.0 = twice as many).
 *  - [passivity]: how often they just call or check strong hands instead of raising (2.0 = very passive).
 *
 * Built from the bot's style (a "read" like a label on a HUD) and refined by what was actually
 * observed during the session, weighted by sample size.
 */
data class OpponentProfile(
    val label: String,
    val looseness: Double = 1.0,
    val foldToBet: Double = 1.0,
    val bluffiness: Double = 1.0,
    val passivity: Double = 1.0,
    /** Where the read comes from, e.g. "style: Casual · seen 42 hands". */
    val source: String = "",
) {
    val isBalanced: Boolean
        get() = abs1(looseness) && abs1(foldToBet) && abs1(bluffiness) && abs1(passivity)

    private fun abs1(x: Double) = kotlin.math.abs(x - 1.0) < 0.08

    /** Plain-language description of the read, e.g. "plays lots of hands, calls too much, rarely bluffs". */
    fun describe(): String {
        val parts = mutableListOf<String>()
        if (looseness > 1.35) parts += "plays lots of hands" else if (looseness < 0.75) parts += "plays few hands"
        if (foldToBet < 0.8) parts += "calls too much" else if (foldToBet > 1.2) parts += "folds to bets often"
        if (bluffiness > 1.4) parts += "bluffs a lot" else if (bluffiness < 0.6) parts += "rarely bluffs"
        if (passivity > 1.4) parts += "passive with strong hands" else if (passivity < 0.8) parts += "aggressive"
        return if (parts.isEmpty()) "plays a balanced, solid game" else parts.joinToString(", ")
    }

    fun encode(): String = listOf(label.replace('|', '/').replace(';', ','), looseness, foldToBet, bluffiness, passivity, source.replace('|', '/').replace(';', ','))
        .joinToString("|")

    companion object {
        val BALANCED = OpponentProfile("Balanced", source = "no read")

        /** A read from a bot's style, mapped from its profile numbers. */
        fun fromBot(p: BotProfile): OpponentProfile = OpponentProfile(
            label = p.label,
            looseness = (p.vpip / 0.23).coerceIn(0.5, 3.0),
            foldToBet = (1.0 - 2.5 * p.callBias).coerceIn(0.4, 1.3),
            bluffiness = if (p.gto) 1.0 else (p.bluff / 0.12).coerceIn(0.2, 2.5),
            passivity = if (p.gto) 1.0 else (0.65 / p.aggression).coerceIn(0.6, 2.6),
            source = "style: ${p.label}",
        )

        /**
         * Refines a prior read with observed tendencies. Each observation is weighted by its
         * sample size, so a handful of hands barely moves the read.
         */
        fun withObservations(prior: OpponentProfile, c: OpponentStats.Counts?): OpponentProfile {
            if (c == null || c.hands == 0) return prior
            fun blend(p: Double, obs: Double, n: Int, k: Double) = (p * k + obs * n) / (k + n)
            val loose = if (c.hands > 0) blend(prior.looseness, (c.vpip.toDouble() / c.hands / 0.23).coerceIn(0.4, 3.0), c.hands, 30.0) else prior.looseness
            val fold = if (c.facedBet > 0) blend(prior.foldToBet, (c.foldedToBet.toDouble() / c.facedBet / 0.45).coerceIn(0.3, 1.6), c.facedBet, 12.0) else prior.foldToBet
            val actions = c.postflopBetsRaises + c.postflopCalls
            val af = c.postflopBetsRaises.toDouble() / c.postflopCalls.coerceAtLeast(1)
            val bluff = if (actions > 0) blend(prior.bluffiness, (af / 2.0).coerceIn(0.3, 2.5), actions, 15.0) else prior.bluffiness
            val passive = if (actions > 0) blend(prior.passivity, (2.0 / af.coerceAtLeast(0.3)).coerceIn(0.6, 2.6), actions, 15.0) else prior.passivity
            val seen = buildString {
                append(prior.source.ifEmpty { "read" })
                append(" · seen ${c.hands} hand${if (c.hands == 1) "" else "s"}")
                if (c.facedBet >= 4) append(", folds to bets ${(100 * c.foldedToBet / c.facedBet)}%")
            }
            return OpponentProfile(prior.label, loose, fold, bluff, passive, seen)
        }

        fun decode(text: String): OpponentProfile? {
            val p = text.split("|")
            if (p.size != 6) return null
            return OpponentProfile(
                label = p[0],
                looseness = p[1].toDoubleOrNull() ?: return null,
                foldToBet = p[2].toDoubleOrNull() ?: return null,
                bluffiness = p[3].toDoubleOrNull() ?: return null,
                passivity = p[4].toDoubleOrNull() ?: return null,
                source = p[5],
            )
        }

        /** "seat=profile;seat=profile" for storing reads alongside a hand. */
        fun encodeAll(reads: Map<Int, OpponentProfile>): String =
            reads.entries.joinToString(";") { (seat, p) -> "$seat=${p.encode()}" }

        fun decodeAll(text: String): Map<Int, OpponentProfile> =
            if (text.isBlank()) emptyMap() else text.split(";").mapNotNull { entry ->
                val i = entry.indexOf('=')
                if (i <= 0) return@mapNotNull null
                val seat = entry.substring(0, i).toIntOrNull() ?: return@mapNotNull null
                decode(entry.substring(i + 1))?.let { seat to it }
            }.toMap()
    }
}
