package com.pokercoach.engine.analysis

import com.pokercoach.engine.card.Card
import com.pokercoach.engine.game.Street
import com.pokercoach.engine.range.Range

enum class Grade(val label: String) {
    BEST("Best"), GOOD("Good"), INACCURACY("Inaccuracy"), MISTAKE("Mistake"), BLUNDER("Blunder");

    companion object {
        /**
         * Grades by EV lost relative to the pot (a 2 BB loss is huge in a 3 BB pot and small in a
         * 200 BB pot), with small absolute losses never graded worse than Good.
         */
        fun of(lossChips: Double, potChips: Long, bigBlind: Long, preflop: Boolean): Grade {
            val scale = maxOf(potChips.toDouble(), bigBlind * (if (preflop) 6.0 else 4.0))
            val r = lossChips / scale
            val lossBb = lossChips / bigBlind
            val byRatio = when {
                r <= 0.03 || lossBb <= 0.15 -> BEST // within the model's margin: a close spot
                r < 0.05 || lossBb < 0.3 -> GOOD
                r < 0.12 -> INACCURACY
                r < 0.30 -> MISTAKE
                else -> BLUNDER
            }
            // A "blunder" must also be big in absolute terms, and a "mistake" at least noticeable.
            return when {
                byRatio == BLUNDER && lossBb < 2.0 -> MISTAKE
                byRatio == MISTAKE && lossBb < 0.75 -> INACCURACY
                else -> byRatio
            }
        }
    }
}

/** Glossary entries shown as tappable chips (beginner mode) and used in explanations. */
enum class Concept(val title: String, val definition: String) {
    EQUITY("Equity", "Your share of the pot if all cards were dealt out with no more betting — how often you'd win, counting ties as half."),
    POT_ODDS("Pot odds", "The price of a call: what you must put in compared with what you can win. Calling 25 to win 75 (after your call: 100) means you need 25% equity."),
    EV("Expected value (EV)", "How much a play wins or loses on average if you made it many times. Shown in big blinds (BB) compared with folding."),
    FOLD_EQUITY("Fold equity", "The extra value a bet gets when opponents fold better hands or hands that would out-draw you."),
    OUTS("Outs", "Cards still in the deck that turn your hand into the likely winner."),
    IMPLIED_ODDS("Implied odds", "Money you expect to win on later streets when you hit, which can justify a call that pot odds alone don't."),
    SPR("Stack-to-pot ratio (SPR)", "Effective stack divided by the pot. Low SPR (under ~3) means one pair is often worth getting all-in; high SPR (over ~10) needs stronger hands."),
    MDF("Minimum defense frequency", "How often you must continue against a bet so that a pure bluff can't profit automatically: pot ÷ (pot + bet)."),
    RANGE("Range", "All the hands a player could have given their actions, not just one guess. Reviews estimate ranges from how people usually play."),
    BLOCKERS("Blockers", "Cards in your hand that make certain opponent hands impossible or less likely, e.g. holding the A♠ on a three-spade board means they can't have the nut flush."),
    RANGE_ADVANTAGE("Range advantage", "Whose overall range has more equity on this board. The player with it can usually bet more often."),
    NUT_ADVANTAGE("Nut advantage", "Who has more of the very strongest hands. It lets that player use bigger bets."),
    REALIZATION("Equity realization", "The share of your raw equity you actually capture. Out of position or with weak hands you realize less, because you get bet off the best hand or can't bet for value."),
    GTO("GTO vs exploitative", "Game-theory-optimal play is balanced so opponents can't exploit it. Exploitative play deviates to punish a specific opponent's leaks."),
    POSITION("Position", "Acting after your opponent. It gives you more information and control, so you can play more hands profitably."),
    VALUE_BET("Value bet", "A bet you make because worse hands will call it."),
    BLUFF("Bluff / semi-bluff", "A bet with a hand that's usually behind, hoping for folds. A semi-bluff has outs to improve if called."),
}

data class OptionEval(
    val label: String,
    val kind: OptionKind,
    /** Street total for bets/raises (chips); 0 otherwise. */
    val to: Long,
    val evBb: Double,
    val foldEquity: Double?,
    val equityWhenCalled: Double?,
    val isChosen: Boolean,
    val isBest: Boolean,
)

data class OutsInfo(
    val count: Int,
    val cards: List<Card>,
    val unseen: Int,
    /** Exact probability of hitting on the next card, given the out count. */
    val nextCard: Double,
    /** Exact probability of hitting by the river (from the flop only). */
    val byRiver: Double?,
)

data class VillainView(
    val seat: Int,
    val range: Range,
    /** Share of all starting hands in the estimated range. */
    val rangeSize: Double,
    val breakdown: List<Pair<String, Double>>,
)

data class Decision(
    val index: Int,
    val street: Street,
    val spot: Spot,
    val board: List<Card>,
    val heroCards: List<Card>,
    val actionLabel: String,
    val potBb: Double,
    val toCallBb: Double,
    val effectiveStackBb: Double,
    /** Required equity to call (pot odds), null when there's nothing to call. Exact. */
    val requiredEquity: Double?,
    /** Minimum defense frequency against the bet faced (postflop). Exact formula. */
    val mdf: Double?,
    /** Stack-to-pot ratio at the decision (postflop). Exact. */
    val spr: Double?,
    val equity: EquityResult,
    val equityVs: String,
    val options: List<OptionEval>,
    val chosen: OptionEval,
    val best: OptionEval,
    val evLossBb: Double,
    val grade: Grade,
    val outs: OutsInfo?,
    /** Extra chips (in BB) you'd need to win later for a losing direct call to break even. */
    val impliedOddsNeededBb: Double?,
    val villains: List<VillainView>,
    val heroRange: Range?,
    val rangeAdvantage: Double?,
    val nutShareHero: Double?,
    val nutShareVillain: Double?,
    val blockerNote: String?,
    val gtoNote: String?,
    val beginnerText: String,
    val advancedPoints: List<String>,
    val concepts: List<Concept>,
    /** Options within the model's margin of the best one ("both fine"). */
    val closeOptions: List<String> = emptyList(),
    /** The best option against a balanced opponent, when it differs from the best vs this player. */
    val balancedBest: OptionEval? = null,
    /** EVs of every option against a balanced opponent (null when there's no read). */
    val balancedOptions: List<OptionEval>? = null,
    /** The coach's read on the main opponent, e.g. "Ava (Casual): calls too much, rarely bluffs". */
    val read: String? = null,
    /** Things worth noticing in this spot: scare cards, weakness, missed draws, tendencies. */
    val hints: List<String> = emptyList(),
)

data class HandReview(
    val handNumber: Long,
    val seed: Long,
    val bigBlind: Long,
    val heroSeat: Int,
    val decisions: List<Decision>,
    val totalEvLossBb: Double,
    val biggestMistake: Decision?,
    val takeaway: String,
    val heroNetBb: Double,
) {
    companion object {
        const val DISCLAIMER =
            "Opponent ranges are estimated from their actions and the coach's read on each player (style plus " +
                "tendencies seen this session), never from their actual cards. Bets on the flop and turn are " +
                "simulated one street further (second barrels and scare cards). " +
                "Equity is exact enumeration (heads-up, turn/river) or Monte Carlo with a fixed seed. " +
                "EVs come from a one-decision model (equity realization, fold equity from MDF) and are estimates. " +
                "Pot odds, MDF, SPR and out probabilities are exact arithmetic."
    }
}
