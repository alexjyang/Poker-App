package com.pokercoach.engine.replay

import com.pokercoach.engine.card.Card
import com.pokercoach.engine.game.ActionType
import com.pokercoach.engine.game.HandEngine
import com.pokercoach.engine.game.HandEvent
import com.pokercoach.engine.game.HandSnapshot
import com.pokercoach.engine.game.PlayerAction

/**
 * One step of a replay.
 * [boardCount]: how many board cards to show (lets an action that closes a street be shown
 * before the next cards appear). [actorSeat]: who acted in this step, if anyone.
 * [revealedSeats]: players whose hole cards were legitimately shown (the hero, showdown).
 */
data class ReplayFrame(
    val snapshot: HandSnapshot,
    val boardCount: Int,
    val description: String,
    val actorSeat: Int?,
    val actionLabel: String?,
    val revealedSeats: Set<Int>,
)

/**
 * Rebuilds a stored hand step by step by replaying its seed and actions through the engine,
 * so every frame is an exact game state rather than an approximation.
 */
object HandReplay {

    fun frames(events: List<HandEvent>, heroSeat: Int, names: (Int) -> String, presetDeck: List<Card>? = null): List<ReplayFrame> {
        val start = events.first() as HandEvent.HandStarted
        val engine = HandEngine(start.players, start.buttonSeat, start.blinds, start.seed, start.handNumber, presetDeck)
        val shown = events.filterIsInstance<HandEvent.ShowdownHand>().map { it.seat }.toSet()
        val revealedAtEnd = shown + heroSeat
        val frames = mutableListOf<ReplayFrame>()
        val bb = start.blinds.bigBlind

        frames += ReplayFrame(
            engine.snapshot(), 0,
            "Hand #${start.handNumber} · blinds ${start.blinds} · ${names(start.buttonSeat)} has the button",
            null, null, setOf(heroSeat),
        )
        for (a in events.filterIsInstance<HandEvent.ActionTaken>()) {
            val boardBefore = engine.board.size
            engine.act(
                when (a.type) {
                    ActionType.FOLD -> PlayerAction.Fold
                    ActionType.CHECK -> PlayerAction.Check
                    ActionType.CALL -> PlayerAction.Call
                    else -> PlayerAction.BetOrRaise(a.streetTotal)
                },
            )
            val label = label(a)
            val snap = engine.snapshot()
            val complete = engine.isComplete
            frames += ReplayFrame(
                snap, boardBefore,
                "${names(a.seat)} ${label.lowercase()}" + " · pot ${fmt(a.potBefore + a.amountAdded, bb)}",
                a.seat, label, setOf(heroSeat),
            )
            // New board cards appear as their own steps.
            var shownCount = boardBefore
            while (shownCount < engine.board.size) {
                val next = if (shownCount < 3) 3 else shownCount + 1
                val street = when (next) { 3 -> "Flop"; 4 -> "Turn"; else -> "River" }
                val cards = engine.board.subList(shownCount, next).joinToString(" ")
                val reveal = if (complete) revealedAtEnd else setOf(heroSeat)
                frames += ReplayFrame(snap, next, "$street: $cards", null, null, reveal)
                shownCount = next
            }
        }
        // Result.
        val awards = events.filterIsInstance<HandEvent.PotAwarded>()
        val result = awards.joinToString(" · ") { p ->
            val who = p.winners.joinToString(" & ") { names(it) }
            "$who ${if (p.winners.size > 1) "split" else "wins"} ${fmt(p.amount, bb)}" + (p.description?.let { " ($it)" } ?: "")
        }
        frames += ReplayFrame(engine.snapshot(), engine.board.size, result.ifEmpty { "Hand over" }, null, null, revealedAtEnd)
        return frames
    }

    private fun label(a: HandEvent.ActionTaken): String = when {
        a.type == ActionType.FOLD -> "Folds"
        a.type == ActionType.CHECK -> "Checks"
        a.isAllIn -> "All-in ${a.streetTotal}"
        a.type == ActionType.CALL -> "Calls ${a.amountAdded}"
        a.type == ActionType.BET -> "Bets ${a.streetTotal}"
        else -> "Raises to ${a.streetTotal}"
    }

    private fun fmt(chips: Long, bb: Long) = "$chips (${"%.1f".format(chips.toDouble() / bb)} BB)"
}
