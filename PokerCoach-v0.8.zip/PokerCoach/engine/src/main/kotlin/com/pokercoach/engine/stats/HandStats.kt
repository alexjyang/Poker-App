package com.pokercoach.engine.stats

import com.pokercoach.engine.game.ActionType
import com.pokercoach.engine.game.HandEvent
import com.pokercoach.engine.game.Street

/**
 * Standard poker tracker stats for one hand, from the hero's point of view. Opportunity flags
 * ("could have 3-bet") let aggregates use the correct denominators, as HUD software does.
 */
data class HandStatLine(
    val players: Int,
    val bigBlind: Long,
    val netChips: Long,
    val vpip: Boolean,
    val pfr: Boolean,
    val threeBetOpp: Boolean,
    val threeBet: Boolean,
    val sawFlop: Boolean,
    val wentToShowdown: Boolean,
    val wonAtShowdown: Boolean,
    val cbetOpp: Boolean,
    val cbet: Boolean,
    val foldToCbetOpp: Boolean,
    val foldToCbet: Boolean,
    val postflopAggressive: Int,
    val postflopCalls: Int,
) {
    val netBb: Double get() = netChips.toDouble() / bigBlind
}

object HandStats {

    /** Returns null if the hero wasn't dealt in. */
    fun extract(events: List<HandEvent>, heroSeat: Int): HandStatLine? {
        val start = events.firstOrNull() as? HandEvent.HandStarted ?: return null
        if (start.players.none { it.seat == heroSeat }) return null
        val ended = events.lastOrNull() as? HandEvent.HandEnded
        val actions = events.filterIsInstance<HandEvent.ActionTaken>()
        val pre = actions.filter { it.street == Street.PREFLOP }
        val heroPre = pre.filter { it.seat == heroSeat }

        val vpip = heroPre.any { it.type == ActionType.CALL || it.type == ActionType.RAISE || it.type == ActionType.BET }
        val pfr = heroPre.any { it.type == ActionType.RAISE || it.type == ActionType.BET }

        // 3-bet opportunity: the hero acts preflop facing exactly one raise.
        var raisesSoFar = 0
        var threeBetOpp = false
        var threeBet = false
        for (a in pre) {
            if (a.seat == heroSeat && raisesSoFar == 1 && !threeBetOpp) {
                threeBetOpp = true
                threeBet = a.type == ActionType.RAISE
            }
            if (a.type == ActionType.RAISE || a.type == ActionType.BET) raisesSoFar++
        }

        val flopDealt = events.any { it is HandEvent.BoardDealt && it.street == Street.FLOP }
        val heroFoldedPreflop = heroPre.any { it.type == ActionType.FOLD }
        val sawFlop = flopDealt && !heroFoldedPreflop
        val wtsd = events.any { it is HandEvent.ShowdownHand && it.seat == heroSeat }
        val wsd = wtsd && events.any { it is HandEvent.PotAwarded && it.wonAtShowdown && heroSeat in it.winners }

        // Continuation bets.
        val preflopAggressor = pre.lastOrNull { it.type == ActionType.RAISE || it.type == ActionType.BET }?.seat
        val flop = actions.filter { it.street == Street.FLOP }
        var cbetOpp = false
        var cbet = false
        var foldToCbetOpp = false
        var foldToCbet = false
        if (sawFlop && preflopAggressor != null) {
            if (preflopAggressor == heroSeat) {
                val firstHero = flop.firstOrNull { it.seat == heroSeat }
                val betBefore = firstHero != null && flop.takeWhile { it !== firstHero }.any { it.type == ActionType.BET }
                if (firstHero != null && !betBefore && firstHero.toCallBefore == 0L) {
                    cbetOpp = true
                    cbet = firstHero.type == ActionType.BET
                }
            } else {
                val firstBet = flop.firstOrNull { it.type == ActionType.BET }
                if (firstBet != null && firstBet.seat == preflopAggressor) {
                    val after = flop.dropWhile { it !== firstBet }.drop(1)
                    val heroResponse = after.firstOrNull { it.seat == heroSeat }
                    val raisedBefore = heroResponse != null && after.takeWhile { it !== heroResponse }.any { it.type == ActionType.RAISE }
                    if (heroResponse != null && !raisedBefore) {
                        foldToCbetOpp = true
                        foldToCbet = heroResponse.type == ActionType.FOLD
                    }
                }
            }
        }
        val post = actions.filter { it.seat == heroSeat && it.street != Street.PREFLOP }
        return HandStatLine(
            players = start.players.size,
            bigBlind = start.blinds.bigBlind,
            netChips = ended?.netResults?.get(heroSeat) ?: 0L,
            vpip = vpip, pfr = pfr, threeBetOpp = threeBetOpp, threeBet = threeBet,
            sawFlop = sawFlop, wentToShowdown = wtsd, wonAtShowdown = wsd,
            cbetOpp = cbetOpp, cbet = cbet, foldToCbetOpp = foldToCbetOpp, foldToCbet = foldToCbet,
            postflopAggressive = post.count { it.type == ActionType.BET || it.type == ActionType.RAISE },
            postflopCalls = post.count { it.type == ActionType.CALL },
        )
    }
}

/** A rate with its sample size ("12 of 40"). */
data class Rate(val hits: Int, val chances: Int) {
    val value: Double? get() = if (chances == 0) null else hits.toDouble() / chances
    override fun toString(): String = value?.let { "${(it * 100).toInt()}%" } ?: "—"
}

data class StatsSummary(
    val hands: Int,
    val netBb: Double,
    /** Win rate in big blinds per 100 hands. */
    val bbPer100: Double?,
    val vpip: Rate,
    val pfr: Rate,
    val threeBet: Rate,
    /** Aggression factor: postflop (bets + raises) / calls. */
    val aggressionFactor: Double?,
    val postflopActions: Int,
    val wtsd: Rate,
    val wsd: Rate,
    val cbet: Rate,
    val foldToCbet: Rate,
    val avgPlayers: Double,
) {
    companion object {
        fun of(lines: List<HandStatLine>): StatsSummary {
            val n = lines.size
            val net = lines.sumOf { it.netBb }
            val aggr = lines.sumOf { it.postflopAggressive }
            val calls = lines.sumOf { it.postflopCalls }
            return StatsSummary(
                hands = n,
                netBb = net,
                bbPer100 = if (n == 0) null else net / n * 100,
                vpip = Rate(lines.count { it.vpip }, n),
                pfr = Rate(lines.count { it.pfr }, n),
                threeBet = Rate(lines.count { it.threeBet }, lines.count { it.threeBetOpp }),
                aggressionFactor = if (aggr + calls == 0) null else aggr.toDouble() / calls.coerceAtLeast(1),
                postflopActions = aggr + calls,
                wtsd = Rate(lines.count { it.wentToShowdown }, lines.count { it.sawFlop }),
                wsd = Rate(lines.count { it.wonAtShowdown }, lines.count { it.wentToShowdown }),
                cbet = Rate(lines.count { it.cbet }, lines.count { it.cbetOpp }),
                foldToCbet = Rate(lines.count { it.foldToCbet }, lines.count { it.foldToCbetOpp }),
                avgPlayers = if (n == 0) 0.0 else lines.sumOf { it.players }.toDouble() / n,
            )
        }
    }
}
