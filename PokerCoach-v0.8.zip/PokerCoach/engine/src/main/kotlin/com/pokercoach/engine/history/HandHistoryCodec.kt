package com.pokercoach.engine.history

import com.pokercoach.engine.card.Card
import com.pokercoach.engine.game.ActionType
import com.pokercoach.engine.game.AnteType
import com.pokercoach.engine.game.Blinds
import com.pokercoach.engine.game.HandEvent
import com.pokercoach.engine.game.SeatedPlayer
import com.pokercoach.engine.game.Street

/**
 * Encodes a hand's event log as compact, human-readable text (one event per line) for storage.
 * Lossless: decode(encode(events)) == events. Because the log includes the seed and every
 * action, a stored hand can be replayed and re-analyzed exactly.
 *
 * Example:
 * ```
 * PCH1
 * HS|12|-4812…|9f3a…|0|1|2|0|EACH_PLAYER|0,hero,You,200;1,bot-ava,Ava,200
 * BP|1|1|0|0
 * AT|0|PREFLOP|RAISE|6|6|0|3|1|200
 * ```
 */
object HandHistoryCodec {
    private const val HEADER = "PCH1"

    fun encode(events: List<HandEvent>): String = buildString {
        append(HEADER)
        for (e in events) {
            append('\n')
            append(
                when (e) {
                    is HandEvent.HandStarted -> fields(
                        "HS", e.handNumber, e.seed, esc(e.deckCommitment), e.buttonSeat,
                        e.blinds.smallBlind, e.blinds.bigBlind, e.blinds.ante, e.blinds.anteType.name,
                        e.players.joinToString(";") { "${it.seat},${esc(it.playerId)},${esc(it.name)},${it.stack}" },
                    )
                    is HandEvent.AntePosted -> fields("AP", e.seat, e.amount, b(e.isAllIn))
                    is HandEvent.BlindPosted -> fields("BP", e.seat, e.amount, b(e.isBigBlind), b(e.isAllIn))
                    is HandEvent.HoleCardsDealt -> fields("HC", e.seat, cards(e.cards))
                    is HandEvent.ActionTaken -> fields(
                        "AT", e.seat, e.street.name, e.type.name, e.amountAdded, e.streetTotal,
                        b(e.isAllIn), e.potBefore, e.toCallBefore, e.stackBefore,
                    )
                    is HandEvent.BoardDealt -> fields("BD", e.street.name, cards(e.cards))
                    is HandEvent.UncalledBetReturned -> fields("UR", e.seat, e.amount)
                    is HandEvent.ShowdownHand -> fields("SD", e.seat, cards(e.holeCards), e.handValue, esc(e.description))
                    is HandEvent.PotAwarded -> fields(
                        "PA", e.potIndex, e.amount, e.winners.joinToString(","), map(e.shares),
                        b(e.wonAtShowdown), e.description?.let { "S" + esc(it) } ?: "N",
                    )
                    is HandEvent.HandEnded -> fields("HE", map(e.finalStacks), map(e.netResults))
                },
            )
        }
    }

    fun decode(text: String): List<HandEvent> {
        val lines = text.split('\n')
        require(lines.firstOrNull() == HEADER) { "Not a PokerCoach hand history" }
        return lines.drop(1).filter { it.isNotEmpty() }.map { line ->
            val f = line.split('|')
            when (f[0]) {
                "HS" -> HandEvent.HandStarted(
                    handNumber = f[1].toLong(),
                    seed = f[2].toLong(),
                    deckCommitment = unesc(f[3]),
                    buttonSeat = f[4].toInt(),
                    blinds = Blinds(f[5].toLong(), f[6].toLong(), f[7].toLong(), AnteType.valueOf(f[8])),
                    players = f[9].split(';').map { p ->
                        val x = p.split(',')
                        SeatedPlayer(x[0].toInt(), unesc(x[1]), unesc(x[2]), x[3].toLong())
                    },
                )
                "AP" -> HandEvent.AntePosted(f[1].toInt(), f[2].toLong(), f[3] == "1")
                "BP" -> HandEvent.BlindPosted(f[1].toInt(), f[2].toLong(), f[3] == "1", f[4] == "1")
                "HC" -> HandEvent.HoleCardsDealt(f[1].toInt(), Card.parseList(f[2]))
                "AT" -> HandEvent.ActionTaken(
                    seat = f[1].toInt(), street = Street.valueOf(f[2]), type = ActionType.valueOf(f[3]),
                    amountAdded = f[4].toLong(), streetTotal = f[5].toLong(), isAllIn = f[6] == "1",
                    potBefore = f[7].toLong(), toCallBefore = f[8].toLong(), stackBefore = f[9].toLong(),
                )
                "BD" -> HandEvent.BoardDealt(Street.valueOf(f[1]), Card.parseList(f[2]))
                "UR" -> HandEvent.UncalledBetReturned(f[1].toInt(), f[2].toLong())
                "SD" -> HandEvent.ShowdownHand(f[1].toInt(), Card.parseList(f[2]), f[3].toInt(), unesc(f[4]))
                "PA" -> HandEvent.PotAwarded(
                    potIndex = f[1].toInt(),
                    amount = f[2].toLong(),
                    winners = if (f[3].isEmpty()) emptyList() else f[3].split(',').map { it.toInt() },
                    shares = unmap(f[4]),
                    wonAtShowdown = f[5] == "1",
                    description = if (f[6] == "N") null else unesc(f[6].substring(1)),
                )
                "HE" -> HandEvent.HandEnded(unmap(f[1]), unmap(f[2]))
                else -> error("Unknown event '${f[0]}'")
            }
        }
    }

    private fun fields(vararg v: Any): String = v.joinToString("|")
    private fun b(x: Boolean) = if (x) "1" else "0"
    private fun cards(c: List<Card>) = c.joinToString("")
    private fun map(m: Map<Int, Long>) = m.entries.joinToString(",") { "${it.key}:${it.value}" }
    private fun unmap(s: String): Map<Int, Long> =
        if (s.isEmpty()) emptyMap()
        else s.split(',').associate { kv -> kv.substringBefore(':').toInt() to kv.substringAfter(':').toLong() }

    /** Escapes separator characters so free text (names, descriptions) can't break the format. */
    private fun esc(s: String): String = buildString {
        for (ch in s) append(
            when (ch) {
                '\\' -> "\\\\"; '|' -> "\\p"; ';' -> "\\s"; ',' -> "\\c"; ':' -> "\\o"; '\n' -> "\\n"
                else -> ch.toString()
            },
        )
    }

    private fun unesc(s: String): String {
        if ('\\' !in s) return s
        val out = StringBuilder()
        var i = 0
        while (i < s.length) {
            val ch = s[i]
            if (ch == '\\' && i + 1 < s.length) {
                out.append(
                    when (s[i + 1]) {
                        '\\' -> '\\'; 'p' -> '|'; 's' -> ';'; 'c' -> ','; 'o' -> ':'; 'n' -> '\n'
                        else -> s[i + 1]
                    },
                )
                i += 2
            } else {
                out.append(ch)
                i++
            }
        }
        return out.toString()
    }
}
