package com.pokercoach.engine.analysis

import com.pokercoach.engine.game.ActionType
import com.pokercoach.engine.game.HandEvent
import com.pokercoach.engine.game.Street

/**
 * The kind of situation a decision was made in. The leak finder groups mistakes by spot, so it
 * can say "you call too much facing river bets" rather than listing single hands.
 */
enum class Spot(val label: String) {
    PREFLOP_OPEN("opening preflop (first in)"),
    PREFLOP_VS_LIMPERS("preflop after limpers"),
    PREFLOP_VS_OPEN("facing a preflop raise"),
    PREFLOP_BB_DEFENSE("defending the big blind"),
    PREFLOP_VS_3BET("facing a 3-bet or more"),
    FLOP_CBET("continuation-betting the flop"),
    FLOP_BET_OPPORTUNITY("checked to on the flop"),
    FLOP_FACING_BET("facing a flop bet"),
    TURN_BARREL("betting the turn again"),
    TURN_BET_OPPORTUNITY("checked to on the turn"),
    TURN_FACING_BET("facing a turn bet"),
    RIVER_VALUE_OR_BLUFF("betting the river after betting the turn"),
    RIVER_BET_OPPORTUNITY("checked to on the river"),
    RIVER_FACING_BET("facing a river bet");

    val street: Street
        get() = when {
            name.startsWith("PREFLOP") -> Street.PREFLOP
            name.startsWith("FLOP") -> Street.FLOP
            name.startsWith("TURN") -> Street.TURN
            else -> Street.RIVER
        }

    companion object {
        /**
         * Classifies the decision about to be made, from the events before it.
         */
        fun classify(eventsBefore: List<HandEvent>, heroSeat: Int, street: Street, toCall: Long, bigBlindSeat: Int): Spot {
            val actions = eventsBefore.filterIsInstance<HandEvent.ActionTaken>()
            if (street == Street.PREFLOP) {
                val pre = actions.filter { it.street == Street.PREFLOP }
                val raises = pre.count { it.type == ActionType.RAISE || it.type == ActionType.BET }
                val limps = pre.count { it.type == ActionType.CALL } > 0
                return when {
                    raises == 0 && !limps -> PREFLOP_OPEN
                    raises == 0 -> PREFLOP_VS_LIMPERS
                    raises == 1 && heroSeat == bigBlindSeat -> PREFLOP_BB_DEFENSE
                    raises == 1 -> PREFLOP_VS_OPEN
                    else -> PREFLOP_VS_3BET
                }
            }
            val previous = when (street) {
                Street.FLOP -> Street.PREFLOP
                Street.TURN -> Street.FLOP
                else -> Street.TURN
            }
            val lastAggressorPrev = actions.lastOrNull {
                it.street == previous && (it.type == ActionType.RAISE || it.type == ActionType.BET)
            }?.seat
            val heroHadInitiative = lastAggressorPrev == heroSeat
            return when (street) {
                Street.FLOP -> when {
                    toCall > 0 -> FLOP_FACING_BET
                    heroHadInitiative -> FLOP_CBET
                    else -> FLOP_BET_OPPORTUNITY
                }
                Street.TURN -> when {
                    toCall > 0 -> TURN_FACING_BET
                    heroHadInitiative -> TURN_BARREL
                    else -> TURN_BET_OPPORTUNITY
                }
                else -> when {
                    toCall > 0 -> RIVER_FACING_BET
                    heroHadInitiative -> RIVER_VALUE_OR_BLUFF
                    else -> RIVER_BET_OPPORTUNITY
                }
            }
        }
    }
}
