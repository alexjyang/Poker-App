package com.pokercoach.engine.stats

import com.pokercoach.engine.analysis.Grade
import com.pokercoach.engine.analysis.OptionKind
import com.pokercoach.engine.analysis.Spot

/** One graded decision as stored in the history database. */
data class DecisionRecord(
    val handId: Long,
    val spot: Spot,
    val chosen: OptionKind,
    val best: OptionKind,
    val grade: Grade,
    val evLossBb: Double,
)

enum class MistakeType(val phrase: String) {
    CALLS_TOO_MUCH("call too often"),
    FOLDS_TOO_MUCH("fold too often"),
    TOO_PASSIVE("check or call when betting/raising is better"),
    TOO_AGGRESSIVE("bet or raise when checking/calling/folding is better"),
    SIZING("pick the wrong bet size"),
    OTHER("choose a weaker option");

    companion object {
        fun of(chosen: OptionKind, best: OptionKind): MistakeType {
            val aggressive = setOf(OptionKind.BET, OptionKind.RAISE, OptionKind.ALL_IN)
            return when {
                chosen == OptionKind.CALL && best == OptionKind.FOLD -> CALLS_TOO_MUCH
                chosen == OptionKind.FOLD -> FOLDS_TOO_MUCH
                (chosen == OptionKind.CHECK || chosen == OptionKind.CALL) && best in aggressive -> TOO_PASSIVE
                chosen in aggressive && best !in aggressive -> TOO_AGGRESSIVE
                chosen in aggressive && best in aggressive -> SIZING
                else -> OTHER
            }
        }
    }
}

data class Leak(
    val title: String,
    val detail: String,
    val advice: String,
    /** Big blinds lost to this leak (decision leaks) or an estimated severity (stat leaks). */
    val costBb: Double,
    /** Hand ids that show the leak, most costly first. */
    val exampleHands: List<Long>,
    val fromStats: Boolean,
)

/**
 * Finds recurring mistakes. Two sources:
 *  1. Decision leaks: graded decisions grouped by spot and mistake type, e.g. "You call too
 *     often facing river bets (4 of 9 spots, −11.2 BB)". Needs at least 3 mistakes.
 *  2. Stat leaks: tracker stats outside healthy ranges for the table size, e.g. folding to
 *     c-bets 70% of the time. Each has a minimum sample so a few hands can't trigger it.
 */
object LeakFinder {

    fun find(hands: List<Pair<Long, HandStatLine>>, decisions: List<DecisionRecord>): List<Leak> =
        (decisionLeaks(decisions) + statLeaks(hands)).sortedByDescending { it.costBb }

    private fun decisionLeaks(decisions: List<DecisionRecord>): List<Leak> {
        val bySpot = decisions.groupBy { it.spot }
        val leaks = mutableListOf<Leak>()
        for ((spot, inSpot) in bySpot) {
            val mistakes = inSpot.filter { it.grade >= Grade.INACCURACY }
            for ((type, group) in mistakes.groupBy { MistakeType.of(it.chosen, it.best) }) {
                val cost = group.sumOf { it.evLossBb }
                if (group.size < 3 || cost < 2.0) continue
                leaks += Leak(
                    title = "You ${type.phrase} when ${spot.label}",
                    detail = "${group.size} of ${inSpot.size} decisions in this spot, costing ${"%.1f".format(cost)} BB " +
                        "(${group.count { it.grade >= Grade.MISTAKE }} mistakes or blunders).",
                    advice = advice(type, spot),
                    costBb = cost,
                    exampleHands = group.sortedByDescending { it.evLossBb }.map { it.handId }.distinct().take(5),
                    fromStats = false,
                )
            }
        }
        return leaks
    }

    private fun advice(type: MistakeType, spot: Spot): String = when (type) {
        MistakeType.CALLS_TOO_MUCH ->
            "Before calling, compare your equity with the pot odds. Against a bet of pot size you need 33%; if your hand rarely has that against their betting range, fold."
        MistakeType.FOLDS_TOO_MUCH -> when (spot) {
            Spot.PREFLOP_BB_DEFENSE -> "You already have a big blind in the pot, so you get a great price. Defend more suited, connected and high-card hands."
            Spot.FLOP_FACING_BET, Spot.TURN_FACING_BET, Spot.RIVER_FACING_BET ->
                "Opponents can profit by betting any two cards if you fold too much. Defend at least close to MDF with hands that have enough equity or draws."
            else -> "When the price is good, a hand only needs as much equity as the pot odds require. Don't give up hands that can win."
        }
        MistakeType.TOO_PASSIVE ->
            "Bet your strong hands for value and your good draws as semi-bluffs. Checking and calling lets worse hands see free cards and wins smaller pots."
        MistakeType.TOO_AGGRESSIVE ->
            "Only bet when enough worse hands call or enough better hands fold. Medium-strength hands usually want to check."
        MistakeType.SIZING ->
            "Match size to purpose: small bets on dry boards and for thin value, big bets with strong hands and draws on wet boards."
        MistakeType.OTHER -> "Review the example hands and compare your choice with the best option's EV."
    }

    private fun statLeaks(hands: List<Pair<Long, HandStatLine>>): List<Leak> {
        if (hands.isEmpty()) return emptyList()
        val lines = hands.map { it.second }
        val s = StatsSummary.of(lines)
        val out = mutableListOf<Leak>()
        val (vpipLo, vpipHi) = when {
            s.avgPlayers <= 2.5 -> 0.45 to 0.85
            s.avgPlayers <= 6.5 -> 0.18 to 0.32
            else -> 0.13 to 0.26
        }
        fun examples(pred: (HandStatLine) -> Boolean): List<Long> =
            hands.filter { pred(it.second) }.sortedBy { it.second.netChips }.map { it.first }.take(5)

        s.vpip.value?.let { v ->
            if (s.hands >= 50 && v > vpipHi) out += Leak(
                "You play too many hands",
                "VPIP ${pct(v)} over ${s.hands} hands; a solid range at this table size is about ${pct(vpipLo)}–${pct(vpipHi)}.",
                "Fold more weak offsuit hands, especially from early position. Loose ranges lose money after the flop.",
                (v - vpipHi) * 40, examples { it.vpip && !it.pfr }, true,
            )
            if (s.hands >= 50 && v < vpipLo) out += Leak(
                "You play too few hands",
                "VPIP ${pct(v)} over ${s.hands} hands; about ${pct(vpipLo)}–${pct(vpipHi)} is typical here.",
                "Open more hands from late position (cutoff, button) and defend your big blind more.",
                (vpipLo - v) * 30, emptyList(), true,
            )
        }
        val gap = (s.vpip.value ?: 0.0) - (s.pfr.value ?: 0.0)
        if (s.hands >= 50 && gap > 0.10) out += Leak(
            "You limp or call too much preflop",
            "VPIP ${s.vpip} vs PFR ${s.pfr}: you enter many pots without raising.",
            "Prefer raising or folding when first in. Raising wins the blinds often and gives you the initiative.",
            gap * 30, examples { it.vpip && !it.pfr }, true,
        )
        s.foldToCbet.value?.let { v ->
            if (s.foldToCbet.chances >= 15 && v > 0.60) out += Leak(
                "You fold to continuation bets too often",
                "Folded to ${s.foldToCbet.hits} of ${s.foldToCbet.chances} flop c-bets (${pct(v)}); aim for roughly 40–55%.",
                "Many c-bets are made with air. Continue with pairs, draws and good overcards, especially against small bets.",
                (v - 0.6) * 25, examples { it.foldToCbet }, true,
            )
        }
        s.cbet.value?.let { v ->
            if (s.cbet.chances >= 15 && v < 0.40) out += Leak(
                "You rarely continuation-bet",
                "C-bet ${pct(v)} (${s.cbet.hits}/${s.cbet.chances}); after raising preflop you usually have the range advantage.",
                "Bet more flops as the preflop raiser, especially dry, high-card boards with a small size.",
                (0.4 - v) * 15, examples { it.cbetOpp && !it.cbet }, true,
            )
        }
        s.wtsd.value?.let { v ->
            if (s.wtsd.chances >= 30 && v > 0.36) out += Leak(
                "You go to showdown too often",
                "WTSD ${pct(v)} of flops seen; above ~35% usually means calling down too light.",
                "Let go of weak pairs against sustained aggression on the turn and river.",
                (v - 0.36) * 30, examples { it.wentToShowdown && !it.wonAtShowdown }, true,
            )
        }
        s.wsd.value?.let { v ->
            if (s.wsd.chances >= 20 && v < 0.45) out += Leak(
                "You lose too often at showdown",
                "Won ${s.wsd.hits} of ${s.wsd.chances} showdowns (${pct(v)}); healthy is about 50%+.",
                "You're reaching showdown with hands that are usually beaten. Fold more marginal hands to river bets.",
                (0.45 - v) * 30, examples { it.wentToShowdown && !it.wonAtShowdown }, true,
            )
        }
        s.aggressionFactor?.let { af ->
            if (s.postflopActions >= 30 && af < 1.2) out += Leak(
                "You're too passive after the flop",
                "Aggression factor ${"%.1f".format(af)}: you call about as often as you bet or raise.",
                "Turn more calls into bets and raises with strong hands and draws; winning players usually sit at 2–3.",
                (1.2 - af) * 10, emptyList(), true,
            )
        }
        s.threeBet.value?.let { v ->
            if (s.threeBet.chances >= 40 && v < 0.03) out += Leak(
                "You rarely 3-bet",
                "3-bet ${pct(v)} of chances; about 6–10% is typical.",
                "Re-raise your best hands for value and a few suited aces or connectors as bluffs instead of just calling.",
                (0.03 - v) * 100, emptyList(), true,
            )
        }
        return out
    }

    private fun pct(x: Double) = "${(x * 100).toInt()}%"
}
