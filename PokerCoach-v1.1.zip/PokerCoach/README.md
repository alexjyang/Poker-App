# PokerCoach

A No-Limit Texas Hold'em training app for Android.

- **Stage 1** — pure-Kotlin rules engine, hand evaluator, tests ✅
- **Stage 2** — playable table UI with basic bots, installable APK ✅
- **Stage 4** — equity/EV calculator and post-hand analysis ✅ (done before Stage 3 by request)
- **Stage 3** — difficulty levels and bot personalities ✅
- **Stage 5** — stats, leak finder, hand replayer, plus redesigned betting controls ✅
- **Stage 6** — polish: animations, sounds, haptics, themes, card styles, UI tests ✅

## Install on your phone without a computer

GitHub builds the APK for you on every upload.

1. Sign in at github.com in your phone's browser and create a new repository
   (**+ → New repository**, any name, tick **Add a README file**).
2. Upload the project: **Add file → Upload files**, pick the newest `PokerCoach-*.zip` as-is (don't
   unzip it), and commit. The build script finds the newest zip and unpacks it itself.
3. Add the build script: **Add file → Create new file**, type the name
   `.github/workflows/build.yml`, paste the contents of that file from this project, and
   tap **Commit changes**. This commit starts the first build.
4. Open the **Actions** tab. The build takes about 5–8 minutes; a green check means done.
5. Open **Releases** (on the repo's main page), tap the newest build, tap `PokerCoach.apk`.
6. Allow your browser to install unknown apps when Android asks. If Play Protect warns about an
   unknown developer, choose **Install anyway** (it's your own build).

For later stages, upload the new zip the same way; the app updates in place because every build
is signed with the same key (`app/debug.keystore`).

If a build fails, open the failed run in **Actions**, expand the red step, and copy the error.

## Bot personalities (Stage 3)

| Style | How it plays | Measured (6-max, 10,800 hands each) |
|---|---|---|
| Beginner | Loose-passive: limps and calls a lot, estimates equity vs random hands with big errors, slow-plays aces | VPIP 52%, PFR 3%, AF 0.5, −262 bb/100 |
| Casual | Limps, calls too wide, treats top pair as the nuts, tilts after big losses | VPIP 37%, PFR 12%, AF 0.9, −59 bb/100 |
| Regular | Tight-aggressive, position-aware, equity vs estimated ranges vs pot odds | VPIP 20%, PFR 17%, AF 2.6, +64 bb/100 |
| Shark | Aggressive, bluffs in good spots, tracks your fold-to-bet and aggression and exploits them | VPIP 21%, PFR 19%, AF 3.7, +102 bb/100 |
| GTO-approx | Position charts preflop (playability ranking + solver-like frequencies), texture-based sizing, balanced bluff ratio size/(1+2·size), defends near MDF | VPIP 24%, PFR 20%, AF 3.3, +86 bb/100 |
| Custom | Sliders: looseness (VPIP), aggression, bluffing, tilt, adaptiveness | depends |

In the lobby, pick a preset or **Mixed**, or use **Customize each seat** to mix styles. Style
labels are toggleable in the lobby and at the table; a label shows "tilted" when a bot is on tilt.

```
engine/bot/  Bot            interface: decide(view, seat, publicHistory), onHandComplete(...)
             BotProfile     presets + custom slider mapping; PlayabilityRanking (169 classes)
             ProfileBot     preflop: hand rank vs position-scaled ranges (charts for GTO),
                            3-bet / 4-bet / push-fold logic; postflop: equity (ranges or random)
                            + noise + leaks vs pot odds, value/bluff/semi-bluff, sizing
             OpponentStats  per-opponent VPIP, aggression factor, fold-to-bet (public actions only)
game/        HandEngine.publicHistory(seat): the history without other players' hole cards or the
             shuffle seed (the seed would reveal the deck), so bots can read the betting honestly
```

Every decision uses numbers (hand rank, position, stack depth, equity, pot odds); the profile bends
them the way real players do, and seeded randomness only mixes between close options.

## Post-hand analysis (Stage 4)

After each hand the result panel names your worst move (for example "Worst move: Turn call
(Mistake, −1.30 BB) · Better: Fold"). **Review hand** opens the full review, with a Beginner / Advanced toggle.

**Beginner mode** shows, for every decision:
- a grade: Best / Good / Inaccuracy / Mistake / Blunder
- equity, the equity you needed, EV bars for each option
- one plain-language explanation
- outs
- tappable concept chips with glossary definitions

**Advanced mode** adds:
- the EV of every option in BB and the EV you gave up
- the equity method and its error margin
- pot odds, MDF, SPR and implied odds
- a breakdown of each opponent's range (monsters, strong, medium, draws, air)
- 13×13 range grids for opponents and for your perceived range
- range and nut advantage, blocker effects, and a GTO-vs-exploit note on river bets

```
engine/range/     Combos (1,326 hands), HandClass (13×13 grid), weighted Range,
                  PreflopRanking (169 classes by equity vs a random hand), BoardStrength
engine/analysis/  RangeEstimator   ranges from actions: preflop templates by position and action,
                                   postflop narrowing by board-relative hand strength
                  EquityCalculator exact enumeration (heads-up turn/river) or seeded Monte Carlo
                  EvModel          EV of fold / check / call / bet / raise sizes
                  HandAnalyzer     replays the hand, analyzes each hero decision
                  Explainer        beginner text, advanced points, takeaway
                  ReviewModel      Grade, Concept glossary, Decision, HandReview
app/ui/review/    ReviewScreen (summary, decision cards, EV bars, range grids, glossary dialogs)
```

**How the numbers are made, and what is exact versus estimated:**
- **Exact arithmetic:** pot odds and required equity, MDF = pot ÷ (pot + bet), SPR, and hit
  probabilities for a given number of outs.
- **Equity:** exact enumeration heads-up on the turn and river. Otherwise Monte Carlo with a fixed
  seed, shown with a 95% error margin. Either way it is computed against *estimated* ranges.
- **Ranges:** estimated from actions the way a reasonable regular plays. They never use the
  opponents' real cards (the analyzer only reads your hole cards).
- **EV:** a one-decision model. Calls and checks use showdown equity × an equity-realization
  factor (in position > out of position). Bets and raises use fold equity: opponents continue
  with the strongest part of their range, as often as the larger of MDF and "strong enough for
  the price". Future streets, re-raises and side pots are not simulated. All options share one
  random seed, so the *differences* between options are precise.
- **Grades** scale with the pot: losing 2 BB in a 3 BB pot is a blunder, in a 200 BB pot it's not.
  A blunder must also cost at least 2 BB, and folding when you could check is always a mistake.
- **Deterministic:** the same hand always produces the same review.

Speed: about 13 ms per decision on a desktop JVM (roughly 0.1 s on a mid-range phone). Analysis
runs on `Dispatchers.Default` while you keep playing.

## Stage 2 architecture

```
app/  (Android, Jetpack Compose + Material 3)
├── MainActivity.kt              edge-to-edge, theme follows the system light/dark setting
├── ui/PokerCoachApp.kt          screen switching: lobby, table, review, stats, replayer, settings
├── ui/home/HomeScreen.kt        game type, players (2/6/9), buy-in, bot speed
├── ui/table/TableViewModel.kt   game loop: owns TableSession + bots, exposes StateFlow<TableUiState>
├── ui/table/TableArea.kt        oval felt, seats clockwise with you at the bottom, bets, dealer button, board
├── ui/table/ActionBar.kt        Fold / Check-Call / Bet-Raise, quick sizes, slider, typed amount
├── ui/table/PlayingCard.kt      cards with deal-in animation
└── ui/theme/Theme.kt            Material 3 color schemes + table colors
engine/bot/  (pure Kotlin)
├── BasicBot.kt                  preflop Chen score + position; postflop equity vs pot odds
└── QuickEquity.kt               Monte Carlo equity vs random hands
```

**MVVM with a single-owner game loop.** The ViewModel runs one coroutine that is the only code
touching the engine, so there is no shared mutable state. The UI sends intents (hero action,
next hand) through channels and renders an immutable `TableUiState`.

**Bots think off the main thread.** Each decision runs on `Dispatchers.Default` and receives
`snapshotFor(seat)`, which hides everyone else's cards, so bots cannot cheat by construction.

**Bots use numbers, not dice.** Preflop: Chen hand score against position-dependent thresholds,
3-bets with premiums, push/fold under 12 BB. Postflop: Monte Carlo equity against the live
opponents, discounted when facing a bet (a bettor's range beats a random hand), compared with
pot odds. Randomness only mixes between close options. Measured over 30 bot-only sit-and-gos:
VPIP ≈ 17%, PFR ≈ 11% (a solid, slightly tight style). Stage 3 adds the personalities.

**Presentation never changes the game.** Board run-outs after all-ins are revealed street by
street, and stacks show pre-payout values until the reveal ends, purely in the UI layer.

**Portrait and landscape.** Seat positions are computed from the available size; in landscape
the controls move to a side panel. The back gesture asks before leaving a hand in progress.



## Stage 1: engine

### Module layout

```
PokerCoach/
├── settings.gradle.kts          # includes :engine (":app" is added in Stage 2)
├── build.gradle.kts
├── gradle/libs.versions.toml    # version catalog
├── gradlew, gradlew.bat, gradle/wrapper/
└── engine/                      # pure Kotlin/JVM — zero Android dependencies
    └── src/main/kotlin/com/pokercoach/engine/
        ├── card/     Card, Rank, Suit, CardMask, Deck (seeded + SHA-256 commitment)
        ├── rng/      SeededRandom (xoshiro256** + SplitMix64)
        ├── eval/     HandEvaluator, HandValue, HandCategory
        ├── game/     HandEngine (state machine), PotCalculator, events, actions, snapshots
        └── session/  TableSession (cash / sit-and-go), BlindSchedule
```

### Architecture decisions

**Pure Kotlin engine.** The engine is a plain `kotlin("jvm")` module. The Android app will
depend on it, but it never depends on Android, so all rules are covered by fast JVM unit tests.

**Integer chips.** All amounts are `Long` chips. No floating point touches money.

**Cards as bits.** A card is an `Int` 0..51 laid out `suit * 13 + rank`, so a set of cards is a
52-bit `Long` and each suit's ranks are a 13-bit slice. This makes the evaluator and (in Stage 4)
Monte Carlo equity allocation-free.

**Evaluator.** Bitwise, 5–7 cards, one 8 KB straight lookup table. Pairs/trips/quads come from
AND/OR combinations of the four suit masks. The result is a single `Int` whose natural order is
poker order (category, then primary ranks, then kickers). About 33 ns per 7-card hand on a
desktop JVM; verified against all 133,784,560 seven-card hands.

**Deterministic, auditable shuffle.** The engine owns its RNG algorithm (xoshiro256**), so a
seed produces the same deck on every JVM, Android version and Kotlin release. Each hand stores
its seed and a SHA-256 commitment of the deck order; each hand's seed is derived from the session
seed, so a whole session replays from one number plus the recorded actions. A golden test locks
the shuffle so old replays can never silently break.

**State machine + event log.** `HandEngine` is driven by `act(action)` and exposes
`legalActions()`. Every step is appended to an immutable `HandEvent` list. `ActionTaken`
records the pot, the amount to call and the stack the player faced, which is exactly what
the post-hand analysis in Stage 4 needs to rebuild each decision.

**No cheating by construction.** `snapshotFor(seat)` hides every other player's hole cards
until showdown. Bots will only ever receive that view.

**Pot math isolated.** `PotCalculator` (uncalled bets, side pots, odd-chip splits) is a set of
pure functions tested independently of the state machine.

### Rules implemented

- 2–9 players; heads-up blind/position rules (button = small blind, first preflop, last postflop)
- Per-player antes (dead, posted before blinds) and big-blind ante (posted after the BB)
- Short blinds and antes post all-in; callers must still match the full big blind
- Minimum raise = last full raise increment (minimum one big blind)
- Incomplete all-in raises don't reopen betting for players who already acted, unless the
  total they now face is at least a full raise (TDA-style cumulative rule)
- A player who checked may raise any later bet, including an incomplete all-in bet
- Raising is disabled when all opponents are all-in
- Uncalled bets returned; any number of side pots; split pots with odd chips to the first
  winner left of the button; automatic board run-out when betting is closed
- Sessions: cash (auto-rebuy, top-ups) and sit-and-go (hand-based blind levels,
  finishing places, same-hand busts ranked by starting stack); moving button

## Build with a computer (optional)

Requirements: Android Studio (Ladybug or newer) or any JDK 17+.

**Android Studio:** File → Open → select the `PokerCoach` folder → let Gradle sync → pick the
`app` run configuration and press Run (phone via USB debugging or an emulator). Engine tests:
right-click `engine/src/test/kotlin` → *Run 'Tests in engine'*.

**Command line:**

```bash
./gradlew :engine:test          # all engine + bot tests
./gradlew :app:assembleDebug    # APK in app/build/outputs/apk/debug/
```

The first run downloads Gradle 8.14 and dependencies. The exhaustive 7-card evaluator test takes
about 5 seconds; everything else runs in about 2 seconds.

## Test coverage

| Suite | What it proves |
|---|---|
| `HandEvaluatorTest` | Category counts for all 2,598,960 five-card and 133,784,560 seven-card hands; 7,462 and 4,824 distinct strength classes; 7-card = best of 21 subsets (20k random); wheels, kickers, three pairs, two sets of trips, six-card flushes |
| `DeckTest` | Seed determinism, permutation validity, frozen golden order, uniformity (chi-square) |
| `PotCalculatorTest` | Multi-way side pots, dead money from folders, uncalled bets, odd-chip distribution |
| `HandEngineTest` | Positions, walks, min-raise, short all-in reopening rules, antes, short BB, side-pot showdown, split pots, run-outs, hidden cards, decision context; 5,000-hand random fuzz (chip conservation and pot accounting); exact replay |
| `TableSessionTest` | Full SNG to one winner, button movement, blind levels, rebuys, session replay |
| `ProfileBotTest` | Every style finishes sit-and-gos with legal actions; VPIP beginner > casual > regular; regulars raise 3× more than beginners; shark most aggressive; public history hides cards and seed; tilt rises after a big loss and cools; custom sliders are monotonic |
| `SolverTest` | Checked-down values equal exact equity (river and turn); textbook river game equilibrium (37.5% bluffs, 50% defence); low exploitability on realistic spots |
| `SolverIntegrationTest` | The GTO bot value-bets the nuts on the river; the coach shows solver frequencies summing to 100% with low exploitability |
| `ChartTest` | Charts widen from UTG to the button, BB defends 40–65% vs the button (including 76s), AA opens everywhere and gets it in vs a 4-bet; the GTO bot opens from UTG and defends the BB at the chart frequencies |
| `RealismTest` | Mixed low-stakes tables see 35%+ multiway flops; the coach recommends open-limping ≤5% of first-in spots; betting an ace-high flop as the preflop raiser beats checking by 1+ BB, gets 25+ points more fold equity than as the caller, and triggers the representation hint |
| `BotDisciplineTest` | KK facing a 3-bet at 100 BB never shoves; KK facing a 4-bet gets it in; the opener calls a 3-bet with JJ; solid bots don't stack off deep with one pair and call 15%+ of 3-bets |
| `ReadsTest` | A river bluff is worth more against a player who folds than against a station, and the coach says never to bluff the station; balanced play is never graded below Inaccuracy; missed-draw hints; scare cards; reads encode, decode and blend with observations |
| `AnalysisTest` | Folding the nuts = Blunder; calling off with 7-high = Mistake+; folding when checking is free is flagged; AA raises / 72o folds; exact turn equity matches brute force; flush draw = 9 outs with exact hit odds; board-strength ordering; 13×13 grid math; determinism; 60-hand review fuzz |
| `BotTest` | Chen scores, Monte Carlo equity vs known values (AA 85.2%, 72o 34.6%), bots raise aces / fold trash, 20 bot-only SNGs with no illegal actions |

UI tests for the table and review flow are still to do (planned with the Stage 6 polish pass).

## Betting controls

Modeled on GGPoker / PokerStars / partypoker mobile:
- Three large buttons in thumb reach: Fold, Check/Call (with amount), Bet…/Raise….
- **Bet/Raise opens a sizing sheet**: context-aware presets (BB when opening, multiples when
  re-raising, % pot after the flop), a slider that snaps to presets with a haptic tick, −/+ steps
  of one big blind, type-in, and a big confirm button that shows the exact amount, % of pot and
  % of your stack.
- **Pre-actions** while bots think: Check/Fold, Check, Call any (one street at a time).
- **Misclick protection**: confirm before folding when checking is free; tap twice for all-in.
  Both can be switched off.
- **Amounts in big blinds** toggle (table menu or Settings).
- **Coach hint** (off by default): live equity vs likely hands and the equity you need to call.
- **Custom presets** in Settings.

## Stats, leaks and history (Stage 5)

- **Room database**: every hand is stored as its seed plus actions (a few hundred bytes) and
  rebuilt exactly by replay; tracker stats and review results are stored alongside.
- **Stats**, per session or lifetime: hands, win rate (bb/100), VPIP, PFR, 3-bet %, aggression
  factor, WTSD, W$SD, c-bet and fold-to-c-bet, decision accuracy.
- **Graphs**: cumulative winnings in BB and rolling decision accuracy.
- **Leak finder**: groups repeated review mistakes by spot (for example "calling too much facing
  river bets") and flags stat leaks with minimum samples (for example "you fold to c-bets too
  often from the big blind"). Each leak links to example hands.
- **Hand history and replayer**: step forward and back, auto-play, show all cards, and open the
  coach's review for any stored hand (re-analyzed identically, since reviews are deterministic).
- **Settings** stored with DataStore.

## Polish (Stage 6)

- **Animations**, scaled by Settings → Animation speed (Normal / Fast / Off):
  - hole cards are dealt from the middle of the table around the seats;
  - hero cards, board cards and showdown reveals flip over;
  - bets slide out to the bet spot, collect into the pot at the end of each street;
  - the pot flies to the winner.
- **Sounds**: dealing, checks, chips, all-ins, your turn and wins, via SoundPool. The sounds
  are synthesized for this app (`app/src/main/res/raw`), so there are no third-party assets.
- **Haptics**: your turn, any all-in, winning a big pot (20+ BB), and bet-size preset ticks.
- **Themes**: System / Light / Dark, plus Material You colors on Android 12+. Status and
  navigation bar icons follow the app theme.
- **Cards**: four-color deck, Classic or Large-index faces, four card-back colors, with a live
  preview in Settings. Cards have spoken descriptions for TalkBack ("Ace of spades").

### UI tests

`app/src/androidTest` holds Compose UI tests:
- `BettingControlsTest`: call sends Call; folding when checking is free asks first; the sizing
  sheet confirms the chosen preset; all-in needs a second tap.
- `TableFlowTest`: the whole app from the lobby through two hands with the real engine and bots.

They need a phone or emulator, so the GitHub build doesn't run them. With a computer:
connect a phone with USB debugging and run `./gradlew :app:connectedDebugAndroidTest`, or
right-click the `androidTest` folder in Android Studio → *Run tests*.

## Opponent-aware coaching (v0.7)

The coach used to judge every decision as if the hand ended right there, against a generic
opponent who defends well. That made it favour safe, value-only play. Now:

- **Reads on every opponent.** Each bot's style label works like a note on a HUD, and it's
  refined by what you've seen that session (how many hands they play, how often they fold to bets,
  how aggressive they are), weighted by sample size. Hide the labels and the coach relies on
  observations only. Reads shape ranges (loose players' ranges are wider, stations call with
  weaker hands, bluffers bet more air) and fold equity (stations fold less, nits fold more).
- **Two verdicts.** Every decision is valued against *this* opponent and against a balanced one.
  When they differ the review shows both ("Vs this player: Check · Vs balanced: Bet ⅓ pot"), and
  Advanced mode lets you flip the EV bars between them. Grades judge you against this opponent,
  but the balanced line is never graded worse than an inaccuracy.
- **Multi-street bets.** Bets and raises on the flop and turn are simulated one street further:
  you fire again when you improve, are already strong, hold a draw, or a scare card comes, and
  opponents fold weaker hands to that second barrel. Semi-bluffs and barrels get proper credit.
- **Close spots.** Options within the model's margin of the best one (about 3% of the pot) all
  count as best, and the review says it's a mixing spot.
- **Balance hints.** In bluffing spots the coach explains how many of your bets should be
  bluffs for a given size, and which weak hands make good bluffs.
- **Spots to notice**: scare cards, missed draws, an opponent who bet and then checked, capped
  ranges, range and nut advantage, blockers, and the opponent's tendencies. The explanation leads
  with a hint that supports the recommendation, never one that contradicts it.
- Reads are stored with each hand (database v2, existing history is kept), so reopening an old
  review gives the same result.

## Bot discipline (v0.8)

Measured over 6,000 bot hands, the bots played too all-or-nothing. Facing a 3-bet they folded 89%
and 4-bet 6% but called only 3%, and 4-bet wars escalated into deep 5-bet shoves. After the flop
they rarely folded to raises, and a sizing rule jammed whenever a raise reached 85% of the stack.
Changes:

- **Preflop re-raise ladder.**
  - The opener facing a 3-bet calls with pairs and good suited hands (JJ–77, AQ, KQs…),
    4-bets a small value range (AA, KK, often QQ/AK), and aggressive styles occasionally 4-bet
    bluff with A5s–A3s.
  - Facing a 4-bet, only AA/KK (sometimes AK or QQ) get it in; QQ and AK may call when deep.
  - Cold 3-bets are respected. A 5-bet is judged by equity against a very strong range.
  - Facing a 3-bet now: fold 78%, call 17%, 4-bet 4%.
- **Commitment-based all-ins.** A bet or raise only becomes all-in when less than a third of the
  pot would be left behind (the player is committed anyway), not at a fixed share of the stack.
- **Postflop discipline.**
  - A first raise needs a strong made hand (or a low stack-to-pot ratio); re-raising a raise
    needs a near-nut hand, which ends one-pair raise wars.
  - Deep stack-offs with one pair need a clear equity margin.
  - Medium hands facing a raise with deep stacks account for reverse implied odds.
  - Multiway pots need stronger hands to bet or raise.
  - Remaining one-pair all-ins happen only when stacks are already short compared to the pot,
    where getting it in with an overpair is correct.
- **Range reading.** Each extra raise on a street narrows the estimated range sharply (fewer
  bluffs and draws). 5-bet ranges are tighter. This also makes the coach's reviews more accurate.
- Style identities are unchanged. Beginners are still calling stations and Casual players still
  call too wide. Win rates still rank Beginner < Casual < Custom < GTO ≈ Regular < Shark.

## More action, better preflop coaching, and representation (v0.9)

Measured problems:
- At an all-Regular table only 22% of hands saw a flop, and at the Mixed table 4+ players saw a
  flop about 1% of the time.
- First to act, the coach recommended limping with 34–50% of decent hands.
- Bets were valued without regard to what they represent.

**Bots play more hands and see more multiway flops.**
- Big blinds defend roughly 40–55% against a late-position min-raise (was ~20%).
- Late position cold-calls in position, and players overcall when others are already in.
- Recreational styles call raises much wider ("want to see a flop"); Casual VPIP is now ~45%.
- Regular and Shark are slightly looser (VPIP ~25%).
- **Mixed** is now a typical low-stakes table: mostly recreational players, a regular, and a
  shark at bigger tables. On it, 3+ players see about half of all flops.

**Limping is modelled honestly.** A limp is no longer a free look at the flop. Players behind
raise to isolate you with their good hands (you fold or call out of position), others limp along
(multiway), and limped pots realize equity poorly. First in, the coach now recommends raising or
folding, like any solid player; decent hands are raised 97% of the time.

**Bets represent the board.**
- When you bet, thinking opponents continue only with hands that beat enough of your
  *perceived* betting range for the price. As the preflop raiser on an ace-high flop, your range is
  full of aces, so their medium pairs fold. Bluffing J9 there is worth about +3 BB versus +1.4 for
  checking; the same bet after the opponent raised preflop gets far fewer folds and checking
  is best.
- On later streets, an ace or king arriving after you raised preflop counts as a card you
  represent in the second-barrel simulation.
- A new hint says so: "You represent the ace: as the preflop raiser, your range holds an ace 14%
  of the time vs 11% for theirs…"
- Calling stations don't think about your range. They call with their own hand, often a weak
  one, so bluffing them stays a mistake.

## Poker AI: CFR solver and preflop charts (v1.0)

The strongest poker AIs (Libratus, Pluribus) are built on counterfactual regret minimization
(CFR). The open-source solvers are AGPL-licensed desktop tools, so PokerCoach implements the
method itself in plain Kotlin. It works offline and has no license strings attached.

**Real-time subgame solver** (`engine/solver/SubgameSolver.kt`)
- Discounted CFR over a heads-up turn or river subgame, vectorized over every hand in both
  ranges, with exact card removal at showdown (O(n log n) sorted sweeps) and best-response
  exploitability for verification.
- Trees:
  - River: bets of ⅓ and ¾ pot, a raise size, all-in when stacks are short.
  - Turn: ⅔ pot plus all-in, with a simplified river inside it. The real river is solved in
    full when it comes.
- Verified by tests:
  - **Textbook river game:** finds the exact equilibrium (⅓ of pot-sized bets are bluffs; the
    defender calls 50%).
  - **Showdown math:** values equal exact equity on the river and the turn.
  - **Convergence:** river spots reach ~0.05% of the pot exploitable, turn spots ~1%.
- Speed (desktop JVM; expect roughly 3× slower on a mid-range phone): river ~0.2 s for 150
  iterations; turn ~1–3 s for 30–90 iterations on wide ranges.

**Bots**
- **Heads-up on the turn and river:** GTO-approx plays the solved strategy, sampled by its
  frequencies. Shark solves with its reads on the opponent and leans aggressive against players
  who fold too much. Regular plays it less mixed (`solverSharpen`).
- **Ranges:** both come from the range estimator on the public betting history, so a bot only
  ever knows its own cards.
- **Thinking time:** the solver runs during the bot's "thinking" pause, and its budget follows
  Bot speed (Relaxed 1.4 s, Normal 0.9 s, Fast 0.45 s on the turn; a third of that on the river).
- **Beginner and Casual** keep their leaky heuristics on purpose.

**Preflop charts** (`engine/bot/PreflopCharts.kt`, generated by `tools/PreflopSolve.kt`)
- **The games:** CFR+ over the 169 hand classes for two-player preflop games (open, 3-bet,
  4-bet, 5-bet all-in) between every pair of 6-max positions, plus heads-up, 100 BB deep.
- **Postflop value:** all-in equity (169×169 matrix with card removal) adjusted for
  realization by position, pot type and playability (suited, connected, small pairs).
- **Combining:** opening ranges account for every player still to act, and the pairwise games
  are re-solved with those ranges until stable.
- **Result:** opens of UTG 20%, HJ 24%, CO 31%, BTN 40%, SB 39%. The big blind defends ~50% vs
  the button (suited connectors included). Heads-up, the button opens 74%.
- **Use:** GTO-approx follows the charts exactly, Regular less mixed, and Shark adds 3-bets
  against loose openers. They apply at 40+ BB in unlimped pots; everything else uses the
  existing logic.

**Coach**
- For heads-up turn and river decisions, the balanced verdict is a real solve of that spot with
  your exact bet sizes.
- The review shows a solver bar, for example "Solver (GTO) with this hand: Bet ⅔ pot 62% ·
  Check 38%", and how far the solution is from perfect.
- Mixed strategies make close spots explicit: actions in the mix have the same value.
- Fixed iteration counts keep reviews reproducible.

**Limits**
- The flop and multiway pots still use the improved rule-based logic; they're too large to solve
  on a phone.
- Turn solutions are approximate when the time budget is short.
- The preflop charts come from a simplified game (fixed sizes, realization estimates), so they
  are solid but not a commercial solver's output.

## Player stats HUD and remembered lobby (v1.1)

- **HUD on every seat:** VPIP/PFR and hands seen this session, under each bot's stack (e.g.
  "24/19 · 42h"). The colour shows looseness once there are 15+ hands: blue tight, green
  solid, orange loose, red very loose.
- **Tap a seat** for the full readout (VPIP, PFR, postflop aggression, fold to bet), with what
  each number means and how to exploit it.
- **Where the numbers come from:** what you've observed this session (the same notes the coach
  uses for its reads), counted every hand including ones you sat out.
- **Turning it on or off:** in Settings or the table menu.
- **The lobby remembers your setup:** game type (Sit & Go stays Sit & Go), players, buy-in, bot
  speed, opponents, per-seat styles, custom sliders and style labels. They're saved in DataStore
  as you change them and on *Take a seat*, so they survive leaving the table and restarting
  the app.

## What's next

All six stages from the original plan are in place. Natural follow-ups: tournament payout
structures and multi-table SNGs, a drills mode (replaying your leak spots as quizzes), exporting
hand histories, and a Play Store release build with its own signing key.
