package com.pokercoach.engine.analysis

import com.pokercoach.engine.card.Card
import com.pokercoach.engine.card.CardMask
import com.pokercoach.engine.card.Suit
import com.pokercoach.engine.eval.HandEvaluator
import com.pokercoach.engine.game.ActionType
import com.pokercoach.engine.game.HandEngine
import com.pokercoach.engine.game.HandEvent
import com.pokercoach.engine.game.HandSnapshot
import com.pokercoach.engine.game.LegalActions
import com.pokercoach.engine.game.PlayerAction
import com.pokercoach.engine.game.Street
import com.pokercoach.engine.range.BoardStrength
import com.pokercoach.engine.range.Combos
import com.pokercoach.engine.range.PreflopRanking
import com.pokercoach.engine.range.Range
import com.pokercoach.engine.range.StrengthCategory
import com.pokercoach.engine.rng.SeededRandom
import kotlin.math.roundToLong

/**
 * Post-hand review. Replays the hand from its seed and recorded actions (so every decision
 * point is reconstructed exactly), then for each of the hero's decisions computes equity vs.
 * estimated ranges, pot odds, MDF, SPR, outs, implied odds, the EV of every sensible option,
 * a grade and a plain-language explanation.
 *
 * Deterministic: all randomness is seeded from the hand's seed and the decision index.
 * Only the hero's hole cards are ever read; opponents' cards are never used.
 *
 * [iterations] controls Monte Carlo accuracy (and time). ~6,000 is a good default on phones.
 */
class HandAnalyzer(private val iterations: Int = 6_000) {

    private val estimator = RangeEstimator()

    /**
     * [reads]: the coach's read on each opponent seat. Without reads every opponent is treated as
     * a balanced regular; with reads, grades judge play against *this* opponent, while playing
     * the balanced line is never graded worse than an inaccuracy.
     */
    fun analyze(
        events: List<HandEvent>,
        heroSeat: Int,
        presetDeck: List<Card>? = null,
        reads: Map<Int, OpponentProfile> = emptyMap(),
    ): HandReview {
        val start = events.first() as HandEvent.HandStarted
        val bb = start.blinds.bigBlind
        val replay = HandEngine(start.players, start.buttonSeat, start.blinds, start.seed, start.handNumber, presetDeck)
        val decisions = mutableListOf<Decision>()

        for (a in events.filterIsInstance<HandEvent.ActionTaken>()) {
            check(replay.actorSeat == a.seat) { "Replay diverged at seat ${a.seat}" }
            if (a.seat == heroSeat) {
                decisions += analyzeDecision(replay, a, heroSeat, decisions.size, start.seed, reads)
            }
            replay.act(toAction(a))
        }

        val biggest = decisions.filter { it.grade >= Grade.INACCURACY }.maxByOrNull { it.evLossBb }
        val ended = events.lastOrNull() as? HandEvent.HandEnded
        return HandReview(
            handNumber = start.handNumber,
            seed = start.seed,
            bigBlind = bb,
            heroSeat = heroSeat,
            decisions = decisions,
            totalEvLossBb = decisions.sumOf { it.evLossBb },
            biggestMistake = biggest,
            takeaway = Explainer.takeaway(biggest, decisions),
            heroNetBb = (ended?.netResults?.get(heroSeat) ?: 0L).toDouble() / bb,
        )
    }

    private fun toAction(a: HandEvent.ActionTaken): PlayerAction = when (a.type) {
        ActionType.FOLD -> PlayerAction.Fold
        ActionType.CHECK -> PlayerAction.Check
        ActionType.CALL -> PlayerAction.Call
        ActionType.BET, ActionType.RAISE -> PlayerAction.BetOrRaise(a.streetTotal)
    }

    // ------------------------------------------------------------------ one decision

    private fun analyzeDecision(
        replay: HandEngine,
        a: HandEvent.ActionTaken,
        heroSeat: Int,
        index: Int,
        handSeed: Long,
        reads: Map<Int, OpponentProfile>,
    ): Decision {
        val snap = replay.snapshot()
        val legal = replay.legalActions()!!
        val bb = snap.blinds.bigBlind
        val hero = snap.seat(heroSeat)
        val heroCards = hero.holeCards!!
        val board = snap.board
        val street = snap.street
        val heroMask = CardMask.of(heroCards)
        val boardMask = CardMask.of(board)
        val dead = heroMask or boardMask
        val seed = SeededRandom.derive(handSeed, 1_000L + index)
        val liveOpps = snap.seats.filter { it.seat != heroSeat && !it.folded }
        val hasReads = liveOpps.any { reads[it.seat]?.isBalanced == false }
        val est = estimator.estimate(replay.events, reads)
        val estBalanced = if (hasReads) estimator.estimate(replay.events) else est

        // --- opponents (with the read, and as balanced players)
        fun opponentsFrom(e: RangeEstimator.Estimate, withReads: Boolean) = liveOpps.map { o ->
            val acted = street != Street.PREFLOP || o.seat in e.actedThisStreet
            val role = if (acted) null else when (o.seat) {
                snap.bigBlindSeat -> UnopenedRole.BIG_BLIND
                snap.smallBlindSeat -> UnopenedRole.SMALL_BLIND
                else -> UnopenedRole.OTHER
            }
            val raw = e.ranges.getValue(o.seat)
            val usable = if (raw.totalWeight(dead) > 1e-9) raw else Range.full()
            Opponent(
                seat = o.seat,
                range = usable,
                streetCommit = o.streetCommit,
                stackBehind = o.stack,
                inPot = acted || o.seat == snap.bigBlindSeat,
                unopenedRole = role,
                profile = if (withReads) reads[o.seat] ?: OpponentProfile.BALANCED else OpponentProfile.BALANCED,
            )
        }
        val opponents = opponentsFrom(est, withReads = true)
        val heroIp = heroInPosition(snap, heroSeat)
        val lastPreflopRaiser = replay.events.filterIsInstance<HandEvent.ActionTaken>()
            .lastOrNull { it.street == Street.PREFLOP && (it.type == ActionType.RAISE || it.type == ActionType.BET) }?.seat
        val heroAggressor = lastPreflopRaiser == heroSeat
        fun situationWith(opps: List<Opponent>, e: RangeEstimator.Estimate) = Situation(
            hero = heroCards, board = board, street = street, pot = snap.pot,
            currentBet = snap.currentBet, heroCommit = hero.streetCommit, heroStack = hero.stack,
            bigBlind = bb, opponents = opps, heroInPosition = heroIp,
            heroPerceived = e.ranges[heroSeat], heroPreflopAggressor = heroAggressor,
        )

        // --- options and EVs: against this opponent, and against a balanced one
        val options = buildOptions(snap, legal, hero.streetCommit, hero.stack, a, opponents)
        val chosenOption = matchChosen(options, a, legal)
        val model = EvModel(iterations)
        val results = model.evaluate(situationWith(opponents, est), options, seed)
        val resultsBalanced = if (hasReads) model.evaluate(situationWith(opponentsFrom(estBalanced, withReads = false), estBalanced), options, seed) else results

        fun bestOf(rs: List<OptionResult>) = rs.maxWith(compareBy<OptionResult> { it.evChips }.thenBy { if (it.option == chosenOption) 1 else 0 })
        fun lossOf(rs: List<OptionResult>) = (bestOf(rs).evChips - rs.first { it.option == chosenOption }.evChips).coerceAtLeast(0.0)
        val bestResult = bestOf(results)
        val lossChips = lossOf(results)
        val preflop = street == Street.PREFLOP
        var grade = Grade.of(lossChips, snap.pot, bb, preflop)
        if (hasReads) {
            // Playing the balanced line is never worse than an inaccuracy, even when this
            // opponent could have been exploited for more.
            val cap = maxOf(Grade.of(lossOf(resultsBalanced), snap.pot, bb, preflop), Grade.INACCURACY)
            if (grade > cap) grade = cap
        }
        // Folding when you could check for free is always a real mistake, whatever the pot size.
        if (chosenOption.kind == OptionKind.FOLD && legal.canCheck && grade < Grade.MISTAKE) grade = Grade.MISTAKE

        fun evalsOf(rs: List<OptionResult>): List<OptionEval> {
            val best = bestOf(rs).option
            return rs.map { r ->
                OptionEval(
                    label = r.option.label, kind = r.option.kind, to = r.option.to,
                    evBb = r.evChips / bb, foldEquity = r.foldEquity, equityWhenCalled = r.equityWhenCalled,
                    isChosen = r.option == chosenOption, isBest = r.option == best,
                )
            }
        }
        val evals = evalsOf(results)
        val balancedEvals = if (hasReads) evalsOf(resultsBalanced) else null
        val balancedBest = balancedEvals?.first { it.isBest }?.takeIf { it.label != evals.first { e -> e.isBest }.label }
        val tolerance = maxOf(0.03 * snap.pot, 0.15 * bb)
        val closeOptions = results.filter { bestResult.evChips - it.evChips <= tolerance }.map { it.option.label }

        // --- equity vs the players in the pot
        val inPot = opponents.filter { it.inPot }
        val equityRanges = if (inPot.isNotEmpty()) inPot.map { it.range } else listOf(Range.full())
        val equity = EquityCalculator.vsRanges(heroCards, board, equityRanges, iterations * 2, SeededRandom(seed xor 0x5EED))
        val equityVs = when {
            inPot.isEmpty() -> "one random hand"
            inPot.size == 1 -> "the estimated range of the ${if (inPot[0].unopenedRole == UnopenedRole.BIG_BLIND) "big blind (any two cards)" else "opponent"}"
            else -> "${inPot.size} opponents' estimated ranges"
        }

        // --- exact arithmetic
        val toCall = legal.toCall
        val requiredEquity = if (toCall > 0) toCall.toDouble() / (snap.pot + toCall) else null
        val mdf = if (street != Street.PREFLOP && toCall > 0) (snap.pot - toCall).toDouble() / snap.pot else null
        val maxOppStack = liveOpps.maxOfOrNull { it.stack } ?: 0L
        val effStack = minOf(hero.stack, maxOppStack)
        val spr = if (street != Street.PREFLOP && snap.pot > 0) effStack.toDouble() / snap.pot else null

        // --- outs and implied odds
        val outs = if ((street == Street.FLOP || street == Street.TURN) && equity.equity < 0.5 && inPot.isNotEmpty()) {
            computeOuts(heroMask, board, inPot.map { it.range })
        } else null
        val impliedNeeded = if (toCall > 0 && street != Street.RIVER && equity.equity > 0.02) {
            val direct = equity.equity * (snap.pot + toCall) - toCall
            if (direct < 0) ((toCall - equity.equity * (snap.pot + toCall)) / equity.equity) / bb else null
        } else null

        // --- ranges, advantage, blockers
        val strength = if (board.size >= 3) BoardStrength(board) else null
        val villainViews = opponents.filter { it.inPot }.map { o ->
            VillainView(o.seat, o.range.without(dead), o.range.fractionOfAllHands(), breakdown(o.range, dead, strength))
        }
        val heroRange = est.ranges[heroSeat]
        val primary = inPot.maxByOrNull { it.streetCommit }
        var rangeAdv: Double? = null
        var nutHero: Double? = null
        var nutVillain: Double? = null
        if (strength != null && primary != null && heroRange != null) {
            rangeAdv = EquityCalculator.rangeVsRange(heroRange, primary.range, board, 2_000, SeededRandom(seed xor 0xADL))
            nutHero = nutShare(heroRange, boardMask, strength)
            nutVillain = nutShare(primary.range, boardMask, strength)
        }
        val blocker = blockerNote(heroCards, board, primary?.range, strength)
        val gto = gtoNote(street, toCall, snap.pot, villainViews.firstOrNull(), strength)

        val chosenEval = evals.first { it.isChosen }
        val bestEval = evals.first { it.isBest }
        val primaryRead = primary?.let { reads[it.seat] }?.takeIf { !it.isBalanced }
        val readText = primaryRead?.let { "${it.label}: ${it.describe()} (${it.source})" }
        val allHints = spotHints(replay.events, heroSeat, heroCards, board, street, primary, primaryRead, rangeAdv, nutHero, nutVillain, blocker, equity.equity) +
            listOfNotNull(representationHint(board, street, heroAggressor, heroRange, primary?.range))
        // Lead with a hint that supports the recommended play, never one that contradicts it.
        val wanted = when (bestEval.kind) {
            OptionKind.BET, OptionKind.RAISE, OptionKind.ALL_IN -> Hint.Favors.BET
            OptionKind.CALL -> Hint.Favors.CALL_DOWN
            else -> Hint.Favors.CHECK_OR_FOLD
        }
        val lead = allHints.firstOrNull { it.favors == wanted } ?: allHints.firstOrNull { it.favors == Hint.Favors.NEUTRAL }
        val hints = (listOfNotNull(lead) + (allHints - setOfNotNull(lead))).map { it.text }
        val facts = Facts(
            street = street, chosen = chosenEval, best = bestEval, options = evals, grade = grade,
            evLossBb = lossChips / bb, equity = equity.equity, equityExact = equity.exact,
            equityMethod = equity.method, equityVs = equityVs, requiredEquity = requiredEquity,
            canCheck = legal.canCheck, potBb = snap.pot.toDouble() / bb, toCallBb = toCall.toDouble() / bb,
            mdf = mdf, spr = spr, outs = outs, impliedOddsNeededBb = impliedNeeded,
            effectiveStackBb = effStack.toDouble() / bb, villains = villainViews,
            rangeAdvantage = rangeAdv, nutShareHero = nutHero, nutShareVillain = nutVillain,
            blockerNote = blocker, gtoNote = gto, inPosition = heroIp, multiway = inPot.size > 1,
            closeOptions = closeOptions, balancedBest = balancedBest, readLabel = primaryRead?.label,
            readDescription = primaryRead?.describe(), hints = hints, leadHint = lead?.text,
        )
        val (beginner, advanced, concepts) = Explainer.explain(facts)

        val spot = Spot.classify(replay.events, heroSeat, street, toCall, snap.bigBlindSeat)
        return Decision(
            index = index, street = street, spot = spot, board = board, heroCards = heroCards,
            actionLabel = chosenEval.label,
            potBb = snap.pot.toDouble() / bb, toCallBb = toCall.toDouble() / bb,
            effectiveStackBb = effStack.toDouble() / bb,
            requiredEquity = requiredEquity, mdf = mdf, spr = spr,
            equity = equity, equityVs = equityVs,
            options = evals, chosen = chosenEval, best = bestEval,
            evLossBb = lossChips / bb, grade = grade,
            outs = outs, impliedOddsNeededBb = impliedNeeded,
            villains = villainViews, heroRange = heroRange?.without(boardMask),
            rangeAdvantage = rangeAdv, nutShareHero = nutHero, nutShareVillain = nutVillain,
            blockerNote = blocker, gtoNote = gto,
            beginnerText = beginner, advancedPoints = advanced, concepts = concepts,
            closeOptions = closeOptions, balancedBest = balancedBest, balancedOptions = balancedEvals,
            read = readText, hints = hints,
        )
    }

    // ------------------------------------------------------------------ helpers

    /**
     * "You represent it": a high card on board that hero's perceived range holds far more often
     * than the opponent's (typically an ace or king for the preflop raiser). Betting tells that
     * story, and the opponent's medium pairs struggle to call.
     */
    private fun representationHint(board: List<Card>, street: Street, heroAggressor: Boolean, heroRange: Range?, villainRange: Range?): Hint? {
        if (street == Street.PREFLOP || heroRange == null || villainRange == null) return null
        val top = board.maxBy { it.rank.ordinal }
        if (top.rank.ordinal < com.pokercoach.engine.card.Rank.KING.ordinal) return null
        val boardMask = CardMask.of(board)
        fun shareWith(r: Range): Double {
            var t = 0.0; var hit = 0.0
            for (i in 0 until Combos.COUNT) {
                val w = r.weight(i)
                if (w <= 0 || Combos.mask[i] and boardMask != 0L) continue
                t += w
                if (Card(Combos.card1[i]).rank == top.rank || Card(Combos.card2[i]).rank == top.rank) hit += w
            }
            return if (t == 0.0) 0.0 else hit / t
        }
        val mine = shareWith(heroRange)
        val theirs = shareWith(villainRange)
        // The preflop raiser only needs to hold it more often than the caller; otherwise a clear edge.
        if (if (heroAggressor) mine <= theirs else mine < theirs + 0.08) return null
        val newCard = street != Street.FLOP && board.last() == top
        val who = if (heroAggressor) "As the preflop raiser, your" else "Your"
        val card = top.rank.displayName.lowercase()
        val article = if (top.rank == com.pokercoach.engine.card.Rank.ACE) "an" else "a"
        return Hint(
            "You represent the $card: $who range holds $article $card " +
                "${(mine * 100).toInt()}% of the time vs ${(theirs * 100).toInt()}% for theirs" +
                (if (newCard) ", and it just arrived" else "") +
                ". A bet tells that story; their medium pairs can't call comfortably, so it works as a bluff too.",
            Hint.Favors.BET,
        )
    }

    /**
     * Things a good player notices beyond their own hand strength: how the board changed, what
     * the opponent's line says about their range, missed draws, and the opponent's tendencies.
     */
    private fun spotHints(
        events: List<HandEvent>,
        heroSeat: Int,
        hero: List<Card>,
        board: List<Card>,
        street: Street,
        primary: Opponent?,
        read: OpponentProfile?,
        rangeAdv: Double?,
        nutHero: Double?,
        nutVillain: Double?,
        blocker: String?,
        heroEquity: Double,
    ): List<Hint> {
        val hints = mutableListOf<Hint>()
        val acts = events.filterIsInstance<HandEvent.ActionTaken>()

        // Scare card: the newest board card changes who is likely ahead.
        if (street == Street.TURN || street == Street.RIVER) {
            val prev = board.dropLast(1)
            val card = board.last()
            if (EvModel.isScareCard(prev, card.id)) {
                val why = when {
                    prev.count { it.suit == card.suit } == 2 -> "puts three ${card.suit.name.lowercase()} on board, so flushes are now possible"
                    card.rank.ordinal > prev.maxOf { it.rank.ordinal } -> "is an overcard that beats many of the pairs they could have"
                    else -> "makes straights possible"
                }
                hints += Hint("Scare card: the $card $why — it changes who is likely ahead.", Hint.Favors.NEUTRAL)
            }
        }

        // Missed draw on the river.
        if (street == Street.RIVER) {
            val turnStrength = BoardStrength(board.take(4))
            val combo = Combos.index(hero[0], hero[1])
            if (turnStrength.draw[combo] > 0 && BoardStrength(board).hs[combo] < 0.35) {
                hints += Hint("Your draw missed. This hand can almost never win at showdown, so it only wins by bluffing — a bluff candidate if they look weak.", Hint.Favors.BET)
            }
        }

        // What the opponent's line says.
        if (primary != null && street != Street.PREFLOP) {
            val theirs = acts.filter { it.seat == primary.seat }
            val thisStreet = theirs.filter { it.street == street }
            val lastStreet = when (street) { Street.TURN -> Street.FLOP; Street.RIVER -> Street.TURN; else -> null }
            val prev = theirs.filter { it.street == lastStreet }
            val aggressedBefore = prev.any { it.type == ActionType.BET || it.type == ActionType.RAISE }
            when {
                aggressedBefore && thisStreet.any { it.type == ActionType.CHECK } ->
                    hints += Hint("They bet last street but checked now: usually a sign they gave up or have a medium hand.", Hint.Favors.BET)
                prev.isNotEmpty() && prev.all { it.type == ActionType.CALL || it.type == ActionType.CHECK } && lastStreet != null ->
                    hints += Hint("Their range is capped: they only checked or called last street, so they rarely hold the very best hands.", Hint.Favors.BET)
            }
        }

        // Board and range advantage.
        if (rangeAdv != null && rangeAdv >= 0.56 && street == Street.FLOP) {
            hints += Hint("This board favours your range (${(rangeAdv * 100).toInt()}% range equity): you can bet often, even with some weak hands.", Hint.Favors.BET)
        }
        if (nutHero != null && nutVillain != null && nutHero - nutVillain >= 0.08) {
            hints += Hint("You have more of the strongest possible hands here, which makes bigger bets credible.", Hint.Favors.BET)
        }
        if (blocker != null) hints += Hint(blocker, Hint.Favors.NEUTRAL)

        // The opponent's tendencies (listed first: they matter most for exploitative play).
        val tendencies = mutableListOf<Hint>()
        if (read != null) {
            when {
                read.foldToBet < 0.8 && heroEquity >= 0.5 ->
                    tendencies += Hint("${read.label} calls too much: your value bets get paid, so bet bigger with good hands.", Hint.Favors.BET)
                read.foldToBet < 0.8 ->
                    tendencies += Hint("${read.label} calls too much: bluffs rarely work against them.", Hint.Favors.CHECK_OR_FOLD)
                read.foldToBet > 1.2 ->
                    tendencies += Hint("${read.label} folds to bets often: bluffs and thin bets work well against them.", Hint.Favors.BET)
            }
            if (read.bluffiness > 1.4) tendencies += Hint("${read.label} bluffs a lot: call down lighter when they bet.", Hint.Favors.CALL_DOWN)
            else if (read.bluffiness < 0.6 && primary != null && primary.streetCommit > 0) {
                tendencies += Hint("${read.label} rarely bluffs: when they bet big, believe them.", Hint.Favors.CHECK_OR_FOLD)
            }
        }
        hints.addAll(0, tendencies)
        return hints
    }

    private fun heroInPosition(snap: HandSnapshot, heroSeat: Int): Boolean {
        val seats = snap.seats.map { it.seat }
        val n = seats.size
        val btn = seats.indexOf(snap.buttonSeat)
        val order = List(n) { seats[(btn + 1 + it) % n] } // postflop acting order
        val live = order.filter { s -> s == heroSeat || !snap.seat(s).folded }
        return live.lastOrNull() == heroSeat
    }

    private fun buildOptions(
        snap: HandSnapshot,
        legal: LegalActions,
        heroCommit: Long,
        heroStack: Long,
        chosen: HandEvent.ActionTaken,
        opponents: List<Opponent>,
    ): List<Option> {
        val bb = snap.blinds.bigBlind
        val out = mutableListOf<Option>()
        if (!legal.canCheck || chosen.type == ActionType.FOLD) out += Option(OptionKind.FOLD, 0, "Fold")
        out += if (legal.canCheck) Option(OptionKind.CHECK, 0, "Check")
        else Option(OptionKind.CALL, heroCommit + legal.toCall, if (legal.callIsAllIn) "Call all-in" else "Call")

        if (legal.canRaise) {
            val pot = snap.pot
            val maxTo = legal.maxRaiseTo
            val effBb = minOf(heroCommit + heroStack, opponents.maxOfOrNull { it.streetCommit + it.stackBehind } ?: 0L).toDouble() / bb
            val targets = mutableListOf<Pair<Long, String?>>()
            if (snap.street == Street.PREFLOP) {
                if (snap.currentBet <= bb) {
                    val limpers = opponents.count { it.streetCommit == bb && it.seat != snap.bigBlindSeat }
                    targets += (bb * 5 / 2 + limpers * bb) to null
                    targets += (bb * 3 + limpers * bb) to null
                    if (effBb <= 25) targets += maxTo to null
                } else {
                    targets += snap.currentBet * 3 to null
                    targets += snap.currentBet * 4 to null
                    if (effBb <= 40) targets += maxTo to null
                }
            } else if (legal.isBet) {
                targets += (pot / 3.0).roundToLong() to "Bet ⅓ pot"
                targets += (pot * 2 / 3.0).roundToLong() to "Bet ⅔ pot"
                targets += pot to "Bet pot"
                if (effBb * bb <= pot * 3.0) targets += maxTo to null
            } else {
                targets += (snap.currentBet * 2.5).roundToLong() to null
                targets += (snap.currentBet * 3.5).roundToLong() to null
                if (effBb * bb <= pot * 4.0) targets += maxTo to null
            }
            if (chosen.type == ActionType.BET || chosen.type == ActionType.RAISE) targets += chosen.streetTotal to null

            val seen = mutableSetOf<Long>()
            for ((raw, label) in targets) {
                var to = raw.coerceIn(legal.minRaiseTo, maxTo)
                if (to >= maxTo * 0.9) to = maxTo
                if (chosen.type == ActionType.BET || chosen.type == ActionType.RAISE) {
                    if (raw == chosen.streetTotal) to = chosen.streetTotal // keep the hero's exact size
                }
                if (!seen.add(to)) continue
                val kind = when {
                    to == maxTo -> OptionKind.ALL_IN
                    legal.isBet -> OptionKind.BET
                    else -> OptionKind.RAISE
                }
                val text = when {
                    kind == OptionKind.ALL_IN -> "All-in"
                    label != null && to == raw.coerceIn(legal.minRaiseTo, maxTo) -> label
                    kind == OptionKind.BET -> "Bet ${(to * 100.0 / pot).roundToLong()}% pot"
                    snap.street == Street.PREFLOP && snap.currentBet <= bb -> "Raise to ${fmtBb(to, bb)}"
                    else -> "Raise to ${"%.1f".format(to.toDouble() / snap.currentBet)}x"
                }
                out += Option(kind, to, text)
            }
        }
        return out
    }

    private fun fmtBb(chips: Long, bb: Long): String {
        val v = chips.toDouble() / bb
        return if (v == v.toLong().toDouble()) "${v.toLong()} BB" else "%.1f BB".format(v)
    }

    private fun matchChosen(options: List<Option>, a: HandEvent.ActionTaken, legal: LegalActions): Option = when (a.type) {
        ActionType.FOLD -> options.first { it.kind == OptionKind.FOLD }
        ActionType.CHECK -> options.first { it.kind == OptionKind.CHECK }
        ActionType.CALL -> options.first { it.kind == OptionKind.CALL }
        ActionType.BET, ActionType.RAISE -> options.first {
            it.kind in setOf(OptionKind.BET, OptionKind.RAISE, OptionKind.ALL_IN) &&
                (it.to == a.streetTotal || (a.streetTotal == legal.maxRaiseTo && it.kind == OptionKind.ALL_IN))
        }
    }

    /**
     * Outs: unseen cards after which hero goes from behind (winning < 50% of the range's
     * weight right now) to ahead of at least 70% of every opponent's range.
     */
    internal fun computeOuts(heroMask: Long, board: List<Card>, ranges: List<Range>): OutsInfo? {
        val boardMask = CardMask.of(board)
        fun shareVs(range: Range, b: Long): Double {
            val hv = HandEvaluator.evaluateMask(heroMask or b)
            var total = 0.0
            var won = 0.0
            for (c in 0 until Combos.COUNT) {
                val w = range.weight(c)
                if (w <= 0 || Combos.mask[c] and (heroMask or b) != 0L) continue
                val v = HandEvaluator.evaluateMask(Combos.mask[c] or b)
                total += w
                won += w * when { hv > v -> 1.0; hv == v -> 0.5; else -> 0.0 }
            }
            return if (total == 0.0) 1.0 else won / total
        }
        val now = ranges.minOf { shareVs(it, boardMask) }
        if (now >= 0.5) return null
        val outs = mutableListOf<Card>()
        var unseen = 0
        for (id in 0 until 52) {
            val bit = 1L shl id
            if ((heroMask or boardMask) and bit != 0L) continue
            unseen++
            if (ranges.all { shareVs(it, boardMask or bit) >= 0.7 }) outs += Card(id)
        }
        if (outs.isEmpty()) return null
        val n = outs.size.toDouble()
        val next = n / unseen
        val byRiver = if (board.size == 3) {
            val miss = (unseen - n) * (unseen - n - 1) / (unseen.toDouble() * (unseen - 1))
            1 - miss
        } else null
        return OutsInfo(outs.size, outs.sortedDescending(), unseen, next, byRiver)
    }

    private fun breakdown(range: Range, dead: Long, strength: BoardStrength?): List<Pair<String, Double>> {
        val totals = LinkedHashMap<String, Double>()
        var total = 0.0
        for (i in 0 until Combos.COUNT) {
            val w = range.weight(i)
            if (w <= 0 || Combos.mask[i] and dead != 0L) continue
            val label = if (strength != null) strength.category(i).label else {
                val s = PreflopRanking.strength(Combos.classOf[i])
                when {
                    s >= 0.95 -> "Premium"
                    s >= 0.85 -> "Strong"
                    s >= 0.60 -> "Playable"
                    else -> "Weak"
                }
            }
            totals[label] = (totals[label] ?: 0.0) + w
            total += w
        }
        if (total == 0.0) return emptyList()
        val order = if (strength != null) StrengthCategory.entries.map { it.label } else listOf("Premium", "Strong", "Playable", "Weak")
        return order.mapNotNull { l -> totals[l]?.let { l to it / total } }
    }

    private fun nutShare(range: Range, boardMask: Long, strength: BoardStrength): Double? {
        var total = 0.0
        var nuts = 0.0
        for (i in 0 until Combos.COUNT) {
            val w = range.weight(i)
            if (w <= 0 || Combos.mask[i] and boardMask != 0L) continue
            total += w
            if (strength.hs[i] >= 0.9) nuts += w
        }
        return if (total == 0.0) null else nuts / total
    }

    private fun blockerNote(hero: List<Card>, board: List<Card>, villain: Range?, strength: BoardStrength?): String? {
        // Nut flush blocker.
        if (board.size >= 3) {
            val suitCounts = board.groupingBy { it.suit }.eachCount()
            val flushSuit: Suit? = suitCounts.entries.firstOrNull { it.value >= 3 }?.key
            if (flushSuit != null) {
                val ace = hero.firstOrNull { it.suit == flushSuit && it.rank.ordinal == 12 }
                val heroSuited = hero.count { it.suit == flushSuit }
                if (ace != null && heroSuited == 1) {
                    return "Blocker: you hold $ace, so they can't have the nut flush."
                }
            }
        }
        if (villain == null) return null
        // Share of their strongest combos that your cards make impossible.
        val heroMask = CardMask.of(hero)
        val boardMask = CardMask.of(board)
        var value = 0.0
        var blocked = 0.0
        for (i in 0 until Combos.COUNT) {
            val w = villain.weight(i)
            if (w <= 0 || Combos.mask[i] and boardMask != 0L) continue
            val strong = if (strength != null) strength.hs[i] >= 0.8 else PreflopRanking.strength(Combos.classOf[i]) >= 0.95
            if (!strong) continue
            value += w
            if (Combos.mask[i] and heroMask != 0L) blocked += w
        }
        if (value == 0.0) return null
        val share = blocked / value
        return if (share >= 0.2) "Blockers: your cards remove about ${(share * 100).toInt()}% of their strongest combinations." else null
    }

    private fun gtoNote(street: Street, toCall: Long, pot: Long, villain: VillainView?, strength: BoardStrength?): String? {
        if (street != Street.RIVER || toCall <= 0 || villain == null || strength == null) return null
        val bet = toCall.toDouble()
        val before = (pot - toCall).toDouble()
        val balancedBluffs = bet / (before + 2 * bet)
        val air = villain.breakdown.firstOrNull { it.first == StrengthCategory.AIR.label }?.second ?: 0.0
        val verdict = when {
            air < balancedBluffs * 0.7 -> "they seem to under-bluff, so folding more than MDF is the exploitative adjustment"
            air > balancedBluffs * 1.3 -> "they seem to over-bluff, so calling more often is the exploitative adjustment"
            else -> "their estimate is close to balanced, so defending near MDF is reasonable"
        }
        return "GTO vs exploit: a balanced river bet of this size contains about ${(balancedBluffs * 100).toInt()}% bluffs; " +
            "the estimated range has ${(air * 100).toInt()}% weak hands — $verdict."
    }
}

/** Something worth noticing, and which kind of play it supports. */
internal data class Hint(val text: String, val favors: Favors) {
    enum class Favors { BET, CHECK_OR_FOLD, CALL_DOWN, NEUTRAL }
}
