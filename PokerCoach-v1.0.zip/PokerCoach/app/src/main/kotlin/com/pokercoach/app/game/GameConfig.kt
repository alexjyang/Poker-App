package com.pokercoach.app.game

import com.pokercoach.engine.bot.BotStyle
import com.pokercoach.engine.bot.CustomSettings
import com.pokercoach.engine.rng.SeededRandom

enum class GameType(val label: String) { CASH("Cash game"), SIT_AND_GO("Sit & Go") }

/** [solverMs]: how long solver bots may think heads-up on the turn (the river needs a third). */
enum class BotSpeed(val label: String, val thinkMs: Long, val pauseMs: Long, val solverMs: Long) {
    RELAXED("Relaxed", 1_100, 900, 1_400),
    NORMAL("Normal", 650, 650, 900),
    FAST("Fast", 220, 300, 450),
}

data class GameConfig(
    val type: GameType = GameType.CASH,
    val players: Int = 6,
    /** Cash games only: buy-in in big blinds. Sit & Go always starts at 1,500 chips. */
    val startingBb: Int = 100,
    val speed: BotSpeed = BotSpeed.NORMAL,
    /** Style of each bot, in seat order (seat 1, 2, ...). */
    val lineup: List<BotStyle> = List(players - 1) { BotStyle.REGULAR },
    /** Slider values used by every seat set to Custom. */
    val custom: CustomSettings = CustomSettings(),
    /** Show each bot's style label at the table. */
    val showStyles: Boolean = true,
) {
    companion object {
        const val CASH_SMALL_BLIND = 1L
        const val CASH_BIG_BLIND = 2L
        const val SNG_STACK = 1_500L
        const val SNG_HANDS_PER_LEVEL = 10
    }
}

data class BotIdentity(val id: String, val name: String, val color: Long)

object BotRoster {
    private val names = listOf(
        "Ava", "Bruno", "Chen", "Dara", "Emeka", "Freya", "Gus", "Hana", "Ivan",
        "Jade", "Kofi", "Lena", "Mateo", "Nia", "Oskar", "Priya", "Quinn", "Rosa",
    )
    private val colors = listOf(
        0xFF8E44AD, 0xFFD35400, 0xFF2980B9, 0xFFC0392B, 0xFF16A085,
        0xFF7F8C8D, 0xFFB7950B, 0xFF1ABC9C, 0xFF34495E, 0xFFAD1457,
    )

    /** [count] distinct bots, chosen deterministically from [seed]. */
    fun pick(count: Int, seed: Long): List<BotIdentity> {
        val rng = SeededRandom(seed)
        val pool = names.toMutableList()
        return List(count) { i ->
            val name = pool.removeAt(rng.nextInt(pool.size))
            BotIdentity(id = "bot-${name.lowercase()}", name = name, color = colors[(i + rng.nextInt(colors.size)) % colors.size])
        }
    }
}

/** Quick table presets in the lobby. */
enum class OpponentMix(val label: String) {
    BEGINNER("Beginner"), CASUAL("Casual"), REGULAR("Regular"), SHARK("Shark"),
    GTO("GTO-approx"), MIXED("Mixed"), CUSTOM("Custom");

    fun lineup(count: Int): List<BotStyle> = when (this) {
        BEGINNER -> List(count) { BotStyle.BEGINNER }
        CASUAL -> List(count) { BotStyle.CASUAL }
        REGULAR -> List(count) { BotStyle.REGULAR }
        SHARK -> List(count) { BotStyle.SHARK }
        GTO -> List(count) { BotStyle.GTO }
        CUSTOM -> List(count) { BotStyle.CUSTOM }
        MIXED -> List(count) { MIXED_ORDER[it % MIXED_ORDER.size] }
    }

    val description: String
        get() = when (this) {
            MIXED -> "A typical low-stakes table: mostly recreational players who like to see flops, plus a regular (and a shark at bigger tables)."
            else -> BotStyle.valueOf(if (this == GTO) "GTO" else name).description
        }

    private companion object {
        // A typical low-stakes table: mostly recreational players, a regular, and (at bigger tables) a shark.
        val MIXED_ORDER = listOf(
            BotStyle.CASUAL, BotStyle.BEGINNER, BotStyle.REGULAR, BotStyle.CASUAL,
            BotStyle.BEGINNER, BotStyle.SHARK, BotStyle.CASUAL, BotStyle.REGULAR,
        )
    }
}
