pluginManagement {
    repositories {
        google()
        mavenCentral()
        gradlePluginPortal()
    }
}

dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)
    repositories {
        google()
        mavenCentral()
    }
}

rootProject.name = "PokerCoach"

include(":engine") // pure Kotlin rules engine, bots (no Android)
include(":app")    // Android app: Jetpack Compose + Material 3
