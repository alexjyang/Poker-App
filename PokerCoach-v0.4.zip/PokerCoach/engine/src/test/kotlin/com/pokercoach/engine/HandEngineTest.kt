package com.pokercoach.engine

import com.pokercoach.engine.game.ActionType
import com.pokercoach.engine.game.AnteType
import com.pokercoach.engine.game.Blinds
import com.pokercoach.engine.game.HandEngine
import com.pokercoach.engine.game.HandEvent
import com.pokercoach.engine.game.IllegalActionException
import com.pokercoach.engine.game.PlayerAction
import com.pokercoach.engine.game.PlayerAction.BetOrRaise
import com.pokercoach.engine.game.PlayerAction.Call
import com.pokercoach.engine.game.PlayerAction.Check
import com.pokercoach.engine.game.PlayerAction.Fold
import com.pokercoach.engine.game.SeatedPlayer
import com.pokercoach.engine.game.Street
import com.pokercoach.engine.rng.SeededRandom
import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertFailsWith
import kotlin.test.assertFalse
import kotlin.test.assertNotNull
import kotlin.test.assertNull
import kotlin.test.assertTrue

class HandEngineTest {

    private fun players(vararg stacks: Long) = stacks.mapIndexed { i, s -> SeatedPlayer(i, "p$i", "P$i", s) }

    private fun HandEngine.finalStacks() = (events.last() as HandEvent.HandEnded).finalStacks
    private fun HandEngine.net() = (events.last() as HandEvent.HandEnded).netResults

    // ------------------------------------------------------------ positions and blinds

    @Test
    fun `heads-up - button posts small blind, acts first preflop and last postflop`() {
        val h = HandEngine(players(1000, 1000), buttonSeat = 0, blinds = Blinds(5, 10), seed = 1)
        val s = h.snapshot()
        assertEquals(0, s.smallBlindSeat)
        assertEquals(1, s.bigBlindSeat)
        assertEquals(0, h.actorSeat)
        val legal = h.legalActions()!!
        assertEquals(5, legal.toCall)
        assertEquals(20, legal.minRaiseTo)
        assertEquals(1000, legal.maxRaiseTo)

        h.act(Call)
        assertEquals(1, h.actorSeat, "big blind gets the option")
        assertTrue(h.legalActions()!!.canCheck)
        assertTrue(h.legalActions()!!.canRaise)
        h.act(Check)
        assertEquals(Street.FLOP, h.street)
        assertEquals(3, h.board.size)
        assertEquals(1, h.actorSeat, "big blind acts first postflop heads-up")
        assertTrue(h.legalActions()!!.isBet)
        assertEquals(10, h.legalActions()!!.minRaiseTo, "min bet is one big blind")
    }

    @Test
    fun `multiway - UTG opens preflop, small blind opens postflop`() {
        val h = HandEngine(players(1000, 1000, 1000, 1000), buttonSeat = 2, blinds = Blinds(5, 10), seed = 1)
        assertEquals(3, h.snapshot().smallBlindSeat)
        assertEquals(0, h.snapshot().bigBlindSeat)
        assertEquals(1, h.actorSeat)
        repeat(3) { h.act(Call) }
        h.act(Check) // BB option
        assertEquals(Street.FLOP, h.street)
        assertEquals(3, h.actorSeat)
    }

    @Test
    fun `walk - everyone folds to the big blind who collects the small blind`() {
        val h = HandEngine(players(1000, 1000, 1000), buttonSeat = 0, blinds = Blinds(5, 10), seed = 3)
        h.act(Fold) // button
        h.act(Fold) // SB
        assertTrue(h.isComplete)
        assertEquals(mapOf(0 to 0L, 1 to -5L, 2 to 5L), h.net())
        assertTrue(h.events.any { it == HandEvent.UncalledBetReturned(2, 5) })
    }

    // ------------------------------------------------------------ raise sizing

    @Test
    fun `min raise equals the last full raise increment`() {
        val h = HandEngine(players(10_000, 10_000, 10_000, 10_000, 10_000, 10_000), 0, Blinds(50, 100), seed = 9)
        assertEquals(3, h.actorSeat)
        assertEquals(200, h.legalActions()!!.minRaiseTo)
        h.act(BetOrRaise(300)) // +200
        assertEquals(500, h.legalActions()!!.minRaiseTo)
        assertFailsWith<IllegalActionException> { h.act(BetOrRaise(450)) }
        h.act(BetOrRaise(1000)) // +700
        assertEquals(1700, h.legalActions()!!.minRaiseTo)
    }

    @Test
    fun `short all-in raise does not reopen betting for players who already acted`() {
        // Button 0 (first to act 3-handed), SB 1, BB 2 with only 450 total.
        val h = HandEngine(players(10_000, 10_000, 450), 0, Blinds(50, 100), seed = 4)
        h.act(BetOrRaise(300))            // button: full raise (+200)
        h.act(Call)                       // SB calls 300
        h.act(PlayerAction.AllIn)         // BB all-in to 450: only +150, less than a full raise
        val btn = h.legalActions()!!
        assertEquals(0, btn.seat)
        assertEquals(150, btn.toCall)
        assertFalse(btn.canRaise, "betting is not reopened")
        assertFailsWith<IllegalActionException> { h.act(PlayerAction.AllIn) }
        h.act(Call)
        assertFalse(h.legalActions()!!.canRaise)
        h.act(Call)
        assertEquals(Street.FLOP, h.street)
    }

    @Test
    fun `two short all-ins that add up to a full raise do reopen betting`() {
        // Button 0, SB 1 (450 total), BB 2 (550 total), UTG 3.
        val h = HandEngine(players(10_000, 450, 550, 10_000), 0, Blinds(50, 100), seed = 5)
        h.act(BetOrRaise(300))       // UTG +200
        h.act(Call)                  // button
        h.act(PlayerAction.AllIn)    // SB to 450 (+150, short)
        h.act(PlayerAction.AllIn)    // BB to 550 (+100, short)
        val utg = h.legalActions()!!
        assertEquals(3, utg.seat)
        assertTrue(utg.canRaise, "facing +250 total, which is at least the 200 full raise")
        assertEquals(750, utg.minRaiseTo)
    }

    @Test
    fun `checked player may raise a short all-in bet`() {
        // BB has only 50 behind on the flop, less than a minimum bet.
        val h = HandEngine(players(1000, 1000, 150), 0, Blinds(50, 100), seed = 6)
        h.act(Call); h.act(Call); h.act(Check)
        assertEquals(Street.FLOP, h.street)
        h.act(Check)               // SB checks
        h.act(PlayerAction.AllIn)  // BB bets all-in 50 (incomplete bet)
        h.act(Call)                // button calls
        val sb = h.legalActions()!!
        assertEquals(1, sb.seat)
        assertTrue(sb.canRaise, "a check followed by a bet still lets the player raise")
        assertEquals(150, sb.minRaiseTo, "raise must be a full bet over the all-in amount")
    }

    @Test
    fun `cannot raise when every opponent is all-in`() {
        val h = HandEngine(players(1000, 300), 0, Blinds(5, 10), seed = 7)
        h.act(Call)               // SB/button completes
        h.act(PlayerAction.AllIn) // BB shoves 300
        val legal = h.legalActions()!!
        assertEquals(290, legal.toCall)
        assertFalse(legal.canRaise)
    }

    @Test
    fun `illegal actions are rejected`() {
        val h = HandEngine(players(1000, 1000), 0, Blinds(5, 10), seed = 8)
        assertFailsWith<IllegalActionException> { h.act(Check) }
        assertFailsWith<IllegalActionException> { h.act(BetOrRaise(15)) }
        assertFailsWith<IllegalActionException> { h.act(BetOrRaise(1001)) }
        h.act(Call)
        assertFailsWith<IllegalActionException> { h.act(Call) } // BB has nothing to call
    }

    // ------------------------------------------------------------ forced bets

    @Test
    fun `per-player antes are dead money and do not count toward calling`() {
        val h = HandEngine(players(1000, 1000, 1000), 0, Blinds(50, 100, ante = 10), seed = 10)
        assertEquals(180, h.pot)
        assertEquals(100, h.legalActions()!!.toCall)
        h.act(Call); h.act(Call)
        assertTrue(h.legalActions()!!.canCheck, "BB has matched: antes are not part of the bet")
        h.act(Check)
        assertEquals(330, h.pot)
    }

    @Test
    fun `big blind ante is posted by the big blind only`() {
        val h = HandEngine(players(1000, 1000, 1000), 0, Blinds(50, 100, ante = 100, anteType = AnteType.BIG_BLIND_ANTE), seed = 11)
        assertEquals(250, h.pot)
        assertEquals(800, h.snapshot().seat(2).stack)
    }

    @Test
    fun `short big blind is all-in but callers must still match a full big blind`() {
        val h = HandEngine(players(1000, 1000, 60), 0, Blinds(50, 100), seed = 12)
        assertTrue(h.snapshot().seat(2).allIn)
        assertEquals(100, h.legalActions()!!.toCall)
        assertEquals(200, h.legalActions()!!.minRaiseTo)
    }

    // ------------------------------------------------------------ showdown and pots

    @Test
    fun `three-way all-in awards main pot, side pot and returns the uncalled bet`() {
        // Deal order starts left of the button: seat 1, seat 2, seat 0.
        val deck = riggedDeck(listOf("AsAh", "KsKh", "QsQh"), board = "2c7d9hJs3c")
        val h = HandEngine(players(1000, 300, 600), 0, Blinds(5, 10), seed = 0, presetDeck = deck)
        h.act(PlayerAction.AllIn) // button 1000
        h.act(Call)               // SB all-in 300
        h.act(Call)               // BB all-in 600
        assertTrue(h.isComplete)
        assertEquals(5, h.board.size)
        assertEquals(mapOf(0 to 400L, 1 to 900L, 2 to 600L), h.finalStacks())
        assertTrue(h.events.contains(HandEvent.UncalledBetReturned(0, 400)))
        val awards = h.events.filterIsInstance<HandEvent.PotAwarded>()
        assertEquals(listOf(900L, 600L), awards.map { it.amount })
        assertEquals(listOf(listOf(1), listOf(2)), awards.map { it.winners })
    }

    @Test
    fun `board plays - split pot with odd chip to first seat left of button`() {
        val deck = riggedDeck(listOf("2c3d", "4h5c", "6d7h"), board = "TsJsQsKsAs")
        val h = HandEngine(players(1000, 1000, 1000), 0, Blinds(5, 10), seed = 0, presetDeck = deck)
        h.act(Call)  // button
        h.act(Fold)  // SB: 5 dead
        h.act(Check) // BB
        h.playOut(checkOrCall)
        // Pot 25 split between BB (seat 2) and button (seat 0); seat 2 is first left of the button.
        assertEquals(mapOf(0 to 2L, 1 to -5L, 2 to 3L), h.net())
    }

    @Test
    fun `all-in preflop runs out the board automatically`() {
        val h = HandEngine(players(500, 500), 1, Blinds(5, 10), seed = 13)
        h.act(PlayerAction.AllIn)
        h.act(Call)
        assertTrue(h.isComplete)
        assertEquals(5, h.board.size)
        assertEquals(1000, h.finalStacks().values.sum())
    }

    @Test
    fun `snapshots hide opponents' cards until showdown`() {
        val h = HandEngine(players(500, 500), 0, Blinds(5, 10), seed = 14)
        val view = h.snapshotFor(0)
        assertNotNull(view.seat(0).holeCards)
        assertNull(view.seat(1).holeCards)
        h.act(Call); h.act(Check)
        h.playOut(checkOrCall)
        assertNotNull(h.snapshotFor(0).seat(1).holeCards, "revealed at showdown")
    }

    @Test
    fun `action events record the decision context`() {
        val h = HandEngine(players(1000, 1000, 1000), 0, Blinds(5, 10), seed = 15)
        h.act(BetOrRaise(30))
        val e = h.events.filterIsInstance<HandEvent.ActionTaken>().single()
        assertEquals(ActionType.RAISE, e.type)
        assertEquals(15, e.potBefore)
        assertEquals(10, e.toCallBefore)
        assertEquals(1000, e.stackBefore)
        assertEquals(30, e.amountAdded)
    }

    // ------------------------------------------------------------ property tests

    @Test
    fun `fuzz - random legal play always conserves chips and terminates`() {
        val rng = SeededRandom(2025)
        repeat(5_000) { handIdx ->
            val n = 2 + rng.nextInt(8)
            val bb = 2L + rng.nextInt(50)
            val blinds = Blinds(
                smallBlind = bb / 2, bigBlind = bb,
                ante = if (rng.nextInt(3) == 0) 1L + rng.nextInt(bb.toInt()) else 0,
                anteType = if (rng.nextInt(2) == 0) AnteType.EACH_PLAYER else AnteType.BIG_BLIND_ANTE,
            )
            val seats = (0 until 9).shuffledWith(rng).take(n).sorted()
            val ps = seats.map { SeatedPlayer(it, "p$it", "P$it", 1L + rng.nextInt(if (rng.nextInt(4) == 0) 40 else 5_000)) }
            val total = ps.sumOf { it.stack }
            val h = HandEngine(ps, seats[rng.nextInt(n)], blinds, seed = handIdx.toLong())
            h.playOut { randomLegalAction(it, rng) }

            val end = h.events.last() as HandEvent.HandEnded
            assertEquals(total, end.finalStacks.values.sum(), "chips conserved in hand $handIdx")
            assertEquals(0L, end.netResults.values.sum())
            assertTrue(end.finalStacks.values.all { it >= 0 })
            val awarded = h.events.filterIsInstance<HandEvent.PotAwarded>().sumOf { it.amount }
            val refunded = h.events.filterIsInstance<HandEvent.UncalledBetReturned>().sumOf { it.amount }
            val put = h.events.sumOf {
                when (it) {
                    is HandEvent.AntePosted -> it.amount
                    is HandEvent.BlindPosted -> it.amount
                    is HandEvent.ActionTaken -> it.amountAdded
                    else -> 0L
                }
            }
            assertEquals(put, awarded + refunded, "pot accounting in hand $handIdx")
        }
    }

    @Test
    fun `replaying the same seed and actions reproduces the hand exactly`() {
        fun play(): List<HandEvent> {
            val rng = SeededRandom(99)
            return HandEngine(players(800, 1200, 400, 2000, 950), 3, Blinds(10, 20, 2), seed = 424242)
                .playOut { randomLegalAction(it, rng) }.events
        }
        assertEquals(play(), play())
    }

    private fun <T> List<T>.shuffledWith(rng: SeededRandom): List<T> {
        val a = toMutableList()
        for (i in a.lastIndex downTo 1) { val j = rng.nextInt(i + 1); val t = a[i]; a[i] = a[j]; a[j] = t }
        return a
    }
    private fun IntRange.shuffledWith(rng: SeededRandom) = toList().shuffledWith(rng)
}
