package com.pokercoach.engine

import com.pokercoach.engine.card.Card
import com.pokercoach.engine.game.HandEngine
import com.pokercoach.engine.game.LegalActions
import com.pokercoach.engine.game.PlayerAction
import com.pokercoach.engine.rng.SeededRandom

/**
 * Builds a full 52-card deck that deals the given hole cards and board.
 * [holes] are in dealing order: the player left of the button first (in heads-up: the big blind).
 */
fun riggedDeck(holes: List<String>, board: String = ""): List<Card> {
    val holeCards = holes.map { Card.parseList(it).also { c -> require(c.size == 2) } }
    val boardCards = Card.parseList(board)
    val used = holeCards.flatten() + boardCards
    require(used.toSet().size == used.size) { "Duplicate card in rig" }
    val pool = ArrayDeque(Card.ALL.filterNot { it in used })
    val out = mutableListOf<Card>()
    holeCards.forEach { out += it[0] }
    holeCards.forEach { out += it[1] }
    fun burnThen(vararg idx: Int) {
        out += pool.removeFirst()
        idx.forEach { i -> out += boardCards.getOrNull(i) ?: pool.removeFirst() }
    }
    burnThen(0, 1, 2)
    burnThen(3)
    burnThen(4)
    out += pool
    return out
}

/** Picks a random legal action — used for fuzz/property tests. */
fun randomLegalAction(legal: LegalActions, rng: SeededRandom): PlayerAction {
    val roll = rng.nextInt(100)
    return when {
        legal.canRaise && roll < 20 -> {
            val span = legal.maxRaiseTo - legal.minRaiseTo
            val to = if (span <= 0 || rng.nextInt(4) == 0) legal.maxRaiseTo
            else legal.minRaiseTo + (rng.nextDouble() * span).toLong()
            PlayerAction.BetOrRaise(to)
        }
        legal.canRaise && roll < 25 -> PlayerAction.AllIn
        legal.canCheck && roll < 85 -> PlayerAction.Check
        legal.canCall && roll < 75 -> PlayerAction.Call
        legal.canCheck -> PlayerAction.Check
        else -> PlayerAction.Fold
    }
}

/** Plays a hand to completion with the given strategy. */
fun HandEngine.playOut(strategy: (LegalActions) -> PlayerAction): HandEngine {
    var guard = 0
    while (!isComplete) {
        act(strategy(legalActions()!!))
        check(++guard < 1000) { "Hand did not terminate" }
    }
    return this
}

/** Always check if possible, otherwise call. */
val checkOrCall: (LegalActions) -> PlayerAction = { if (it.canCheck) PlayerAction.Check else PlayerAction.Call }
