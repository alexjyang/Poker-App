package com.pokercoach.engine

import com.pokercoach.engine.bot.BotProfile
import com.pokercoach.engine.bot.BotStyle
import com.pokercoach.engine.bot.CustomSettings
import com.pokercoach.engine.bot.PlayabilityRanking
import com.pokercoach.engine.bot.ProfileBot
import com.pokercoach.engine.game.ActionType
import com.pokercoach.engine.game.Blinds
import com.pokercoach.engine.game.HandEngine
import com.pokercoach.engine.game.HandEvent
import com.pokercoach.engine.game.SeatedPlayer
import com.pokercoach.engine.game.Street
import com.pokercoach.engine.range.HandClass
import com.pokercoach.engine.session.BlindSchedule
import com.pokercoach.engine.session.GameMode
import com.pokercoach.engine.session.PlayerProfile
import com.pokercoach.engine.session.TableSession
import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertTrue

class ProfileBotTest {

    private fun HandEngine.playWith(bots: Map<Int, ProfileBot>) {
        while (!isComplete) {
            val s = actorSeat!!
            act(bots.getValue(s).decide(snapshotFor(s), s, publicHistory(s)))
        }
    }

    @Test
    fun `every style plays full sit-and-gos with legal actions only`() {
        for (style in BotStyle.entries) {
            repeat(3) { s ->
                val session = TableSession(
                    6, GameMode.SitAndGo(1500, BlindSchedule.turbo(8)),
                    (0 until 6).associateWith { PlayerProfile("b$it", "Bot $it") }, sessionSeed = s.toLong(),
                )
                val bots = (0 until 6).associateWith { ProfileBot(BotProfile.preset(style), s * 10L + it, iterations = 120) }
                var hands = 0
                while (!session.isFinished && hands < 1_500) {
                    val h = session.nextHand()
                    h.playWith(bots)
                    session.completeHand(h)
                    bots.forEach { (seat, b) -> b.onHandComplete(h.publicHistory(seat), seat) }
                    hands++
                }
                assertEquals(9000L, session.occupiedSeats.sumOf { session.stackOf(it) }, "$style chips")
            }
        }
    }

    @Test
    fun `styles have the intended tendencies`() {
        val styles = listOf(BotStyle.BEGINNER, BotStyle.CASUAL, BotStyle.REGULAR, BotStyle.SHARK, BotStyle.GTO, BotStyle.CUSTOM)
        val hands = IntArray(6); val vpip = IntArray(6); val pfr = IntArray(6); val bets = IntArray(6); val calls = IntArray(6)
        repeat(24) { sIdx ->
            val lineup = styles.indices.map { (it + sIdx) % 6 }
            val session = TableSession(6, GameMode.Cash(Blinds(1, 2), 200), (0 until 6).associateWith { PlayerProfile("s$it", "S$it") }, sIdx.toLong())
            val bots = (0 until 6).associateWith { ProfileBot(BotProfile.preset(styles[lineup[it]]), sIdx * 100L + it, iterations = 150) }
            repeat(40) {
                val h = session.nextHand()
                h.playWith(bots)
                session.completeHand(h)
                val acts = h.events.filterIsInstance<HandEvent.ActionTaken>()
                for (p in (h.events.first() as HandEvent.HandStarted).players) {
                    val i = lineup[p.seat]
                    hands[i]++
                    val pre = acts.filter { it.seat == p.seat && it.street == Street.PREFLOP }
                    if (pre.any { it.type == ActionType.CALL || it.type == ActionType.RAISE }) vpip[i]++
                    if (pre.any { it.type == ActionType.RAISE }) pfr[i]++
                    val post = acts.filter { it.seat == p.seat && it.street != Street.PREFLOP }
                    bets[i] += post.count { it.type == ActionType.BET || it.type == ActionType.RAISE }
                    calls[i] += post.count { it.type == ActionType.CALL }
                }
            }
        }
        fun rate(a: IntArray, i: Int) = a[i].toDouble() / hands[i]
        fun af(i: Int) = bets[i].toDouble() / calls[i].coerceAtLeast(1)
        assertTrue(rate(vpip, 0) > rate(vpip, 1) && rate(vpip, 1) > rate(vpip, 2), "VPIP: beginner > casual > regular")
        assertTrue(rate(pfr, 2) > rate(pfr, 0) * 3, "regulars raise far more than beginners")
        assertTrue(af(0) < 1.0 && af(2) > 1.5 && af(3) > af(2), "aggression: beginner passive, shark most aggressive")
        assertTrue(rate(vpip, 0) - rate(pfr, 0) > 0.35, "beginners limp/call a lot")
    }

    @Test
    fun `public history hides other players' cards and the seed`() {
        val ps = (0 until 3).map { SeatedPlayer(it, "p$it", "P$it", 500) }
        val h = HandEngine(ps, 0, Blinds(5, 10), seed = 12345)
        val hist = h.publicHistory(1)
        assertEquals(0L, (hist.first() as HandEvent.HandStarted).seed)
        val dealt = hist.filterIsInstance<HandEvent.HoleCardsDealt>()
        assertEquals(listOf(1), dealt.map { it.seat })
    }

    @Test
    fun `a big loss puts a tilt-prone bot on tilt, and it cools down`() {
        val bot = ProfileBot(BotProfile.CASUAL, seed = 1)
        val start = HandEvent.HandStarted(1, 0, "", 0, Blinds(1, 2), listOf(SeatedPlayer(0, "a", "A", 200), SeatedPlayer(1, "b", "B", 200)))
        val lost = listOf(start, HandEvent.HandEnded(mapOf(0 to 0L, 1 to 400L), mapOf(0 to -200L, 1 to 200L)))
        val quiet = listOf(start, HandEvent.HandEnded(mapOf(0 to 199L, 1 to 201L), mapOf(0 to -1L, 1 to 1L)))
        assertEquals(0.0, bot.tilt)
        bot.onHandComplete(lost, 0)
        val tilted = bot.tilt
        assertTrue(tilted > 0.2)
        repeat(5) { bot.onHandComplete(quiet, 0) }
        assertTrue(bot.tilt < tilted / 2)
        assertEquals(0.0, ProfileBot(BotProfile.GTO, 1).also { it.onHandComplete(lost, 0) }.tilt, "GTO never tilts")
    }

    @Test
    fun `custom sliders map monotonically`() {
        val tight = BotProfile.custom(CustomSettings(looseness = 0.15, aggression = 0.2))
        val loose = BotProfile.custom(CustomSettings(looseness = 0.55, aggression = 0.9))
        assertTrue(loose.vpip > tight.vpip && loose.pfr > tight.pfr && loose.aggression > tight.aggression)
        assertTrue(tight.limps && !loose.limps)
    }

    @Test
    fun `playability ranking puts suited connectors above weak offsuit aces`() {
        assertTrue(PlayabilityRanking.rankPct(HandClass.parse("AA").index) < 0.01)
        assertTrue(PlayabilityRanking.rankPct(HandClass.parse("JTs").index) < PlayabilityRanking.rankPct(HandClass.parse("A5o").index))
    }
}
