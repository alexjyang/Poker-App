package com.pokercoach.engine

import com.pokercoach.engine.card.Card
import com.pokercoach.engine.card.CardMask
import com.pokercoach.engine.eval.HandCategory
import com.pokercoach.engine.eval.HandEvaluator
import com.pokercoach.engine.eval.HandValue
import com.pokercoach.engine.rng.SeededRandom
import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertFailsWith
import kotlin.test.assertTrue

class HandEvaluatorTest {

    private fun eval(cards: String): HandValue = HandEvaluator.evaluate(Card.parseList(cards))

    /** Known combinatorics: every 5-card hand, category counts and 7,462 distinct strengths. */
    @Test
    fun `all 2,598,960 five-card hands have correct category counts`() {
        val counts = IntArray(HandCategory.entries.size)
        val distinct = HashSet<Int>()
        for (a in 0 until 52) for (b in a + 1 until 52) for (c in b + 1 until 52)
            for (d in c + 1 until 52) for (e in d + 1 until 52) {
                val v = HandEvaluator.evaluateMask((1L shl a) or (1L shl b) or (1L shl c) or (1L shl d) or (1L shl e))
                counts[v ushr 26]++
                distinct += v
            }
        val expected = mapOf(
            HandCategory.HIGH_CARD to 1_302_540, HandCategory.PAIR to 1_098_240,
            HandCategory.TWO_PAIR to 123_552, HandCategory.THREE_OF_A_KIND to 54_912,
            HandCategory.STRAIGHT to 10_200, HandCategory.FLUSH to 5_108,
            HandCategory.FULL_HOUSE to 3_744, HandCategory.FOUR_OF_A_KIND to 624,
            HandCategory.STRAIGHT_FLUSH to 40,
        )
        expected.forEach { (cat, n) -> assertEquals(n, counts[cat.ordinal], "count for $cat") }
        assertEquals(7_462, distinct.size, "distinct 5-card equivalence classes")
    }

    /** All 133,784,560 seven-card hands (takes a few seconds on a desktop JVM). */
    @Test
    fun `all seven-card hands have correct category counts`() {
        val counts = LongArray(HandCategory.entries.size)
        val distinct = HashSet<Int>()
        for (a in 0 until 52) { val ma = 1L shl a
        for (b in a + 1 until 52) { val mb = ma or (1L shl b)
        for (c in b + 1 until 52) { val mc = mb or (1L shl c)
        for (d in c + 1 until 52) { val md = mc or (1L shl d)
        for (e in d + 1 until 52) { val me = md or (1L shl e)
        for (f in e + 1 until 52) { val mf = me or (1L shl f)
        for (g in f + 1 until 52) {
            val v = HandEvaluator.evaluateMask(mf or (1L shl g))
            counts[v ushr 26]++
            if (distinct.size < 10_000) distinct += v
        } } } } } } }
        val expected = mapOf(
            HandCategory.HIGH_CARD to 23_294_460L, HandCategory.PAIR to 58_627_800L,
            HandCategory.TWO_PAIR to 31_433_400L, HandCategory.THREE_OF_A_KIND to 6_461_620L,
            HandCategory.STRAIGHT to 6_180_020L, HandCategory.FLUSH to 4_047_644L,
            HandCategory.FULL_HOUSE to 3_473_184L, HandCategory.FOUR_OF_A_KIND to 224_848L,
            HandCategory.STRAIGHT_FLUSH to 41_584L,
        )
        expected.forEach { (cat, n) -> assertEquals(n, counts[cat.ordinal], "count for $cat") }
        assertEquals(4_824, distinct.size, "distinct 7-card equivalence classes")
    }

    /** The 7-card value must equal the best of its 21 five-card subsets. */
    @Test
    fun `seven-card evaluation equals best five-card subset`() {
        val rng = SeededRandom(42)
        repeat(20_000) {
            val ids = (0 until 52).toMutableList()
            val seven = List(7) { ids.removeAt(rng.nextInt(ids.size)) }.map(::Card)
            var best = -1
            for (skip1 in 0 until 7) for (skip2 in skip1 + 1 until 7) {
                val five = seven.filterIndexed { i, _ -> i != skip1 && i != skip2 }
                best = maxOf(best, HandEvaluator.evaluateMask(CardMask.of(five)))
            }
            assertEquals(best, HandEvaluator.evaluateMask(CardMask.of(seven)), "hand $seven")
        }
    }

    @Test
    fun `category ordering`() {
        val ladder = listOf(
            "AsKd9h7c2d", // high card
            "2s2d9h7c4d", // pair
            "2s2d3h3c4d", // two pair
            "2s2d2h7c4d", // trips
            "As2d3h4c5d", // wheel straight
            "2s4s6s8sTs", // flush
            "2s2d2h3c3d", // full house
            "2s2d2h2c3d", // quads
            "As2s3s4s5s", // steel wheel
        )
        ladder.zipWithNext().forEach { (lo, hi) -> assertTrue(eval(lo) < eval(hi), "$lo < $hi") }
    }

    @Test
    fun `straights - wheel is lowest, broadway highest, no wrap-around`() {
        assertTrue(eval("As2d3h4c5d") < eval("2s3d4h5c6d"))
        assertEquals(HandCategory.STRAIGHT, eval("TsJdQhKcAd").category)
        assertEquals(HandCategory.HIGH_CARD, eval("QsKdAh2c3d").category, "Q-K-A-2-3 is not a straight")
        assertEquals("Straight, Five high", eval("As2d3h4c5d").describe())
    }

    @Test
    fun `kickers decide pairs and two pair`() {
        assertTrue(eval("AsAdKh7c2d") > eval("AhAcQh7d2c"))
        assertTrue(eval("KsKd7h7cAd") > eval("KhKc7s7dQd"))
        // Board pairs twice: third pair is irrelevant, the kicker plays.
        assertEquals(eval("AsKs QhQd 7c7d 2h").raw, eval("AsJs QhQd 7c7d 2h").raw, "ace kicker plays for both")
        assertTrue(eval("As3c QhQd 7c7d 2h") > eval("Ks3d QhQd 7c7d 2h"))
    }

    @Test
    fun `counterfeited two pair and two trips make the right hands`() {
        // 3 pairs: best two pair + highest remaining card as kicker (which may be the 3rd pair).
        assertEquals("Two Pair, Kings and Queens (J kicker)", eval("KsKd QhQc JsJd 2c").describe())
        // Two sets of trips = full house, higher trips full of lower.
        assertEquals("Full House, Nines full of Fours", eval("9s9d9h 4s4d4c Ac").describe())
    }

    @Test
    fun `flush with six suited cards uses top five`() {
        assertTrue(eval("As Ks 9s 7s 4s 2s Qd") > eval("Ah Kh 9h 7h 3h 2h Qd"))
        assertEquals(eval("As Ks 9s 7s 4s").raw, eval("As Ks 9s 7s 4s 2s Qd").raw)
    }

    @Test
    fun `straight flush beats a higher plain straight on the same seven cards`() {
        val v = eval("5h 6h 7h 8h 9h Td Jc")
        assertEquals(HandCategory.STRAIGHT_FLUSH, v.category)
        assertEquals("Royal Flush", eval("Ts Js Qs Ks As 2d 3c").describe())
    }

    @Test
    fun `bestFive returns the cards making the hand`() {
        val best = HandEvaluator.bestFive(Card.parseList("AsAd KhKc 7s 3d 2c"))
        assertEquals(Card.parseList("AsAdKhKc7s").sorted(), best.sorted())
    }

    @Test
    fun `rejects wrong card counts and duplicates`() {
        assertFailsWith<IllegalArgumentException> { eval("AsKsQs") }
        assertFailsWith<IllegalArgumentException> { HandEvaluator.evaluate(Card.parseList("AsAsKdQh2c")) }
    }
}
