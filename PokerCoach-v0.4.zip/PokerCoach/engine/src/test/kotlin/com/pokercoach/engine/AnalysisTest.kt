package com.pokercoach.engine

import com.pokercoach.engine.analysis.EquityCalculator
import com.pokercoach.engine.analysis.Grade
import com.pokercoach.engine.analysis.HandAnalyzer
import com.pokercoach.engine.analysis.HandReview
import com.pokercoach.engine.analysis.OptionKind
import com.pokercoach.engine.bot.BasicBot
import com.pokercoach.engine.card.Card
import com.pokercoach.engine.card.CardMask
import com.pokercoach.engine.game.Blinds
import com.pokercoach.engine.game.HandEngine
import com.pokercoach.engine.game.PlayerAction
import com.pokercoach.engine.game.PlayerAction.BetOrRaise
import com.pokercoach.engine.game.PlayerAction.Call
import com.pokercoach.engine.game.PlayerAction.Check
import com.pokercoach.engine.game.PlayerAction.Fold
import com.pokercoach.engine.game.SeatedPlayer
import com.pokercoach.engine.range.BoardStrength
import com.pokercoach.engine.range.Combos
import com.pokercoach.engine.range.HandClass
import com.pokercoach.engine.range.PreflopRanking
import com.pokercoach.engine.range.Range
import com.pokercoach.engine.rng.SeededRandom
import kotlin.math.abs
import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertNotNull
import kotlin.test.assertTrue

class AnalysisTest {

    private fun players(vararg stacks: Long) = stacks.mapIndexed { i, s -> SeatedPlayer(i, "p$i", "P$i", s) }

    /** Heads-up, hero = seat 0 on the button. Deal order: villain (seat 1) first. */
    private fun headsUp(hero: String, villain: String, board: String, script: HandEngine.() -> Unit): Pair<HandEngine, List<Card>> {
        val deck = riggedDeck(listOf(villain, hero), board)
        val h = HandEngine(players(1000, 1000), buttonSeat = 0, blinds = Blinds(5, 10), seed = 77, presetDeck = deck)
        h.script()
        return h to deck
    }

    private fun review(h: HandEngine, deck: List<Card>, hero: Int = 0): HandReview =
        HandAnalyzer(iterations = 4_000).analyze(h.events, hero, deck)

    private fun HandEngine.checkDownToRiver() {
        act(Call); act(Check)           // preflop: button completes, BB checks
        act(Check); act(Check)          // flop
        act(Check); act(Check)          // turn
    }

    // --------------------------------------------------------------- grading sanity

    @Test
    fun `folding the nuts to a river bet is a blunder`() {
        val (h, deck) = headsUp("AsKs", "QhQd", "QsJsTs2d3c") {
            checkDownToRiver()
            act(BetOrRaise(20))  // villain bets
            act(Fold)            // hero folds a royal flush
        }
        val d = review(h, deck).decisions.last()
        assertEquals(OptionKind.FOLD, d.chosen.kind)
        assertEquals(Grade.BLUNDER, d.grade)
        assertTrue(d.best.kind != OptionKind.FOLD)
        assertTrue(d.equity.exact, "river heads-up equity is exact")
        assertEquals(1.0, d.equity.equity, 1e-9)
    }

    @Test
    fun `calling a pot-sized river bet with seven high is a mistake or worse`() {
        val (h, deck) = headsUp("7h2c", "AdAc", "KsQd9s4h3d") {
            checkDownToRiver()
            act(BetOrRaise(20))  // pot-sized bet into 20
            act(Call)
        }
        val d = review(h, deck).decisions.last()
        assertEquals(OptionKind.FOLD, d.best.kind)
        assertTrue(d.grade >= Grade.MISTAKE, "grade was ${d.grade}")
        assertEquals(20.0 / 60.0, d.requiredEquity!!, 1e-9)
        assertEquals(0.5, d.mdf!!, 1e-9)
    }

    @Test
    fun `folding the big blind when checking is free is flagged`() {
        // Hero is the big blind (seat 0), villain on the button limps.
        val deck = riggedDeck(listOf("9c8c", "KdQs"))
        val h = HandEngine(players(1000, 1000), buttonSeat = 1, blinds = Blinds(5, 10), seed = 1, presetDeck = deck)
        h.act(Call)  // villain completes
        h.act(Fold)  // hero folds instead of checking
        val r = HandAnalyzer(4_000).analyze(h.events, 0, deck)
        val d = r.decisions.single()
        assertTrue(d.best.kind != OptionKind.FOLD)
        assertTrue(d.options.first { it.kind == OptionKind.CHECK }.evBb > 0)
        assertTrue(d.grade >= Grade.MISTAKE, "grade was ${d.grade}")
        assertEquals("Never fold when you can check for free.", r.takeaway)
    }

    @Test
    fun `preflop - aces should raise, seven-deuce should fold`() {
        fun utg(hole: String, action: PlayerAction): HandReview {
            // 6 players, button 0, hero UTG = seat 3. Deal order: 1,2,3,4,5,0.
            val holes = listOf("2s3s", "4d5d", hole, "8h9h", "TcJc", "QdKd")
            val deck = riggedDeck(holes)
            val h = HandEngine(players(1000, 1000, 1000, 1000, 1000, 1000), 0, Blinds(5, 10), seed = 3, presetDeck = deck)
            h.act(action)
            return HandAnalyzer(4_000).analyze(h.events, 3, deck)
        }
        val aces = utg("AsAh", BetOrRaise(25)).decisions.single()
        assertTrue(aces.best.kind == OptionKind.RAISE || aces.best.kind == OptionKind.ALL_IN, "best was ${aces.best.label}")
        assertTrue(aces.grade <= Grade.GOOD)

        val trash = utg("7c2d", BetOrRaise(25)).decisions.single()
        assertEquals(OptionKind.FOLD, trash.best.kind)
        assertTrue(trash.grade >= Grade.INACCURACY, "grade was ${trash.grade}")

        val folded = utg("7c2d", Fold).decisions.single()
        assertEquals(Grade.BEST, folded.grade)
    }

    // --------------------------------------------------------------- math building blocks

    @Test
    fun `equity - exact river and Monte Carlo preflop`() {
        val kk = Range.ofClasses(listOf("KK"))
        val river = EquityCalculator.vsRanges(Card.parseList("AsAh"), Card.parseList("2c7d9hJs3c"), listOf(kk), 1000, SeededRandom(1))
        assertTrue(river.exact)
        assertEquals(1.0, river.equity, 1e-9)

        val pre = EquityCalculator.vsRanges(Card.parseList("AsAh"), emptyList(), listOf(kk), 40_000, SeededRandom(2))
        assertTrue(abs(pre.equity - 0.82) < 0.01, "AA vs KK ≈ 82%, got ${pre.equity}")
        assertTrue(pre.stdError < 0.003)

        // Turn: exact enumeration must agree with an independent brute-force simulation.
        val turnBoard = Card.parseList("Kh9s4c2d")
        val hero = Card.parseList("JhJd")
        val range = Range.ofClasses(listOf("QQ", "AKs"))
        val exact = EquityCalculator.vsRanges(hero, turnBoard, listOf(range), 0, SeededRandom(3))
        assertTrue(exact.exact)
        val rng = SeededRandom(4)
        val known = CardMask.of(hero + turnBoard)
        val combos = (0 until Combos.COUNT).filter { range.weight(it) > 0 && Combos.mask[it] and known == 0L }
        var won = 0.0
        val trials = 200_000
        repeat(trials) {
            val c = combos[rng.nextInt(combos.size)]
            var river: Int
            do { river = rng.nextInt(52) } while ((known or Combos.mask[c]) and (1L shl river) != 0L)
            val b = CardMask.of(turnBoard) or (1L shl river)
            val hv = com.pokercoach.engine.eval.HandEvaluator.evaluateMask(CardMask.of(hero) or b)
            val vv = com.pokercoach.engine.eval.HandEvaluator.evaluateMask(Combos.mask[c] or b)
            won += if (hv > vv) 1.0 else if (hv == vv) 0.5 else 0.0
        }
        assertTrue(abs(exact.equity - won / trials) < 0.005, "exact ${exact.equity} vs simulated ${won / trials}")
    }

    @Test
    fun `outs - a flush draw against an overpair has nine outs`() {
        val analyzer = HandAnalyzer()
        val hero = CardMask.of(Card.parseList("5h6h"))
        val outs = analyzer.computeOuts(hero, Card.parseList("2h9hKc"), listOf(Range.ofClasses(listOf("QQ"))))
        assertNotNull(outs)
        assertEquals(9, outs.count)
        assertEquals(47, outs.unseen)
        assertEquals(9.0 / 47, outs.nextCard, 1e-12)
        // 1 - C(38,2)/C(47,2)
        assertEquals(1 - (38.0 * 37) / (47.0 * 46), outs.byRiver!!, 1e-12)
    }

    @Test
    fun `board strength ranks the nuts at the top`() {
        val bs = BoardStrength(Card.parseList("QsJsTs2d3c"))
        val royal = Combos.index(Card.parse("As"), Card.parse("Ks"))
        val trash = Combos.index(Card.parse("4h"), Card.parse("5d"))
        assertEquals(1.0, bs.hs[royal], 1e-9)
        assertTrue(bs.hs[trash] < 0.2)
        assertEquals(-1.0, bs.hs[Combos.index(Card.parse("Qs"), Card.parse("2h"))], "uses a board card")
    }

    @Test
    fun `preflop ranking and grid classes are consistent`() {
        assertEquals("AA", PreflopRanking.order.first().label)
        assertEquals("32o", PreflopRanking.order.last().label)
        assertEquals(1326, HandClass.ALL.sumOf { it.comboCount })
        assertEquals(0.0, PreflopRanking.top(0.0).fractionOfAllHands(), 1e-12)
        assertEquals(1.0, PreflopRanking.top(1.0).fractionOfAllHands(), 1e-12)
        assertEquals(0.15, PreflopRanking.top(0.15).fractionOfAllHands(), 1e-9)
        assertEquals(HandClass(0, 1), HandClass.parse("AKs"))
        assertEquals(HandClass(1, 0), HandClass.parse("AKo"))
    }

    // --------------------------------------------------------------- whole-hand properties

    @Test
    fun `reviews are deterministic`() {
        val (h, deck) = headsUp("AhJd", "KcQc", "Jc8c3d5sKh") {
            act(BetOrRaise(30)); act(Call)
            act(Check); act(BetOrRaise(30))
            act(Call); act(Check)
        }
        h.playOut(checkOrCall)
        fun sig(r: HandReview) = r.decisions.map { d -> Triple(d.grade, d.options.map { it.evBb }, d.beginnerText) }
        assertEquals(sig(review(h, deck)), sig(review(h, deck)))
    }

    @Test
    fun `fuzz - every bot hand can be reviewed with sane numbers`() {
        val rng = SeededRandom(11)
        repeat(60) { i ->
            val n = 2 + rng.nextInt(5)
            val ps = (0 until n).map { SeatedPlayer(it, "p$it", "P$it", 200L + rng.nextInt(1800)) }
            val bots = (0 until n).associateWith { BasicBot(i * 10L + it, iterations = 100) }
            val h = HandEngine(ps, rng.nextInt(n), Blinds(5, 10), seed = i.toLong())
            while (!h.isComplete) {
                val s = h.actorSeat!!
                h.act(bots.getValue(s).decide(h.snapshotFor(s), s))
            }
            val hero = rng.nextInt(n)
            val r = HandAnalyzer(iterations = 800).analyze(h.events, hero)
            for (d in r.decisions) {
                assertTrue(d.options.count { it.isChosen } == 1 && d.options.count { it.isBest } == 1)
                assertTrue(d.options.all { it.evBb.isFinite() })
                assertTrue(d.evLossBb >= 0 && d.evLossBb.isFinite())
                assertTrue(d.equity.equity in 0.0..1.0)
                assertTrue(d.beginnerText.isNotBlank())
            }
            assertEquals(r.decisions.sumOf { it.evLossBb }, r.totalEvLossBb, 1e-9)
        }
    }
}
