package com.pokercoach.engine

import com.pokercoach.engine.bot.BasicBot
import com.pokercoach.engine.bot.QuickEquity
import com.pokercoach.engine.card.Card
import com.pokercoach.engine.game.Blinds
import com.pokercoach.engine.game.HandEngine
import com.pokercoach.engine.game.PlayerAction
import com.pokercoach.engine.game.SeatedPlayer
import com.pokercoach.engine.rng.SeededRandom
import com.pokercoach.engine.session.BlindSchedule
import com.pokercoach.engine.session.GameMode
import com.pokercoach.engine.session.PlayerProfile
import com.pokercoach.engine.session.TableSession
import kotlin.math.abs
import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertIs
import kotlin.test.assertTrue

class BotTest {

    @Test
    fun `chen scores match the published values`() {
        fun s(c: String) = BasicBot.chenScore(Card.parseList(c))
        assertEquals(20.0, s("AsAh"))
        assertEquals(12.0, s("AsKs"))
        assertEquals(10.0, s("AsKd"))
        assertEquals(5.0, s("2s2d"))
        assertEquals(-1.0, s("7s2d"))
        assertEquals(8.0, s("Ts9s")) // 5 + 2 suited + 1 connector bonus
    }

    @Test
    fun `quick equity is close to known values`() {
        val rng = SeededRandom(1)
        // AA vs one random hand ≈ 85.2%; 72o vs one random hand ≈ 34.6%.
        val aa = QuickEquity.vsRandom(Card.parseList("AsAh"), emptyList(), 1, 40_000, rng)
        val sevenTwo = QuickEquity.vsRandom(Card.parseList("7s2d"), emptyList(), 1, 40_000, rng)
        assertTrue(abs(aa - 0.852) < 0.01, "AA equity $aa")
        assertTrue(abs(sevenTwo - 0.346) < 0.01, "72o equity $sevenTwo")
        // The nuts on the river always wins.
        val nuts = QuickEquity.vsRandom(Card.parseList("AsKs"), Card.parseList("QsJsTs2d3c"), 3, 2_000, rng)
        assertEquals(1.0, nuts)
    }

    @Test
    fun `bot raises aces and folds seven-deuce to a big raise`() {
        // 4 players: button 0, SB 1, BB 2, UTG 3. Deal order: 1, 2, 3, 0.
        val h = HandEngine(
            listOf(1000L, 1000L, 1000L, 1000L).mapIndexed { i, s -> SeatedPlayer(i, "p$i", "P$i", s) },
            buttonSeat = 0, blinds = Blinds(5, 10), seed = 0,
            presetDeck = riggedDeck(listOf("4h5c", "AsAh", "7s2d", "KsQd")),
        )
        h.act(PlayerAction.BetOrRaise(60)) // UTG (seat 3) raises with 7-2
        h.act(PlayerAction.Call)           // button calls
        h.act(PlayerAction.Fold)           // SB folds
        val bot = BasicBot(seed = 3)
        val decision = bot.decide(h.snapshotFor(2), 2) // BB holds AA
        assertIs<PlayerAction.BetOrRaise>(decision)

        val h2 = HandEngine(
            listOf(1000L, 1000L, 1000L).mapIndexed { i, s -> SeatedPlayer(i, "p$i", "P$i", s) },
            buttonSeat = 0, blinds = Blinds(5, 10), seed = 0,
            presetDeck = riggedDeck(listOf("KsKd", "7s2d", "AhQh")),
        )
        h2.act(PlayerAction.BetOrRaise(80)) // button raises big
        h2.act(PlayerAction.Fold)            // SB folds
        assertEquals(PlayerAction.Fold, BasicBot(seed = 4).decide(h2.snapshotFor(2), 2))
    }

    @Test
    fun `bots play full sit-and-gos without illegal actions`() {
        repeat(20) { s ->
            val session = TableSession(
                6, GameMode.SitAndGo(1500, BlindSchedule.turbo(8)),
                (0 until 6).associateWith { PlayerProfile("b$it", "Bot $it") }, sessionSeed = s.toLong(),
            )
            val bots = (0 until 6).associateWith { BasicBot(seed = s * 10L + it, iterations = 150) }
            var hands = 0
            while (!session.isFinished && hands < 2_000) {
                val h = session.nextHand()
                while (!h.isComplete) {
                    val seat = h.actorSeat!!
                    h.act(bots.getValue(seat).decide(h.snapshotFor(seat), seat))
                }
                session.completeHand(h)
                hands++
            }
            assertEquals(9000L, session.occupiedSeats.sumOf { session.stackOf(it) })
        }
    }
}
