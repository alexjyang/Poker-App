package com.pokercoach.engine

import com.pokercoach.engine.card.Card
import com.pokercoach.engine.card.Deck
import com.pokercoach.engine.game.Contribution
import com.pokercoach.engine.game.Pot
import com.pokercoach.engine.game.PotCalculator
import com.pokercoach.engine.rng.SeededRandom
import kotlin.math.abs
import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertNotEquals
import kotlin.test.assertNull
import kotlin.test.assertTrue

class DeckTest {
    @Test
    fun `same seed gives the same order and commitment`() {
        val a = Deck(123456789L)
        val b = Deck(123456789L)
        assertEquals(a.order, b.order)
        assertEquals(a.commitment, b.commitment)
        assertEquals(64, a.commitment.length)
        assertNotEquals(a.order, Deck(123456790L).order)
    }

    @Test
    fun `deck is a permutation of 52 cards`() {
        repeat(200) { seed ->
            assertEquals(Card.ALL.toSet(), Deck(seed.toLong()).order.toSet())
        }
    }

    /** Guards against platform drift: this exact order must never change, or old replays break. */
    @Test
    fun `shuffle algorithm is frozen`() {
        assertEquals(GOLDEN_2024, Deck(2024L).order.take(5).joinToString(" "))
    }

    @Test
    fun `nextInt is roughly uniform`() {
        val rng = SeededRandom(7)
        val buckets = IntArray(52)
        val n = 520_000
        repeat(n) { buckets[rng.nextInt(52)]++ }
        val expected = n / 52.0
        val chi2 = buckets.sumOf { (it - expected) * (it - expected) / expected }
        assertTrue(chi2 < 100, "chi-square $chi2 too high for 51 dof") // p ≈ 0.0001 cutoff
        assertTrue(buckets.all { abs(it - expected) < expected * 0.05 })
    }

    @Test
    fun `every position of the shuffle is uniform`() {
        // Card at position 0 over many seeds should hit all 52 cards about equally.
        val counts = IntArray(52)
        repeat(52_000) { counts[Deck(it.toLong()).order[0].id]++ }
        assertTrue(counts.all { it in 800..1200 }, counts.joinToString())
    }

    companion object {
        const val GOLDEN_2024 = "2c Qh Kh Ad 6h"
    }
}

class PotCalculatorTest {
    @Test
    fun `three-way all-in creates main and side pots`() {
        // A all-in 100, B all-in 300, C calls 300 (covering).
        val pots = PotCalculator.buildPots(
            listOf(Contribution(0, 100, false), Contribution(1, 300, false), Contribution(2, 300, false))
        )
        assertEquals(listOf(Pot(300, setOf(0, 1, 2)), Pot(400, setOf(1, 2))), pots)
    }

    @Test
    fun `four players with a folder's dead money`() {
        // D folded after putting in 50. A all-in 40, B all-in 120, C 120.
        val pots = PotCalculator.buildPots(
            listOf(
                Contribution(0, 40, false), Contribution(1, 120, false),
                Contribution(2, 120, false), Contribution(3, 50, true),
            )
        )
        // Main: 40*4 = 160 (A,B,C). Side: (120-40)*2 + (50-40) = 170 (B,C).
        assertEquals(listOf(Pot(160, setOf(0, 1, 2)), Pot(170, setOf(1, 2))), pots)
        assertEquals(330, pots.sumOf { it.amount })
    }

    @Test
    fun `uncalled bet is the excess over the second largest contribution`() {
        val c = listOf(Contribution(0, 1000, false), Contribution(1, 400, false), Contribution(2, 200, true))
        assertEquals(0 to 600L, PotCalculator.uncalledBet(c))
        assertNull(PotCalculator.uncalledBet(listOf(Contribution(0, 200, false), Contribution(1, 200, false))))
    }

    @Test
    fun `odd chips go to the first winner left of the button`() {
        val shares = PotCalculator.split(101, winners = listOf(5, 2), seatOrderFromButton = listOf(2, 3, 5, 0))
        assertEquals(mapOf(2 to 51L, 5 to 50L), shares)
        val three = PotCalculator.split(100, listOf(0, 3, 5), listOf(3, 5, 0))
        assertEquals(mapOf(3 to 34L, 5 to 33L, 0 to 33L), three)
    }

    @Test
    fun `lone live player gets everything`() {
        val pots = PotCalculator.buildPots(listOf(Contribution(0, 0, false), Contribution(1, 30, true)))
        assertEquals(listOf(Pot(30, setOf(0))), pots)
    }
}
