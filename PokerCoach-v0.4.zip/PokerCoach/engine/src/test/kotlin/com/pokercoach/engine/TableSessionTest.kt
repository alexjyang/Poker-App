package com.pokercoach.engine

import com.pokercoach.engine.game.Blinds
import com.pokercoach.engine.game.PlayerAction
import com.pokercoach.engine.rng.SeededRandom
import com.pokercoach.engine.session.BlindSchedule
import com.pokercoach.engine.session.GameMode
import com.pokercoach.engine.session.PlayerProfile
import com.pokercoach.engine.session.TableSession
import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertFailsWith
import kotlin.test.assertTrue

class TableSessionTest {

    private fun seating(vararg seats: Int) = seats.associateWith { PlayerProfile("id$it", "Player $it") }

    @Test
    fun `sit-and-go plays to a single winner with unique finishing places`() {
        val session = TableSession(
            tableSize = 6,
            mode = GameMode.SitAndGo(startingStack = 1500, schedule = BlindSchedule.turbo(handsPerLevel = 5)),
            seating = seating(0, 1, 2, 3, 4, 5),
            sessionSeed = 77,
        )
        val rng = SeededRandom(1)
        var hands = 0
        while (!session.isFinished) {
            val h = session.nextHand()
            h.playOut { randomLegalAction(it, rng) }
            session.completeHand(h)
            assertEquals(9000L, session.occupiedSeats.sumOf { session.stackOf(it) }, "chips conserved")
            assertTrue(++hands < 10_000)
        }
        val places = session.finishes.sortedBy { it.place }
        assertEquals((1..6).toList(), places.map { it.place })
        assertEquals(6, places.map { it.playerId }.toSet().size)
    }

    @Test
    fun `button moves clockwise to the next seat with chips`() {
        val session = TableSession(9, GameMode.Cash(Blinds(1, 2), buyIn = 200), seating(1, 4, 7), sessionSeed = 5)
        val buttons = List(6) {
            val h = session.nextHand()
            h.playOut { if (it.canCheck) PlayerAction.Check else PlayerAction.Fold }
            session.completeHand(h)
            session.buttonSeat!!
        }
        val order = listOf(1, 4, 7)
        buttons.zipWithNext().forEach { (a, b) -> assertEquals(order[(order.indexOf(a) + 1) % 3], b) }
    }

    @Test
    fun `blinds rise by level in a sit-and-go`() {
        val schedule = BlindSchedule.turbo(handsPerLevel = 2)
        assertEquals(Blinds(10, 20, 0, schedule.levels[0].anteType), schedule.blindsForHand(1))
        assertEquals(schedule.levels[0], schedule.blindsForHand(2))
        assertEquals(schedule.levels[1], schedule.blindsForHand(3))
        assertEquals(schedule.levels.last(), schedule.blindsForHand(10_000))
    }

    @Test
    fun `cash game auto-rebuys busted players and allows top-ups between hands`() {
        val session = TableSession(2, GameMode.Cash(Blinds(5, 10), buyIn = 100, autoRebuy = true), seating(0, 1), 3)
        repeat(30) {
            val h = session.nextHand()
            h.playOut { l -> if (l.canRaise) PlayerAction.AllIn else if (l.canCall) PlayerAction.Call else PlayerAction.Check }
            session.completeHand(h)
            assertTrue(session.occupiedSeats.all { session.stackOf(it) > 0 })
        }
        session.addChips(0, 50)
        assertFailsWith<IllegalStateException> {
            session.nextHand().also { session.addChips(1, 10) }
        }
    }

    @Test
    fun `whole session is reproducible from its seed`() {
        fun run(): List<Any> {
            val s = TableSession(4, GameMode.SitAndGo(1000, BlindSchedule.turbo(3)), seating(0, 1, 2, 3), 2024)
            val rng = SeededRandom(8)
            val log = mutableListOf<Any>()
            repeat(20) {
                if (s.isFinished) return log
                val h = s.nextHand()
                h.playOut { randomLegalAction(it, rng) }
                s.completeHand(h)
                log.addAll(h.events)
            }
            return log
        }
        assertEquals(run(), run())
    }
}
