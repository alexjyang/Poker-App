package com.pokercoach.engine.bot

import com.pokercoach.engine.game.HandEvent
import com.pokercoach.engine.game.HandSnapshot
import com.pokercoach.engine.game.PlayerAction

/**
 * A bot sees only what a player at [seat] would see: a card-hiding snapshot
 * ([com.pokercoach.engine.game.HandEngine.snapshotFor]) and, optionally, the public action
 * history ([com.pokercoach.engine.game.HandEngine.publicHistory]).
 */
interface Bot {
    val styleLabel: String

    fun decide(view: HandSnapshot, seat: Int): PlayerAction

    /** Bots that read the betting (ranges, opponent tendencies) override this. */
    fun decide(view: HandSnapshot, seat: Int, history: List<HandEvent>): PlayerAction = decide(view, seat)

    /** Called with the public history after every hand, for tilt and opponent modelling. */
    fun onHandComplete(history: List<HandEvent>, seat: Int) {}
}
