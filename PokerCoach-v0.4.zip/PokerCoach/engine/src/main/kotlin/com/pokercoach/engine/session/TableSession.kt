package com.pokercoach.engine.session

import com.pokercoach.engine.game.AnteType
import com.pokercoach.engine.game.Blinds
import com.pokercoach.engine.game.Chips
import com.pokercoach.engine.game.HandEngine
import com.pokercoach.engine.game.HandEvent
import com.pokercoach.engine.game.SeatedPlayer
import com.pokercoach.engine.rng.SeededRandom

/** Blind levels that advance every [handsPerLevel] hands (hand-based: fair against bots of any speed). */
data class BlindSchedule(val levels: List<Blinds>, val handsPerLevel: Int) {
    init {
        require(levels.isNotEmpty() && handsPerLevel > 0)
    }

    fun levelIndexForHand(handNumber: Long): Int =
        ((handNumber - 1) / handsPerLevel).coerceAtMost(levels.lastIndex.toLong()).toInt()

    fun blindsForHand(handNumber: Long): Blinds = levels[levelIndexForHand(handNumber)]

    companion object {
        /** A typical turbo sit-and-go structure for 1500-chip stacks, BB-ante from level 5. */
        fun turbo(handsPerLevel: Int = 10): BlindSchedule {
            val sbBb = listOf(
                10L to 20L, 15L to 30L, 25L to 50L, 50L to 100L, 75L to 150L, 100L to 200L,
                150L to 300L, 200L to 400L, 300L to 600L, 400L to 800L, 500L to 1000L, 750L to 1500L,
            )
            return BlindSchedule(
                levels = sbBb.mapIndexed { i, (sb, bb) ->
                    Blinds(sb, bb, ante = if (i >= 4) bb else 0, anteType = AnteType.BIG_BLIND_ANTE)
                },
                handsPerLevel = handsPerLevel,
            )
        }
    }
}

sealed interface GameMode {
    /** Cash game: fixed blinds. Busted players are topped back up if [autoRebuy]. */
    data class Cash(val blinds: Blinds, val buyIn: Chips, val autoRebuy: Boolean = true) : GameMode

    /** Single-table tournament: everyone starts with [startingStack], blinds rise per [schedule]. */
    data class SitAndGo(val startingStack: Chips, val schedule: BlindSchedule) : GameMode
}

data class PlayerProfile(val id: String, val name: String)

data class Finish(val playerId: String, val place: Int)

/**
 * Owns everything between hands: stacks, button movement, blind levels, rebuys, eliminations.
 *
 * Replayability: every hand's shuffle seed is derived from [sessionSeed] and the hand number, so
 * a whole session can be reproduced from one Long plus the recorded player actions.
 *
 * Button: simplified "moving button" — it always advances to the next seat that has chips.
 * (Casinos sometimes use a dead-button rule when players bust; for single-table training play
 * the moving button is standard in most apps and keeps blinds simple.)
 */
class TableSession(
    val tableSize: Int,
    val mode: GameMode,
    seating: Map<Int, PlayerProfile>,
    val sessionSeed: Long,
) {
    init {
        require(tableSize in 2..9) { "Table size must be 2-9" }
        require(seating.size >= 2) { "Need at least 2 players" }
        require(seating.keys.all { it in 0 until tableSize }) { "Seat out of range" }
    }

    private val profiles: MutableMap<Int, PlayerProfile> = seating.toMutableMap()
    private val stacks: MutableMap<Int, Chips> = seating.keys.associateWith {
        when (mode) {
            is GameMode.Cash -> mode.buyIn
            is GameMode.SitAndGo -> mode.startingStack
        }
    }.toMutableMap()

    private val _finishes = mutableListOf<Finish>()
    val finishes: List<Finish> get() = _finishes.toList()

    var handNumber: Long = 0
        private set
    var buttonSeat: Int? = null
        private set
    private var current: HandEngine? = null

    fun stackOf(seat: Int): Chips = stacks[seat] ?: 0
    fun profileAt(seat: Int): PlayerProfile? = profiles[seat]
    val occupiedSeats: List<Int> get() = profiles.keys.sorted()
    private val seatsWithChips: List<Int> get() = occupiedSeats.filter { stackOf(it) > 0 }

    val isFinished: Boolean
        get() = seatsWithChips.size < 2

    val currentBlinds: Blinds
        get() = when (mode) {
            is GameMode.Cash -> mode.blinds
            is GameMode.SitAndGo -> mode.schedule.blindsForHand(handNumber.coerceAtLeast(1))
        }

    /** Deals the next hand. Call [completeHand] with the finished engine before dealing again. */
    fun nextHand(): HandEngine {
        check(current == null) { "Previous hand not completed" }
        check(!isFinished) { "Session is over" }
        handNumber++
        val live = seatsWithChips
        buttonSeat = buttonSeat.let { prev ->
            if (prev == null) live[SeededRandom(SeededRandom.derive(sessionSeed, -1)).nextInt(live.size)]
            else live.firstOrNull { it > prev } ?: live.first()
        }
        val blinds = when (mode) {
            is GameMode.Cash -> mode.blinds
            is GameMode.SitAndGo -> mode.schedule.blindsForHand(handNumber)
        }
        val players = live.map { seat ->
            val p = profiles.getValue(seat)
            SeatedPlayer(seat, p.id, p.name, stackOf(seat))
        }
        return HandEngine(
            players = players,
            buttonSeat = buttonSeat!!,
            blinds = blinds,
            seed = SeededRandom.derive(sessionSeed, handNumber),
            handNumber = handNumber,
        ).also { current = it }
    }

    /** Applies the result of a finished hand: stacks, eliminations, rebuys. */
    fun completeHand(engine: HandEngine) {
        check(engine === current) { "Not the current hand" }
        check(engine.isComplete) { "Hand still in progress" }
        val ended = engine.events.last() as HandEvent.HandEnded
        val startStacks = (engine.events.first() as HandEvent.HandStarted).players.associate { it.seat to it.stack }
        ended.finalStacks.forEach { (seat, chips) -> stacks[seat] = chips }
        current = null

        val busted = ended.finalStacks.filterValues { it == 0L }.keys
        when (mode) {
            is GameMode.Cash -> if (mode.autoRebuy) busted.forEach { stacks[it] = mode.buyIn }
            is GameMode.SitAndGo -> {
                // Players busting on the same hand: bigger starting stack finishes higher.
                val remainingAfter = seatsWithChips.size
                busted.sortedWith(compareByDescending<Int> { startStacks.getValue(it) }.thenBy { it })
                    .forEachIndexed { i, seat ->
                        _finishes += Finish(profiles.getValue(seat).id, place = remainingAfter + 1 + i)
                    }
                if (seatsWithChips.size == 1) {
                    _finishes += Finish(profiles.getValue(seatsWithChips.single()).id, place = 1)
                }
            }
        }
    }

    /** Cash games only: add chips between hands (top-up or manual rebuy). */
    fun addChips(seat: Int, amount: Chips) {
        check(mode is GameMode.Cash) { "Rebuys are only allowed in cash games" }
        check(current == null) { "Only between hands" }
        require(amount > 0 && seat in profiles)
        stacks[seat] = stackOf(seat) + amount
    }
}
