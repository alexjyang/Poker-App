package com.pokercoach.engine.analysis

import com.pokercoach.engine.game.Street
import kotlin.math.abs
import kotlin.math.roundToInt

/** Numbers the explainer needs about one decision. */
internal data class Facts(
    val street: Street,
    val chosen: OptionEval,
    val best: OptionEval,
    val options: List<OptionEval>,
    val grade: Grade,
    val evLossBb: Double,
    val equity: Double,
    val equityExact: Boolean,
    val equityMethod: String,
    val equityVs: String,
    val requiredEquity: Double?,
    val canCheck: Boolean,
    val potBb: Double,
    val toCallBb: Double,
    val mdf: Double?,
    val spr: Double?,
    val outs: OutsInfo?,
    val impliedOddsNeededBb: Double?,
    val effectiveStackBb: Double,
    val villains: List<VillainView>,
    val rangeAdvantage: Double?,
    val nutShareHero: Double?,
    val nutShareVillain: Double?,
    val blockerNote: String?,
    val gtoNote: String?,
    val inPosition: Boolean,
    val multiway: Boolean,
)

internal object Explainer {

    private fun pct(x: Double) = "${(x * 100).roundToInt()}%"
    private fun pct1(x: Double) = "%.1f%%".format(x * 100)
    private fun bb(x: Double) = "%.2f BB".format(x)
    private fun signedBb(x: Double) = (if (x >= 0) "+" else "−") + "%.2f BB".format(abs(x))

    private val OptionKind.aggressive get() = this == OptionKind.BET || this == OptionKind.RAISE || this == OptionKind.ALL_IN
    private val OptionKind.passive get() = this == OptionKind.CHECK || this == OptionKind.CALL

    fun explain(f: Facts): Triple<String, List<String>, List<Concept>> {
        val concepts = linkedSetOf<Concept>()
        val c = f.chosen.kind
        val b = f.best.kind
        val eq = f.equity
        val req = f.requiredEquity

        val headline = when (f.grade) {
            Grade.BEST -> "Best move."
            Grade.GOOD -> "Good — close to the best option."
            Grade.INACCURACY -> "Inaccuracy — a better option was available."
            Grade.MISTAKE -> "Mistake."
            Grade.BLUNDER -> "Blunder."
        }

        val reason: String = when {
            // Folding when checking was free.
            c == OptionKind.FOLD && f.canCheck -> {
                "You folded when you could check for free. Checking is never worse than folding: you keep your ${pct(eq)} equity at no cost."
            }
            // Chosen is (about) best.
            f.grade == Grade.BEST || f.grade == Grade.GOOD -> goodReason(f, concepts)
            // Fold, but calling/raising was better.
            c == OptionKind.FOLD && b.passive && req != null -> {
                concepts += Concept.POT_ODDS; concepts += Concept.EQUITY
                "Folding gave up a profitable call. The price needed ${pct(req)} equity, and against their likely hands you had about ${pct(eq)}."
            }
            c == OptionKind.FOLD && b.aggressive -> {
                concepts += Concept.FOLD_EQUITY
                "Folding was too cautious: ${f.best.label.lowercase()} was profitable" +
                    (f.best.foldEquity?.let { " — opponents would fold about ${pct(it)} of the time" } ?: "") + "."
            }
            // Call, but fold was better.
            c == OptionKind.CALL && b == OptionKind.FOLD && req != null -> {
                concepts += Concept.POT_ODDS; concepts += Concept.EQUITY
                val base = "This call loses chips: you needed ${pct(req)} equity but had only about ${pct(eq)} against their likely hands."
                val io = f.impliedOddsNeededBb
                if (io != null && f.street != Street.RIVER) {
                    concepts += Concept.IMPLIED_ODDS
                    base + " To make it worthwhile you'd need to win about ${"%.1f".format(io)} BB more on later streets when you hit" +
                        if (io > f.effectiveStackBb * 0.5) ", which is unrealistic here." else "."
                } else base
            }
            // Passive, but aggression was better.
            c.passive && b.aggressive -> {
                val value = (f.best.equityWhenCalled ?: eq) >= 0.5
                if (f.street == Street.PREFLOP) {
                    concepts += Concept.POSITION
                    "Raising was better than ${if (c == OptionKind.CHECK) "checking" else "calling"}: ${f.best.label.lowercase()} wins the blinds " +
                        "about ${pct(f.best.foldEquity ?: 0.0)} of the time and gives you the initiative, and your hand has about ${pct(eq)} equity."
                } else if (value) {
                    concepts += Concept.VALUE_BET
                    "Your hand was strong enough to ${if (f.best.kind == OptionKind.BET) "bet" else "raise"} for value (${pct(eq)} equity). " +
                        "${f.best.label} makes worse hands pay; ${if (c == OptionKind.CHECK) "checking" else "just calling"} lets them see cards cheaply."
                } else {
                    concepts += Concept.BLUFF; concepts += Concept.FOLD_EQUITY
                    "This was a good spot to apply pressure: ${f.best.label.lowercase()} wins the pot right away about " +
                        "${pct(f.best.foldEquity ?: 0.0)} of the time" +
                        (if ((f.outs?.count ?: 0) > 0) ", and your ${f.outs!!.count} outs give you a backup plan (semi-bluff)." else ".")
                }
            }
            // Aggressive, but passive/fold was better.
            c.aggressive && (b.passive || b == OptionKind.FOLD) -> {
                concepts += Concept.FOLD_EQUITY
                val fe = f.chosen.foldEquity
                val eqc = f.chosen.equityWhenCalled
                "Betting here was too ambitious" +
                    (if (fe != null) ": opponents fold only about ${pct(fe)} of the time" else "") +
                    (if (eqc != null) ", and when they continue you win about ${pct(eqc)}" else "") +
                    ". ${f.best.label} was better."
            }
            // Wrong size.
            c.aggressive && b.aggressive -> {
                "The idea to ${if (c == OptionKind.BET) "bet" else "raise"} was right, but ${f.best.label.lowercase()} was a better size than ${f.chosen.label.lowercase()}."
            }
            c == OptionKind.CHECK && b == OptionKind.FOLD -> "Checking was fine."
            else -> "${f.best.label} was better than ${f.chosen.label.lowercase()}."
        }

        if (f.street != Street.PREFLOP) concepts += Concept.RANGE
        val beginner = "$headline $reason"

        // ------------------------------------------------ advanced points
        val adv = mutableListOf<String>()
        adv += "EV: " + f.options.sortedByDescending { it.evBb }.joinToString(" · ") {
            "${it.label} ${signedBb(it.evBb)}${if (it.isChosen) " (you)" else ""}"
        }
        if (f.evLossBb > 0.005) adv += "You gave up ${bb(f.evLossBb)} versus the best option (${f.best.label})."
        adv += "Equity ${pct1(f.equity)} vs ${f.equityVs} — ${f.equityMethod}."
        if (req != null) {
            adv += "Pot odds: call ${"%.1f".format(f.toCallBb)} BB to win ${"%.1f".format(f.potBb + f.toCallBb)} BB → need ${pct1(req)} equity."
            concepts += Concept.POT_ODDS
        }
        f.mdf?.let {
            concepts += Concept.MDF
            adv += "MDF: a balanced player defends at least ${pct(it)} of their range against this bet."
        }
        f.spr?.let {
            concepts += Concept.SPR
            val note = when {
                it < 3 -> "low: top pair or better is usually happy to get all-in"
                it > 10 -> "deep: one pair hands should keep the pot small"
                else -> "medium: strong one-pair hands can play for stacks with care"
            }
            adv += "SPR ${"%.1f".format(it)} ($note)."
        }
        f.outs?.let { o ->
            concepts += Concept.OUTS
            adv += "Outs: ${o.count} (${o.cards.joinToString(" ")}) → ${pct1(o.nextCard)} next card" +
                (o.byRiver?.let { ", ${pct1(it)} by the river" } ?: "") + ". Rule of 2 and 4: ≈${o.count * 2}% / ${o.count * 4}%."
        }
        f.impliedOddsNeededBb?.let {
            concepts += Concept.IMPLIED_ODDS
            adv += "Implied odds needed: ${"%.1f".format(it)} BB extra (effective stack ${"%.1f".format(f.effectiveStackBb)} BB)."
        }
        for (v in f.villains) {
            adv += "Opponent range (~${pct(v.rangeSize)} of hands): " +
                v.breakdown.filter { it.second >= 0.005 }.joinToString(" · ") { "${it.first} ${pct(it.second)}" }
        }
        f.rangeAdvantage?.let {
            concepts += Concept.RANGE_ADVANTAGE
            val who = when { it > 0.53 -> "You have the range advantage"; it < 0.47 -> "They have the range advantage"; else -> "Ranges are close" }
            adv += "$who: your perceived range has ${pct(it)} equity against theirs."
        }
        if (f.nutShareHero != null && f.nutShareVillain != null) {
            concepts += Concept.NUT_ADVANTAGE
            adv += "Nut advantage: ${pct(f.nutShareHero)} of your range vs ${pct(f.nutShareVillain)} of theirs is very strong (top 10% of hands on this board)."
        }
        f.blockerNote?.let { concepts += Concept.BLOCKERS; adv += it }
        f.gtoNote?.let { concepts += Concept.GTO; adv += it }
        if (f.street != Street.RIVER) concepts += Concept.REALIZATION
        if (!f.inPosition && f.street != Street.RIVER) concepts += Concept.POSITION

        return Triple(beginner, adv, concepts.toList())
    }

    private fun goodReason(f: Facts, concepts: MutableSet<Concept>): String {
        val eq = f.equity
        val req = f.requiredEquity
        return when (f.chosen.kind) {
            OptionKind.FOLD -> {
                concepts += Concept.POT_ODDS
                when {
                    req != null && eq < req -> "You needed ${pct(req)} equity to call and had about ${pct(eq)} — folding saves chips."
                    req != null -> {
                        concepts += Concept.REALIZATION
                        "On raw pot odds it's close (${pct(eq)} vs ${pct(req)} needed), but " +
                            (if (f.inPosition) "with more betting to come" else "out of position") +
                            " you won't realize all of that equity, so folding is fine."
                    }
                    else -> "Your hand wasn't strong enough to play profitably here."
                }
            }
            OptionKind.CALL -> {
                concepts += Concept.POT_ODDS
                when {
                    req != null && eq >= req -> "You needed ${pct(req)} equity and had about ${pct(eq)}, so calling is profitable."
                    req != null -> "On pure pot odds you're short (${pct(eq)} vs ${pct(req)} needed), but the extra you can win later makes calling reasonable."
                    else -> "Calling keeps your options open."
                }
            }
            OptionKind.CHECK -> when {
                eq < 0.35 -> "With little equity and no good bluff, checking avoids wasting chips."
                eq < 0.6 -> "A medium-strength hand: checking controls the pot and still lets you win at showdown."
                else -> { concepts += Concept.VALUE_BET; "Checking a strong hand works here — betting wouldn't gain much more." }
            }
            else -> {
                val called = f.chosen.equityWhenCalled ?: eq
                val fe = f.chosen.foldEquity ?: 0.0
                when {
                    f.street == Street.PREFLOP -> {
                        concepts += Concept.POSITION
                        "Raising takes the initiative: everyone folds about ${pct(fe)} of the time, and when called you have about ${pct(called)}."
                    }
                    called >= 0.5 -> {
                        concepts += Concept.VALUE_BET
                        "A value ${if (f.chosen.kind == OptionKind.BET) "bet" else "raise"}: when called you win about ${pct(called)}."
                    }
                    eq >= 0.5 -> {
                        concepts += Concept.FOLD_EQUITY
                        "Betting works here: it wins right away about ${pct(fe)} of the time and still has ${pct(called)} when called, which also protects your hand from free cards."
                    }
                    else -> {
                        concepts += Concept.FOLD_EQUITY; concepts += Concept.BLUFF
                        "A profitable ${if ((f.outs?.count ?: 0) > 0) "semi-bluff" else "bluff"}: it wins the pot immediately about ${pct(fe)} of the time."
                    }
                }
            }
        }
    }

    fun takeaway(biggest: Decision?, decisions: List<Decision>): String {
        if (decisions.isEmpty()) return "No decisions for you this hand."
        if (biggest == null) return "Solid hand: every decision was within a fraction of a big blind of the best option."
        val c = biggest.chosen.kind
        val b = biggest.best.kind
        return when {
            c == OptionKind.FOLD && biggest.options.any { it.kind == OptionKind.CHECK } ->
                "Never fold when you can check for free."
            c == OptionKind.CALL && b == OptionKind.FOLD ->
                "Before calling, compare your equity to the pot odds. If you need more equity than you have, fold unless implied odds clearly make up the gap."
            c == OptionKind.FOLD && (b == OptionKind.CALL || b == OptionKind.CHECK) ->
                "When the price is good, defend: a hand only needs as much equity as the pot odds require."
            c == OptionKind.FOLD ->
                "Look for chances to take the initiative; folding gives up both your equity and your fold equity."
            (c == OptionKind.CHECK || c == OptionKind.CALL) && (b == OptionKind.BET || b == OptionKind.RAISE || b == OptionKind.ALL_IN) ->
                if ((biggest.best.equityWhenCalled ?: biggest.equity.equity) >= 0.5)
                    "Bet your strong hands for value — worse hands will pay you, and checking gives free cards."
                else "Use fold equity: a well-timed bet can win pots your hand can't win at showdown."
            (c == OptionKind.BET || c == OptionKind.RAISE || c == OptionKind.ALL_IN) && (b == OptionKind.CHECK || b == OptionKind.CALL || b == OptionKind.FOLD) ->
                "Only bet when enough worse hands call or enough better hands fold; otherwise check or fold."
            else -> "Choose bet sizes that fit your goal: bigger with strong hands and draws against calling ranges, smaller for thin value."
        }
    }
}
