package com.pokercoach.engine.game

import com.pokercoach.engine.card.Card

/** Chips are whole units (Long) everywhere. No floating point touches money. */
typealias Chips = Long

enum class Street { PREFLOP, FLOP, TURN, RIVER, SHOWDOWN }

enum class AnteType {
    /** Every dealt-in player posts the ante. */
    EACH_PLAYER,
    /** The big blind posts one ante on behalf of the table (modern tournament format). */
    BIG_BLIND_ANTE,
}

data class Blinds(
    val smallBlind: Chips,
    val bigBlind: Chips,
    val ante: Chips = 0,
    val anteType: AnteType = AnteType.EACH_PLAYER,
) {
    init {
        require(smallBlind >= 0 && bigBlind > 0 && ante >= 0) { "Invalid blinds $this" }
        require(smallBlind <= bigBlind) { "Small blind must not exceed big blind" }
    }

    /** For BB-ante the total ante is conventionally one big blind's worth unless specified. */
    override fun toString(): String =
        "$smallBlind/$bigBlind" + if (ante > 0) " ante $ante${if (anteType == AnteType.BIG_BLIND_ANTE) " (BB)" else ""}" else ""
}

/** A player taking part in a hand. [seat] is the physical seat index (0 until table size). */
data class SeatedPlayer(
    val seat: Int,
    val playerId: String,
    val name: String,
    val stack: Chips,
)

/**
 * What a player chooses. Bets/raises use "raise TO" semantics: [BetOrRaise.to] is the player's
 * total commitment on this street after the action, exactly like the number shown on a bet slider.
 */
sealed interface PlayerAction {
    data object Fold : PlayerAction
    data object Check : PlayerAction
    data object Call : PlayerAction
    data class BetOrRaise(val to: Chips) : PlayerAction
    /** Convenience: resolves to a call or a raise for the whole stack. */
    data object AllIn : PlayerAction
}

/** What actually happened (the resolved form of a [PlayerAction]), recorded in history. */
enum class ActionType { FOLD, CHECK, CALL, BET, RAISE }

/**
 * The legal options for the player to act. Amounts are street totals ("to") except [toCall],
 * which is the number of additional chips needed to call (already capped at the stack).
 */
data class LegalActions(
    val seat: Int,
    val canCheck: Boolean,
    val toCall: Chips,
    val callIsAllIn: Boolean,
    val canRaise: Boolean,
    /** True when there is no bet yet on this street, so an aggressive action is a "bet". */
    val isBet: Boolean,
    val minRaiseTo: Chips,
    val maxRaiseTo: Chips,
) {
    val canCall: Boolean get() = toCall > 0
    /** Folding is always allowed; UIs may warn when [canCheck] is true. */
    val canFold: Boolean get() = true
}

/** Immutable, append-only record of a hand. Enough to replay and to analyse every decision. */
sealed interface HandEvent {
    data class HandStarted(
        val handNumber: Long,
        val seed: Long,
        val deckCommitment: String,
        val buttonSeat: Int,
        val blinds: Blinds,
        val players: List<SeatedPlayer>,
    ) : HandEvent

    data class AntePosted(val seat: Int, val amount: Chips, val isAllIn: Boolean) : HandEvent
    data class BlindPosted(val seat: Int, val amount: Chips, val isBigBlind: Boolean, val isAllIn: Boolean) : HandEvent
    data class HoleCardsDealt(val seat: Int, val cards: List<Card>) : HandEvent

    /**
     * A voluntary action, with the situation the player faced *before* acting. The analysis
     * module rebuilds each decision point from these fields.
     */
    data class ActionTaken(
        val seat: Int,
        val street: Street,
        val type: ActionType,
        /** Chips moved from stack into the pot by this action. */
        val amountAdded: Chips,
        /** Player's street total after the action. */
        val streetTotal: Chips,
        val isAllIn: Boolean,
        val potBefore: Chips,
        val toCallBefore: Chips,
        val stackBefore: Chips,
    ) : HandEvent

    data class BoardDealt(val street: Street, val cards: List<Card>) : HandEvent
    data class UncalledBetReturned(val seat: Int, val amount: Chips) : HandEvent
    data class ShowdownHand(val seat: Int, val holeCards: List<Card>, val handValue: Int, val description: String) : HandEvent
    data class PotAwarded(
        val potIndex: Int,
        val amount: Chips,
        val winners: List<Int>,
        val shares: Map<Int, Chips>,
        val wonAtShowdown: Boolean,
        val description: String?,
    ) : HandEvent

    data class HandEnded(val finalStacks: Map<Int, Chips>, val netResults: Map<Int, Chips>) : HandEvent
}
