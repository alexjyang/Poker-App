package com.pokercoach.engine.range

import com.pokercoach.engine.card.Card
import com.pokercoach.engine.card.Rank

/**
 * The 1,326 two-card starting hands, indexed 0..1325. Precomputed card ids and masks make range
 * math allocation-free.
 */
object Combos {
    const val COUNT = 1326
    val card1 = IntArray(COUNT)
    val card2 = IntArray(COUNT)
    val mask = LongArray(COUNT)
    private val indexOf = Array(52) { IntArray(52) { -1 } }

    /** 13x13 grid class of each combo (see [HandClass]). */
    val classOf = IntArray(COUNT)

    init {
        var i = 0
        for (a in 0 until 52) for (b in a + 1 until 52) {
            card1[i] = a; card2[i] = b
            mask[i] = (1L shl a) or (1L shl b)
            indexOf[a][b] = i; indexOf[b][a] = i
            classOf[i] = HandClass.of(Card(a), Card(b)).index
            i++
        }
    }

    fun index(a: Card, b: Card): Int = indexOf[a.id][b.id].also { require(it >= 0) { "Same card twice" } }
    fun cards(i: Int): List<Card> = listOf(Card(card1[i]), Card(card2[i]))
}

/**
 * One of the 169 preflop hand classes laid out on the standard 13x13 grid:
 * rows/columns ordered A..2, pairs on the diagonal, suited hands above it, offsuit below.
 * [index] = row * 13 + col.
 */
data class HandClass(val row: Int, val col: Int) {
    val index: Int get() = row * 13 + col
    val isPair: Boolean get() = row == col
    val isSuited: Boolean get() = row < col

    /** Number of card combinations: 6 for pairs, 4 suited, 12 offsuit. */
    val comboCount: Int get() = when { isPair -> 6; isSuited -> 4; else -> 12 }

    val label: String
        get() {
            val hi = GRID_RANKS[minOf(row, col)]
            val lo = GRID_RANKS[maxOf(row, col)]
            return when { isPair -> "$hi$lo"; isSuited -> "$hi${lo}s"; else -> "$hi${lo}o" }
        }

    override fun toString(): String = label

    companion object {
        const val GRID_RANKS = "AKQJT98765432"
        private fun gridPos(r: Rank) = 12 - r.ordinal

        fun of(a: Card, b: Card): HandClass {
            val pa = gridPos(a.rank)
            val pb = gridPos(b.rank)
            val hi = minOf(pa, pb)
            val lo = maxOf(pa, pb)
            return when {
                pa == pb -> HandClass(pa, pa)
                a.suit == b.suit -> HandClass(hi, lo)   // above diagonal
                else -> HandClass(lo, hi)               // below diagonal
            }
        }

        fun fromIndex(i: Int) = HandClass(i / 13, i % 13)

        fun parse(label: String): HandClass {
            val hi = GRID_RANKS.indexOf(label[0].uppercaseChar())
            val lo = GRID_RANKS.indexOf(label[1].uppercaseChar())
            require(hi >= 0 && lo >= 0) { "Bad hand class '$label'" }
            return when {
                hi == lo -> HandClass(hi, hi)
                label.getOrNull(2) == 's' -> HandClass(minOf(hi, lo), maxOf(hi, lo))
                else -> HandClass(maxOf(hi, lo), minOf(hi, lo))
            }
        }

        val ALL: List<HandClass> = (0 until 169).map(::fromIndex)
    }
}

/**
 * A weighted range: weight in [0, 1] per combo (1 = always has this hand in this spot).
 * Immutable; operations return new ranges.
 */
class Range(private val w: DoubleArray) {
    init {
        require(w.size == Combos.COUNT)
    }

    fun weight(combo: Int): Double = w[combo]

    /** Sum of weights of combos that don't use any card in [dead]. */
    fun totalWeight(dead: Long = 0L): Double {
        var t = 0.0
        for (i in 0 until Combos.COUNT) if (Combos.mask[i] and dead == 0L) t += w[i]
        return t
    }

    fun times(factor: (Int) -> Double): Range = Range(DoubleArray(Combos.COUNT) { w[it] * factor(it) })

    fun without(dead: Long): Range = Range(DoubleArray(Combos.COUNT) { if (Combos.mask[it] and dead != 0L) 0.0 else w[it] })

    /**
     * Average weight per 13x13 class, excluding combos blocked by [dead] (for the grid view).
     * Returns 169 values in [0, 1].
     */
    fun classWeights(dead: Long = 0L): DoubleArray {
        val sum = DoubleArray(169)
        val n = IntArray(169)
        for (i in 0 until Combos.COUNT) {
            if (Combos.mask[i] and dead != 0L) continue
            val c = Combos.classOf[i]
            sum[c] += w[i]
            n[c]++
        }
        return DoubleArray(169) { if (n[it] == 0) 0.0 else sum[it] / n[it] }
    }

    /** Fraction of all 1,326 combos (by weight) this range contains, e.g. 0.15 = "15% of hands". */
    fun fractionOfAllHands(): Double = w.sum() / Combos.COUNT

    companion object {
        fun full(): Range = Range(DoubleArray(Combos.COUNT) { 1.0 })

        /** Range of explicit combos, e.g. from a list of class labels ("AA", "AKs", "KQo"). */
        fun ofClasses(labels: Collection<String>): Range {
            val set = labels.map { HandClass.parse(it).index }.toSet()
            return Range(DoubleArray(Combos.COUNT) { if (Combos.classOf[it] in set) 1.0 else 0.0 })
        }
    }
}
