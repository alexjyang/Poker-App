package com.pokercoach.engine.bot

import com.pokercoach.engine.analysis.EquityCalculator
import com.pokercoach.engine.analysis.RangeEstimator
import com.pokercoach.engine.card.Card
import com.pokercoach.engine.card.CardMask
import com.pokercoach.engine.eval.HandCategory
import com.pokercoach.engine.eval.HandEvaluator
import com.pokercoach.engine.game.Chips
import com.pokercoach.engine.game.HandEvent
import com.pokercoach.engine.game.HandSnapshot
import com.pokercoach.engine.game.LegalActions
import com.pokercoach.engine.game.PlayerAction
import com.pokercoach.engine.game.Street
import com.pokercoach.engine.range.BoardStrength
import com.pokercoach.engine.range.Combos
import com.pokercoach.engine.range.HandClass
import com.pokercoach.engine.rng.SeededRandom
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToLong

/**
 * A bot whose style comes from a [BotProfile]. Every decision is driven by the numbers —
 * preflop hand rank vs. position-scaled ranges, postflop equity (vs. estimated ranges or random
 * hands, depending on skill) vs. pot odds — and the profile bends those numbers the way real
 * players do: loose players widen ranges, stations add "hope" to their equity, weak players
 * estimate equity noisily, aggressive players bet more of their strong hands and bluff more.
 *
 * Memory across hands: tilt after big losses, and opponent tendencies for adaptive profiles.
 * Randomness only picks between options the profile considers close; it is seeded, so a
 * session replays identically.
 */
class ProfileBot(
    val profile: BotProfile,
    seed: Long,
    private val iterations: Int = 500,
) : Bot {
    override val styleLabel: String get() = profile.label

    private val rng = SeededRandom(seed)
    private val estimator = RangeEstimator()
    private val stats = OpponentStats()
    private var tiltLevel = 0.0

    /** Current tilt, 0 (calm) to 1 (steaming). Exposed for the UI/tests. */
    val tilt: Double get() = tiltLevel * profile.tilt

    override fun decide(view: HandSnapshot, seat: Int): PlayerAction = decide(view, seat, emptyList())

    override fun decide(view: HandSnapshot, seat: Int, history: List<HandEvent>): PlayerAction {
        val legal = requireNotNull(view.legalActions) { "Not this bot's turn" }
        require(legal.seat == seat)
        val hole = requireNotNull(view.seat(seat).holeCards) { "Bot must see its own cards" }
        val ctx = Context(view, seat, legal, hole, history)
        return if (view.street == Street.PREFLOP) preflop(ctx) else postflop(ctx)
    }

    override fun onHandComplete(history: List<HandEvent>, seat: Int) {
        val start = history.firstOrNull() as? HandEvent.HandStarted ?: return
        val ended = history.lastOrNull() as? HandEvent.HandEnded ?: return
        val bb = start.blinds.bigBlind
        val net = ended.netResults[seat] ?: 0L
        val startStack = start.players.firstOrNull { it.seat == seat }?.stack ?: return
        tiltLevel = when {
            net < 0 && (-net >= 25 * bb || -net * 2 >= startStack) -> min(1.0, tiltLevel + 0.5)
            net > 10 * bb -> tiltLevel * 0.5
            else -> tiltLevel * 0.8
        }
        if (profile.adaptiveness > 0) stats.record(history, seat)
    }

    private inner class Context(
        val view: HandSnapshot,
        val seat: Int,
        val legal: LegalActions,
        val hole: List<Card>,
        val history: List<HandEvent>,
    ) {
        val bb: Chips = view.blinds.bigBlind
        val me = view.seat(seat)
        val stackBb: Double = (me.stack + me.streetCommit).toDouble() / bb
        val opponents = view.seats.filter { it.seat != seat && !it.folded }
        val t = tilt

        // Profile values after tilt.
        val vpip = min(0.9, profile.vpip * (1 + 0.8 * t))
        val pfr = min(vpip, profile.pfr * (1 + 0.6 * t))
        val bluff = profile.bluff + 0.15 * t
        val callBias = profile.callBias + 0.08 * t
        val noise = profile.noise + 0.05 * t

        /** Players acting after this one preflop: 0 = BB, 1 = SB, 2 = button, 3 = cutoff... */
        val leftBehind: Int by lazy {
            val seats = view.seats.map { it.seat }
            val n = seats.size
            val btn = seats.indexOf(view.buttonSeat)
            if (n == 2) {
                if (seat == view.buttonSeat) 1 else 0
            } else {
                val utg = (btn + 3) % n
                val d = (seats.indexOf(seat) - utg + n) % n
                n - 1 - d
            }
        }
        val headsUpTable get() = view.seats.size == 2
        val inPosition: Boolean by lazy {
            val seats = view.seats.map { it.seat }
            val n = seats.size
            val btn = seats.indexOf(view.buttonSeat)
            val order = List(n) { seats[(btn + 1 + it) % n] }.filter { s -> s == seat || !view.seat(s).folded }
            order.last() == seat
        }
    }

    // ================================================================= preflop

    private fun preflop(c: Context): PlayerAction {
        val legal = c.legal
        val cls = HandClass.of(c.hole[0], c.hole[1]).index
        val rank = PlayabilityRanking.rankPct(cls) // 0 = AA
        val bb = c.bb
        val raises = raisesSoFar(c)
        val posFactor = positionFactor(c)

        // Short stacks: push or fold (Beginners just keep limping/calling).
        if (c.stackBb <= 12 && profile.style != BotStyle.BEGINNER) {
            val pushPct = min(0.85, (if (raises == 0) c.pfr * posFactor * 1.6 else c.pfr * 0.8) * (1 + (12 - c.stackBb) / 10))
            return if (rank < pushPct) allIn(legal) else checkOrFold(legal)
        }

        if (raises == 0) {
            val limpers = c.view.seats.count { it.streetCommit == bb && it.seat != c.view.bigBlindSeat && it.seat != c.seat }
            val openPct = if (profile.gto) gtoOpenPct(c) else c.pfr * posFactor
            val playPct = if (profile.limps) max(openPct, c.vpip * posFactor) else openPct
            val slowplay = rank < 0.03 && rng.nextDouble() < profile.slowplay
            return when {
                rank < openPct && !slowplay && legal.canRaise -> {
                    val size = when {
                        profile.style == BotStyle.BEGINNER -> 3.0 + rng.nextInt(3)
                        c.leftBehind <= 2 || c.headsUpTable -> 2.5
                        else -> 3.0
                    }
                    raiseTo(legal, ((size + limpers) * bb).roundToLong())
                }
                legal.canCheck -> PlayerAction.Check
                rank < playPct -> PlayerAction.Call
                else -> PlayerAction.Fold
            }
        }

        // Facing a raise (or more).
        val raiseToBb = c.view.currentBet.toDouble() / bb
        val price = (3.0 / raiseToBb).coerceIn(0.35, 1.2)
        val isBigBlind = c.seat == c.view.bigBlindSeat
        val bigCall = legal.toCall >= (c.me.stack + c.me.streetCommit) * 0.3

        if (bigCall) return callOrFoldByEquity(c, preflop = true)

        if (raises == 1) {
            val threeBetPct = if (profile.gto) (if (isBigBlind || c.leftBehind <= 1) 0.11 else 0.09)
            else c.pfr * profile.threeBetShare * (1 + 0.3 * c.t)
            var continuePct = if (profile.gto) (if (isBigBlind) 0.45 else if (c.inPosition) 0.18 else 0.12) * price
            else c.vpip * 0.55 * price * (if (isBigBlind) 1.6 else 1.0)
            continuePct += c.callBias
            val bluffBand = rank >= continuePct && rank < continuePct + 0.08 && c.hole[0].suit == c.hole[1].suit
            val bluff3b = bluffBand && legal.canRaise && rng.nextDouble() < (if (profile.gto) 0.3 else c.bluff * 1.5)
            val size = if (c.inPosition) 3.0 else 3.8
            return when {
                (rank < threeBetPct || bluff3b) && legal.canRaise -> raiseTo(legal, (c.view.currentBet * size).roundToLong())
                rank < continuePct -> PlayerAction.Call
                legal.canCheck -> PlayerAction.Check
                else -> PlayerAction.Fold
            }
        }

        // Facing a 3-bet or more.
        val fourBetPct = if (profile.gto) 0.03 else 0.025 * (if (profile.aggression > 0.6) 1.3 else 0.7)
        val callPct = (c.vpip * 0.2 + c.callBias) * price
        return when {
            rank < fourBetPct && legal.canRaise -> raiseTo(legal, (c.view.currentBet * 2.3).roundToLong())
            rank < callPct -> PlayerAction.Call
            legal.canCheck -> PlayerAction.Check
            else -> PlayerAction.Fold
        }
    }

    private fun raisesSoFar(c: Context): Int {
        if (c.history.isNotEmpty()) {
            return c.history.count {
                it is HandEvent.ActionTaken && it.street == Street.PREFLOP &&
                    (it.type == com.pokercoach.engine.game.ActionType.RAISE || it.type == com.pokercoach.engine.game.ActionType.BET)
            }
        }
        // Without history, infer from the bet size.
        val bb = c.bb
        return when {
            c.view.currentBet <= bb -> 0
            c.view.currentBet <= bb * 5 -> 1
            else -> 2
        }
    }

    /** Scales the baseline (6-max middle position) range by position and table size. */
    private fun positionFactor(c: Context): Double {
        if (c.headsUpTable) return if (c.leftBehind == 1) 3.2 else 1.6
        return when (c.leftBehind) {
            0 -> 0.9   // big blind (vs limps)
            1 -> 1.5   // small blind
            2 -> 1.9   // button
            3 -> 1.25  // cutoff
            4 -> 1.0
            5 -> 0.8
            else -> 0.65
        }
    }

    /** Solver-like opening frequencies by position (raise-or-fold). */
    private fun gtoOpenPct(c: Context): Double {
        if (c.headsUpTable) return if (c.leftBehind == 1) 0.80 else 0.30
        return when (c.leftBehind) {
            0 -> 0.30
            1 -> 0.40
            2 -> 0.44
            3 -> 0.27
            4 -> 0.21
            5 -> 0.17
            6 -> 0.14
            7 -> 0.12
            else -> 0.11
        }
    }

    // ================================================================= postflop

    private fun postflop(c: Context): PlayerAction {
        val legal = c.legal
        val board = c.view.board
        val pot = c.view.pot
        val eqRaw = equity(c)
        var eq = (eqRaw + (rng.nextDouble() * 2 - 1) * c.noise).coerceIn(0.0, 1.0)

        val made = HandEvaluator.evaluate(c.hole + board)
        val strength = BoardStrength(board)
        val combo = Combos.index(c.hole[0], c.hole[1])
        val hasDraw = board.size < 5 && strength.draw[combo] > 0
        if (profile.overvaluesPairs && isTopPairOrBetter(c.hole, board, made.category)) eq = max(eq, 0.70)

        // Adaptation to the opponents still in the hand.
        var bluff = c.bluff
        var callBias = c.callBias
        var valueT = if (profile.gto) 0.60 else 0.64 - (profile.aggression - 0.5) * 0.1
        if (profile.adaptiveness > 0) {
            val a = profile.adaptiveness
            val ids = c.opponents.map { it.playerId }
            val fold = ids.mapNotNull { stats.of(it)?.foldToBet }.average().takeIf { !it.isNaN() }
            val af = ids.mapNotNull { stats.of(it)?.aggressionFactor }.average().takeIf { !it.isNaN() }
            if (fold != null) {
                if (fold > 0.55) bluff *= 1 + a * (fold - 0.55) * 4          // they fold too much: bluff more
                if (fold < 0.35) { bluff *= 1 - 0.6 * a; valueT -= 0.05 * a } // stations: bluff less, value thinner
            }
            if (af != null) {
                if (af > 2.5) callBias += 0.05 * a                            // maniac: call down lighter
                if (af < 1.0) callBias -= 0.05 * a                            // passive: respect their bets
            }
        }
        val multiwayFactor = if (c.opponents.size <= 1) 1.0 else 0.35
        val positionBoost = if (c.inPosition) 1.2 else 0.8

        if (legal.toCall == 0L) {
            // Checked to us (or we act first).
            val size = if (profile.gto) gtoSize(board) else profile.valueSize
            val bluffP = if (profile.gto) (size / (1 + 2 * size)) * 0.8 else bluff * multiwayFactor * positionBoost
            return when {
                eq >= valueT && legal.canRaise && rng.nextDouble() < profile.aggression + 0.25 ->
                    raiseTo(legal, (pot * size).roundToLong())
                hasDraw && eq < valueT && legal.canRaise && rng.nextDouble() < min(0.8, bluffP * 2) ->
                    raiseTo(legal, (pot * (if (profile.gto) size else profile.bluffSize)).roundToLong())
                eq < 0.30 && legal.canRaise && rng.nextDouble() < bluffP ->
                    raiseTo(legal, (pot * (if (profile.gto) size else profile.bluffSize)).roundToLong())
                else -> PlayerAction.Check
            }
        }

        // Facing a bet.
        val required = legal.toCall.toDouble() / (pot + legal.toCall)
        // Players reading ranges already account for the bettor's strength; others discount by bet size.
        val betFrac = legal.toCall.toDouble() / max(1, pot - legal.toCall)
        val discount = if (profile.readsRanges) 0.0 else 0.06 * min(betFrac, 1.5)
        val effEq = eq + callBias - discount
        val raiseT = 0.80 - (profile.aggression - 0.5) * 0.1
        val allInCall = legal.callIsAllIn
        return when {
            eq >= raiseT && legal.canRaise && rng.nextDouble() < profile.aggression ->
                raiseTo(legal, (c.view.currentBet * 2.8).roundToLong())
            hasDraw && effEq >= required - 0.08 && legal.canRaise && rng.nextDouble() < bluff * profile.aggression ->
                raiseTo(legal, (c.view.currentBet * 2.8).roundToLong())
            effEq >= required + (if (allInCall) 0.02 else 0.0) - (if (profile.gto) 0.02 else 0.0) -> PlayerAction.Call
            else -> PlayerAction.Fold
        }
    }

    private fun equity(c: Context): Double {
        val opponents = c.opponents.size.coerceAtLeast(1)
        if (profile.readsRanges && c.history.isNotEmpty()) {
            val est = estimator.estimate(c.history)
            val dead = CardMask.of(c.hole + c.view.board)
            val ranges = c.opponents.mapNotNull { est.ranges[it.seat] }.map { r ->
                if (r.totalWeight(dead) > 1e-9) r else com.pokercoach.engine.range.Range.full()
            }
            if (ranges.isNotEmpty()) {
                return EquityCalculator.vsRanges(c.hole, c.view.board, ranges, iterations, rng).equity
            }
        }
        return QuickEquity.vsRandom(c.hole, c.view.board, opponents, iterations, rng)
    }

    private fun callOrFoldByEquity(c: Context, preflop: Boolean): PlayerAction {
        val legal = c.legal
        val eq = (equity(c) + (rng.nextDouble() * 2 - 1) * c.noise).coerceIn(0.0, 1.0)
        val required = legal.toCall.toDouble() / (c.view.pot + legal.toCall)
        val strong = eq > 0.62 && legal.canRaise && rng.nextDouble() < profile.aggression
        return when {
            strong -> allIn(legal)
            eq + c.callBias >= required + (if (preflop) 0.03 else 0.0) -> PlayerAction.Call
            legal.canCheck -> PlayerAction.Check
            else -> PlayerAction.Fold
        }
    }

    private fun isTopPairOrBetter(hole: List<Card>, board: List<Card>, category: HandCategory): Boolean {
        if (category > HandCategory.PAIR) return true
        if (category != HandCategory.PAIR) return false
        val topBoard = board.maxOf { it.rank.ordinal }
        val pairRank = hole.firstOrNull { h -> board.any { it.rank == h.rank } }?.rank?.ordinal
        val overpair = hole[0].rank == hole[1].rank && hole[0].rank.ordinal > topBoard
        return overpair || pairRank == topBoard
    }

    /** Small bets on dry boards (range advantage), big bets on wet boards. */
    private fun gtoSize(board: List<Card>): Double {
        val suits = board.groupingBy { it.suit }.eachCount().values.maxOrNull() ?: 0
        val ranks = board.map { it.rank.ordinal }.distinct().sorted()
        val paired = ranks.size < board.size
        val connected = ranks.zipWithNext().count { (a, b) -> b - a <= 2 }
        val wet = suits >= 2 && connected >= 1 || connected >= 2
        return when {
            paired && !wet -> 0.33
            wet -> 0.75
            else -> 0.5
        }
    }

    // ================================================================= sizing helpers

    private fun raiseTo(legal: LegalActions, target: Chips): PlayerAction {
        if (!legal.canRaise) return if (legal.canCheck) PlayerAction.Check else PlayerAction.Call
        val to = target.coerceIn(legal.minRaiseTo, legal.maxRaiseTo)
        return if (to >= legal.maxRaiseTo * 0.85) PlayerAction.BetOrRaise(legal.maxRaiseTo) else PlayerAction.BetOrRaise(to)
    }

    private fun allIn(legal: LegalActions): PlayerAction = when {
        legal.canRaise -> PlayerAction.BetOrRaise(legal.maxRaiseTo)
        legal.canCall -> PlayerAction.Call
        else -> PlayerAction.Check
    }

    private fun checkOrFold(legal: LegalActions) = if (legal.canCheck) PlayerAction.Check else PlayerAction.Fold
}
