package com.pokercoach.engine.card

import com.pokercoach.engine.rng.SeededRandom
import java.security.MessageDigest

/**
 * A deck shuffled deterministically from [seed] (Fisher–Yates over [SeededRandom]).
 *
 * Audit trail: the same seed always yields the same [order], and [commitment] is a SHA-256
 * hash of that order. The app can store/show the commitment before the hand and reveal the
 * seed afterwards, so anyone can verify the deal wasn't altered.
 */
class Deck private constructor(val seed: Long, val order: List<Card>) {
    private var position = 0

    /** Shuffles a fresh deck from [seed]. */
    constructor(seed: Long) : this(seed, shuffledOrder(seed))

    val remaining: Int get() = 52 - position
    val dealtCount: Int get() = position

    fun deal(): Card {
        check(position < 52) { "Deck exhausted" }
        return order[position++]
    }

    fun burn() { deal() }

    val commitment: String get() = commitmentOf(order)

    companion object {
        fun shuffledOrder(seed: Long): List<Card> {
            val ids = IntArray(52) { it }
            val rng = SeededRandom(seed)
            for (i in 51 downTo 1) {
                val j = rng.nextInt(i + 1)
                val tmp = ids[i]; ids[i] = ids[j]; ids[j] = tmp
            }
            return ids.map(::Card)
        }

        /**
         * A deck with an explicit order: for tests, puzzles ("replay this spot") and importing
         * hand histories. [seed] is informational only.
         */
        fun fromOrder(order: List<Card>, seed: Long = 0): Deck {
            require(order.size == 52 && order.toSet().size == 52) { "Deck must contain each card exactly once" }
            return Deck(seed, order.toList())
        }

        fun commitmentOf(order: List<Card>): String {
            val digest = MessageDigest.getInstance("SHA-256")
                .digest(order.joinToString("").toByteArray(Charsets.US_ASCII))
            return digest.joinToString("") { "%02x".format(it) }
        }
    }
}
