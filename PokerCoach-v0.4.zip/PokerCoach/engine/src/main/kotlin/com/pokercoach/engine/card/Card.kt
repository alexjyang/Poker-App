package com.pokercoach.engine.card

/** Ranks in ascending order. `ordinal` (0..12) is used directly as the rank bit index. */
enum class Rank(val symbol: Char, val displayName: String, val pluralName: String) {
    TWO('2', "Two", "Twos"), THREE('3', "Three", "Threes"), FOUR('4', "Four", "Fours"),
    FIVE('5', "Five", "Fives"), SIX('6', "Six", "Sixes"), SEVEN('7', "Seven", "Sevens"),
    EIGHT('8', "Eight", "Eights"), NINE('9', "Nine", "Nines"), TEN('T', "Ten", "Tens"),
    JACK('J', "Jack", "Jacks"), QUEEN('Q', "Queen", "Queens"), KING('K', "King", "Kings"),
    ACE('A', "Ace", "Aces");

    companion object {
        private val BY_SYMBOL = entries.associateBy { it.symbol }
        fun fromSymbol(c: Char): Rank = BY_SYMBOL[c.uppercaseChar()]
            ?: throw IllegalArgumentException("Unknown rank '$c'")
    }
}

enum class Suit(val symbol: Char, val glyph: Char) {
    CLUBS('c', '♣'), DIAMONDS('d', '♦'), HEARTS('h', '♥'), SPADES('s', '♠');

    companion object {
        private val BY_SYMBOL = entries.associateBy { it.symbol }
        fun fromSymbol(c: Char): Suit = BY_SYMBOL[c.lowercaseChar()]
            ?: throw IllegalArgumentException("Unknown suit '$c'")
    }
}

/**
 * A playing card packed into an Int id in 0..51, laid out suit-major: `id = suit * 13 + rank`.
 *
 * This layout means a set of cards can be stored as a 52-bit Long where bits
 * `[13*s, 13*s+12]` are the rank mask of suit `s`. The hand evaluator relies on that.
 */
@JvmInline
value class Card(val id: Int) : Comparable<Card> {
    init {
        require(id in 0 until 52) { "Card id out of range: $id" }
    }

    val rank: Rank get() = Rank.entries[id % 13]
    val suit: Suit get() = Suit.entries[id / 13]

    /** Single-bit mask of this card within a 52-bit card set. */
    val mask: Long get() = 1L shl id

    override fun compareTo(other: Card): Int =
        compareValuesBy(this, other, { it.rank.ordinal }, { it.suit.ordinal })

    override fun toString(): String = "${rank.symbol}${suit.symbol}"

    companion object {
        fun of(rank: Rank, suit: Suit): Card = Card(suit.ordinal * 13 + rank.ordinal)

        /** Parses "As", "Td", "9h". */
        fun parse(text: String): Card {
            require(text.length == 2) { "Card must be 2 chars, got '$text'" }
            return of(Rank.fromSymbol(text[0]), Suit.fromSymbol(text[1]))
        }

        /** Parses a whitespace-separated or concatenated list, e.g. "AsKd Qh" or "AsKdQh". */
        fun parseList(text: String): List<Card> {
            val compact = text.filterNot { it.isWhitespace() || it == ',' }
            require(compact.length % 2 == 0) { "Odd-length card string '$text'" }
            return compact.chunked(2).map(::parse)
        }

        val ALL: List<Card> = (0 until 52).map(::Card)
    }
}

/** Helpers for 52-bit card-set masks. */
object CardMask {
    fun of(cards: Iterable<Card>): Long = cards.fold(0L) { acc, c -> acc or c.mask }
    fun count(mask: Long): Int = java.lang.Long.bitCount(mask)
    fun toCards(mask: Long): List<Card> {
        val out = ArrayList<Card>(count(mask))
        var m = mask
        while (m != 0L) {
            val id = java.lang.Long.numberOfTrailingZeros(m)
            out += Card(id)
            m = m and (m - 1)
        }
        return out
    }
}
