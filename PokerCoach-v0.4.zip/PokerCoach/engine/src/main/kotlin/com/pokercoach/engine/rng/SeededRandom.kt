package com.pokercoach.engine.rng

/**
 * xoshiro256** seeded through SplitMix64.
 *
 * Why not java.util.Random / kotlin.random? Their algorithms are implementation details that
 * could differ between JVMs, Android versions or Kotlin releases. Owning the algorithm keeps
 * every shuffle reproducible forever from its seed, which is what makes hand replay auditable.
 */
class SeededRandom(seed: Long) {
    private var s0: Long
    private var s1: Long
    private var s2: Long
    private var s3: Long

    init {
        var sm = seed
        fun next(): Long {
            sm += -0x61c8864680b583ebL // 0x9E3779B97F4A7C15
            return mix64(sm)
        }
        s0 = next(); s1 = next(); s2 = next(); s3 = next()
    }

    fun nextLong(): Long {
        val result = java.lang.Long.rotateLeft(s1 * 5, 7) * 9
        val t = s1 shl 17
        s2 = s2 xor s0
        s3 = s3 xor s1
        s1 = s1 xor s2
        s0 = s0 xor s3
        s2 = s2 xor t
        s3 = java.lang.Long.rotateLeft(s3, 45)
        return result
    }

    /** Uniform integer in [0, bound) without modulo bias (rejection sampling). */
    fun nextInt(bound: Int): Int {
        require(bound > 0) { "bound must be positive" }
        val b = bound.toLong()
        val limit = Long.MAX_VALUE - (Long.MAX_VALUE % b) // largest multiple of b, exclusive
        while (true) {
            val r = nextLong() ushr 1
            if (r < limit) return (r % b).toInt()
        }
    }

    /** Uniform double in [0, 1). */
    fun nextDouble(): Double = (nextLong() ushr 11) * (1.0 / (1L shl 53))

    companion object {
        fun mix64(z0: Long): Long {
            var z = z0
            z = (z xor (z ushr 30)) * -0x40a7b892e31b1a47L // 0xBF58476D1CE4E5B9
            z = (z xor (z ushr 27)) * -0x6b2fb644ecceee15L // 0x94D049BB133111EB
            return z xor (z ushr 31)
        }

        /** Derives an independent child seed, e.g. hand N of a session from the session seed. */
        fun derive(parent: Long, index: Long): Long = mix64(parent xor mix64(index + 0x5DEECE66DL))
    }
}
