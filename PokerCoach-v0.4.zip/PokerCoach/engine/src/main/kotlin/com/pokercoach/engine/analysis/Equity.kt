package com.pokercoach.engine.analysis

import com.pokercoach.engine.card.Card
import com.pokercoach.engine.card.CardMask
import com.pokercoach.engine.eval.HandEvaluator
import com.pokercoach.engine.range.Combos
import com.pokercoach.engine.range.Range
import com.pokercoach.engine.rng.SeededRandom
import kotlin.math.sqrt

/** Draws combos from a weighted range, skipping combos that use [dead] cards. */
class RangeSampler(range: Range, dead: Long) {
    private val combos: IntArray
    private val cumulative: DoubleArray
    val total: Double

    init {
        val ids = ArrayList<Int>(Combos.COUNT)
        val cum = ArrayList<Double>(Combos.COUNT)
        var t = 0.0
        for (i in 0 until Combos.COUNT) {
            val w = range.weight(i)
            if (w <= 0.0 || Combos.mask[i] and dead != 0L) continue
            t += w
            ids += i
            cum += t
        }
        combos = ids.toIntArray()
        cumulative = cum.toDoubleArray()
        total = t
    }

    val isEmpty: Boolean get() = combos.isEmpty()

    fun sample(rng: SeededRandom): Int {
        val x = rng.nextDouble() * total
        var lo = 0
        var hi = cumulative.size - 1
        while (lo < hi) {
            val m = (lo + hi) ushr 1
            if (cumulative[m] <= x) lo = m + 1 else hi = m
        }
        return combos[lo]
    }
}

object Showdown {
    /** Deals random cards until the board has five. [used] must include every known card. */
    fun completeBoard(boardMask: Long, boardCount: Int, used: Long, rng: SeededRandom): Long {
        var b = boardMask
        var u = used
        repeat(5 - boardCount) {
            var id: Int
            do { id = rng.nextInt(52) } while (u and (1L shl id) != 0L)
            b = b or (1L shl id)
            u = u or (1L shl id)
        }
        return b
    }

    /** Hero's share of the pot (1 win, 1/k for a k-way tie, 0 loss) against [opponents] masks. */
    fun heroShare(heroMask: Long, board5: Long, opponents: LongArray, count: Int): Double {
        val hero = HandEvaluator.evaluateMask(heroMask or board5)
        var ties = 1
        for (i in 0 until count) {
            val v = HandEvaluator.evaluateMask(opponents[i] or board5)
            if (v > hero) return 0.0
            if (v == hero) ties++
        }
        return 1.0 / ties
    }
}

data class EquityResult(
    val equity: Double,
    /** Standard error of a Monte Carlo estimate; 0 for exact enumeration. */
    val stdError: Double,
    val exact: Boolean,
    val samples: Int,
) {
    val method: String
        get() = if (exact) "exact enumeration over the estimated range"
        else "Monte Carlo, ${"%,d".format(samples)} samples (±${"%.1f".format(stdError * 196)}% at 95%)"
}

/**
 * Hero equity against one or more weighted ranges.
 * Heads-up on the turn or river it enumerates every villain combo and river card exactly;
 * otherwise it uses Monte Carlo with a fixed seed (so the review is reproducible).
 */
object EquityCalculator {

    fun vsRanges(
        hero: List<Card>,
        board: List<Card>,
        villains: List<Range>,
        iterations: Int,
        rng: SeededRandom,
    ): EquityResult {
        require(hero.size == 2 && board.size <= 5)
        if (villains.isEmpty()) return EquityResult(1.0, 0.0, true, 0)
        val heroMask = CardMask.of(hero)
        val boardMask = CardMask.of(board)
        if (villains.size == 1 && board.size >= 4) return exactHeadsUp(heroMask, boardMask, board.size, villains[0])

        val samplers = villains.map { RangeSampler(it, heroMask or boardMask) }
        if (samplers.any { it.isEmpty }) return EquityResult(0.0, 0.0, false, 0)
        val opp = LongArray(villains.size)
        var sum = 0.0
        var sumSq = 0.0
        var done = 0
        var attempts = 0
        while (done < iterations && attempts < iterations * 4) {
            attempts++
            var used = heroMask or boardMask
            var ok = true
            for (v in samplers.indices) {
                val c = samplers[v].sample(rng)
                val m = Combos.mask[c]
                if (m and used != 0L) { ok = false; break }
                opp[v] = m
                used = used or m
            }
            if (!ok) continue
            val b5 = Showdown.completeBoard(boardMask, board.size, used, rng)
            val s = Showdown.heroShare(heroMask, b5, opp, villains.size)
            sum += s
            sumSq += s * s
            done++
        }
        if (done == 0) return EquityResult(0.0, 0.0, false, 0)
        val mean = sum / done
        val variance = (sumSq / done - mean * mean).coerceAtLeast(0.0)
        return EquityResult(mean, sqrt(variance / done), false, done)
    }

    private fun exactHeadsUp(heroMask: Long, boardMask: Long, boardCount: Int, range: Range): EquityResult {
        var total = 0.0
        var won = 0.0
        val known = heroMask or boardMask
        for (c in 0 until Combos.COUNT) {
            val w = range.weight(c)
            if (w <= 0.0) continue
            val vm = Combos.mask[c]
            if (vm and known != 0L) continue
            if (boardCount == 5) {
                total += w
                won += w * share(heroMask, vm, boardMask)
            } else {
                val used = known or vm
                for (id in 0 until 52) {
                    val bit = 1L shl id
                    if (used and bit != 0L) continue
                    total += w
                    won += w * share(heroMask, vm, boardMask or bit)
                }
            }
        }
        return if (total == 0.0) EquityResult(0.0, 0.0, true, 0) else EquityResult(won / total, 0.0, true, 0)
    }

    private fun share(hero: Long, villain: Long, board5: Long): Double {
        val h = HandEvaluator.evaluateMask(hero or board5)
        val v = HandEvaluator.evaluateMask(villain or board5)
        return when { h > v -> 1.0; h == v -> 0.5; else -> 0.0 }
    }

    /**
     * Range-vs-range equity (used for "range advantage"). Monte Carlo over both ranges.
     */
    fun rangeVsRange(a: Range, b: Range, board: List<Card>, iterations: Int, rng: SeededRandom): Double? {
        val boardMask = CardMask.of(board)
        val sa = RangeSampler(a, boardMask)
        val sb = RangeSampler(b, boardMask)
        if (sa.isEmpty || sb.isEmpty) return null
        var sum = 0.0
        var done = 0
        var attempts = 0
        val opp = LongArray(1)
        while (done < iterations && attempts < iterations * 4) {
            attempts++
            val ma = Combos.mask[sa.sample(rng)]
            val mb = Combos.mask[sb.sample(rng)]
            if (ma and mb != 0L) continue
            val b5 = Showdown.completeBoard(boardMask, board.size, boardMask or ma or mb, rng)
            opp[0] = mb
            sum += Showdown.heroShare(ma, b5, opp, 1)
            done++
        }
        return if (done == 0) null else sum / done
    }
}
