package com.pokercoach.engine.bot

import com.pokercoach.engine.range.HandClass

enum class BotStyle(val label: String, val description: String) {
    BEGINNER("Beginner", "Loose-passive: plays lots of hands, calls too much, rarely bluffs."),
    CASUAL("Casual", "Plays some hands well but limps, overvalues top pair and calls too wide."),
    REGULAR("Regular", "Solid tight-aggressive: uses position, pot odds and hand reading."),
    SHARK("Shark", "Aggressive and well-balanced; bluffs at good moments and adapts to you."),
    GTO("GTO-approx", "Precomputed preflop charts and balanced postflop frequencies; hard to exploit."),
    CUSTOM("Custom", "Your own mix of looseness, aggression, bluffing, tilt and adaptiveness."),
}

/**
 * Everything that makes one bot play differently from another. All values are 0..1 unless noted.
 */
data class BotProfile(
    val style: BotStyle,
    val label: String,
    /** Share of hands played preflop (a 6-max middle-position baseline; position scales it). */
    val vpip: Double,
    /** Share of hands raised preflop; at most [vpip]. */
    val pfr: Double,
    /** Share of the raising range used to 3-bet a raise. */
    val threeBetShare: Double,
    /** Postflop: probability of betting/raising strong hands rather than checking/calling. */
    val aggression: Double,
    /** Base probability of bluffing with air when checked to (heads-up). */
    val bluff: Double,
    /** Extra equity the bot "feels" when facing a bet: the calling-station leak. */
    val callBias: Double,
    /** Random error added to its equity estimate: mistakes. */
    val noise: Double,
    /** Equity vs. estimated ranges (true) or vs. random hands (false). */
    val readsRanges: Boolean,
    /** Limps instead of raising with its weaker playable hands. */
    val limps: Boolean,
    /** Treats top pair / overpairs as near-nuts. */
    val overvaluesPairs: Boolean,
    /** Chance of slow-playing a premium hand preflop (limping aces). */
    val slowplay: Double,
    /** How strongly big losses make it play looser and wilder. */
    val tilt: Double,
    /** How strongly it adjusts to opponents' observed tendencies. */
    val adaptiveness: Double,
    /** Uses position charts preflop and balanced bluff ratios postflop. */
    val gto: Boolean,
    /** Bet sizes as a fraction of the pot. */
    val valueSize: Double,
    val bluffSize: Double,
) {
    companion object {
        val BEGINNER = BotProfile(
            BotStyle.BEGINNER, "Beginner", vpip = 0.50, pfr = 0.06, threeBetShare = 0.15, aggression = 0.25,
            bluff = 0.03, callBias = 0.15, noise = 0.10, readsRanges = false, limps = true, overvaluesPairs = true,
            slowplay = 0.30, tilt = 0.3, adaptiveness = 0.0, gto = false, valueSize = 0.4, bluffSize = 0.4,
        )
        val CASUAL = BotProfile(
            BotStyle.CASUAL, "Casual", vpip = 0.34, pfr = 0.13, threeBetShare = 0.25, aggression = 0.45,
            bluff = 0.08, callBias = 0.07, noise = 0.06, readsRanges = false, limps = true, overvaluesPairs = true,
            slowplay = 0.10, tilt = 0.5, adaptiveness = 0.1, gto = false, valueSize = 0.55, bluffSize = 0.5,
        )
        val REGULAR = BotProfile(
            BotStyle.REGULAR, "Regular", vpip = 0.23, pfr = 0.18, threeBetShare = 0.35, aggression = 0.65,
            bluff = 0.12, callBias = 0.0, noise = 0.03, readsRanges = true, limps = false, overvaluesPairs = false,
            slowplay = 0.0, tilt = 0.1, adaptiveness = 0.2, gto = false, valueSize = 0.66, bluffSize = 0.66,
        )
        val SHARK = BotProfile(
            BotStyle.SHARK, "Shark", vpip = 0.26, pfr = 0.21, threeBetShare = 0.45, aggression = 0.75,
            bluff = 0.20, callBias = 0.0, noise = 0.015, readsRanges = true, limps = false, overvaluesPairs = false,
            slowplay = 0.05, tilt = 0.0, adaptiveness = 0.9, gto = false, valueSize = 0.75, bluffSize = 0.75,
        )
        val GTO = BotProfile(
            BotStyle.GTO, "GTO-approx", vpip = 0.24, pfr = 0.20, threeBetShare = 0.45, aggression = 0.6,
            bluff = 0.0, callBias = 0.0, noise = 0.0, readsRanges = true, limps = false, overvaluesPairs = false,
            slowplay = 0.0, tilt = 0.0, adaptiveness = 0.0, gto = true, valueSize = 0.66, bluffSize = 0.66,
        )

        fun preset(style: BotStyle): BotProfile = when (style) {
            BotStyle.BEGINNER -> BEGINNER
            BotStyle.CASUAL -> CASUAL
            BotStyle.REGULAR -> REGULAR
            BotStyle.SHARK -> SHARK
            BotStyle.GTO -> GTO
            BotStyle.CUSTOM -> custom(CustomSettings())
        }

        /** Builds a profile from the five Custom sliders. */
        fun custom(s: CustomSettings): BotProfile {
            val vpip = s.looseness.coerceIn(0.08, 0.70)
            val aggr = s.aggression.coerceIn(0.0, 1.0)
            return BotProfile(
                style = BotStyle.CUSTOM,
                label = "Custom",
                vpip = vpip,
                pfr = vpip * (0.15 + 0.8 * aggr),
                threeBetShare = 0.15 + 0.35 * aggr,
                aggression = 0.2 + 0.7 * aggr,
                bluff = s.bluffing.coerceIn(0.0, 0.4),
                callBias = (1 - aggr) * (if (vpip > 0.35) 0.12 else 0.05),
                noise = 0.04,
                readsRanges = vpip < 0.40,
                limps = aggr < 0.4,
                overvaluesPairs = vpip > 0.40,
                slowplay = if (aggr < 0.3) 0.15 else 0.0,
                tilt = s.tilt.coerceIn(0.0, 1.0),
                adaptiveness = s.adaptiveness.coerceIn(0.0, 1.0),
                gto = false,
                valueSize = 0.45 + 0.35 * aggr,
                bluffSize = 0.45 + 0.35 * aggr,
            )
        }
    }
}

/** Custom slider values (all 0..1 except looseness, which is the VPIP share). */
data class CustomSettings(
    val looseness: Double = 0.28,
    val aggression: Double = 0.5,
    val bluffing: Double = 0.10,
    val tilt: Double = 0.2,
    val adaptiveness: Double = 0.3,
)

/**
 * Preflop order by playability: the average rank of each class by equity heads-up and against
 * two random hands (each computed with 120,000+ Monte Carlo trials). Suited and connected hands
 * rank higher than in a pure heads-up ordering, which suits multi-player charts.
 */
object PlayabilityRanking {
    private const val ORDER =
        "AA KK QQ JJ TT 99 88 AKs AQs AKo AJs 77 ATs AQo KQs AJo KJs A9s 66 KTs ATo KQo A8s QJs KJo A7s A9o K9s " +
            "QTs A5s KTo A8o A6s 55 A4s QJo JTs K8s A3s Q9s A7o QTo K9o K7s A6o A5o A2s J9s Q8s K6s JTo A4o 44 K5s " +
            "K8o Q9o T9s A3o J8s K4s K7o Q7s A2o K3s J9o Q6s Q8o T8s K6o K2s J7s Q5s 33 K5o T9o 98s Q4s J8o K4o Q7o " +
            "T7s K3o J6s Q3s 97s Q6o T8o J5s 87s Q2s T6s K2o J7o Q5o 98o J4s 22 Q4o J3s 96s T7o 86s 76s 97o T5s Q3o " +
            "J6o J2s T4s 95s 87o J5o Q2o T3s T6o 85s 75s 65s J4o T2s 96o 94s J3o 86o 54s T5o 93s 84s 76o J2o 74s " +
            "64s 92s T4o 95o 83s 53s T3o 85o 65o 75o 63s 73s T2o 82s 43s 94o 93o 64o 54o 52s 84o 74o 62s 72s 92o " +
            "42s 53o 83o 32s 82o 73o 63o 43o 52o 72o 62o 42o 32o"

    val order: List<HandClass> = ORDER.split(" ").map(HandClass::parse)

    /** For each class index: fraction of all combos ranked better (0 = best). */
    private val rankPct = DoubleArray(169)

    init {
        require(order.size == 169 && order.map { it.index }.toSet().size == 169)
        var cum = 0
        for (c in order) {
            rankPct[c.index] = (cum + c.comboCount / 2.0) / 1326.0
            cum += c.comboCount
        }
    }

    /** 0 = the best hand (AA), ~1 = the worst. "Top 20%" means rankPct < 0.20. */
    fun rankPct(classIndex: Int): Double = rankPct[classIndex]
}
