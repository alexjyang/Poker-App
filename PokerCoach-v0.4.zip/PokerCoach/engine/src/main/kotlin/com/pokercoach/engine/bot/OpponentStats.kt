package com.pokercoach.engine.bot

import com.pokercoach.engine.game.ActionType
import com.pokercoach.engine.game.HandEvent
import com.pokercoach.engine.game.Street

/**
 * Tendencies a bot has observed for each opponent, from public actions only.
 * Adaptive bots (Shark, Custom) use these to bluff players who fold too much, value-bet
 * calling stations thinner, and call down aggressive players lighter.
 */
class OpponentStats {
    class Counts {
        var hands = 0
        var vpip = 0
        var pfr = 0
        var postflopBetsRaises = 0
        var postflopCalls = 0
        var facedBet = 0
        var foldedToBet = 0

        /** Share of hands played (null until enough hands). */
        val vpipRate: Double? get() = if (hands >= 8) vpip.toDouble() / hands else null
        /** Postflop aggression factor: (bets + raises) / calls. */
        val aggressionFactor: Double? get() = if (postflopBetsRaises + postflopCalls >= 8) postflopBetsRaises.toDouble() / postflopCalls.coerceAtLeast(1) else null
        /** How often they fold when facing a postflop bet. */
        val foldToBet: Double? get() = if (facedBet >= 6) foldedToBet.toDouble() / facedBet else null
    }

    private val byPlayer = HashMap<String, Counts>()

    fun of(playerId: String): Counts? = byPlayer[playerId]

    fun record(history: List<HandEvent>, observerSeat: Int) {
        val start = history.firstOrNull() as? HandEvent.HandStarted ?: return
        val idBySeat = start.players.associate { it.seat to it.playerId }
        val seen = HashSet<Int>()
        val vpip = HashSet<Int>()
        val pfr = HashSet<Int>()
        for (e in history) {
            if (e !is HandEvent.ActionTaken || e.seat == observerSeat) continue
            val c = byPlayer.getOrPut(idBySeat.getValue(e.seat)) { Counts() }
            seen += e.seat
            if (e.street == Street.PREFLOP) {
                if (e.type == ActionType.CALL || e.type == ActionType.RAISE || e.type == ActionType.BET) vpip += e.seat
                if (e.type == ActionType.RAISE || e.type == ActionType.BET) pfr += e.seat
            } else {
                when (e.type) {
                    ActionType.BET, ActionType.RAISE -> c.postflopBetsRaises++
                    ActionType.CALL -> c.postflopCalls++
                    else -> {}
                }
                if (e.toCallBefore > 0) {
                    c.facedBet++
                    if (e.type == ActionType.FOLD) c.foldedToBet++
                }
            }
        }
        for (seat in start.players.map { it.seat }) {
            if (seat == observerSeat) continue
            val c = byPlayer.getOrPut(idBySeat.getValue(seat)) { Counts() }
            c.hands++
            if (seat in vpip) c.vpip++
            if (seat in pfr) c.pfr++
        }
    }
}
