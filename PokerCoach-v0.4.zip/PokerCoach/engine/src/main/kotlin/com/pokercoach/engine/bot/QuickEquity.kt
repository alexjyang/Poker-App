package com.pokercoach.engine.bot

import com.pokercoach.engine.card.Card
import com.pokercoach.engine.eval.HandEvaluator
import com.pokercoach.engine.rng.SeededRandom

/**
 * Quick Monte Carlo equity against N opponents holding random hands.
 *
 * This is a deliberately simple strength estimate for the basic bots. The full range-vs-range
 * equity calculator with exact enumeration arrives in Stage 4 for the post-hand analysis.
 * Ties count as a share of the pot (1 / number of tied winners).
 */
object QuickEquity {

    fun vsRandom(
        hole: List<Card>,
        board: List<Card>,
        opponents: Int,
        iterations: Int,
        rng: SeededRandom,
    ): Double {
        require(hole.size == 2 && board.size <= 5 && opponents >= 1)
        val dead = (hole + board).map { it.id }.toSet()
        val live = IntArray(52 - dead.size)
        var k = 0
        for (id in 0 until 52) if (id !in dead) live[k++] = id

        val heroBase = hole.fold(0L) { m, c -> m or c.mask }
        val boardBase = board.fold(0L) { m, c -> m or c.mask }
        val boardNeeded = 5 - board.size
        val draw = boardNeeded + 2 * opponents
        require(draw <= live.size) { "Not enough cards for $opponents opponents" }

        var equity = 0.0
        repeat(iterations) {
            // Partial Fisher–Yates: the first `draw` slots become a random sample.
            for (i in 0 until draw) {
                val j = i + rng.nextInt(live.size - i)
                val t = live[i]; live[i] = live[j]; live[j] = t
            }
            var boardMask = boardBase
            for (i in 0 until boardNeeded) boardMask = boardMask or (1L shl live[i])
            val hero = HandEvaluator.evaluateMask(heroBase or boardMask)
            var best = hero
            var heroTied = 1
            var heroLost = false
            var idx = boardNeeded
            repeat(opponents) {
                val opp = HandEvaluator.evaluateMask(boardMask or (1L shl live[idx]) or (1L shl live[idx + 1]))
                idx += 2
                when {
                    opp > best -> { best = opp; heroLost = true }
                    opp == hero && !heroLost -> heroTied++
                }
            }
            if (!heroLost && best == hero) equity += 1.0 / heroTied
        }
        return equity / iterations
    }
}
