package com.pokercoach.engine.range

import com.pokercoach.engine.card.Card
import com.pokercoach.engine.card.CardMask
import com.pokercoach.engine.eval.HandEvaluator

/**
 * The 169 classes ordered by all-in equity against one random hand (computed with 200,000
 * Monte Carlo trials per class). It's the classic "top X% of hands" ordering; real ranges also
 * depend on position and playability, which [RangeEstimator] layers on top.
 */
object PreflopRanking {
    private const val ORDER =
        "AA KK QQ JJ TT 99 88 AKs AQs 77 AKo AJs ATs AQo AJo 66 KQs A9s ATo KJs A8s KTs KQo A7s KJo A9o QJs 55 " +
            "A8o K9s A5s A6s KTo QTs A4s A7o K8s A3s QJo A6o K9o A5o QTo Q9s JTs K7s A2s 44 A4o K6s Q8s K8o A3o " +
            "K5s J9s Q9o JTo K7o A2o K4s Q7s K6o J8s K3s T9s Q8o 33 Q6s K5o J9o K2s Q5s K4o J7s T8s Q4s Q7o K3o " +
            "J8o T9o Q6o Q3s 98s J6s K2o T7s 22 Q2s J5s Q5o J7o T8o 97s Q4o J4s T6s J3s 87s Q3o J6o T7o 98o 96s " +
            "J2s J5o Q2o T5s T4s 97o J4o 86s 95s T6o 76s T3s J3o 87o T2s 85s 96o J2o T5o 94s 75s T4o 93s 65s " +
            "86o 84s 95o T3o 76o 92s T2o 74s 85o 54s 64s 83s 94o 75o 82s 93o 73s 65o 53s 63s 84o 92o 43s 74o " +
            "64o 72s 54o 52s 62s 83o 82o 42s 73o 53o 63o 32s 43o 72o 52o 62o 42o 32o"

    val order: List<HandClass> = ORDER.split(" ").map(HandClass::parse)

    /** For each class index: the fraction of all combos that rank strictly better. */
    private val startPct = DoubleArray(169)
    private val endPct = DoubleArray(169)

    init {
        require(order.size == 169 && order.map { it.index }.toSet().size == 169)
        var cum = 0
        for (c in order) {
            startPct[c.index] = cum / 1326.0
            cum += c.comboCount
            endPct[c.index] = cum / 1326.0
        }
    }

    /** Strength in [0, 1]: 1 = best hand (AA), ~0 = worst. Midpoint of the class's band. */
    fun strength(classIndex: Int): Double = 1.0 - (startPct[classIndex] + endPct[classIndex]) / 2

    /**
     * Weight of a class inside "the top [pct] of hands": 1 if fully inside, 0 if outside,
     * fractional for the class straddling the boundary.
     */
    fun topWeight(classIndex: Int, pct: Double): Double {
        val s = startPct[classIndex]
        val e = endPct[classIndex]
        return when {
            pct >= e -> 1.0
            pct <= s -> 0.0
            else -> (pct - s) / (e - s)
        }
    }

    /** Range of the top [pct] of hands (0..1). */
    fun top(pct: Double): Range = Range(DoubleArray(Combos.COUNT) { topWeight(Combos.classOf[it], pct) })
}

/**
 * Strength of every combo on a given board, used to narrow ranges after postflop actions and
 * to decide which hands continue versus a bet.
 *
 * [hs]: hand-strength percentile — the share of all other possible holdings this combo beats
 * right now (ties count half). 1.0 = the nuts. Combos that use a board card get -1.
 * [draw]: extra "potential" on the flop/turn: flush draws, open-enders, gutshots.
 */
class BoardStrength(val board: List<Card>) {
    val hs = DoubleArray(Combos.COUNT) { -1.0 }
    val draw = DoubleArray(Combos.COUNT)

    init {
        require(board.size in 3..5)
        val boardMask = CardMask.of(board)
        val values = IntArray(Combos.COUNT) { Int.MIN_VALUE }
        val live = ArrayList<Int>(1100)
        for (i in 0 until Combos.COUNT) {
            if (Combos.mask[i] and boardMask != 0L) continue
            values[i] = HandEvaluator.evaluateMask(Combos.mask[i] or boardMask)
            live += i
        }
        val sorted = live.map { values[it] }.sorted()
        val n = sorted.size.toDouble()
        for (i in live) {
            val v = values[i]
            val below = lowerBound(sorted, v)
            val equal = upperBound(sorted, v) - below
            hs[i] = (below + (equal - 1) * 0.5) / (n - 1)
        }
        if (board.size < 5) computeDraws(boardMask, live)
    }

    /** Effective strength for "does this hand continue": made strength or draw potential. */
    fun effective(combo: Int): Double = maxOf(hs[combo], draw[combo])

    fun category(combo: Int): StrengthCategory {
        val s = hs[combo]
        return when {
            s < 0 -> StrengthCategory.AIR
            s >= 0.90 -> StrengthCategory.MONSTER
            s >= 0.70 -> StrengthCategory.STRONG
            s >= 0.45 -> StrengthCategory.MEDIUM
            draw[combo] > 0 -> StrengthCategory.DRAW
            else -> StrengthCategory.AIR
        }
    }

    private fun computeDraws(boardMask: Long, live: List<Int>) {
        val onTurn = board.size == 4
        val boardSuits = IntArray(4)
        board.forEach { boardSuits[it.suit.ordinal]++ }
        val boardRanks = board.fold(0) { m, c -> m or (1 shl c.rank.ordinal) }
        for (i in live) {
            val c1 = Card(Combos.card1[i])
            val c2 = Card(Combos.card2[i])
            val made = hs[i]
            // Flush draw: exactly four of a suit including at least one hole card.
            var flushDraw = false
            for (s in 0 until 4) {
                val holeOfSuit = (if (c1.suit.ordinal == s) 1 else 0) + (if (c2.suit.ordinal == s) 1 else 0)
                if (holeOfSuit > 0 && boardSuits[s] + holeOfSuit == 4) flushDraw = true
            }
            // Straight draws: ranks that would complete a straight using a hole card.
            val ranks = boardRanks or (1 shl c1.rank.ordinal) or (1 shl c2.rank.ordinal)
            var completing = 0
            if (HandEvaluator.straightHigh(ranks) < 0) {
                for (r in 0 until 13) {
                    if (ranks and (1 shl r) != 0) continue
                    if (HandEvaluator.straightHigh(ranks or (1 shl r)) >= 0 &&
                        HandEvaluator.straightHigh(boardRanks or (1 shl r)) < 0
                    ) completing++
                }
            }
            val d = when {
                flushDraw && completing >= 1 -> if (onTurn) 0.72 else 0.85
                flushDraw -> if (onTurn) 0.62 else 0.72
                completing >= 2 -> if (onTurn) 0.55 else 0.62
                completing == 1 -> if (onTurn) 0.38 else 0.45
                else -> 0.0
            }
            draw[i] = if (d > made) d else 0.0
        }
    }

    private fun lowerBound(a: List<Int>, v: Int): Int {
        var lo = 0; var hi = a.size
        while (lo < hi) { val m = (lo + hi) ushr 1; if (a[m] < v) lo = m + 1 else hi = m }
        return lo
    }

    private fun upperBound(a: List<Int>, v: Int): Int {
        var lo = 0; var hi = a.size
        while (lo < hi) { val m = (lo + hi) ushr 1; if (a[m] <= v) lo = m + 1 else hi = m }
        return lo
    }
}

enum class StrengthCategory(val label: String) {
    MONSTER("Monsters"), STRONG("Strong"), MEDIUM("Medium"), DRAW("Draws"), AIR("Air / weak"),
}
