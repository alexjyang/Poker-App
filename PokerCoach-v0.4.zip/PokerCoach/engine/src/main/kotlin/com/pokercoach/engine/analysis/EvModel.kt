package com.pokercoach.engine.analysis

import com.pokercoach.engine.card.Card
import com.pokercoach.engine.card.CardMask
import com.pokercoach.engine.game.Street
import com.pokercoach.engine.range.BoardStrength
import com.pokercoach.engine.range.Combos
import com.pokercoach.engine.range.PreflopRanking
import com.pokercoach.engine.range.Range
import com.pokercoach.engine.rng.SeededRandom
import kotlin.math.pow

enum class OptionKind { FOLD, CHECK, CALL, BET, RAISE, ALL_IN }

data class Option(val kind: OptionKind, val to: Long, val label: String)

data class OptionResult(
    val option: Option,
    /** Expected value in chips relative to folding now (chips already in the pot are sunk). */
    val evChips: Double,
    /** For bets/raises: how often everyone folds. */
    val foldEquity: Double?,
    /** For bets/raises: hero's pot share when at least one opponent continues. */
    val equityWhenCalled: Double?,
)

/** Preflop role of an opponent who hasn't voluntarily acted yet (their range is still "any two"). */
enum class UnopenedRole { BIG_BLIND, SMALL_BLIND, OTHER }

/**
 * One opponent as seen at the decision.
 * [unopenedRole]: set for players who haven't acted yet preflop; they continue versus a raise at
 * typical preflop defend frequencies instead of MDF on a narrowed range.
 * [inPot]: included in check/call showdowns (players yet to act preflop are assumed to fold).
 */
data class Opponent(
    val seat: Int,
    val range: Range,
    val streetCommit: Long,
    val stackBehind: Long,
    val inPot: Boolean,
    val unopenedRole: UnopenedRole?,
)

data class Situation(
    val hero: List<Card>,
    val board: List<Card>,
    val street: Street,
    val pot: Long,
    val currentBet: Long,
    val heroCommit: Long,
    val heroStack: Long,
    val bigBlind: Long,
    val opponents: List<Opponent>,
    val heroInPosition: Boolean,
)

/**
 * A one-decision EV model, simulated with Monte Carlo. It is an ESTIMATE with stated
 * simplifications, the same kind used by most trainers' quick analysis:
 *
 *  - Call / check: showdown equity vs. the players in the pot, scaled by an equity-realization
 *    factor for streets still to come (in position realizes more than out of position).
 *  - Bet / raise: each opponent continues with the strongest part of their range. How much they
 *    continue is the larger of minimum defense frequency (MDF) and the share of their range
 *    strong enough for the price; players who haven't acted preflop use typical defend
 *    frequencies. Folds win the pot now; calls go to showdown.
 *  - No future betting, side pots or re-raises are simulated.
 *
 * All options use the same random seed (common random numbers), so EV *differences* between
 * options are much more precise than each EV on its own.
 */
class EvModel(private val iterations: Int) {

    fun evaluate(s: Situation, options: List<Option>, seed: Long): List<OptionResult> {
        val strength = if (s.board.size >= 3) BoardStrength(s.board) else null
        return options.map { opt ->
            val rng = SeededRandom(seed)
            when (opt.kind) {
                OptionKind.FOLD -> OptionResult(opt, 0.0, null, null)
                OptionKind.CHECK -> OptionResult(opt, passive(s, 0L, rng), null, null)
                OptionKind.CALL -> OptionResult(opt, passive(s, minOf(s.currentBet - s.heroCommit, s.heroStack), rng), null, null)
                else -> aggressive(s, opt, strength, rng)
            }
        }
    }

    private fun realization(s: Situation, players: Int, heroAllIn: Boolean, allOppsAllIn: Boolean, aggressor: Boolean): Double {
        if (s.street == Street.RIVER || heroAllIn || allOppsAllIn) return 1.0
        var r = if (s.heroInPosition) 0.95 else 0.85
        if (s.street == Street.PREFLOP) r -= 0.05
        if (aggressor) r += 0.05
        r -= 0.05 * (players - 1).coerceAtLeast(0)
        return r.coerceIn(0.6, 1.0)
    }

    /** Check (toCall = 0) or call: showdown vs players already in the pot. */
    private fun passive(s: Situation, toCall: Long, rng: SeededRandom): Double {
        val inPot = s.opponents.filter { it.inPot }
        val heroMask = CardMask.of(s.hero)
        val boardMask = CardMask.of(s.board)
        val heroTotal = s.heroCommit + toCall
        // Chips opponents bet beyond what hero can match come back to them.
        val uncalled = inPot.sumOf { (it.streetCommit - heroTotal).coerceAtLeast(0) }
        val winnable = (s.pot + toCall - uncalled).toDouble()
        if (inPot.isEmpty()) return winnable - toCall
        val heroAllIn = toCall >= s.heroStack && toCall > 0
        val r = realization(s, inPot.size, heroAllIn, inPot.all { it.stackBehind == 0L }, aggressor = false)

        val samplers = inPot.map { RangeSampler(it.range, heroMask or boardMask) }
        if (samplers.any { it.isEmpty }) return -toCall.toDouble()
        val opp = LongArray(inPot.size)
        var sum = 0.0
        var done = 0
        var attempts = 0
        while (done < iterations && attempts < iterations * 4) {
            attempts++
            var used = heroMask or boardMask
            var ok = true
            for (i in samplers.indices) {
                val m = Combos.mask[samplers[i].sample(rng)]
                if (m and used != 0L) { ok = false; break }
                opp[i] = m; used = used or m
            }
            if (!ok) continue
            val b5 = Showdown.completeBoard(boardMask, s.board.size, used, rng)
            sum += Showdown.heroShare(heroMask, b5, opp, inPot.size)
            done++
        }
        if (done == 0) return -toCall.toDouble()
        val eq = sum / done
        return r * eq * winnable - toCall
    }

    private fun aggressive(s: Situation, opt: Option, strength: BoardStrength?, rng: SeededRandom): OptionResult {
        val heroMask = CardMask.of(s.hero)
        val boardMask = CardMask.of(s.board)
        val live = s.opponents
        val responders = live.filter { it.stackBehind > 0 }
        val allIns = live.filter { it.stackBehind == 0L }

        // Hero can't put in more than the deepest opponent can match.
        val maxCover = live.maxOfOrNull { it.streetCommit + it.stackBehind } ?: s.currentBet
        val effectiveTo = minOf(opt.to, maxOf(maxCover, s.currentBet))
        val heroAdd = (effectiveTo - s.heroCommit).coerceAtLeast(0)
        val heroAllIn = opt.to >= s.heroCommit + s.heroStack

        // How often each responder continues, and the strength cut-off inside their range.
        val k = responders.size.coerceAtLeast(1)
        val mdfCombined = s.pot.toDouble() / (s.pot + heroAdd).coerceAtLeast(1)
        val facingRaise = s.currentBet > 0 && s.street != Street.PREFLOP
        val thresholds = DoubleArray(responders.size)
        val defend = DoubleArray(responders.size)
        responders.forEachIndexed { i, o ->
            val role = o.unopenedRole
            val f = if (role != null) {
                preflopDefend(role, effectiveTo.toDouble() / s.bigBlind, heroAllIn)
            } else {
                // Two views of how often a player with a narrowed range continues; use the larger:
                // (1) MDF — a balanced player can't fold more without being exploited;
                // (2) price — they call with every hand strong enough for the odds they're getting.
                val individual = 1.0 - (1.0 - mdfCombined).pow(1.0 / k)
                val byMdf = individual * if (facingRaise) 0.85 else 1.0
                val call = minOf(effectiveTo - o.streetCommit, o.stackBehind).coerceAtLeast(0)
                val price = call.toDouble() / (s.pot + heroAdd + call).coerceAtLeast(1)
                val byPrice = shareAtLeast(o.range, heroMask or boardMask, 0.35 + price, strength)
                maxOf(byMdf, byPrice)
            }
            defend[i] = f.coerceIn(0.03, 0.97)
            thresholds[i] = cutoff(o.range, heroMask or boardMask, defend[i], strength)
        }

        val samplers = live.map { RangeSampler(it.range, heroMask or boardMask) }
        if (samplers.any { it.isEmpty }) return OptionResult(opt, s.pot.toDouble(), 1.0, null)

        val opp = LongArray(live.size)
        val inHand = LongArray(live.size)
        var sum = 0.0
        var folds = 0
        var calledShare = 0.0
        var calledCount = 0
        var done = 0
        var attempts = 0
        val respIndex = live.map { o -> responders.indexOf(o) }
        while (done < iterations && attempts < iterations * 4) {
            attempts++
            var used = heroMask or boardMask
            var ok = true
            val combos = IntArray(live.size)
            for (i in live.indices) {
                val c = samplers[i].sample(rng)
                val m = Combos.mask[c]
                if (m and used != 0L) { ok = false; break }
                combos[i] = c; opp[i] = m; used = used or m
            }
            if (!ok) continue
            done++

            var nIn = 0
            var callChips = 0L
            var anyCaller = false
            var allCallersAllIn = true
            for (i in live.indices) {
                val o = live[i]
                val ri = respIndex[i]
                val continues = if (ri < 0) true else strengthOf(combos[i], strength) >= thresholds[ri]
                if (!continues) continue
                inHand[nIn++] = opp[i]
                if (ri >= 0) {
                    anyCaller = true
                    val call = minOf(effectiveTo - o.streetCommit, o.stackBehind).coerceAtLeast(0)
                    callChips += call
                    if (call < o.stackBehind) allCallersAllIn = false
                }
            }
            if (!anyCaller && allIns.isEmpty()) {
                folds++
                sum += s.pot
                continue
            }
            val b5 = Showdown.completeBoard(boardMask, s.board.size, used, rng)
            val share = Showdown.heroShare(heroMask, b5, inHand, nIn)
            val r = realization(s, nIn, heroAllIn, allCallersAllIn, aggressor = true)
            val finalPot = s.pot + heroAdd + callChips
            sum += r * share * finalPot - heroAdd
            calledShare += share
            calledCount++
        }
        if (done == 0) return OptionResult(opt, 0.0, null, null)
        return OptionResult(
            option = opt,
            evChips = sum / done,
            foldEquity = folds.toDouble() / done,
            equityWhenCalled = if (calledCount > 0) calledShare / calledCount else null,
        )
    }

    private fun strengthOf(combo: Int, strength: BoardStrength?): Double =
        strength?.effective(combo) ?: PreflopRanking.strength(Combos.classOf[combo])

    /** Weight share of the range whose strength is at least [minStrength]. */
    private fun shareAtLeast(range: Range, dead: Long, minStrength: Double, strength: BoardStrength?): Double {
        var total = 0.0
        var above = 0.0
        for (i in 0 until Combos.COUNT) {
            val w = range.weight(i)
            if (w <= 0 || Combos.mask[i] and dead != 0L) continue
            total += w
            if (strengthOf(i, strength) >= minStrength) above += w
        }
        return if (total == 0.0) 0.0 else above / total
    }

    /** Strength value such that the top [fraction] of the range's weight is at or above it. */
    private fun cutoff(range: Range, dead: Long, fraction: Double, strength: BoardStrength?): Double {
        val items = ArrayList<Pair<Double, Double>>(Combos.COUNT)
        var total = 0.0
        for (i in 0 until Combos.COUNT) {
            val w = range.weight(i)
            if (w <= 0 || Combos.mask[i] and dead != 0L) continue
            items += strengthOf(i, strength) to w
            total += w
        }
        if (items.isEmpty()) return Double.MAX_VALUE
        items.sortByDescending { it.first }
        var acc = 0.0
        for ((str, w) in items) {
            acc += w
            if (acc >= fraction * total) return str
        }
        return items.last().first
    }

    companion object {
        /** Preflop continue frequency for a player with an unopened (full) range facing a raise. */
        fun preflopDefend(role: UnopenedRole, raiseToBb: Double, isShove: Boolean): Double = when {
            isShove && role == UnopenedRole.BIG_BLIND -> (3.5 / raiseToBb).coerceIn(0.05, 0.5)
            isShove -> (1.8 / raiseToBb).coerceIn(0.03, 0.25)
            role == UnopenedRole.BIG_BLIND -> (0.62 - 0.07 * raiseToBb).coerceIn(0.15, 0.55)
            role == UnopenedRole.SMALL_BLIND -> (0.24 - 0.025 * raiseToBb).coerceIn(0.05, 0.2)
            else -> (0.16 - 0.015 * raiseToBb).coerceIn(0.04, 0.13)
        }
    }
}
