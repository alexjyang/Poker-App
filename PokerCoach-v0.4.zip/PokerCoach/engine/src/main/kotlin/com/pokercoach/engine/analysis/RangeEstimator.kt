package com.pokercoach.engine.analysis

import com.pokercoach.engine.card.Card
import com.pokercoach.engine.game.ActionType
import com.pokercoach.engine.game.HandEvent
import com.pokercoach.engine.game.Street
import com.pokercoach.engine.range.BoardStrength
import com.pokercoach.engine.range.Combos
import com.pokercoach.engine.range.PreflopRanking
import com.pokercoach.engine.range.Range

/**
 * Estimates every player's range from the actions seen so far. This is an ESTIMATE based on how
 * a reasonable regular plays, not on the bots' actual cards or code:
 *
 *  - Preflop: position-dependent "top X%" templates for opens, limps, flats, 3-bets, 4-bets,
 *    shoves and big-blind checks, multiplied together as actions accumulate.
 *  - Postflop: each combo's strength on the board at that moment ([BoardStrength]) decides how
 *    likely it is to take the observed action — bets keep strong hands, draws and some bluffs;
 *    calls keep medium hands and draws and shed air; checks shed some of the strongest hands.
 */
class RangeEstimator {

    data class Estimate(
        val ranges: Map<Int, Range>,
        val folded: Set<Int>,
        /** Players who have voluntarily acted this street (used for preflop responder logic). */
        val actedThisStreet: Set<Int>,
        val preflopRaises: Int,
        val board: List<Card>,
        val street: Street,
    )

    fun estimate(events: List<HandEvent>): Estimate {
        val start = events.first() as HandEvent.HandStarted
        val bb = start.blinds.bigBlind.toDouble()
        val seats = start.players.map { it.seat }
        val n = seats.size
        val btnIdx = seats.indexOf(start.buttonSeat)
        val bbSeat = if (n == 2) seats[(btnIdx + 1) % n] else seats[(btnIdx + 2) % n]

        val ranges = seats.associateWith { Range.full() }.toMutableMap()
        val folded = mutableSetOf<Int>()
        var acted = mutableSetOf<Int>()
        val board = mutableListOf<Card>()
        var street = Street.PREFLOP
        var raises = 0
        var limps = 0
        var strength: BoardStrength? = null

        for (e in events) {
            when (e) {
                is HandEvent.BoardDealt -> {
                    board += e.cards
                    street = e.street
                    strength = BoardStrength(board.toList())
                    acted = mutableSetOf()
                }
                is HandEvent.ActionTaken -> {
                    val seat = e.seat
                    if (e.type == ActionType.FOLD) {
                        folded += seat
                        acted += seat
                        continue
                    }
                    val r = ranges.getValue(seat)
                    ranges[seat] = if (street == Street.PREFLOP) {
                        val k = playersLeftBehind(seats, btnIdx, seat)
                        val stackBb = e.stackBefore / bb
                        val template = preflopTemplate(e, raises, limps, seat == bbSeat, n, k, stackBb, bb)
                        r.times { template(PreflopRanking.topWeightFn(Combos.classOf[it])) }
                    } else {
                        val bs = strength!!
                        val sizeFrac = (e.amountAdded - e.toCallBefore).toDouble() / (e.potBefore + e.toCallBefore).coerceAtLeast(1)
                        r.times { postflopFactor(bs, it, e.type, sizeFrac, street == Street.RIVER) }
                    }
                    if (street == Street.PREFLOP) {
                        when (e.type) {
                            ActionType.BET, ActionType.RAISE -> raises++
                            ActionType.CALL -> if (raises == 0) limps++
                            else -> {}
                        }
                    }
                    acted += seat
                }
                else -> {}
            }
        }
        return Estimate(ranges, folded, acted, raises, board.toList(), street)
    }

    /** How many players act after [seat] preflop (0 = big blind, 1 = small blind, 2 = button...). */
    private fun playersLeftBehind(seats: List<Int>, btnIdx: Int, seat: Int): Int {
        val n = seats.size
        if (n == 2) return if (seats[btnIdx] == seat) 1 else 0
        val utg = (btnIdx + 3) % n
        val idx = seats.indexOf(seat)
        val d = (idx - utg + n) % n // 0 = UTG ... n-1 = BB
        return n - 1 - d
    }

    /**
     * Returns a function from "top-X% membership" to a weight for this preflop action.
     * The argument gives, for a pct, whether the combo's class is inside the top pct.
     */
    private fun preflopTemplate(
        e: HandEvent.ActionTaken,
        raises: Int,
        limps: Int,
        isBigBlind: Boolean,
        players: Int,
        leftBehind: Int,
        stackBb: Double,
        bb: Double,
    ): (TopFn) -> Double = { top ->
        val w = when (e.type) {
            ActionType.CHECK -> 1.0 - 0.7 * top(0.12)                   // BB option: would often raise strong hands
            ActionType.CALL -> when {
                raises == 0 -> top(0.55) - 0.7 * top(0.08)              // limp: weak-to-medium, rarely premiums
                e.toCallBefore >= 15 * bb -> top(0.12)                  // calling a big bet / shove
                raises >= 2 -> top(0.10) - 0.6 * top(0.025)             // calling a 3-bet
                isBigBlind -> top(0.50) - 0.6 * top(0.06)               // big blind defense
                players == 2 -> top(0.45) - 0.6 * top(0.06)
                else -> top(0.22) - 0.65 * top(0.04)                    // flat call of an open
            }
            ActionType.BET, ActionType.RAISE -> when {
                raises == 0 -> {
                    var pct = openPct(players, leftBehind)
                    if (limps > 0) pct = minOf(pct, 0.20)               // isolation raise
                    if (e.isAllIn) pct = if (stackBb <= 12) maxOf(pct, 0.30) else pct * 0.7
                    top(pct)
                }
                raises == 1 -> if (e.isAllIn && stackBb <= 25) top(0.14) else top(0.075)
                else -> if (e.isAllIn) top(0.05) else top(0.035)
            }
            ActionType.FOLD -> 0.0
        }
        w.coerceIn(0.0, 1.0)
    }

    private fun openPct(players: Int, leftBehind: Int): Double = when {
        players == 2 -> if (leftBehind == 1) 0.80 else 0.35
        else -> when (leftBehind) {
            0 -> 0.25 // big blind raising limpers
            1 -> 0.40 // small blind
            2 -> 0.45 // button
            3 -> 0.28 // cutoff
            4 -> 0.21
            5 -> 0.17
            6 -> 0.14
            7 -> 0.12
            else -> 0.11
        }
    }

    private fun postflopFactor(bs: BoardStrength, combo: Int, type: ActionType, sizeFrac: Double, river: Boolean): Double {
        val s = bs.hs[combo]
        if (s < 0) return 0.0 // uses a board card
        val d = if (river) 0.0 else bs.draw[combo]
        return when (type) {
            ActionType.BET, ActionType.RAISE -> {
                val raise = type == ActionType.RAISE
                val valueT = 0.62 + 0.08 * sizeFrac.coerceIn(0.0, 1.5) + if (raise) 0.10 else 0.0
                when {
                    s >= valueT -> 1.0
                    d > 0 -> if (raise) 0.45 else 0.65
                    s >= valueT - 0.2 -> 0.35
                    else -> if (raise) 0.08 else 0.12 // bluffs
                }
            }
            ActionType.CALL -> when {
                s >= 0.90 -> 0.55   // would often raise
                s >= 0.40 -> 1.0
                d > 0 -> 0.9
                s >= 0.25 -> 0.35
                else -> 0.08
            }
            ActionType.CHECK -> if (s >= 0.85) 0.45 else 1.0
            ActionType.FOLD -> 0.0
        }
    }
}

/** top(pct) → weight in [0,1] of this combo's class inside the top pct of hands. */
typealias TopFn = (Double) -> Double

/** Adapter so templates can ask "is this class in the top X%?". */
fun PreflopRanking.topWeightFn(classIndex: Int): TopFn = { pct -> topWeight(classIndex, pct) }
