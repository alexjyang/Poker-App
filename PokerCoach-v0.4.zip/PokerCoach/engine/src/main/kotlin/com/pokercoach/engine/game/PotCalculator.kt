package com.pokercoach.engine.game

/** A main or side pot. */
data class Pot(val amount: Chips, val eligibleSeats: Set<Int>)

/** One player's total chips put into the pot this hand (antes, blinds and bets). */
data class Contribution(val seat: Int, val amount: Chips, val folded: Boolean)

/**
 * Pure pot arithmetic, kept separate from the state machine so it can be tested exhaustively.
 */
object PotCalculator {

    /**
     * The uncalled part of the largest contribution: if one player put in more than anyone
     * else, the excess over the second-largest contribution goes back to them.
     * Folded players' chips count toward "called" (they're dead money that was matched).
     */
    fun uncalledBet(contributions: List<Contribution>): Pair<Int, Chips>? {
        if (contributions.size < 2) return null
        val sorted = contributions.sortedByDescending { it.amount }
        val top = sorted[0]
        val second = sorted[1].amount
        return if (top.amount > second) top.seat to (top.amount - second) else null
    }

    /**
     * Builds the main pot and side pots.
     *
     * Each distinct contribution level of a live (non-folded) player caps a pot. A pot at level L
     * collects, from every player (folded or not), what they put in between the previous level
     * and L. Only live players who reached L are eligible to win it.
     *
     * Call [uncalledBet] and refund it first; otherwise the top "pot" would have one eligible
     * player and would just be that player's own money.
     */
    fun buildPots(contributions: List<Contribution>): List<Pot> {
        val total = contributions.sumOf { it.amount }
        if (total == 0L) return emptyList()
        val live = contributions.filterNot { it.folded }
        require(live.isNotEmpty()) { "At least one player must still be in the hand" }

        val levels = live.map { it.amount }.filter { it > 0 }.distinct().sorted()
        val pots = mutableListOf<Pot>()
        var previous = 0L
        for (level in levels) {
            val amount = contributions.sumOf { minOf(it.amount, level) - minOf(it.amount, previous) }
            val eligible = live.filter { it.amount >= level }.map { it.seat }.toSet()
            if (amount > 0) pots += Pot(amount, eligible)
            previous = level
        }

        // Dead money above the highest live level (only possible without an uncalled-bet refund)
        // or a hand where the only live player put nothing in: goes to the last pot / live players.
        val leftover = total - pots.sumOf { it.amount }
        if (leftover > 0) {
            if (pots.isEmpty()) pots += Pot(leftover, live.map { it.seat }.toSet())
            else pots[pots.lastIndex] = pots.last().let { it.copy(amount = it.amount + leftover) }
        }
        return pots
    }

    /**
     * Splits [amount] among [winners]. Odd chips go one at a time to winners in seating order
     * starting left of the button (the standard rule), given by [seatOrderFromButton].
     */
    fun split(amount: Chips, winners: Collection<Int>, seatOrderFromButton: List<Int>): Map<Int, Chips> {
        require(winners.isNotEmpty())
        val ordered = seatOrderFromButton.filter { it in winners }
        require(ordered.size == winners.size) { "Winners $winners not all in seat order $seatOrderFromButton" }
        val base = amount / ordered.size
        var remainder = amount % ordered.size
        return ordered.associateWith { seat ->
            base + if (remainder > 0) { remainder--; 1L } else 0L
        }
    }
}
