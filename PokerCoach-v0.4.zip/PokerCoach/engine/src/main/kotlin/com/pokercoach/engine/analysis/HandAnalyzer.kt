package com.pokercoach.engine.analysis

import com.pokercoach.engine.card.Card
import com.pokercoach.engine.card.CardMask
import com.pokercoach.engine.card.Suit
import com.pokercoach.engine.eval.HandEvaluator
import com.pokercoach.engine.game.ActionType
import com.pokercoach.engine.game.HandEngine
import com.pokercoach.engine.game.HandEvent
import com.pokercoach.engine.game.HandSnapshot
import com.pokercoach.engine.game.LegalActions
import com.pokercoach.engine.game.PlayerAction
import com.pokercoach.engine.game.Street
import com.pokercoach.engine.range.BoardStrength
import com.pokercoach.engine.range.Combos
import com.pokercoach.engine.range.PreflopRanking
import com.pokercoach.engine.range.Range
import com.pokercoach.engine.range.StrengthCategory
import com.pokercoach.engine.rng.SeededRandom
import kotlin.math.roundToLong

/**
 * Post-hand review. Replays the hand from its seed and recorded actions (so every decision
 * point is reconstructed exactly), then for each of the hero's decisions computes equity vs.
 * estimated ranges, pot odds, MDF, SPR, outs, implied odds, the EV of every sensible option,
 * a grade and a plain-language explanation.
 *
 * Deterministic: all randomness is seeded from the hand's seed and the decision index.
 * Only the hero's hole cards are ever read; opponents' cards are never used.
 *
 * [iterations] controls Monte Carlo accuracy (and time). ~6,000 is a good default on phones.
 */
class HandAnalyzer(private val iterations: Int = 6_000) {

    private val estimator = RangeEstimator()

    fun analyze(events: List<HandEvent>, heroSeat: Int, presetDeck: List<Card>? = null): HandReview {
        val start = events.first() as HandEvent.HandStarted
        val bb = start.blinds.bigBlind
        val replay = HandEngine(start.players, start.buttonSeat, start.blinds, start.seed, start.handNumber, presetDeck)
        val decisions = mutableListOf<Decision>()

        for (a in events.filterIsInstance<HandEvent.ActionTaken>()) {
            check(replay.actorSeat == a.seat) { "Replay diverged at seat ${a.seat}" }
            if (a.seat == heroSeat) {
                decisions += analyzeDecision(replay, a, heroSeat, decisions.size, start.seed)
            }
            replay.act(toAction(a))
        }

        val biggest = decisions.filter { it.grade >= Grade.INACCURACY }.maxByOrNull { it.evLossBb }
        val ended = events.lastOrNull() as? HandEvent.HandEnded
        return HandReview(
            handNumber = start.handNumber,
            seed = start.seed,
            bigBlind = bb,
            heroSeat = heroSeat,
            decisions = decisions,
            totalEvLossBb = decisions.sumOf { it.evLossBb },
            biggestMistake = biggest,
            takeaway = Explainer.takeaway(biggest, decisions),
            heroNetBb = (ended?.netResults?.get(heroSeat) ?: 0L).toDouble() / bb,
        )
    }

    private fun toAction(a: HandEvent.ActionTaken): PlayerAction = when (a.type) {
        ActionType.FOLD -> PlayerAction.Fold
        ActionType.CHECK -> PlayerAction.Check
        ActionType.CALL -> PlayerAction.Call
        ActionType.BET, ActionType.RAISE -> PlayerAction.BetOrRaise(a.streetTotal)
    }

    // ------------------------------------------------------------------ one decision

    private fun analyzeDecision(replay: HandEngine, a: HandEvent.ActionTaken, heroSeat: Int, index: Int, handSeed: Long): Decision {
        val snap = replay.snapshot()
        val legal = replay.legalActions()!!
        val bb = snap.blinds.bigBlind
        val hero = snap.seat(heroSeat)
        val heroCards = hero.holeCards!!
        val board = snap.board
        val street = snap.street
        val heroMask = CardMask.of(heroCards)
        val boardMask = CardMask.of(board)
        val dead = heroMask or boardMask
        val est = estimator.estimate(replay.events)
        val seed = SeededRandom.derive(handSeed, 1_000L + index)

        // --- opponents
        val liveOpps = snap.seats.filter { it.seat != heroSeat && !it.folded }
        val opponents = liveOpps.map { o ->
            val acted = street != Street.PREFLOP || o.seat in est.actedThisStreet
            val role = if (acted) null else when (o.seat) {
                snap.bigBlindSeat -> UnopenedRole.BIG_BLIND
                snap.smallBlindSeat -> UnopenedRole.SMALL_BLIND
                else -> UnopenedRole.OTHER
            }
            val raw = est.ranges.getValue(o.seat)
            val usable = if (raw.totalWeight(dead) > 1e-9) raw else Range.full()
            Opponent(
                seat = o.seat,
                range = usable,
                streetCommit = o.streetCommit,
                stackBehind = o.stack,
                inPot = acted || o.seat == snap.bigBlindSeat,
                unopenedRole = role,
            )
        }
        val heroIp = heroInPosition(snap, heroSeat)
        val situation = Situation(
            hero = heroCards, board = board, street = street, pot = snap.pot,
            currentBet = snap.currentBet, heroCommit = hero.streetCommit, heroStack = hero.stack,
            bigBlind = bb, opponents = opponents, heroInPosition = heroIp,
        )

        // --- options and EVs
        val options = buildOptions(snap, legal, hero.streetCommit, hero.stack, a, opponents)
        val chosenOption = matchChosen(options, a, legal)
        val results = EvModel(iterations).evaluate(situation, options, seed)
        val bestResult = results.maxWith(compareBy<OptionResult> { it.evChips }.thenBy { if (it.option == chosenOption) 1 else 0 })
        val chosenResult = results.first { it.option == chosenOption }
        val lossChips = (bestResult.evChips - chosenResult.evChips).coerceAtLeast(0.0)
        var grade = Grade.of(lossChips, snap.pot, bb, street == Street.PREFLOP)
        // Folding when you could check for free is always a real mistake, whatever the pot size.
        if (chosenOption.kind == OptionKind.FOLD && legal.canCheck && grade < Grade.MISTAKE) grade = Grade.MISTAKE
        val evals = results.map { r ->
            OptionEval(
                label = r.option.label, kind = r.option.kind, to = r.option.to,
                evBb = r.evChips / bb, foldEquity = r.foldEquity, equityWhenCalled = r.equityWhenCalled,
                isChosen = r.option == chosenOption, isBest = r.option == bestResult.option,
            )
        }

        // --- equity vs the players in the pot
        val inPot = opponents.filter { it.inPot }
        val equityRanges = if (inPot.isNotEmpty()) inPot.map { it.range } else listOf(Range.full())
        val equity = EquityCalculator.vsRanges(heroCards, board, equityRanges, iterations * 2, SeededRandom(seed xor 0x5EED))
        val equityVs = when {
            inPot.isEmpty() -> "one random hand"
            inPot.size == 1 -> "the estimated range of the ${if (inPot[0].unopenedRole == UnopenedRole.BIG_BLIND) "big blind (any two cards)" else "opponent"}"
            else -> "${inPot.size} opponents' estimated ranges"
        }

        // --- exact arithmetic
        val toCall = legal.toCall
        val requiredEquity = if (toCall > 0) toCall.toDouble() / (snap.pot + toCall) else null
        val mdf = if (street != Street.PREFLOP && toCall > 0) (snap.pot - toCall).toDouble() / snap.pot else null
        val maxOppStack = liveOpps.maxOfOrNull { it.stack } ?: 0L
        val effStack = minOf(hero.stack, maxOppStack)
        val spr = if (street != Street.PREFLOP && snap.pot > 0) effStack.toDouble() / snap.pot else null

        // --- outs and implied odds
        val outs = if ((street == Street.FLOP || street == Street.TURN) && equity.equity < 0.5 && inPot.isNotEmpty()) {
            computeOuts(heroMask, board, inPot.map { it.range })
        } else null
        val impliedNeeded = if (toCall > 0 && street != Street.RIVER && equity.equity > 0.02) {
            val direct = equity.equity * (snap.pot + toCall) - toCall
            if (direct < 0) ((toCall - equity.equity * (snap.pot + toCall)) / equity.equity) / bb else null
        } else null

        // --- ranges, advantage, blockers
        val strength = if (board.size >= 3) BoardStrength(board) else null
        val villainViews = opponents.filter { it.inPot }.map { o ->
            VillainView(o.seat, o.range.without(dead), o.range.fractionOfAllHands(), breakdown(o.range, dead, strength))
        }
        val heroRange = est.ranges[heroSeat]
        val primary = inPot.maxByOrNull { it.streetCommit }
        var rangeAdv: Double? = null
        var nutHero: Double? = null
        var nutVillain: Double? = null
        if (strength != null && primary != null && heroRange != null) {
            rangeAdv = EquityCalculator.rangeVsRange(heroRange, primary.range, board, 2_000, SeededRandom(seed xor 0xADL))
            nutHero = nutShare(heroRange, boardMask, strength)
            nutVillain = nutShare(primary.range, boardMask, strength)
        }
        val blocker = blockerNote(heroCards, board, primary?.range, strength)
        val gto = gtoNote(street, toCall, snap.pot, villainViews.firstOrNull(), strength)

        val chosenEval = evals.first { it.isChosen }
        val bestEval = evals.first { it.isBest }
        val facts = Facts(
            street = street, chosen = chosenEval, best = bestEval, options = evals, grade = grade,
            evLossBb = lossChips / bb, equity = equity.equity, equityExact = equity.exact,
            equityMethod = equity.method, equityVs = equityVs, requiredEquity = requiredEquity,
            canCheck = legal.canCheck, potBb = snap.pot.toDouble() / bb, toCallBb = toCall.toDouble() / bb,
            mdf = mdf, spr = spr, outs = outs, impliedOddsNeededBb = impliedNeeded,
            effectiveStackBb = effStack.toDouble() / bb, villains = villainViews,
            rangeAdvantage = rangeAdv, nutShareHero = nutHero, nutShareVillain = nutVillain,
            blockerNote = blocker, gtoNote = gto, inPosition = heroIp, multiway = inPot.size > 1,
        )
        val (beginner, advanced, concepts) = Explainer.explain(facts)

        return Decision(
            index = index, street = street, board = board, heroCards = heroCards,
            actionLabel = chosenEval.label,
            potBb = snap.pot.toDouble() / bb, toCallBb = toCall.toDouble() / bb,
            effectiveStackBb = effStack.toDouble() / bb,
            requiredEquity = requiredEquity, mdf = mdf, spr = spr,
            equity = equity, equityVs = equityVs,
            options = evals, chosen = chosenEval, best = bestEval,
            evLossBb = lossChips / bb, grade = grade,
            outs = outs, impliedOddsNeededBb = impliedNeeded,
            villains = villainViews, heroRange = heroRange?.without(boardMask),
            rangeAdvantage = rangeAdv, nutShareHero = nutHero, nutShareVillain = nutVillain,
            blockerNote = blocker, gtoNote = gto,
            beginnerText = beginner, advancedPoints = advanced, concepts = concepts,
        )
    }

    // ------------------------------------------------------------------ helpers

    private fun heroInPosition(snap: HandSnapshot, heroSeat: Int): Boolean {
        val seats = snap.seats.map { it.seat }
        val n = seats.size
        val btn = seats.indexOf(snap.buttonSeat)
        val order = List(n) { seats[(btn + 1 + it) % n] } // postflop acting order
        val live = order.filter { s -> s == heroSeat || !snap.seat(s).folded }
        return live.lastOrNull() == heroSeat
    }

    private fun buildOptions(
        snap: HandSnapshot,
        legal: LegalActions,
        heroCommit: Long,
        heroStack: Long,
        chosen: HandEvent.ActionTaken,
        opponents: List<Opponent>,
    ): List<Option> {
        val bb = snap.blinds.bigBlind
        val out = mutableListOf<Option>()
        if (!legal.canCheck || chosen.type == ActionType.FOLD) out += Option(OptionKind.FOLD, 0, "Fold")
        out += if (legal.canCheck) Option(OptionKind.CHECK, 0, "Check")
        else Option(OptionKind.CALL, heroCommit + legal.toCall, if (legal.callIsAllIn) "Call all-in" else "Call")

        if (legal.canRaise) {
            val pot = snap.pot
            val maxTo = legal.maxRaiseTo
            val effBb = minOf(heroCommit + heroStack, opponents.maxOfOrNull { it.streetCommit + it.stackBehind } ?: 0L).toDouble() / bb
            val targets = mutableListOf<Pair<Long, String?>>()
            if (snap.street == Street.PREFLOP) {
                if (snap.currentBet <= bb) {
                    val limpers = opponents.count { it.streetCommit == bb && it.seat != snap.bigBlindSeat }
                    targets += (bb * 5 / 2 + limpers * bb) to null
                    targets += (bb * 3 + limpers * bb) to null
                    if (effBb <= 25) targets += maxTo to null
                } else {
                    targets += snap.currentBet * 3 to null
                    targets += snap.currentBet * 4 to null
                    if (effBb <= 40) targets += maxTo to null
                }
            } else if (legal.isBet) {
                targets += (pot / 3.0).roundToLong() to "Bet ⅓ pot"
                targets += (pot * 2 / 3.0).roundToLong() to "Bet ⅔ pot"
                targets += pot to "Bet pot"
                if (effBb * bb <= pot * 3.0) targets += maxTo to null
            } else {
                targets += (snap.currentBet * 2.5).roundToLong() to null
                targets += (snap.currentBet * 3.5).roundToLong() to null
                if (effBb * bb <= pot * 4.0) targets += maxTo to null
            }
            if (chosen.type == ActionType.BET || chosen.type == ActionType.RAISE) targets += chosen.streetTotal to null

            val seen = mutableSetOf<Long>()
            for ((raw, label) in targets) {
                var to = raw.coerceIn(legal.minRaiseTo, maxTo)
                if (to >= maxTo * 0.9) to = maxTo
                if (chosen.type == ActionType.BET || chosen.type == ActionType.RAISE) {
                    if (raw == chosen.streetTotal) to = chosen.streetTotal // keep the hero's exact size
                }
                if (!seen.add(to)) continue
                val kind = when {
                    to == maxTo -> OptionKind.ALL_IN
                    legal.isBet -> OptionKind.BET
                    else -> OptionKind.RAISE
                }
                val text = when {
                    kind == OptionKind.ALL_IN -> "All-in"
                    label != null && to == raw.coerceIn(legal.minRaiseTo, maxTo) -> label
                    kind == OptionKind.BET -> "Bet ${(to * 100.0 / pot).roundToLong()}% pot"
                    snap.street == Street.PREFLOP && snap.currentBet <= bb -> "Raise to ${fmtBb(to, bb)}"
                    else -> "Raise to ${"%.1f".format(to.toDouble() / snap.currentBet)}x"
                }
                out += Option(kind, to, text)
            }
        }
        return out
    }

    private fun fmtBb(chips: Long, bb: Long): String {
        val v = chips.toDouble() / bb
        return if (v == v.toLong().toDouble()) "${v.toLong()} BB" else "%.1f BB".format(v)
    }

    private fun matchChosen(options: List<Option>, a: HandEvent.ActionTaken, legal: LegalActions): Option = when (a.type) {
        ActionType.FOLD -> options.first { it.kind == OptionKind.FOLD }
        ActionType.CHECK -> options.first { it.kind == OptionKind.CHECK }
        ActionType.CALL -> options.first { it.kind == OptionKind.CALL }
        ActionType.BET, ActionType.RAISE -> options.first {
            it.kind in setOf(OptionKind.BET, OptionKind.RAISE, OptionKind.ALL_IN) &&
                (it.to == a.streetTotal || (a.streetTotal == legal.maxRaiseTo && it.kind == OptionKind.ALL_IN))
        }
    }

    /**
     * Outs: unseen cards after which hero goes from behind (winning < 50% of the range's
     * weight right now) to ahead of at least 70% of every opponent's range.
     */
    internal fun computeOuts(heroMask: Long, board: List<Card>, ranges: List<Range>): OutsInfo? {
        val boardMask = CardMask.of(board)
        fun shareVs(range: Range, b: Long): Double {
            val hv = HandEvaluator.evaluateMask(heroMask or b)
            var total = 0.0
            var won = 0.0
            for (c in 0 until Combos.COUNT) {
                val w = range.weight(c)
                if (w <= 0 || Combos.mask[c] and (heroMask or b) != 0L) continue
                val v = HandEvaluator.evaluateMask(Combos.mask[c] or b)
                total += w
                won += w * when { hv > v -> 1.0; hv == v -> 0.5; else -> 0.0 }
            }
            return if (total == 0.0) 1.0 else won / total
        }
        val now = ranges.minOf { shareVs(it, boardMask) }
        if (now >= 0.5) return null
        val outs = mutableListOf<Card>()
        var unseen = 0
        for (id in 0 until 52) {
            val bit = 1L shl id
            if ((heroMask or boardMask) and bit != 0L) continue
            unseen++
            if (ranges.all { shareVs(it, boardMask or bit) >= 0.7 }) outs += Card(id)
        }
        if (outs.isEmpty()) return null
        val n = outs.size.toDouble()
        val next = n / unseen
        val byRiver = if (board.size == 3) {
            val miss = (unseen - n) * (unseen - n - 1) / (unseen.toDouble() * (unseen - 1))
            1 - miss
        } else null
        return OutsInfo(outs.size, outs.sortedDescending(), unseen, next, byRiver)
    }

    private fun breakdown(range: Range, dead: Long, strength: BoardStrength?): List<Pair<String, Double>> {
        val totals = LinkedHashMap<String, Double>()
        var total = 0.0
        for (i in 0 until Combos.COUNT) {
            val w = range.weight(i)
            if (w <= 0 || Combos.mask[i] and dead != 0L) continue
            val label = if (strength != null) strength.category(i).label else {
                val s = PreflopRanking.strength(Combos.classOf[i])
                when {
                    s >= 0.95 -> "Premium"
                    s >= 0.85 -> "Strong"
                    s >= 0.60 -> "Playable"
                    else -> "Weak"
                }
            }
            totals[label] = (totals[label] ?: 0.0) + w
            total += w
        }
        if (total == 0.0) return emptyList()
        val order = if (strength != null) StrengthCategory.entries.map { it.label } else listOf("Premium", "Strong", "Playable", "Weak")
        return order.mapNotNull { l -> totals[l]?.let { l to it / total } }
    }

    private fun nutShare(range: Range, boardMask: Long, strength: BoardStrength): Double? {
        var total = 0.0
        var nuts = 0.0
        for (i in 0 until Combos.COUNT) {
            val w = range.weight(i)
            if (w <= 0 || Combos.mask[i] and boardMask != 0L) continue
            total += w
            if (strength.hs[i] >= 0.9) nuts += w
        }
        return if (total == 0.0) null else nuts / total
    }

    private fun blockerNote(hero: List<Card>, board: List<Card>, villain: Range?, strength: BoardStrength?): String? {
        // Nut flush blocker.
        if (board.size >= 3) {
            val suitCounts = board.groupingBy { it.suit }.eachCount()
            val flushSuit: Suit? = suitCounts.entries.firstOrNull { it.value >= 3 }?.key
            if (flushSuit != null) {
                val ace = hero.firstOrNull { it.suit == flushSuit && it.rank.ordinal == 12 }
                val heroSuited = hero.count { it.suit == flushSuit }
                if (ace != null && heroSuited == 1) {
                    return "Blocker: you hold $ace, so they can't have the nut flush."
                }
            }
        }
        if (villain == null) return null
        // Share of their strongest combos that your cards make impossible.
        val heroMask = CardMask.of(hero)
        val boardMask = CardMask.of(board)
        var value = 0.0
        var blocked = 0.0
        for (i in 0 until Combos.COUNT) {
            val w = villain.weight(i)
            if (w <= 0 || Combos.mask[i] and boardMask != 0L) continue
            val strong = if (strength != null) strength.hs[i] >= 0.8 else PreflopRanking.strength(Combos.classOf[i]) >= 0.95
            if (!strong) continue
            value += w
            if (Combos.mask[i] and heroMask != 0L) blocked += w
        }
        if (value == 0.0) return null
        val share = blocked / value
        return if (share >= 0.2) "Blockers: your cards remove about ${(share * 100).toInt()}% of their strongest combinations." else null
    }

    private fun gtoNote(street: Street, toCall: Long, pot: Long, villain: VillainView?, strength: BoardStrength?): String? {
        if (street != Street.RIVER || toCall <= 0 || villain == null || strength == null) return null
        val bet = toCall.toDouble()
        val before = (pot - toCall).toDouble()
        val balancedBluffs = bet / (before + 2 * bet)
        val air = villain.breakdown.firstOrNull { it.first == StrengthCategory.AIR.label }?.second ?: 0.0
        val verdict = when {
            air < balancedBluffs * 0.7 -> "they seem to under-bluff, so folding more than MDF is the exploitative adjustment"
            air > balancedBluffs * 1.3 -> "they seem to over-bluff, so calling more often is the exploitative adjustment"
            else -> "their estimate is close to balanced, so defending near MDF is reasonable"
        }
        return "GTO vs exploit: a balanced river bet of this size contains about ${(balancedBluffs * 100).toInt()}% bluffs; " +
            "the estimated range has ${(air * 100).toInt()}% weak hands — $verdict."
    }
}
