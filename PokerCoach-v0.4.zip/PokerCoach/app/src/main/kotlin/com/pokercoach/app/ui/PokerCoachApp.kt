package com.pokercoach.app.ui

import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.lifecycle.viewmodel.compose.viewModel
import com.pokercoach.app.ui.home.HomeScreen
import com.pokercoach.app.ui.review.ReviewScreen
import com.pokercoach.app.ui.table.TableScreen
import com.pokercoach.app.ui.table.TableViewModel

private enum class Screen { HOME, TABLE, REVIEW }

/**
 * Three screens (lobby, table, hand review), so a saveable enum is enough for now.
 * Stage 5 (stats, history, replayer) introduces Navigation.
 */
@Composable
fun PokerCoachApp() {
    val tableViewModel: TableViewModel = viewModel()
    var screen by rememberSaveable { mutableStateOf(Screen.HOME) }
    var reviewHand by rememberSaveable { mutableLongStateOf(0L) }

    when (screen) {
        Screen.HOME -> HomeScreen(
            onStart = { config ->
                tableViewModel.start(config)
                screen = Screen.TABLE
            },
        )
        Screen.TABLE -> TableScreen(
            viewModel = tableViewModel,
            onLeave = {
                tableViewModel.leave()
                screen = Screen.HOME
            },
            onReview = { hand ->
                reviewHand = hand
                screen = Screen.REVIEW
            },
        )
        Screen.REVIEW -> {
            val review = tableViewModel.reviewFor(reviewHand)
            if (review == null) {
                LaunchedEffect(Unit) { screen = Screen.TABLE }
            } else {
                ReviewScreen(
                    review = review,
                    seatNames = tableViewModel.seatNames(),
                    onBack = { screen = Screen.TABLE },
                )
            }
        }
    }
}
