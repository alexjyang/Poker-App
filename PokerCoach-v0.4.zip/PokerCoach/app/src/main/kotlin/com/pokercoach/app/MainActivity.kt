package com.pokercoach.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import com.pokercoach.app.ui.PokerCoachApp
import com.pokercoach.app.ui.theme.PokerCoachTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        enableEdgeToEdge()
        super.onCreate(savedInstanceState)
        setContent {
            PokerCoachTheme {
                PokerCoachApp()
            }
        }
    }
}
