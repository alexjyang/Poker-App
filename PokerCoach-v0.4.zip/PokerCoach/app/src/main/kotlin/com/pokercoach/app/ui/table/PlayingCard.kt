package com.pokercoach.app.ui.table

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.pokercoach.app.ui.theme.TableColors
import com.pokercoach.engine.card.Card
import com.pokercoach.engine.card.Rank
import com.pokercoach.engine.card.Suit

/**
 * A single card. Face up when [card] is non-null, otherwise the back is drawn.
 * Cards fade and scale in when they first appear (the "deal" animation).
 */
@Composable
fun PlayingCard(
    card: Card?,
    width: Dp,
    modifier: Modifier = Modifier,
    dimmed: Boolean = false,
) {
    val height = width * 1.4f
    val corner = RoundedCornerShape(width * 0.14f)
    val appear = remember(card) { Animatable(0f) }
    LaunchedEffect(card) { appear.animateTo(1f, tween(durationMillis = 220)) }

    Box(
        modifier
            .size(width, height)
            .graphicsLayer {
                val s = 0.85f + 0.15f * appear.value
                scaleX = s
                scaleY = s
                alpha = appear.value * (if (dimmed) 0.45f else 1f)
            }
            .shadow(3.dp, corner)
            .clip(corner),
    ) {
        if (card != null) CardFace(card, width) else CardBack(width)
    }
}

@Composable
private fun CardFace(card: Card, width: Dp) {
    val red = card.suit == Suit.HEARTS || card.suit == Suit.DIAMONDS
    val color = if (red) TableColors.CardRed else TableColors.CardBlack
    val rankText = if (card.rank == Rank.TEN) "10" else card.rank.symbol.toString()
    // U+FE0E forces the text (not emoji) presentation of the suit symbol.
    val suitText = "${card.suit.glyph}\uFE0E"
    val rankSize = (width.value * 0.44f).sp
    val suitSize = (width.value * 0.52f).sp
    Box(
        Modifier
            .size(width, width * 1.4f)
            .background(Color.White)
            .border(0.5.dp, Color(0x33000000), RoundedCornerShape(width * 0.14f)),
    ) {
        Text(
            text = rankText,
            color = color,
            fontSize = rankSize,
            lineHeight = rankSize,
            fontWeight = FontWeight.Bold,
            letterSpacing = if (rankText.length > 1) (-1).sp else 0.sp,
            modifier = Modifier
                .align(Alignment.TopStart)
                .padding(start = width * 0.08f, top = width * 0.04f),
        )
        Text(
            text = suitText,
            color = color,
            fontSize = suitSize,
            lineHeight = suitSize,
            modifier = Modifier
                .align(Alignment.BottomEnd)
                .padding(end = width * 0.08f, bottom = width * 0.04f),
        )
    }
}

@Composable
private fun CardBack(width: Dp) {
    Box(
        Modifier
            .size(width, width * 1.4f)
            .background(Brush.linearGradient(listOf(TableColors.CardBackTop, TableColors.CardBackBottom)))
            .padding(width * 0.1f)
            .border(1.dp, Color(0x66FFFFFF), RoundedCornerShape(width * 0.08f)),
    )
}

/** An empty board slot outline. */
@Composable
fun CardSlot(width: Dp, modifier: Modifier = Modifier) {
    Box(
        modifier
            .size(width, width * 1.4f)
            .border(1.dp, Color(0x33FFFFFF), RoundedCornerShape(width * 0.14f)),
    )
}
