package com.pokercoach.app.ui.table

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawingPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle

@Composable
fun TableScreen(viewModel: TableViewModel, onLeave: () -> Unit, onReview: (Long) -> Unit) {
    val state by viewModel.state.collectAsStateWithLifecycle()
    var confirmLeave by remember { mutableStateOf(false) }
    val haptics = LocalHapticFeedback.current

    // The app was restarted by the system and the game is gone: go back to the lobby.
    LaunchedEffect(state.active) { if (!state.active) onLeave() }

    // Haptic nudge when it's your turn.
    val heroTurn = state.heroLegal != null
    LaunchedEffect(heroTurn) {
        if (heroTurn) haptics.performHapticFeedback(HapticFeedbackType.LongPress)
    }

    val requestLeave: () -> Unit = {
        if (state.handInProgress) {
            confirmLeave = true
        } else {
            onLeave()
        }
    }
    BackHandler(onBack = requestLeave)

    BoxWithConstraints(
        Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .safeDrawingPadding(),
    ) {
        if (maxWidth > maxHeight) {
            // Landscape: table on the left, controls on the right.
            Row(Modifier.fillMaxSize()) {
                Column(
                    Modifier
                        .weight(1f)
                        .fillMaxHeight(),
                ) {
                    TopBar(state, onBack = requestLeave, onToggleStyles = viewModel::toggleStyleLabels)
                    TableArea(state, Modifier.weight(1f).fillMaxWidth())
                }
                ControlPanel(
                    state = state,
                    viewModel = viewModel,
                    onReview = onReview,
                    modifier = Modifier
                        .width(320.dp)
                        .fillMaxHeight(),
                )
            }
        } else {
            // Portrait (default): controls at the bottom, within thumb reach.
            Column(Modifier.fillMaxSize()) {
                TopBar(state, onBack = requestLeave, onToggleStyles = viewModel::toggleStyleLabels)
                TableArea(state, Modifier.weight(1f).fillMaxWidth())
                ControlPanel(state = state, viewModel = viewModel, onReview = onReview, modifier = Modifier.fillMaxWidth())
            }
        }
    }

    if (confirmLeave) {
        AlertDialog(
            onDismissRequest = { confirmLeave = false },
            title = { Text("Leave the table?") },
            text = { Text("A hand is in progress. If you leave now, this game ends.") },
            confirmButton = {
                TextButton(onClick = { confirmLeave = false; onLeave() }) { Text("Leave") }
            },
            dismissButton = {
                TextButton(onClick = { confirmLeave = false }) { Text("Keep playing") }
            },
        )
    }

    state.sessionOver?.let { over ->
        AlertDialog(
            onDismissRequest = {},
            title = { Text(over.title) },
            text = { if (over.message.isNotEmpty()) Text(over.message) },
            confirmButton = { TextButton(onClick = { viewModel.restart() }) { Text("Play again") } },
            dismissButton = { TextButton(onClick = onLeave) { Text("Lobby") } },
        )
    }
}

@Composable
private fun TopBar(state: TableUiState, onBack: () -> Unit, onToggleStyles: () -> Unit) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 4.dp),
    ) {
        TextButton(onClick = onBack) { Text("‹ Lobby") }
        TextButton(onClick = onToggleStyles) { Text(if (state.showStyles) "Hide styles" else "Show styles") }
        Column(
            horizontalAlignment = Alignment.End,
            modifier = Modifier
                .weight(1f)
                .padding(end = 12.dp),
        ) {
            Text(
                "${state.modeLabel} · ${state.blindsLabel}",
                style = MaterialTheme.typography.labelLarge,
                fontWeight = FontWeight.SemiBold,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
            if (state.handNumber > 0) {
                Text(
                    "Hand #${state.handNumber}",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
        }
    }
}

@Composable
private fun ControlPanel(
    state: TableUiState,
    viewModel: TableViewModel,
    onReview: (Long) -> Unit,
    modifier: Modifier = Modifier,
) {
    Surface(
        modifier = modifier,
        tonalElevation = 3.dp,
        shape = RoundedCornerShape(topStart = 20.dp, topEnd = 20.dp),
    ) {
        Box(
            Modifier
                .heightIn(min = 150.dp)
                .verticalScroll(rememberScrollState()),
            contentAlignment = Alignment.BottomCenter,
        ) {
            Column {
                state.error?.let { msg ->
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.padding(start = 16.dp, end = 4.dp, top = 8.dp),
                    ) {
                        Text(
                            msg,
                            color = MaterialTheme.colorScheme.error,
                            style = MaterialTheme.typography.bodySmall,
                            modifier = Modifier.weight(1f),
                        )
                        TextButton(onClick = viewModel::dismissError) { Text("OK") }
                    }
                }
                when {
                    state.heroLegal != null -> ActionBar(state, onAction = viewModel::act)
                    state.result != null -> ResultPanel(
                        result = state.result,
                        review = state.review,
                        onNext = viewModel::nextHand,
                        onReview = onReview,
                    )
                    else -> WaitingPanel(state.actingName)
                }
            }
        }
    }
}
