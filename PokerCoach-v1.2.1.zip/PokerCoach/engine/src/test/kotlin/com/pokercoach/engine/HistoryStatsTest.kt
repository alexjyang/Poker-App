package com.pokercoach.engine

import com.pokercoach.engine.analysis.Grade
import com.pokercoach.engine.analysis.HandAnalyzer
import com.pokercoach.engine.analysis.OptionKind
import com.pokercoach.engine.analysis.Spot
import com.pokercoach.engine.bot.BotProfile
import com.pokercoach.engine.bot.BotStyle
import com.pokercoach.engine.bot.ProfileBot
import com.pokercoach.engine.game.Blinds
import com.pokercoach.engine.game.HandEngine
import com.pokercoach.engine.game.HandEvent
import com.pokercoach.engine.game.PlayerAction.BetOrRaise
import com.pokercoach.engine.game.PlayerAction.Call
import com.pokercoach.engine.game.PlayerAction.Check
import com.pokercoach.engine.game.PlayerAction.Fold
import com.pokercoach.engine.game.SeatedPlayer
import com.pokercoach.engine.history.HandHistoryCodec
import com.pokercoach.engine.replay.HandReplay
import com.pokercoach.engine.rng.SeededRandom
import com.pokercoach.engine.stats.DecisionRecord
import com.pokercoach.engine.stats.HandStats
import com.pokercoach.engine.stats.LeakFinder
import com.pokercoach.engine.stats.StatsSummary
import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertTrue

class HistoryStatsTest {

    private fun players(vararg stacks: Long) = stacks.mapIndexed { i, s -> SeatedPlayer(i, "p$i", "P$i", s) }

    private fun botHand(i: Int): HandEngine {
        val rng = SeededRandom(i.toLong())
        val n = 2 + rng.nextInt(8)
        val ps = (0 until n).map { SeatedPlayer(it, "id|$it;x,y:z\\", "Name, $it", 50L + rng.nextInt(2000)) }
        val bots = (0 until n).associateWith { ProfileBot(BotProfile.preset(BotStyle.entries[it % 5]), i * 10L + it, 100, solverBudgetMs = 0) }
        val h = HandEngine(ps, rng.nextInt(n), Blinds(1, 2, if (i % 3 == 0) 1 else 0), seed = i.toLong())
        while (!h.isComplete) { val s = h.actorSeat!!; h.act(bots.getValue(s).decide(h.snapshotFor(s), s, h.publicHistory(s))) }
        return h
    }

    @Test
    fun `codec round-trips every event exactly, including awkward names`() {
        repeat(300) { i ->
            val events = botHand(i).events
            val text = HandHistoryCodec.encode(events)
            assertEquals(events, HandHistoryCodec.decode(text), "hand $i")
        }
    }

    @Test
    fun `stored hands can be re-analyzed identically`() {
        val h = botHand(7)
        val decoded = HandHistoryCodec.decode(HandHistoryCodec.encode(h.events))
        fun sig(e: List<HandEvent>) = HandAnalyzer(1_000).analyze(e, 0).decisions.map { it.grade to it.evLossBb }
        assertEquals(sig(h.events), sig(decoded))
    }

    @Test
    fun `stats for a scripted hand`() {
        // Hero = seat 0 on the button (6-max seats 0..3 here: button 0, SB 1, BB 2, UTG 3).
        val h = HandEngine(players(1000, 1000, 1000, 1000), 0, Blinds(5, 10), seed = 5)
        h.act(BetOrRaise(30)) // UTG opens
        h.act(BetOrRaise(90)) // hero 3-bets
        h.act(Fold); h.act(Fold)
        h.act(Call)           // UTG calls
        // Flop: UTG checks, hero c-bets, UTG folds.
        h.act(Check); h.act(BetOrRaise(100)); h.act(Fold)
        val s = HandStats.extract(h.events, 0)!!
        assertTrue(s.vpip && s.pfr && s.threeBetOpp && s.threeBet && s.sawFlop)
        assertTrue(s.cbetOpp && s.cbet && !s.wentToShowdown)
        assertEquals(1, s.postflopAggressive)
        val v = HandStats.extract(h.events, 3)!!
        assertTrue(v.vpip && v.pfr && !v.threeBetOpp && v.foldToCbetOpp && v.foldToCbet)
        assertEquals(-90L, v.netChips)
    }

    @Test
    fun `summary uses correct denominators`() {
        val lines = (0 until 400).mapNotNull { HandStats.extract(botHand(it).events, 0) }
        val s = StatsSummary.of(lines)
        assertEquals(lines.size, s.hands)
        assertEquals(lines.count { it.threeBetOpp }, s.threeBet.chances)
        assertEquals(lines.count { it.sawFlop }, s.wtsd.chances)
        assertTrue(s.pfr.value!! <= s.vpip.value!!)
        assertEquals(lines.sumOf { it.netBb } / lines.size * 100, s.bbPer100!!, 1e-9)
    }

    @Test
    fun `leak finder groups repeated mistakes by spot and ignores one-offs`() {
        val d = mutableListOf<DecisionRecord>()
        repeat(4) { d += DecisionRecord(100L + it, Spot.RIVER_FACING_BET, OptionKind.CALL, OptionKind.FOLD, Grade.MISTAKE, 3.0 + it) }
        repeat(6) { d += DecisionRecord(200L + it, Spot.RIVER_FACING_BET, OptionKind.FOLD, OptionKind.FOLD, Grade.BEST, 0.0) }
        d += DecisionRecord(300, Spot.FLOP_CBET, OptionKind.CHECK, OptionKind.BET, Grade.BLUNDER, 9.0)
        val leaks = LeakFinder.find(emptyList(), d)
        assertEquals(1, leaks.size)
        val leak = leaks.single()
        assertTrue(leak.title.contains("call too often") && leak.title.contains("river bet"), leak.title)
        assertEquals(listOf(103L, 102L, 101L, 100L), leak.exampleHands)
        assertEquals(18.0, leak.costBb, 1e-9)
        assertTrue(leak.detail.startsWith("4 of 10"))
    }

    @Test
    fun `stat leaks need a real sample`() {
        val folder = (0 until 60).mapNotNull { i -> HandStats.extract(botHand(i).events, 0)?.copy(vpip = true, pfr = false) }
            .mapIndexed { i, l -> i.toLong() to l }
        val leaks = LeakFinder.find(folder, emptyList())
        assertTrue(leaks.any { it.title == "You play too many hands" })
        assertTrue(leaks.any { it.title == "You limp or call too much preflop" })
        assertTrue(LeakFinder.find(folder.take(10), emptyList()).isEmpty(), "10 hands is too few")
    }

    @Test
    fun `replay frames end in the real final state`() {
        repeat(40) { i ->
            val h = botHand(i)
            val frames = HandReplay.frames(h.events, 0, { "Seat $it" })
            val end = h.events.last() as HandEvent.HandEnded
            assertEquals(end.finalStacks, frames.last().snapshot.seats.associate { it.seat to it.stack })
            assertEquals(h.board.size, frames.last().boardCount)
            val actions = h.events.count { it is HandEvent.ActionTaken }
            assertEquals(actions + 2 + when (h.board.size) { 0 -> 0; 3 -> 1; 4 -> 2; else -> 3 }, frames.size)
        }
    }

    @Test
    fun `spots are classified`() {
        val h = HandEngine(players(1000, 1000, 1000, 1000), 0, Blinds(5, 10), seed = 5)
        assertEquals(Spot.PREFLOP_OPEN, Spot.classify(h.events, 3, h.street, 10, 2))
        h.act(BetOrRaise(30))
        assertEquals(Spot.PREFLOP_VS_OPEN, Spot.classify(h.events, 0, h.street, 30, 2))
        assertEquals(Spot.PREFLOP_BB_DEFENSE, Spot.classify(h.events, 2, h.street, 20, 2))
        h.act(Fold); h.act(Fold); h.act(Call)
        assertEquals(Spot.FLOP_BET_OPPORTUNITY, Spot.classify(h.events, 2, h.street, 0, 2))
        assertEquals(Spot.FLOP_CBET, Spot.classify(h.events, 3, h.street, 0, 2))
    }
}
