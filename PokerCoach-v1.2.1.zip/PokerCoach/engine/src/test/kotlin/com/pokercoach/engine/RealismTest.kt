package com.pokercoach.engine

import com.pokercoach.engine.analysis.Decision
import com.pokercoach.engine.analysis.HandAnalyzer
import com.pokercoach.engine.analysis.OptionKind
import com.pokercoach.engine.bot.BotProfile
import com.pokercoach.engine.bot.BotStyle
import com.pokercoach.engine.bot.ProfileBot
import com.pokercoach.engine.game.ActionType
import com.pokercoach.engine.game.Blinds
import com.pokercoach.engine.game.HandEngine
import com.pokercoach.engine.game.HandEvent
import com.pokercoach.engine.game.PlayerAction.BetOrRaise
import com.pokercoach.engine.game.PlayerAction.Call
import com.pokercoach.engine.game.PlayerAction.Check
import com.pokercoach.engine.game.SeatedPlayer
import com.pokercoach.engine.game.Street
import com.pokercoach.engine.session.GameMode
import com.pokercoach.engine.session.PlayerProfile
import com.pokercoach.engine.session.TableSession
import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertTrue

/** More players in pots, no "limp everything" coaching, and bets that represent the board. */
class RealismTest {

    @Test
    fun `a low-stakes mixed table sees plenty of multiway flops`() {
        val lineup = listOf(BotStyle.REGULAR, BotStyle.CASUAL, BotStyle.BEGINNER, BotStyle.REGULAR, BotStyle.CASUAL, BotStyle.BEGINNER)
        var flops = 0
        var multiway = 0
        repeat(20) { sIdx ->
            val session = TableSession(6, GameMode.Cash(Blinds(1, 2), 200), (0 until 6).associateWith { PlayerProfile("s$it", "S$it") }, sIdx.toLong())
            val bots = (0 until 6).associateWith { ProfileBot(BotProfile.preset(lineup[it]), sIdx * 100L + it, iterations = 120, solverBudgetMs = 0) }
            repeat(30) {
                val h = session.nextHand()
                while (!h.isComplete) { val s = h.actorSeat!!; h.act(bots.getValue(s).decide(h.snapshotFor(s), s, h.publicHistory(s))) }
                session.completeHand(h)
                if (h.events.none { it is HandEvent.BoardDealt }) return@repeat
                val folded = h.events.filterIsInstance<HandEvent.ActionTaken>().filter { it.street == Street.PREFLOP && it.type == ActionType.FOLD }.map { it.seat }.toSet()
                flops++
                if (6 - folded.size >= 3) multiway++
            }
        }
        assertTrue(multiway.toDouble() / flops >= 0.35, "multiway flops: $multiway of $flops")
    }

    @Test
    fun `the coach doesn't recommend open-limping`() {
        var firstIn = 0
        var limpBest = 0
        for (i in 0 until 150) {
            val ps = (0 until 6).map { SeatedPlayer(it, "p$it", "P$it", 200L) }
            val bots = (0 until 6).associateWith { ProfileBot(BotProfile.preset(BotStyle.REGULAR), i * 10L + it, iterations = 80, solverBudgetMs = 0) }
            val h = HandEngine(ps, i % 6, Blinds(1, 2), seed = 9000L + i)
            while (!h.isComplete) { val s = h.actorSeat!!; h.act(bots.getValue(s).decide(h.snapshotFor(s), s, h.publicHistory(s))) }
            val d = HandAnalyzer(800).analyze(h.events, 0).decisions.firstOrNull() ?: continue
            // First in (only blinds posted), not the small blind completing.
            if (d.street != Street.PREFLOP || d.toCallBb != 1.0 || d.options.none { it.kind == OptionKind.CALL }) continue
            firstIn++
            if (d.best.kind == OptionKind.CALL) limpBest++
        }
        assertTrue(firstIn >= 30)
        assertTrue(limpBest.toDouble() / firstIn <= 0.05, "limp recommended $limpBest of $firstIn times")
    }

    private fun aceHighFlop(heroRaisedPreflop: Boolean): Decision {
        val deck = riggedDeck(listOf("Qd8d", "Jc9c"), "Ad7c2s9h4d")
        val h = HandEngine(listOf(SeatedPlayer(0, "h", "Hero", 1000), SeatedPlayer(1, "v", "Villain", 1000)), 0, Blinds(5, 10), seed = 3, presetDeck = deck)
        if (heroRaisedPreflop) { h.act(BetOrRaise(25)); h.act(Call) } else { h.act(Call); h.act(BetOrRaise(30)); h.act(Call) }
        h.act(Check); h.act(Check)
        return HandAnalyzer(3_000).analyze(h.events, 0, deck).decisions.last()
    }

    @Test
    fun `betting an ace-high flop you represent beats checking, and the coach says why`() {
        val raiser = aceHighFlop(heroRaisedPreflop = true)
        val caller = aceHighFlop(heroRaisedPreflop = false)
        fun bestBet(d: Decision) = d.options.filter { it.kind == OptionKind.BET }.maxOf { it.evBb }
        fun check(d: Decision) = d.options.first { it.kind == OptionKind.CHECK }.evBb
        assertTrue(bestBet(raiser) > check(raiser) + 1.0, "raiser: bet ${bestBet(raiser)} vs check ${check(raiser)}")
        assertEquals(OptionKind.BET, raiser.best.kind)
        assertTrue(raiser.hints.any { it.startsWith("You represent the ace") })
        assertTrue(bestBet(raiser) > bestBet(caller) + 1.0, "the same bluff is worth much less when you didn't raise preflop")
        val raiserFe = raiser.options.first { it.kind == OptionKind.BET }.foldEquity!!
        val callerFe = caller.options.first { it.kind == OptionKind.BET }.foldEquity!!
        assertTrue(raiserFe > callerFe + 0.25, "fold equity $raiserFe vs $callerFe")
    }
}
