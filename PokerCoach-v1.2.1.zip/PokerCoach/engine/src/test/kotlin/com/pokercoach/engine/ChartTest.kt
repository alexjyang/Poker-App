package com.pokercoach.engine

import com.pokercoach.engine.bot.BotProfile
import com.pokercoach.engine.bot.PreflopCharts
import com.pokercoach.engine.bot.PreflopCharts.Pos
import com.pokercoach.engine.bot.ProfileBot
import com.pokercoach.engine.game.Blinds
import com.pokercoach.engine.game.HandEngine
import com.pokercoach.engine.game.PlayerAction
import com.pokercoach.engine.game.SeatedPlayer
import com.pokercoach.engine.range.HandClass
import kotlin.math.abs
import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertTrue

/** The CFR preflop charts are sane, and the GTO bot follows them. */
class ChartTest {
    private fun share(f: (Int) -> Double?) = (0 until 169).sumOf { (f(it) ?: 0.0) * HandClass.fromIndex(it).comboCount } / 1326.0
    private fun cls(s: String) = HandClass.parse(s).index

    @Test
    fun `charts look like real preflop strategy`() {
        val rfi = listOf(Pos.UTG, Pos.HJ, Pos.CO, Pos.BTN).map { p -> share { PreflopCharts.open(p, it, false) } }
        assertTrue(rfi.zipWithNext().all { (a, b) -> a <= b + 0.01 }, "opening ranges widen towards the button: $rfi")
        assertTrue(rfi[0] in 0.12..0.24 && rfi[3] in 0.33..0.50, "UTG ${rfi[0]}, BTN ${rfi[3]}")
        val bbDefend = share { PreflopCharts.vsOpen(Pos.BB, Pos.BTN, it, false)?.let { p -> p.first + p.second } }
        assertTrue(bbDefend in 0.40..0.65, "big blind defends vs the button: $bbDefend")
        for (p in listOf(Pos.UTG, Pos.HJ, Pos.CO, Pos.BTN, Pos.SB)) assertEquals(1.0, PreflopCharts.open(p, cls("AA"), false))
        assertEquals(0.0, PreflopCharts.open(Pos.UTG, cls("72o"), false))
        assertTrue((PreflopCharts.vsOpen(Pos.BB, Pos.BTN, cls("76s"), false)?.first ?: 0.0) > 0.5, "BB defends 76s vs a button open")
        assertTrue((PreflopCharts.vsFourBet(Pos.BB, Pos.BTN, cls("AA"), false)?.second ?: 0.0) > 0.9, "AA gets it in vs a 4-bet")
    }

    @Test
    fun `the GTO bot opens from UTG as often as the chart says`() {
        var raises = 0
        val n = 2_000
        repeat(n) { i ->
            val h = HandEngine((0 until 6).map { SeatedPlayer(it, "p$it", "P$it", 1000) }, 0, Blinds(5, 10), seed = 50_000L + i)
            val a = ProfileBot(BotProfile.GTO, i.toLong(), solverBudgetMs = 0).decide(h.snapshotFor(3), 3, h.publicHistory(3))
            if (a is PlayerAction.BetOrRaise) raises++
        }
        val expected = share { PreflopCharts.open(Pos.UTG, it, false) }
        assertTrue(abs(raises.toDouble() / n - expected) < 0.03, "opened ${raises.toDouble() / n} vs chart $expected")
    }

    @Test
    fun `the GTO big blind defends against a button open as the chart says`() {
        var defends = 0
        val n = 1_500
        repeat(n) { i ->
            val h = HandEngine((0 until 6).map { SeatedPlayer(it, "p$it", "P$it", 1000) }, 0, Blinds(5, 10), seed = 70_000L + i)
            h.act(PlayerAction.Fold); h.act(PlayerAction.Fold); h.act(PlayerAction.Fold) // UTG, HJ, CO
            h.act(PlayerAction.BetOrRaise(25))                                             // button opens
            h.act(PlayerAction.Fold)                                                        // small blind
            val a = ProfileBot(BotProfile.GTO, i.toLong(), solverBudgetMs = 0).decide(h.snapshotFor(2), 2, h.publicHistory(2))
            if (a != PlayerAction.Fold) defends++
        }
        val expected = share { PreflopCharts.vsOpen(Pos.BB, Pos.BTN, it, false)?.let { p -> p.first + p.second } }
        assertTrue(abs(defends.toDouble() / n - expected) < 0.04, "defended ${defends.toDouble() / n} vs chart $expected")
    }
}
