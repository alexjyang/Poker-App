package com.pokercoach.engine

import com.pokercoach.engine.analysis.EvModel
import com.pokercoach.engine.analysis.Grade
import com.pokercoach.engine.analysis.HandAnalyzer
import com.pokercoach.engine.analysis.OpponentProfile
import com.pokercoach.engine.analysis.OptionKind
import com.pokercoach.engine.bot.BotProfile
import com.pokercoach.engine.bot.BotStyle
import com.pokercoach.engine.bot.OpponentStats
import com.pokercoach.engine.bot.ProfileBot
import com.pokercoach.engine.card.Card
import com.pokercoach.engine.game.Blinds
import com.pokercoach.engine.game.HandEngine
import com.pokercoach.engine.game.PlayerAction.BetOrRaise
import com.pokercoach.engine.game.PlayerAction.Call
import com.pokercoach.engine.game.PlayerAction.Check
import com.pokercoach.engine.game.SeatedPlayer
import com.pokercoach.engine.rng.SeededRandom
import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertNotNull
import kotlin.test.assertNull
import kotlin.test.assertTrue

class ReadsTest {
    private val station = OpponentProfile.fromBot(BotProfile.BEGINNER)
    private val nit = OpponentProfile("Nit", looseness = 0.6, foldToBet = 1.3, bluffiness = 0.5, passivity = 1.0, source = "test")

    /** Heads-up, hero on the button (seat 0); villain dealt first. */
    private fun riverSpot(hero: String, villain: String, board: String): Pair<HandEngine, List<Card>> {
        val deck = riggedDeck(listOf(villain, hero), board)
        val h = HandEngine(listOf(SeatedPlayer(0, "h", "Hero", 1000), SeatedPlayer(1, "v", "Villain", 1000)), 0, Blinds(5, 10), seed = 9, presetDeck = deck)
        h.act(BetOrRaise(25)); h.act(Call)          // preflop
        h.act(Check); h.act(BetOrRaise(25)); h.act(Call) // flop c-bet, called
        h.act(Check); h.act(Check)                   // turn
        h.act(Check)                                 // river: villain checks to hero
        h.act(Check)                                 // hero checks back
        return h to deck
    }

    @Test
    fun `the same river bluff is worth more against a player who folds than against a station`() {
        val (h, deck) = riverSpot("7h6h", "QcJc", "Ks Qd 2c 9s 3d")
        val analyzer = HandAnalyzer(iterations = 4_000)
        val vsStation = analyzer.analyze(h.events, 0, deck, reads = mapOf(1 to station)).decisions.last()
        val vsNit = analyzer.analyze(h.events, 0, deck, reads = mapOf(1 to nit)).decisions.last()
        fun bestBetEv(d: com.pokercoach.engine.analysis.Decision) =
            d.options.filter { it.kind == OptionKind.BET || it.kind == OptionKind.ALL_IN }.maxOf { it.evBb }
        assertTrue(bestBetEv(vsNit) > bestBetEv(vsStation) + 0.3, "nit ${bestBetEv(vsNit)} vs station ${bestBetEv(vsStation)}")
        assertEquals(OptionKind.CHECK, vsStation.best.kind, "never bluff a calling station")
        assertNotNull(vsStation.balancedOptions, "with a read, the balanced line is computed too")
        assertNotNull(vsStation.read)
        assertTrue(vsStation.hints.any { it.contains("calls too much") })
    }

    @Test
    fun `playing the balanced line is never graded worse than an inaccuracy`() {
        val rng = SeededRandom(21)
        val styles = BotStyle.entries
        var checked = 0
        repeat(40) { i ->
            val n = 2 + rng.nextInt(3)
            val ps = (0 until n).map { SeatedPlayer(it, "p$it", "P$it", 300L + rng.nextInt(1500)) }
            val bots = (0 until n).associateWith { ProfileBot(BotProfile.preset(styles[(it + i) % styles.size]), i * 7L + it, iterations = 100, solverBudgetMs = 0) }
            val h = HandEngine(ps, rng.nextInt(n), Blinds(5, 10), seed = 500L + i)
            while (!h.isComplete) { val s = h.actorSeat!!; h.act(bots.getValue(s).decide(h.snapshotFor(s), s, h.publicHistory(s))) }
            val reads = (1 until n).associateWith { OpponentProfile.fromBot(bots.getValue(it).profile) }
            val r = HandAnalyzer(iterations = 600).analyze(h.events, 0, reads = reads)
            for (d in r.decisions) {
                val bal = d.balancedOptions ?: continue
                if (bal.first { it.isBest }.isChosen) {
                    assertTrue(d.grade <= Grade.INACCURACY || d.chosen.kind == OptionKind.FOLD, "balanced-best graded ${d.grade}")
                    checked++
                }
                assertTrue(d.closeOptions.contains(d.best.label))
            }
        }
        assertTrue(checked > 5)
    }

    @Test
    fun `a missed draw on the river is pointed out`() {
        val (h, deck) = riverSpot("Ah5h", "KcQc", "Kh 9h 2c 4d Jc")
        val d = HandAnalyzer(3_000).analyze(h.events, 0, deck).decisions.last()
        assertTrue(d.hints.any { it.startsWith("Your draw missed") }, d.hints.toString())
        assertNull(d.balancedOptions, "no read: only one line")
    }

    @Test
    fun `scare cards and possible straights`() {
        val board = Card.parseList("9h5h2c")
        assertTrue(EvModel.isScareCard(board, Card.parse("Kd").id), "overcard")
        assertTrue(EvModel.isScareCard(board, Card.parse("3h").id), "third heart")
        assertTrue(!EvModel.isScareCard(board, Card.parse("2s").id), "pairing the bottom card is not scary")
    }

    @Test
    fun `reads encode, decode, and blend with observations`() {
        val reads = mapOf(1 to station, 4 to nit)
        assertEquals(reads, OpponentProfile.decodeAll(OpponentProfile.encodeAll(reads)))
        val counts = OpponentStats.Counts().apply { hands = 100; vpip = 60; facedBet = 40; foldedToBet = 8 }
        val blended = OpponentProfile.withObservations(OpponentProfile.fromBot(BotProfile.REGULAR), counts)
        assertTrue(blended.looseness > 1.5, "plays 60% of hands: read loosens")
        assertTrue(blended.foldToBet < 0.7, "folds only 20% to bets: read becomes a station")
        assertTrue(blended.source.contains("seen 100 hands"))
    }
}
