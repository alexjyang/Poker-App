package com.pokercoach.engine

import com.pokercoach.engine.analysis.EquityCalculator
import com.pokercoach.engine.card.Card
import com.pokercoach.engine.range.Combos
import com.pokercoach.engine.range.PreflopRanking
import com.pokercoach.engine.range.Range
import com.pokercoach.engine.rng.SeededRandom
import com.pokercoach.engine.solver.SolverAction
import com.pokercoach.engine.solver.SolverConfig
import com.pokercoach.engine.solver.SpotState
import com.pokercoach.engine.solver.SubgameSolver
import kotlin.math.abs
import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertTrue

class SolverTest {
    private fun combo(s: String) = Card.parseList(s).let { Combos.index(it[0], it[1]) }

    @Test
    fun `with no betting, values equal exact equity on the river and the turn`() {
        val hero = Card.parseList("JhJd")
        val villain = Range.ofClasses(listOf("QQ", "AKs", "T9s", "88"))
        val heroRange = Range.ofClasses(listOf("JJ"))
        for (boardText in listOf("Kh9s4c2d7h", "Kh9s4c2d")) {
            val board = Card.parseList(boardText)
            // Stacks of 0: nobody can bet, so the hand is checked down.
            val spot = SpotState(board, pot = 100.0, commits = DoubleArray(2), stacks = DoubleArray(2), toAct = 0)
            val solver = SubgameSolver(spot, listOf(heroRange, villain))
            solver.solve(1)
            val value = solver.rootActionValues(Combos.index(hero[0], hero[1]))!![0]
            val exact = EquityCalculator.vsRanges(hero, board, listOf(villain), 0, SeededRandom(1))
            assertTrue(exact.exact)
            assertEquals(exact.equity * 100, value, 0.01, "board $boardText")
        }
    }

    @Test
    fun `textbook river game - a pot-sized bet is one-third bluffs and gets called half the time`() {
        // IP holds the nuts (AA: a set on an ace-high board) or air (65s); OOP holds a bluff-catcher (QQ).
        val board = Card.parseList("AhKd7c4s2h")
        val oop = Range.ofClasses(listOf("QQ"))
        val ip = Range.ofClasses(listOf("AA", "65s"))
        val config = SolverConfig(betSizes = listOf(1.0), raiseSizes = emptyList(), maxRaises = 0, allInMaxSpr = 0.0)
        val spot = SpotState(board, pot = 100.0, commits = DoubleArray(2), stacks = doubleArrayOf(10_000.0, 10_000.0), toAct = 1, otherChecked = true)
        val solver = SubgameSolver(spot, listOf(oop, ip), config)
        solver.solve(3_000)
        val acts = solver.rootActions
        val bet = acts.indexOfFirst { it.kind == SolverAction.Kind.BET }
        // 3 AA combos value-bet; bluffs should be half as many: 1.5 of 4 air combos = 37.5%.
        val aa = solver.rootStrategy(combo("AsAc"))!![bet]
        val air = listOf("6h5h", "6s5s", "6c5c", "6d5d").map { solver.rootStrategy(combo(it))!![bet] }.average()
        assertTrue(aa > 0.97, "AA bets for value: $aa")
        assertEquals(0.375, air, 0.05, "bluff frequency")
        // OOP facing the bet calls with frequency pot / (pot + bet) = 50%.
        val oopActions = solver.actionsAt(listOf(bet))!!
        val call = oopActions.indexOfFirst { it.kind == SolverAction.Kind.CALL }
        val callFreq = solver.strategyAt(listOf(bet), combo("QsQh"))!![call]
        assertEquals(0.5, callFreq.toDouble(), 0.07, "defense frequency")
        assertTrue(solver.exploitability() < 0.005, "exploitability ${solver.exploitability()}")
    }

    @Test
    fun `realistic river and turn spots converge to low exploitability`() {
        val oop = PreflopRanking.top(0.35).times { 1.0 }
        val ip = PreflopRanking.top(0.25).times { 1.0 }
        for ((boardText, iters) in listOf("Kh9s4c2d7h" to 250, "Qs8h3d2c" to 60)) {
            val board = Card.parseList(boardText)
            val spot = SpotState(board, 60.0, DoubleArray(2), doubleArrayOf(170.0, 170.0), toAct = 0)
            val solver = SubgameSolver(spot, listOf(oop, ip), if (board.size == 4) SolverConfig.turn() else SolverConfig.river())
            val t0 = System.currentTimeMillis()
            solver.solve(iters)
            val ms = System.currentTimeMillis() - t0
            val e = solver.exploitability()
            println("board $boardText: ${solver.nodeCount} decision nodes, $iters iterations in $ms ms, exploitability ${"%.2f".format(e * 100)}% of pot")
            assertTrue(e < 0.02, "exploitability $e")
            // Frequencies are a proper distribution.
            val f = solver.rootRangeFrequencies()
            assertEquals(1.0, f.sum().toDouble(), 1e-3)
        }
    }
}

class SolverIntegrationTest {
    /** Heads-up, hero seat 0 on the button; villain (BB) dealt first. Checked down to a river decision. */
    private fun riverSpot(hero: String, villain: String, board: String): Pair<com.pokercoach.engine.game.HandEngine, List<Card>> {
        val deck = riggedDeck(listOf(villain, hero), board)
        val h = com.pokercoach.engine.game.HandEngine(
            listOf(com.pokercoach.engine.game.SeatedPlayer(0, "h", "Hero", 1000), com.pokercoach.engine.game.SeatedPlayer(1, "v", "Villain", 1000)),
            0, com.pokercoach.engine.game.Blinds(5, 10), seed = 5, presetDeck = deck,
        )
        h.act(com.pokercoach.engine.game.PlayerAction.BetOrRaise(25)); h.act(com.pokercoach.engine.game.PlayerAction.Call)
        h.act(com.pokercoach.engine.game.PlayerAction.Check); h.act(com.pokercoach.engine.game.PlayerAction.BetOrRaise(25)); h.act(com.pokercoach.engine.game.PlayerAction.Call)
        h.act(com.pokercoach.engine.game.PlayerAction.Check); h.act(com.pokercoach.engine.game.PlayerAction.Check)
        h.act(com.pokercoach.engine.game.PlayerAction.Check) // river: villain checks to hero
        return h to deck
    }

    @Test
    fun `the GTO bot value-bets the nuts on the river when checked to`() {
        var bets = 0
        repeat(10) { s ->
            val (h, _) = riverSpot("AsKs", "QhQd", "Qs Js Ts 2d 3c") // royal flush
            val bot = com.pokercoach.engine.bot.ProfileBot(com.pokercoach.engine.bot.BotProfile.GTO, s.toLong(), solverBudgetMs = 600)
            val a = bot.decide(h.snapshotFor(0), 0, h.publicHistory(0))
            if (a is com.pokercoach.engine.game.PlayerAction.BetOrRaise) bets++
        }
        assertTrue(bets >= 9, "bet the nuts $bets of 10 times")
    }

    @Test
    fun `the coach shows solver frequencies for heads-up river decisions`() {
        val (h, deck) = riverSpot("7h6h", "QcJc", "Ks Qd 2c 9s 3d")
        h.act(com.pokercoach.engine.game.PlayerAction.Check) // hero checks back (the decision reviewed)
        val d = com.pokercoach.engine.analysis.HandAnalyzer(2_000, solverBudgetMs = 500).analyze(h.events, 0, deck).decisions.last()
        val mix = d.solver
        assertTrue(mix != null && mix.options.isNotEmpty(), "solver mix present")
        assertEquals(1.0, mix!!.options.sumOf { it.second }, 0.02)
        assertTrue((mix.exploitability ?: 1.0) < 0.05, "exploitability ${mix.exploitability}")
        assertTrue(d.beginnerText.contains("Solver:"))
    }
}
