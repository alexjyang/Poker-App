package com.pokercoach.engine

import com.pokercoach.engine.bot.BotProfile
import com.pokercoach.engine.bot.BotStyle
import com.pokercoach.engine.bot.ProfileBot
import com.pokercoach.engine.eval.HandCategory
import com.pokercoach.engine.eval.HandEvaluator
import com.pokercoach.engine.game.ActionType
import com.pokercoach.engine.game.Blinds
import com.pokercoach.engine.game.HandEngine
import com.pokercoach.engine.game.HandEvent
import com.pokercoach.engine.game.PlayerAction
import com.pokercoach.engine.game.PlayerAction.BetOrRaise
import com.pokercoach.engine.game.PlayerAction.Fold
import com.pokercoach.engine.game.SeatedPlayer
import com.pokercoach.engine.game.Street
import com.pokercoach.engine.session.GameMode
import com.pokercoach.engine.session.PlayerProfile
import com.pokercoach.engine.session.TableSession
import kotlin.test.Test
import kotlin.test.assertTrue

/** Bots shouldn't play all-or-nothing: sensible re-raise ladders and no deep one-pair stack-offs. */
class BotDisciplineTest {

    /** 3 players, 100 BB deep: button 0, SB 1, BB 2. Deal order: 1, 2, 0. */
    private fun table(button: String, sb: String, bb: String) = HandEngine(
        (0 until 3).map { SeatedPlayer(it, "p$it", "P$it", 1000) }, 0, Blinds(5, 10), seed = 1,
        presetDeck = riggedDeck(listOf(sb, bb, button)),
    )

    private fun decide(style: BotStyle, h: HandEngine, seed: Long): PlayerAction {
        val seat = h.actorSeat!!
        return ProfileBot(BotProfile.preset(style), seed).decide(h.snapshotFor(seat), seat, h.publicHistory(seat))
    }

    @Test
    fun `kings facing a 3-bet at 100 BB re-raise to a normal size or call, never shove`() {
        for (style in listOf(BotStyle.REGULAR, BotStyle.SHARK, BotStyle.GTO, BotStyle.CASUAL)) repeat(15) { s ->
            val h = table(button = "KsKh", sb = "7c2d", bb = "QdJd")
            h.act(BetOrRaise(25)); h.act(Fold); h.act(BetOrRaise(90)) // open, fold, 3-bet
            val a = decide(style, h, s.toLong())
            val legal = h.legalActions()!!
            assertTrue(a is PlayerAction.Call || (a is BetOrRaise && a.to < legal.maxRaiseTo), "$style shoved: $a")
        }
    }

    @Test
    fun `kings facing a 4-bet get it in (or call when passive)`() {
        repeat(10) { s ->
            val h = table(button = "AdQc", sb = "7c2d", bb = "KsKh")
            h.act(BetOrRaise(25)); h.act(Fold); h.act(BetOrRaise(90)); h.act(BetOrRaise(205)) // BB 3-bets, button 4-bets
            val a = decide(BotStyle.REGULAR, h, s.toLong())
            val legal = h.legalActions()!!
            assertTrue(a is PlayerAction.Call || (a is BetOrRaise && a.to == legal.maxRaiseTo), "got $a")
        }
    }

    @Test
    fun `the opener continues with jacks against a 3-bet without folding or shoving`() {
        repeat(10) { s ->
            val h = table(button = "JsJh", sb = "7c2d", bb = "AdKd")
            h.act(BetOrRaise(25)); h.act(Fold); h.act(BetOrRaise(90))
            val a = decide(BotStyle.REGULAR, h, s.toLong())
            val legal = h.legalActions()!!
            assertTrue(a == PlayerAction.Call || (a is BetOrRaise && a.to < legal.maxRaiseTo), "got $a")
        }
    }

    @Test
    fun `solid bots don't stack off deep with one pair, and do call some 3-bets`() {
        val styles = listOf(BotStyle.REGULAR, BotStyle.SHARK, BotStyle.GTO, BotStyle.REGULAR, BotStyle.SHARK, BotStyle.GTO)
        var deepOnePairStackOffs = 0
        var faced3bet = 0
        var called3bet = 0
        repeat(25) { sIdx ->
            val session = TableSession(6, GameMode.Cash(Blinds(1, 2), 200), (0 until 6).associateWith { PlayerProfile("s$it", "S$it") }, sIdx.toLong())
            val bots = (0 until 6).associateWith { ProfileBot(BotProfile.preset(styles[it]), sIdx * 100L + it, iterations = 150, solverBudgetMs = 0) }
            repeat(40) {
                val h = session.nextHand()
                while (!h.isComplete) { val s = h.actorSeat!!; h.act(bots.getValue(s).decide(h.snapshotFor(s), s, h.publicHistory(s))) }
                session.completeHand(h)
                val holes = h.events.filterIsInstance<HandEvent.HoleCardsDealt>().associate { it.seat to it.cards }
                var raises = 0
                val openers = mutableSetOf<Int>()
                for (a in h.events.filterIsInstance<HandEvent.ActionTaken>()) {
                    if (a.street == Street.PREFLOP) {
                        if (raises == 2 && a.seat in openers) { faced3bet++; if (a.type == ActionType.CALL) called3bet++ }
                        if (a.type == ActionType.RAISE) { if (raises == 0) openers += a.seat; raises++ }
                        continue
                    }
                    val spr = a.stackBefore.toDouble() / a.potBefore
                    if (a.isAllIn && spr > 3) {
                        val board = h.events.filterIsInstance<HandEvent.BoardDealt>().takeWhile { it.street <= a.street }.flatMap { it.cards }
                        if (HandEvaluator.evaluate(holes.getValue(a.seat) + board).category <= HandCategory.PAIR) deepOnePairStackOffs++
                    }
                }
            }
        }
        assertTrue(deepOnePairStackOffs <= 2, "deep one-pair stack-offs: $deepOnePairStackOffs")
        assertTrue(faced3bet > 20 && called3bet.toDouble() / faced3bet >= 0.15, "called $called3bet of $faced3bet 3-bets")
    }
}
