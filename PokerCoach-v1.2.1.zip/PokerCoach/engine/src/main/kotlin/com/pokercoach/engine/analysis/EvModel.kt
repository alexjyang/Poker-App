package com.pokercoach.engine.analysis

import com.pokercoach.engine.card.Card
import com.pokercoach.engine.card.CardMask
import com.pokercoach.engine.eval.HandCategory
import com.pokercoach.engine.eval.HandEvaluator
import com.pokercoach.engine.game.Street
import com.pokercoach.engine.range.BoardStrength
import com.pokercoach.engine.range.Combos
import com.pokercoach.engine.range.PreflopRanking
import com.pokercoach.engine.range.Range
import com.pokercoach.engine.rng.SeededRandom
import kotlin.math.pow

enum class OptionKind { FOLD, CHECK, CALL, BET, RAISE, ALL_IN }

data class Option(val kind: OptionKind, val to: Long, val label: String)

data class OptionResult(
    val option: Option,
    /** Expected value in chips relative to folding now (chips already in the pot are sunk). */
    val evChips: Double,
    /** For bets/raises: how often everyone folds. */
    val foldEquity: Double?,
    /** For bets/raises: hero's pot share when at least one opponent continues. */
    val equityWhenCalled: Double?,
)

/** Preflop role of an opponent who hasn't voluntarily acted yet (their range is still "any two"). */
enum class UnopenedRole { BIG_BLIND, SMALL_BLIND, OTHER }

/**
 * One opponent as seen at the decision.
 * [unopenedRole]: set for players who haven't acted yet preflop; they continue versus a raise at
 * typical preflop defend frequencies instead of MDF on a narrowed range.
 * [inPot]: included in check/call showdowns (players yet to act preflop are assumed to fold).
 */
data class Opponent(
    val seat: Int,
    val range: Range,
    val streetCommit: Long,
    val stackBehind: Long,
    val inPot: Boolean,
    val unopenedRole: UnopenedRole?,
    /** The coach's read on this player; balanced by default. */
    val profile: OpponentProfile = OpponentProfile.BALANCED,
)

data class Situation(
    val hero: List<Card>,
    val board: List<Card>,
    val street: Street,
    val pot: Long,
    val currentBet: Long,
    val heroCommit: Long,
    val heroStack: Long,
    val bigBlind: Long,
    val opponents: List<Opponent>,
    val heroInPosition: Boolean,
    /** Hero's range as opponents see it (from hero's actions); drives how credible a bet looks. */
    val heroPerceived: Range? = null,
    /** Hero made the last preflop raise: their range is full of big cards and overpairs. */
    val heroPreflopAggressor: Boolean = false,
)

/**
 * A one-decision EV model, simulated with Monte Carlo. It is an ESTIMATE with stated
 * simplifications, the same kind used by most trainers' quick analysis:
 *
 *  - Call / check: showdown equity vs. the players in the pot, scaled by an equity-realization
 *    factor for streets still to come (in position realizes more than out of position).
 *  - Bet / raise: each opponent continues with the strongest part of their range. How much they
 *    continue is the larger of minimum defense frequency (MDF) and the share of their range
 *    strong enough for the price; players who haven't acted preflop use typical defend
 *    frequencies. Folds win the pot now; calls go to showdown.
 *  - No future betting, side pots or re-raises are simulated.
 *
 * All options use the same random seed (common random numbers), so EV *differences* between
 * options are much more precise than each EV on its own.
 */
class EvModel(private val iterations: Int) {

    fun evaluate(s: Situation, options: List<Option>, seed: Long): List<OptionResult> {
        val strength = if (s.board.size >= 3) BoardStrength(s.board) else null
        return options.map { opt ->
            val rng = SeededRandom(seed)
            when (opt.kind) {
                OptionKind.FOLD -> OptionResult(opt, 0.0, null, null)
                OptionKind.CHECK -> OptionResult(opt, passive(s, 0L, rng), null, null)
                OptionKind.CALL -> OptionResult(opt, passive(s, minOf(s.currentBet - s.heroCommit, s.heroStack), rng), null, null)
                else -> aggressive(s, opt, strength, rng)
            }
        }
    }

    private fun realization(s: Situation, players: Int, heroAllIn: Boolean, allOppsAllIn: Boolean, aggressor: Boolean): Double {
        if (s.street == Street.RIVER || heroAllIn || allOppsAllIn) return 1.0
        var r = if (s.heroInPosition) 0.95 else 0.85
        if (s.street == Street.PREFLOP) r -= 0.05
        if (aggressor) r += 0.05
        r -= 0.05 * (players - 1).coerceAtLeast(0)
        return r.coerceIn(0.6, 1.0)
    }

    /** Check (toCall = 0) or call: showdown vs players already in the pot. */
    private fun passive(s: Situation, toCall: Long, rng: SeededRandom): Double {
        if (s.street == Street.PREFLOP && toCall > 0 && s.currentBet <= s.bigBlind && s.opponents.any { it.unopenedRole != null || it.inPot }) {
            return limp(s, toCall, rng)
        }
        val inPot = s.opponents.filter { it.inPot }
        val heroMask = CardMask.of(s.hero)
        val boardMask = CardMask.of(s.board)
        val heroTotal = s.heroCommit + toCall
        // Chips opponents bet beyond what hero can match come back to them.
        val uncalled = inPot.sumOf { (it.streetCommit - heroTotal).coerceAtLeast(0) }
        val winnable = (s.pot + toCall - uncalled).toDouble()
        if (inPot.isEmpty()) return winnable - toCall
        val heroAllIn = toCall >= s.heroStack && toCall > 0
        val r = realization(s, inPot.size, heroAllIn, inPot.all { it.stackBehind == 0L }, aggressor = false)

        val samplers = inPot.map { RangeSampler(it.range, heroMask or boardMask) }
        if (samplers.any { it.isEmpty }) return -toCall.toDouble()
        val opp = LongArray(inPot.size)
        var sum = 0.0
        var done = 0
        var attempts = 0
        while (done < iterations && attempts < iterations * 4) {
            attempts++
            var used = heroMask or boardMask
            var ok = true
            for (i in samplers.indices) {
                val m = Combos.mask[samplers[i].sample(rng)]
                if (m and used != 0L) { ok = false; break }
                opp[i] = m; used = used or m
            }
            if (!ok) continue
            val b5 = Showdown.completeBoard(boardMask, s.board.size, used, rng)
            sum += Showdown.heroShare(heroMask, b5, opp, inPot.size)
            done++
        }
        if (done == 0) return -toCall.toDouble()
        val eq = sum / done
        return r * eq * winnable - toCall
    }

    /**
     * Limping (or completing the small blind) isn't a free look at the flop: players behind raise
     * to isolate you with their good hands, more players limp along, and you play the flop out
     * of position without the initiative. This models all three.
     */
    private fun limp(s: Situation, toCall: Long, rng: SeededRandom): Double {
        val heroMask = CardMask.of(s.hero)
        val live = s.opponents
        val samplers = live.map { RangeSampler(it.range, heroMask) }
        if (samplers.any { it.isEmpty }) return -toCall.toDouble()
        val bb = s.bigBlind
        val onlyBlindsLeft = live.all { it.unopenedRole == UnopenedRole.BIG_BLIND || it.unopenedRole == UnopenedRole.SMALL_BLIND || it.inPot && it.streetCommit >= bb }
        // How often each player raises over the limp, and how often they limp along.
        val isoShare = live.map { o ->
            val loose = kotlin.math.sqrt(o.profile.looseness) / o.profile.passivity
            when {
                o.unopenedRole == UnopenedRole.BIG_BLIND -> (if (live.size == 1 || onlyBlindsLeft && live.size <= 2) 0.25 else 0.12) * loose
                o.unopenedRole != null -> 0.10 * loose
                else -> 0.03 * loose // limp-raise from someone who already limped: rare
            }.coerceIn(0.01, 0.5)
        }
        val alongShare = live.map { o ->
            when (o.unopenedRole) {
                UnopenedRole.BIG_BLIND -> 1.0          // checks the option
                UnopenedRole.SMALL_BLIND -> 0.45 * o.profile.looseness
                null -> 1.0                            // already in
                else -> 0.12 * o.profile.looseness     // over-limps
            }.coerceIn(0.0, 1.0)
        }
        val heroStrength = PreflopRanking.strength(Combos.classOf[Combos.index(s.hero[0], s.hero[1])])
        val raiseTo = bb * 4 + bb * live.count { it.inPot && it.unopenedRole == null && it.streetCommit >= bb }
        val opp = LongArray(live.size)
        val inHand = LongArray(live.size + 1)
        var sum = 0.0
        var done = 0
        var attempts = 0
        while (done < iterations && attempts < iterations * 4) {
            attempts++
            var used = heroMask
            var ok = true
            val strengths = DoubleArray(live.size)
            for (i in live.indices) {
                val c = samplers[i].sample(rng)
                val m = Combos.mask[c]
                if (m and used != 0L) { ok = false; break }
                opp[i] = m; used = used or m
                strengths[i] = PreflopRanking.strength(Combos.classOf[c])
            }
            if (!ok) continue
            done++
            // Does anyone isolate? (Their strongest hands raise.)
            val raiser = live.indices.firstOrNull { strengths[it] >= 1.0 - isoShare[it] }
            if (raiser != null) {
                if (heroStrength < 0.80) { sum -= toCall; continue } // fold to the raise, limp lost
                // Call the raise heads-up, out of position, without the initiative.
                val call = raiseTo - (s.heroCommit + toCall)
                inHand[0] = opp[raiser]
                val b5 = Showdown.completeBoard(0L, 0, used, rng)
                val share = Showdown.heroShare(heroMask, b5, inHand, 1)
                val pot = s.pot + toCall + raiseTo - (live[raiser].streetCommit) + call
                sum += 0.75 * share * pot - toCall - call
                continue
            }
            var n = 0
            var extra = 0L
            for (i in live.indices) {
                val goesAlong = live[i].inPot || live[i].unopenedRole == UnopenedRole.BIG_BLIND || strengths[i] >= 1.0 - alongShare[i]
                if (!goesAlong) continue
                inHand[n++] = opp[i]
                extra += (bb - live[i].streetCommit).coerceAtLeast(0)
            }
            if (n == 0) { sum += s.pot; continue }
            val b5 = Showdown.completeBoard(0L, 0, used, rng)
            val share = Showdown.heroShare(heroMask, b5, inHand, n)
            // Limped pots: passive, often out of position and multiway, so equity is poorly realized.
            val r = ((if (s.heroInPosition) 0.80 else 0.72) - 0.04 * (n - 1)).coerceAtLeast(0.55)
            sum += r * share * (s.pot + toCall + extra) - toCall
        }
        return if (done == 0) -toCall.toDouble() else sum / done
    }

    private fun aggressive(s: Situation, opt: Option, strength: BoardStrength?, rng: SeededRandom): OptionResult {
        val heroMask = CardMask.of(s.hero)
        val boardMask = CardMask.of(s.board)
        val live = s.opponents
        val responders = live.filter { it.stackBehind > 0 }
        val allIns = live.filter { it.stackBehind == 0L }
        val dead = heroMask or boardMask

        // Hero can't put in more than the deepest opponent can match.
        val maxCover = live.maxOfOrNull { it.streetCommit + it.stackBehind } ?: s.currentBet
        val effectiveTo = minOf(opt.to, maxOf(maxCover, s.currentBet))
        val heroAdd = (effectiveTo - s.heroCommit).coerceAtLeast(0)
        val heroAllIn = opt.to >= s.heroCommit + s.heroStack

        // Hero's perceived betting range for this size (value hands, draws, some bluffs).
        val perceived = if (strength != null && s.heroPerceived != null) {
            PerceivedRange.forBet(s.heroPerceived, strength, dead, heroAdd.toDouble() / s.pot.coerceAtLeast(1))
        } else null

        // How often each responder continues, and the strength cut-off inside their range.
        val k = responders.size.coerceAtLeast(1)
        val mdfCombined = s.pot.toDouble() / (s.pot + heroAdd).coerceAtLeast(1)
        val facingRaise = s.currentBet > 0 && s.street != Street.PREFLOP
        val thresholds = DoubleArray(responders.size)
        val barrelCut = DoubleArray(responders.size)
        responders.forEachIndexed { i, o ->
            val role = o.unopenedRole
            val prof = o.profile
            val f = if (role != null) {
                // Players who haven't acted yet: typical defend frequencies, looser players defend more.
                preflopDefend(role, effectiveTo.toDouble() / s.bigBlind, heroAllIn) * kotlin.math.sqrt(prof.looseness) / prof.foldToBet
            } else {
                // A balanced player defends at least MDF, and always continues with hands strong
                // enough for the price. Then the read bends it: stations fold less, nits fold more.
                val individual = 1.0 - (1.0 - mdfCombined).pow(1.0 / k)
                val byMdf = individual * if (facingRaise) 0.85 else 1.0
                val call = minOf(effectiveTo - o.streetCommit, o.stackBehind).coerceAtLeast(0)
                val price = call.toDouble() / (s.pot + heroAdd + call).coerceAtLeast(1)
                val base = if (perceived != null) {
                    // What does the bet represent? Thinking opponents continue with hands that beat
                    // enough of hero's perceived betting range for the price, so when the board favours
                    // hero's range (say an ace for the preflop raiser) their medium hands fold more.
                    // Calling stations don't think about ranges: they call with their own hand.
                    val byPerception = perceived.continueShare(o.range, dead, price + 0.03, strength!!)
                    // Stations call with much weaker hands than the price justifies.
                    val byOwnHand = shareAtLeast(o.range, dead, (0.35 + price) * minOf(1.0, prof.foldToBet), strength)
                    val thinking = ((prof.foldToBet - 0.5) / 0.5).coerceIn(0.0, 1.0)
                    maxOf(thinking * byPerception + (1 - thinking) * byOwnHand, 0.5 * byMdf)
                } else {
                    maxOf(byMdf, shareAtLeast(o.range, dead, 0.35 + price, strength))
                }
                1.0 - (1.0 - base) * prof.foldToBet
            }
            val defend = f.coerceIn(0.03, 0.97)
            thresholds[i] = cutoff(o.range, dead, defend, strength)
            // Second barrel next street (⅔ pot, MDF 60%): cut-off inside the range that called.
            if (strength != null) {
                val t = thresholds[i]
                val continuing = o.range.times { if (strengthOf(it, strength) >= t) 1.0 else 0.0 }
                val defend2 = (1.0 - 0.4 * prof.foldToBet).coerceIn(0.2, 0.95)
                barrelCut[i] = cutoff(continuing, dead, defend2, strength)
            }
        }

        val samplers = live.map { RangeSampler(it.range, dead) }
        if (samplers.any { it.isEmpty }) return OptionResult(opt, s.pot.toDouble(), 1.0, null)

        // Multi-street: on the flop and turn, a called bet isn't the end — hero can fire again
        // next street (when improving, already strong, holding a draw, or on a scare card) and
        // opponents fold weaker hands to that second barrel.
        val simulateNext = strength != null && (s.street == Street.FLOP || s.street == Street.TURN) && !heroAllIn
        val heroCombo = Combos.index(s.hero[0], s.hero[1])
        val heroStrength = strength?.effective(heroCombo) ?: 0.0
        val heroHasDraw = (strength?.draw?.get(heroCombo) ?: 0.0) > 0.0
        val heroStackAfter = (s.heroStack - heroAdd).coerceAtLeast(0)

        val opp = LongArray(live.size)
        val inHand = LongArray(live.size)
        val inIdx = IntArray(live.size)
        var sum = 0.0
        var folds = 0
        var calledShare = 0.0
        var calledCount = 0
        var done = 0
        var attempts = 0
        val respIndex = live.map { o -> responders.indexOf(o) }
        val combos = IntArray(live.size)
        while (done < iterations && attempts < iterations * 4) {
            attempts++
            var used = dead
            var ok = true
            for (i in live.indices) {
                val c = samplers[i].sample(rng)
                val m = Combos.mask[c]
                if (m and used != 0L) { ok = false; break }
                combos[i] = c; opp[i] = m; used = used or m
            }
            if (!ok) continue
            done++

            var nIn = 0
            var callChips = 0L
            var anyCaller = false
            var allCallersAllIn = true
            for (i in live.indices) {
                val o = live[i]
                val ri = respIndex[i]
                val continues = if (ri < 0) true else strengthOf(combos[i], strength) >= thresholds[ri]
                if (!continues) continue
                inIdx[nIn] = i
                inHand[nIn++] = opp[i]
                if (ri >= 0) {
                    anyCaller = true
                    val call = minOf(effectiveTo - o.streetCommit, o.stackBehind).coerceAtLeast(0)
                    callChips += call
                    if (call < o.stackBehind) allCallersAllIn = false
                }
            }
            if (!anyCaller && allIns.isEmpty()) {
                folds++
                sum += s.pot
                continue
            }
            val potAfter = s.pot + heroAdd + callChips

            if (simulateNext && !allCallersAllIn && heroStackAfter > 0) {
                // Deal the next card and play one more street with a simple, sensible plan.
                var id: Int
                do { id = rng.nextInt(52) } while (used and (1L shl id) != 0L)
                val card = 1L shl id
                val heroImproved = improved(heroMask, boardMask, card)
                val scare = isScareCard(s.board, id)
                // An ace or king arriving when hero raised preflop: hero "has it" in the opponent's eyes.
                val represents = s.heroPreflopAggressor && (id % 13) >= com.pokercoach.engine.card.Rank.KING.ordinal &&
                    (id % 13) > s.board.maxOf { it.rank.ordinal }
                val barrel = heroImproved || heroStrength >= 0.70 ||
                    (heroHasDraw && rng.nextDouble() < 0.5) || (represents && rng.nextDouble() < 0.85) || (scare && rng.nextDouble() < 0.7)
                if (barrel) {
                    val bet = minOf((potAfter * 0.66).toLong(), heroStackAfter)
                    var n2 = 0
                    var calls2 = 0L
                    val inHand2 = LongArray(nIn)
                    for (j in 0 until nIn) {
                        val i = inIdx[j]
                        val ri = respIndex[i]
                        val o = live[i]
                        val keeps = if (ri < 0 || o.stackBehind == 0L) true else {
                            val villainImproved = improved(opp[i], boardMask, card)
                            val future = if (villainImproved) 0.95 else strengthOf(combos[i], strength) - when {
                                represents -> 0.12
                                scare -> 0.05
                                else -> 0.0
                            }
                            future >= barrelCut[ri]
                        }
                        if (keeps) {
                            inHand2[n2++] = opp[i]
                            if (ri >= 0) calls2 += minOf(bet, (o.stackBehind - minOf(effectiveTo - o.streetCommit, o.stackBehind)).coerceAtLeast(0))
                        }
                    }
                    if (n2 == 0) {
                        sum += potAfter - heroAdd // everyone folds to the second barrel
                    } else {
                        val b5 = Showdown.completeBoard(boardMask or card, s.board.size + 1, used or card, rng)
                        val share = Showdown.heroShare(heroMask, b5, inHand2, n2)
                        val finalPot = potAfter + bet + calls2
                        val r2 = if (s.street == Street.TURN) 1.0 else 0.95 // after a turn barrel only the river is left
                        sum += r2 * share * finalPot - heroAdd - bet
                        calledShare += share
                        calledCount++
                    }
                } else {
                    // Hero checks the next street and mostly sees a showdown.
                    val b5 = Showdown.completeBoard(boardMask or card, s.board.size + 1, used or card, rng)
                    val share = Showdown.heroShare(heroMask, b5, inHand, nIn)
                    sum += 0.92 * share * potAfter - heroAdd
                    calledShare += share
                    calledCount++
                }
                continue
            }

            val b5 = Showdown.completeBoard(boardMask, s.board.size, used, rng)
            val share = Showdown.heroShare(heroMask, b5, inHand, nIn)
            val r = realization(s, nIn, heroAllIn, allCallersAllIn, aggressor = true)
            sum += r * share * potAfter - heroAdd
            calledShare += share
            calledCount++
        }
        if (done == 0) return OptionResult(opt, 0.0, null, null)
        return OptionResult(
            option = opt,
            evChips = sum / done,
            foldEquity = folds.toDouble() / done,
            equityWhenCalled = if (calledCount > 0) calledShare / calledCount else null,
        )
    }

    /** Did [card] improve this hand meaningfully (made a straight or better, or paired a hole card)? */
    private fun improved(hole: Long, board: Long, card: Long): Boolean {
        val before = HandEvaluator.evaluateMask(hole or board) ushr 26
        val after = HandEvaluator.evaluateMask(hole or board or card) ushr 26
        if (after <= before) return false
        if (after >= HandCategory.STRAIGHT.ordinal && before < HandCategory.STRAIGHT.ordinal) return true
        val rank = java.lang.Long.numberOfTrailingZeros(card) % 13
        var h = hole
        while (h != 0L) {
            val c = java.lang.Long.numberOfTrailingZeros(h)
            if (c % 13 == rank) return true
            h = h and (h - 1)
        }
        return false
    }

    private fun strengthOf(combo: Int, strength: BoardStrength?): Double =
        strength?.effective(combo) ?: PreflopRanking.strength(Combos.classOf[combo])

    /** Weight share of the range whose strength is at least [minStrength]. */
    private fun shareAtLeast(range: Range, dead: Long, minStrength: Double, strength: BoardStrength?): Double {
        var total = 0.0
        var above = 0.0
        for (i in 0 until Combos.COUNT) {
            val w = range.weight(i)
            if (w <= 0 || Combos.mask[i] and dead != 0L) continue
            total += w
            if (strengthOf(i, strength) >= minStrength) above += w
        }
        return if (total == 0.0) 0.0 else above / total
    }

    /** Strength value such that the top [fraction] of the range's weight is at or above it. */
    private fun cutoff(range: Range, dead: Long, fraction: Double, strength: BoardStrength?): Double {
        val items = ArrayList<Pair<Double, Double>>(Combos.COUNT)
        var total = 0.0
        for (i in 0 until Combos.COUNT) {
            val w = range.weight(i)
            if (w <= 0 || Combos.mask[i] and dead != 0L) continue
            items += strengthOf(i, strength) to w
            total += w
        }
        if (items.isEmpty()) return Double.MAX_VALUE
        items.sortByDescending { it.first }
        var acc = 0.0
        for ((str, w) in items) {
            acc += w
            if (acc >= fraction * total) return str
        }
        return items.last().first
    }

    companion object {
        /**
         * A card that changes the story: an overcard (Q or higher above the board), a third card
         * of a suit, or one that puts a straight on the board for two-card holdings.
         */
        fun isScareCard(board: List<Card>, cardId: Int): Boolean {
            val c = Card(cardId)
            val topBoard = board.maxOf { it.rank.ordinal }
            if (c.rank.ordinal > topBoard && c.rank.ordinal >= com.pokercoach.engine.card.Rank.QUEEN.ordinal) return true
            if (board.count { it.suit == c.suit } == 2) return true
            val before = board.fold(0) { m, b -> m or (1 shl b.rank.ordinal) }
            return straightPossible(before or (1 shl c.rank.ordinal)) && !straightPossible(before)
        }

        /** Can any two hole cards make a straight with these board ranks? */
        fun straightPossible(boardRanks: Int): Boolean {
            for (a in 0 until 13) for (b in a until 13) {
                if (HandEvaluator.straightHigh(boardRanks or (1 shl a) or (1 shl b)) >= 0) return true
            }
            return false
        }

        /** Preflop continue frequency for a player with an unopened (full) range facing a raise. */
        fun preflopDefend(role: UnopenedRole, raiseToBb: Double, isShove: Boolean): Double = when {
            isShove && role == UnopenedRole.BIG_BLIND -> (3.5 / raiseToBb).coerceIn(0.05, 0.5)
            isShove -> (1.8 / raiseToBb).coerceIn(0.03, 0.25)
            role == UnopenedRole.BIG_BLIND -> (0.62 - 0.07 * raiseToBb).coerceIn(0.15, 0.55)
            role == UnopenedRole.SMALL_BLIND -> (0.24 - 0.025 * raiseToBb).coerceIn(0.05, 0.2)
            else -> (0.16 - 0.015 * raiseToBb).coerceIn(0.04, 0.13)
        }
    }
}

/**
 * Hero's range as opponents perceive it when hero bets: the hands a reasonable player would bet
 * with this size on this board. Used to judge how credible a bet is.
 */
internal class PerceivedRange private constructor(
    private val values: IntArray,      // sorted hand values of hero's perceived combos
    private val cumWeight: DoubleArray, // cumulative weights aligned with values
) {
    private val total = if (cumWeight.isEmpty()) 0.0 else cumWeight.last()

    /** Share of hero's perceived range that the hand [value] beats right now (ties half). */
    fun beats(value: Int): Double {
        if (total == 0.0) return 0.5
        var lo = 0; var hi = values.size
        while (lo < hi) { val m = (lo + hi) ushr 1; if (values[m] < value) lo = m + 1 else hi = m }
        val below = if (lo == 0) 0.0 else cumWeight[lo - 1]
        var hi2 = lo
        while (hi2 < values.size && values[hi2] == value) hi2++
        val equal = (if (hi2 == 0) 0.0 else cumWeight[hi2 - 1]) - below
        return (below + equal / 2) / total
    }

    /**
     * Weight share of [range] that continues: combos winning against at least [needed] of hero's
     * perceived range now, with draws credited for their chance to improve.
     */
    fun continueShare(range: Range, dead: Long, needed: Double, strength: BoardStrength): Double {
        val boardMask = strength.board.fold(0L) { m, c -> m or c.mask }
        var t = 0.0
        var cont = 0.0
        for (i in 0 until Combos.COUNT) {
            val w = range.weight(i)
            if (w <= 0 || Combos.mask[i] and dead != 0L) continue
            t += w
            var eq = beats(HandEvaluator.evaluateMask(Combos.mask[i] or boardMask))
            if (strength.board.size < 5 && strength.draw[i] > 0) eq = maxOf(eq, strength.draw[i] * 0.5)
            if (eq >= needed) cont += w
        }
        return if (t == 0.0) 0.0 else cont / t
    }

    companion object {
        fun forBet(heroRange: Range, strength: BoardStrength, dead: Long, sizeFrac: Double): PerceivedRange? {
            val boardMask = strength.board.fold(0L) { m, c -> m or c.mask }
            val valueT = 0.62 + 0.08 * sizeFrac.coerceIn(0.0, 1.5)
            val items = ArrayList<Pair<Int, Double>>()
            for (i in 0 until Combos.COUNT) {
                val w0 = heroRange.weight(i)
                if (w0 <= 0 || Combos.mask[i] and boardMask != 0L) continue
                val hs = strength.hs[i]
                val f = when {
                    hs >= valueT -> 1.0
                    strength.board.size < 5 && strength.draw[i] > 0 -> 0.65
                    hs >= valueT - 0.2 -> 0.35
                    else -> 0.12
                }
                items += HandEvaluator.evaluateMask(Combos.mask[i] or boardMask) to w0 * f
            }
            if (items.isEmpty()) return null
            items.sortBy { it.first }
            val values = IntArray(items.size) { items[it].first }
            val cum = DoubleArray(items.size)
            var acc = 0.0
            items.forEachIndexed { idx, p -> acc += p.second; cum[idx] = acc }
            return PerceivedRange(values, cum)
        }
    }
}
