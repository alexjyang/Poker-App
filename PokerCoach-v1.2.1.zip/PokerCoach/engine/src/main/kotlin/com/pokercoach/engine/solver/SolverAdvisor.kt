package com.pokercoach.engine.solver

import com.pokercoach.engine.analysis.OpponentProfile
import com.pokercoach.engine.analysis.RangeEstimator
import com.pokercoach.engine.card.Card
import com.pokercoach.engine.game.ActionType
import com.pokercoach.engine.game.HandEvent
import com.pokercoach.engine.game.HandSnapshot
import com.pokercoach.engine.game.LegalActions
import com.pokercoach.engine.game.PlayerAction
import com.pokercoach.engine.game.Street
import com.pokercoach.engine.range.Combos
import com.pokercoach.engine.range.Range

/** The solver's answer for one hand at one decision. */
data class SolverAdvice(
    val actions: List<SolverAction>,
    /** How often to take each action with this hand (sums to 1). */
    val frequencies: List<Double>,
    /** Expected chips of each action for this hand (relative to folding now = 0). */
    val values: List<Double>,
    val iterations: Int,
    /** Exploitability of the solution as a share of the pot, if measured. */
    val exploitability: Double?,
    /** The actor's street commitment when the spot was solved (to turn "adds" into bet totals). */
    val actorCommit: Long,
) {
    /** Street total ("raise to") for a bet/raise action. */
    fun totalFor(a: SolverAction): Long = actorCommit + Math.round(a.add)
}

/**
 * Builds a solvable spot from a live hand and runs the solver. Eligible spots: heads-up (exactly
 * two players left), on the turn or river, with the player to act still holding chips.
 * Ranges come from [RangeEstimator] on the public history (optionally shaped by reads), so the
 * solver never sees anyone's actual cards except the actor's own.
 */
object SolverAdvisor {

    fun eligible(view: HandSnapshot, actorSeat: Int): Boolean {
        if (view.street != Street.TURN && view.street != Street.RIVER) return false
        val live = view.seats.filter { !it.folded }
        if (live.size != 2) return false
        return view.seat(actorSeat).stack > 0
    }

    /**
     * Solves the spot for [actorSeat] holding [hole]. [extraSizes]: bet/raise street totals to add
     * at the root (e.g. the options a player is choosing between). Returns null if not eligible.
     */
    fun advise(
        view: HandSnapshot,
        history: List<HandEvent>,
        actorSeat: Int,
        hole: List<Card>,
        timeBudgetMs: Long,
        maxIterations: Int = 400,
        reads: Map<Int, OpponentProfile> = emptyMap(),
        extraSizes: List<Long> = emptyList(),
        measureExploitability: Boolean = false,
    ): SolverAdvice? {
        if (!eligible(view, actorSeat) || history.isEmpty()) return null
        val live = view.seats.filter { !it.folded }.map { it.seat }
        val seats = view.seats.map { it.seat }
        val n = seats.size
        val btn = seats.indexOf(view.buttonSeat)
        val order = List(n) { seats[(btn + 1 + it) % n] }.filter { it in live }
        val oop = order[0]
        val ip = order[1]
        val actor = if (actorSeat == oop) 0 else 1
        val bySeat = listOf(oop, ip)

        val est = RangeEstimator().estimate(history, reads)
        val combo = Combos.index(hole[0], hole[1])
        val ranges = bySeat.mapIndexed { i, seat ->
            val r = est.ranges[seat] ?: Range.full()
            if (i == actor) withOwnHand(r, combo) else r
        }

        val streetActs = history.filterIsInstance<HandEvent.ActionTaken>().filter { it.street == view.street }
        val raises = streetActs.count { it.type == ActionType.BET || it.type == ActionType.RAISE }
        val oopChecked = streetActs.lastOrNull()?.let { it.seat == oop && it.type == ActionType.CHECK } == true
        val me = view.seat(actorSeat)
        val commits = DoubleArray(2) { view.seat(bySeat[it]).streetCommit.toDouble() }
        val stacks = DoubleArray(2) { view.seat(bySeat[it]).stack.toDouble() }
        val base = if (view.street == Street.RIVER) SolverConfig.river() else SolverConfig.turn()
        val config = base.copy(rootBetAmounts = extraSizes.map { (it - me.streetCommit).toDouble() }.filter { it > 0 })
        val spot = SpotState(
            board = view.board,
            pot = view.pot.toDouble(),
            commits = commits,
            stacks = stacks,
            toAct = actor,
            raises = raises,
            otherChecked = actor == 1 && oopChecked && view.currentBet == 0L,
        )
        val solver = try { SubgameSolver(spot, ranges, config) } catch (e: IllegalArgumentException) { return null }
        val iterations = solver.solve(maxIterations, timeBudgetMs)
        val strategy = solver.rootStrategy(combo) ?: return null
        val values = solver.rootActionValues(combo) ?: return null
        return SolverAdvice(
            actions = solver.rootActions,
            frequencies = strategy.map { it.toDouble() },
            values = values.toList(),
            iterations = iterations,
            exploitability = if (measureExploitability) solver.exploitability() else null,
            actorCommit = me.streetCommit,
        )
    }

    /** Makes sure the actor's own hand is in its range (the estimate may have discarded it). */
    private fun withOwnHand(r: Range, combo: Int): Range {
        var heaviest = 0.0
        for (i in 0 until Combos.COUNT) heaviest = maxOf(heaviest, r.weight(i))
        val floor = maxOf(heaviest * 0.15, 1e-3)
        if (r.weight(combo) >= floor) return r
        return Range(DoubleArray(Combos.COUNT) { if (it == combo) floor else r.weight(it) })
    }

    /** Turns a solver action into a legal game action. */
    fun toPlayerAction(advice: SolverAdvice, action: SolverAction, legal: LegalActions): PlayerAction = when (action.kind) {
        SolverAction.Kind.FOLD -> if (legal.canCheck) PlayerAction.Check else PlayerAction.Fold
        SolverAction.Kind.CHECK -> if (legal.canCheck) PlayerAction.Check else PlayerAction.Call
        SolverAction.Kind.CALL -> if (legal.canCall) PlayerAction.Call else PlayerAction.Check
        SolverAction.Kind.ALL_IN -> when {
            legal.canRaise -> PlayerAction.BetOrRaise(legal.maxRaiseTo)
            legal.canCall -> PlayerAction.Call
            else -> PlayerAction.Check
        }
        SolverAction.Kind.BET, SolverAction.Kind.RAISE -> if (!legal.canRaise) {
            if (legal.canCall) PlayerAction.Call else PlayerAction.Check
        } else {
            PlayerAction.BetOrRaise(advice.totalFor(action).coerceIn(legal.minRaiseTo, legal.maxRaiseTo))
        }
    }
}
