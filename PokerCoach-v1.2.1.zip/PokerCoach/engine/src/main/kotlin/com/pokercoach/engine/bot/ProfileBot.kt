package com.pokercoach.engine.bot

import com.pokercoach.engine.analysis.EquityCalculator
import com.pokercoach.engine.analysis.OpponentProfile
import com.pokercoach.engine.solver.SolverAction
import com.pokercoach.engine.solver.SolverAdvisor
import com.pokercoach.engine.analysis.RangeEstimator
import com.pokercoach.engine.card.Card
import com.pokercoach.engine.card.CardMask
import com.pokercoach.engine.eval.HandCategory
import com.pokercoach.engine.eval.HandEvaluator
import com.pokercoach.engine.game.Chips
import com.pokercoach.engine.game.HandEvent
import com.pokercoach.engine.game.HandSnapshot
import com.pokercoach.engine.game.LegalActions
import com.pokercoach.engine.game.PlayerAction
import com.pokercoach.engine.game.Street
import com.pokercoach.engine.range.BoardStrength
import com.pokercoach.engine.range.Combos
import com.pokercoach.engine.range.HandClass
import com.pokercoach.engine.rng.SeededRandom
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToLong

/**
 * A bot whose style comes from a [BotProfile]. Every decision is driven by the numbers —
 * preflop hand rank vs. position-scaled ranges, postflop equity (vs. estimated ranges or random
 * hands, depending on skill) vs. pot odds — and the profile bends those numbers the way real
 * players do: loose players widen ranges, stations add "hope" to their equity, weak players
 * estimate equity noisily, aggressive players bet more of their strong hands and bluff more.
 *
 * Memory across hands: tilt after big losses, and opponent tendencies for adaptive profiles.
 * Randomness only picks between options the profile considers close; it is seeded, so a
 * session replays identically.
 */
class ProfileBot(
    val profile: BotProfile,
    seed: Long,
    private val iterations: Int = 500,
    /** Thinking time for the CFR solver on the turn (the river uses less). */
    private val solverBudgetMs: Long = 900,
) : Bot {
    override val styleLabel: String get() = profile.label

    private val rng = SeededRandom(seed)
    private val estimator = RangeEstimator()
    private val stats = OpponentStats()
    private var tiltLevel = 0.0

    /** Current tilt, 0 (calm) to 1 (steaming). Exposed for the UI/tests. */
    val tilt: Double get() = tiltLevel * profile.tilt

    override fun decide(view: HandSnapshot, seat: Int): PlayerAction = decide(view, seat, emptyList())

    override fun decide(view: HandSnapshot, seat: Int, history: List<HandEvent>): PlayerAction {
        val legal = requireNotNull(view.legalActions) { "Not this bot's turn" }
        require(legal.seat == seat)
        val hole = requireNotNull(view.seat(seat).holeCards) { "Bot must see its own cards" }
        val ctx = Context(view, seat, legal, hole, history)
        return if (view.street == Street.PREFLOP) preflop(ctx) else postflop(ctx)
    }

    override fun onHandComplete(history: List<HandEvent>, seat: Int) {
        val start = history.firstOrNull() as? HandEvent.HandStarted ?: return
        val ended = history.lastOrNull() as? HandEvent.HandEnded ?: return
        val bb = start.blinds.bigBlind
        val net = ended.netResults[seat] ?: 0L
        val startStack = start.players.firstOrNull { it.seat == seat }?.stack ?: return
        tiltLevel = when {
            net < 0 && (-net >= 25 * bb || -net * 2 >= startStack) -> min(1.0, tiltLevel + 0.5)
            net > 10 * bb -> tiltLevel * 0.5
            else -> tiltLevel * 0.8
        }
        if (profile.adaptiveness > 0) stats.record(history, seat)
    }

    private inner class Context(
        val view: HandSnapshot,
        val seat: Int,
        val legal: LegalActions,
        val hole: List<Card>,
        val history: List<HandEvent>,
    ) {
        val bb: Chips = view.blinds.bigBlind
        val me = view.seat(seat)
        val stackBb: Double = (me.stack + me.streetCommit).toDouble() / bb
        val opponents = view.seats.filter { it.seat != seat && !it.folded }
        val t = tilt

        // Profile values after tilt.
        val vpip = min(0.9, profile.vpip * (1 + 0.8 * t))
        val pfr = min(vpip, profile.pfr * (1 + 0.6 * t))
        val bluff = profile.bluff + 0.15 * t
        val callBias = profile.callBias + 0.08 * t
        val noise = profile.noise + 0.05 * t

        /** Players acting after this one preflop: 0 = BB, 1 = SB, 2 = button, 3 = cutoff... */
        val leftBehind: Int by lazy {
            val seats = view.seats.map { it.seat }
            val n = seats.size
            val btn = seats.indexOf(view.buttonSeat)
            if (n == 2) {
                if (seat == view.buttonSeat) 1 else 0
            } else {
                val utg = (btn + 3) % n
                val d = (seats.indexOf(seat) - utg + n) % n
                n - 1 - d
            }
        }
        val headsUpTable get() = view.seats.size == 2
        val inPosition: Boolean by lazy {
            val seats = view.seats.map { it.seat }
            val n = seats.size
            val btn = seats.indexOf(view.buttonSeat)
            val order = List(n) { seats[(btn + 1 + it) % n] }.filter { s -> s == seat || !view.seat(s).folded }
            order.last() == seat
        }
    }

    // ================================================================= preflop

    private fun preflop(c: Context): PlayerAction {
        if (profile.useSolver && c.stackBb >= 40 && c.history.isNotEmpty()) chartAction(c)?.let { return it }
        val legal = c.legal
        val cls = HandClass.of(c.hole[0], c.hole[1]).index
        val rank = PlayabilityRanking.rankPct(cls) // 0 = AA
        val bb = c.bb
        val raises = raisesSoFar(c)
        val posFactor = positionFactor(c)

        // Short stacks: push or fold (Beginners just keep limping/calling).
        if (c.stackBb <= 12 && profile.style != BotStyle.BEGINNER) {
            val pushPct = min(0.85, (if (raises == 0) c.pfr * posFactor * 1.6 else c.pfr * 0.8) * (1 + (12 - c.stackBb) / 10))
            return if (rank < pushPct) allIn(legal) else checkOrFold(legal)
        }

        if (raises == 0) {
            val limpers = c.view.seats.count { it.streetCommit == bb && it.seat != c.view.bigBlindSeat && it.seat != c.seat }
            val openPct = if (profile.gto) gtoOpenPct(c) else c.pfr * posFactor
            val playPct = if (profile.limps) max(openPct, c.vpip * posFactor) else openPct
            val slowplay = rank < 0.03 && rng.nextDouble() < profile.slowplay
            return when {
                rank < openPct && !slowplay && legal.canRaise -> {
                    val size = when {
                        profile.style == BotStyle.BEGINNER -> 3.0 + rng.nextInt(3)
                        c.leftBehind <= 2 || c.headsUpTable -> 2.5
                        else -> 3.0
                    }
                    raiseTo(c, ((size + limpers) * bb).roundToLong())
                }
                legal.canCheck -> PlayerAction.Check
                rank < playPct -> PlayerAction.Call
                else -> PlayerAction.Fold
            }
        }

        // Facing a raise (or more).
        val raiseToBb = c.view.currentBet.toDouble() / bb
        val price = (3.0 / raiseToBb).coerceIn(0.35, 1.2)
        val isBigBlind = c.seat == c.view.bigBlindSeat
        if (raises >= 2) return facingReraise(c, raises)
        val bigCall = legal.toCall >= (c.me.stack + c.me.streetCommit) * 0.3
        if (bigCall) return callOrFoldByEquity(c, preflop = true)

        val threeBetPct = if (profile.gto) (if (isBigBlind || c.leftBehind <= 1) 0.11 else 0.09)
        else c.pfr * profile.threeBetShare * (1 + 0.3 * c.t)
        // Continue ranges by seat. The big blind already has a chip in and closes the action, so it
        // defends wide (roughly 40-55% against a late-position min-raise); cold calls are narrower and
        // widen in position. Players already calling improve the price for everyone behind (overcalls).
        val looseFactor = c.vpip / 0.25
        val callersAlready = c.view.seats.count { it.seat != c.seat && !it.folded && it.streetCommit == c.view.currentBet } - 1
        val bbPrice = (2.5 / raiseToBb).coerceIn(0.3, 1.2)
        var continuePct = when {
            profile.gto -> (if (isBigBlind) 0.45 * bbPrice else if (c.inPosition) 0.18 * price else 0.12 * price)
            isBigBlind -> 0.42 * bbPrice * kotlin.math.sqrt(looseFactor)
            c.seat == c.view.smallBlindSeat -> 0.12 * price * Math.pow(looseFactor, 1.3)
            c.leftBehind in 2..3 -> 0.15 * price * Math.pow(looseFactor, 1.3)  // button / cutoff: in position
            else -> 0.09 * price * Math.pow(looseFactor, 1.3)
        }
        // Recreational players "want to see a flop": they call raises far wider than regulars.
        continuePct += 0.05 * callersAlready.coerceAtLeast(0)
        continuePct += c.callBias * 1.5
        val bluffBand = rank >= continuePct && rank < continuePct + 0.08 && c.hole[0].suit == c.hole[1].suit
        val bluff3b = bluffBand && legal.canRaise && rng.nextDouble() < (if (profile.gto) 0.3 else c.bluff * 1.5)
        val size = if (c.inPosition) 3.0 else 3.8
        return when {
            (rank < threeBetPct || bluff3b) && legal.canRaise -> raiseTo(c, (c.view.currentBet * size).roundToLong())
            rank < continuePct -> PlayerAction.Call
            legal.canCheck -> PlayerAction.Check
            else -> PlayerAction.Fold
        }
    }

    /**
     * Facing a 3-bet, 4-bet or more. Real players don't just fold or shove here: the opener
     * calls many 3-bets with pairs and good suited hands, 4-bets a small value range (plus the
     * odd bluff with a suited wheel ace), and only gets it all in with the very top.
     */
    private fun facingReraise(c: Context, raises: Int): PlayerAction {
        val legal = c.legal
        val label = HandClass.of(c.hole[0], c.hole[1]).label
        val rank = PlayabilityRanking.rankPct(HandClass.of(c.hole[0], c.hole[1]).index)
        val iRaised = if (c.history.isNotEmpty()) c.history.any {
            it is HandEvent.ActionTaken && it.street == Street.PREFLOP && it.seat == c.seat &&
                (it.type == com.pokercoach.engine.game.ActionType.RAISE || it.type == com.pokercoach.engine.game.ActionType.BET)
        } else c.me.streetCommit > c.bb
        val deep = c.stackBb >= 60
        val passive = profile.aggression < 0.4
        val loose = c.callBias >= 0.07 || c.t > 0.3
        val aggressive = profile.aggression >= 0.6
        val fourBetTo = (c.view.currentBet * 2.25).roundToLong()

        // A 5-bet or more is almost always all-in: decide by equity against their (very strong) range.
        if (raises >= 4) return callOrFoldByEquity(c, preflop = true)

        if (raises == 3) {
            // Facing a 4-bet: get it in with the very top, call a little when deep, fold the rest.
            return when {
                label in PREMIUM -> if (passive && rng.nextDouble() < 0.5) PlayerAction.Call else allIn(legal)
                label in CALL_4BET && aggressive && rng.nextDouble() < 0.35 -> allIn(legal)
                label in CALL_4BET && (deep || loose) -> PlayerAction.Call
                loose && label in CALL_3BET && rng.nextDouble() < 0.3 -> PlayerAction.Call
                legal.canCheck -> PlayerAction.Check
                else -> PlayerAction.Fold
            }
        }

        // Facing a 3-bet.
        val extraCalls = if (loose) rank < c.vpip * 0.3 + c.callBias else false
        return if (iRaised) {
            when {
                label in PREMIUM && legal.canRaise -> if (passive && rng.nextDouble() < 0.4) PlayerAction.Call else raiseTo(c, fourBetTo)
                label in FOURBET_VALUE && legal.canRaise && !passive && rng.nextDouble() < (if (profile.gto) 0.7 else 0.6) -> raiseTo(c, fourBetTo)
                label in FOURBET_BLUFF && aggressive && legal.canRaise && rng.nextDouble() < (if (profile.gto) 0.4 else c.bluff * 1.5) -> raiseTo(c, fourBetTo)
                label in FOURBET_VALUE || label in CALL_3BET || extraCalls -> PlayerAction.Call
                legal.canCheck -> PlayerAction.Check
                else -> PlayerAction.Fold
            }
        } else {
            // Cold: someone raised and someone else 3-bet before we acted. Very tight.
            when {
                label in PREMIUM && legal.canRaise && !passive -> raiseTo(c, fourBetTo)
                label in PREMIUM || label in COLD_CALL_3BET || (loose && extraCalls && rng.nextDouble() < 0.4) -> PlayerAction.Call
                legal.canCheck -> PlayerAction.Check
                else -> PlayerAction.Fold
            }
        }
    }

    /** Players acting after [seat] preflop (0 = big blind, 1 = small blind, 2 = button...). */
    private fun leftBehindOf(c: Context, seat: Int): Int {
        val seats = c.view.seats.map { it.seat }
        val n = seats.size
        val btn = seats.indexOf(c.view.buttonSeat)
        if (n == 2) return if (seat == c.view.buttonSeat) 1 else 0
        val utg = (btn + 3) % n
        return n - 1 - ((seats.indexOf(seat) - utg + n) % n)
    }

    /**
     * Preflop from the CFR charts (see [PreflopCharts]) for unlimped pots at 40+ big blinds:
     * first in, facing an open, the opener facing a 3-bet, the 3-bettor facing a 4-bet, and the
     * 4-bettor facing an all-in. Returns null for anything the charts don't cover.
     */
    private fun chartAction(c: Context): PlayerAction? {
        val legal = c.legal
        val n = c.view.seats.size
        val hu = n == 2
        val cls = HandClass.of(c.hole[0], c.hole[1]).index
        val pre = c.history.filterIsInstance<HandEvent.ActionTaken>().filter { it.street == Street.PREFLOP }
        val raisers = pre.filter { it.type == com.pokercoach.engine.game.ActionType.RAISE || it.type == com.pokercoach.engine.game.ActionType.BET }.map { it.seat }
        val firstRaise = pre.indexOfFirst { it.type == com.pokercoach.engine.game.ActionType.RAISE || it.type == com.pokercoach.engine.game.ActionType.BET }
        // Limped or cold-called pots aren't in the charts.
        if (pre.take(if (firstRaise < 0) pre.size else firstRaise).any { it.type == com.pokercoach.engine.game.ActionType.CALL }) return null
        if (pre.any { it.type == com.pokercoach.engine.game.ActionType.CALL }) return null
        fun pos(seat: Int): PreflopCharts.Pos = PreflopCharts.position(leftBehindOf(c, seat), n) ?: PreflopCharts.Pos.UTG
        val me = PreflopCharts.position(c.leftBehind, n) ?: return null
        val bb = c.bb
        // Earlier seats at a full-ring table play tighter than a 6-max UTG.
        val tighten = when { hu -> 1.0; c.leftBehind >= 8 -> 0.6; c.leftBehind == 7 -> 0.75; c.leftBehind == 6 -> 0.9; else -> 1.0 }

        fun pick(vararg options: Pair<Double, () -> PlayerAction>): PlayerAction {
            var probs = options.map { maxOf(0.0, it.first) }
            if (profile.solverSharpen != 1.0) probs = probs.map { Math.pow(it, profile.solverSharpen) }
            val total = probs.sum()
            if (total <= 0) return if (legal.canCheck) PlayerAction.Check else PlayerAction.Fold
            var x = rng.nextDouble() * total
            for (i in probs.indices) { x -= probs[i]; if (x <= 0) return options[i].second() }
            return options.last().second()
        }
        val fold: () -> PlayerAction = { if (legal.canCheck) PlayerAction.Check else PlayerAction.Fold }
        val call: () -> PlayerAction = { if (legal.canCall) PlayerAction.Call else PlayerAction.Check }

        return when (raisers.size) {
            0 -> {
                val f = (PreflopCharts.open(me, cls, hu) ?: return null) * tighten
                val size = if (me == PreflopCharts.Pos.SB && !hu) 3.0 else 2.5
                pick(f to { raiseTo(c, (size * bb).roundToLong()) }, (1 - f) to fold)
            }
            1 -> {
                val opener = pos(raisers[0])
                val (cl, tb) = PreflopCharts.vsOpen(me, opener, cls, hu) ?: return null
                // Shark: 3-bet loose openers more.
                val openerVpip = stats.of(c.view.seat(raisers[0]).playerId)?.vpipRate
                val exploit = if (profile.adaptiveness >= 0.5 && openerVpip != null && openerVpip > 0.35) 1.3 else 1.0
                // Postflop order: SB, BB, then UTG..BTN; heads-up the button (small blind) acts last.
                fun rank(p: PreflopCharts.Pos) = if (hu) (if (p == PreflopCharts.Pos.SB) 1 else 0) else when (p) {
                    PreflopCharts.Pos.SB -> 0; PreflopCharts.Pos.BB -> 1; else -> p.ordinal + 2
                }
                val meIp = rank(me) > rank(opener)
                val threeTo = (c.view.currentBet * (if (meIp) 3.0 else 4.0)).roundToLong()
                pick((tb * exploit) to { raiseTo(c, threeTo) }, cl to call, (1 - cl - tb).coerceAtLeast(0.0) to fold)
            }
            2 -> {
                if (raisers[0] != c.seat) return null
                val threeBettor = pos(raisers[1])
                val (cl, fb) = PreflopCharts.vsThreeBet(me, threeBettor, cls, hu) ?: return null
                pick(fb to { raiseTo(c, (c.view.currentBet * 2.25).roundToLong()) }, cl to call, (1 - cl - fb).coerceAtLeast(0.0) to fold)
            }
            3 -> {
                if (raisers[1] != c.seat) return null
                val opener = pos(raisers[0])
                val (cl, jam) = PreflopCharts.vsFourBet(me, opener, cls, hu) ?: return null
                pick(jam to { allIn(legal) }, cl to call, (1 - cl - jam).coerceAtLeast(0.0) to fold)
            }
            4 -> {
                if (raisers[2] != c.seat) return null
                val jammer = pos(raisers[3])
                val cl = PreflopCharts.vsJam(me, jammer, cls, hu) ?: return null
                pick(cl to call, (1 - cl) to fold)
            }
            else -> null
        }
    }

    private fun raisesSoFar(c: Context): Int {
        if (c.history.isNotEmpty()) {
            return c.history.count {
                it is HandEvent.ActionTaken && it.street == Street.PREFLOP &&
                    (it.type == com.pokercoach.engine.game.ActionType.RAISE || it.type == com.pokercoach.engine.game.ActionType.BET)
            }
        }
        // Without history, infer from the bet size.
        val bb = c.bb
        return when {
            c.view.currentBet <= bb -> 0
            c.view.currentBet <= bb * 5 -> 1
            else -> 2
        }
    }

    /** Scales the baseline (6-max middle position) range by position and table size. */
    private fun positionFactor(c: Context): Double {
        if (c.headsUpTable) return if (c.leftBehind == 1) 3.2 else 1.6
        return when (c.leftBehind) {
            0 -> 0.9   // big blind (vs limps)
            1 -> 1.5   // small blind
            2 -> 1.9   // button
            3 -> 1.25  // cutoff
            4 -> 1.0
            5 -> 0.8
            else -> 0.65
        }
    }

    /** Solver-like opening frequencies by position (raise-or-fold). */
    private fun gtoOpenPct(c: Context): Double {
        if (c.headsUpTable) return if (c.leftBehind == 1) 0.80 else 0.30
        return when (c.leftBehind) {
            0 -> 0.30
            1 -> 0.40
            2 -> 0.44
            3 -> 0.27
            4 -> 0.21
            5 -> 0.17
            6 -> 0.14
            7 -> 0.12
            else -> 0.11
        }
    }

    // ================================================================= postflop

    private fun postflop(c: Context): PlayerAction {
        if (profile.useSolver && solverBudgetMs > 0 && c.history.isNotEmpty() && SolverAdvisor.eligible(c.view, c.seat)) {
            solverAction(c)?.let { return it }
        }
        val legal = c.legal
        val board = c.view.board
        val pot = c.view.pot
        val eqRaw = equity(c)
        var eq = (eqRaw + (rng.nextDouble() * 2 - 1) * c.noise).coerceIn(0.0, 1.0)

        val made = HandEvaluator.evaluate(c.hole + board)
        val strength = BoardStrength(board)
        val combo = Combos.index(c.hole[0], c.hole[1])
        val hasDraw = board.size < 5 && strength.draw[combo] > 0
        // Overvaluing top pair is a leak for bets and single calls, but even casual players slow down
        // when they get raised.
        val facingRaise = raisesOnStreet(c) >= 1 && legal.toCall > 0
        if (profile.overvaluesPairs && !facingRaise && isTopPairOrBetter(c.hole, board, made.category)) eq = max(eq, 0.70)

        // Adaptation to the opponents still in the hand.
        var bluff = c.bluff
        var callBias = c.callBias
        var valueT = if (profile.gto) 0.60 else 0.64 - (profile.aggression - 0.5) * 0.1
        if (profile.adaptiveness > 0) {
            val a = profile.adaptiveness
            val ids = c.opponents.map { it.playerId }
            val fold = ids.mapNotNull { stats.of(it)?.foldToBet }.average().takeIf { !it.isNaN() }
            val af = ids.mapNotNull { stats.of(it)?.aggressionFactor }.average().takeIf { !it.isNaN() }
            if (fold != null) {
                if (fold > 0.55) bluff *= 1 + a * (fold - 0.55) * 4          // they fold too much: bluff more
                if (fold < 0.35) { bluff *= 1 - 0.6 * a; valueT -= 0.05 * a } // stations: bluff less, value thinner
            }
            if (af != null) {
                if (af > 2.5) callBias += 0.05 * a                            // maniac: call down lighter
                if (af < 1.0) callBias -= 0.05 * a                            // passive: respect their bets
            }
        }
        val multiwayFactor = if (c.opponents.size <= 1) 1.0 else 0.35
        val positionBoost = if (c.inPosition) 1.2 else 0.8
        val hs = strength.hs[combo]
        val extraOpponents = (c.opponents.size - 1).coerceAtLeast(0)
        // Stack-to-pot ratio: how many pots are still behind. Deep = one pair isn't worth stacks.
        val effStack = min(c.me.stack, c.opponents.maxOfOrNull { it.stack } ?: c.me.stack)
        val spr = effStack.toDouble() / max(1L, pot)
        val raisesThisStreet = raisesOnStreet(c)

        if (legal.toCall == 0L) {
            // Checked to us (or we act first).
            val size = if (profile.gto) gtoSize(board) else profile.valueSize
            val bluffP = if (profile.gto) (size / (1 + 2 * size)) * 0.8 else bluff * multiwayFactor * positionBoost
            return when {
                eq >= valueT + 0.04 * extraOpponents && legal.canRaise && rng.nextDouble() < profile.aggression + 0.25 ->
                    raiseTo(c, (pot * size).roundToLong())
                hasDraw && eq < valueT && legal.canRaise && rng.nextDouble() < min(0.8, bluffP * 2) ->
                    raiseTo(c, (pot * (if (profile.gto) size else profile.bluffSize)).roundToLong())
                eq < 0.30 && legal.canRaise && rng.nextDouble() < bluffP ->
                    raiseTo(c, (pot * (if (profile.gto) size else profile.bluffSize)).roundToLong())
                else -> PlayerAction.Check
            }
        }

        // Facing a bet.
        val required = legal.toCall.toDouble() / (pot + legal.toCall)
        // Players reading ranges already account for the bettor's strength; others discount by bet size.
        val betFrac = legal.toCall.toDouble() / max(1, pot - legal.toCall)
        // (A raise says even more: non-readers discount their "vs random hands" estimate a lot more.)
        val discount = if (profile.readsRanges) 0.0 else 0.06 * min(betFrac, 1.5) + (if (raisesOnStreet(c) >= 1) 0.15 else 0.0)
        val effEq = eq + (if (facingRaise) callBias * 0.5 else callBias) - discount
        val allInCall = legal.callIsAllIn
        // Reverse implied odds: a medium hand facing a raise with deep stacks is usually behind and
        // faces more bets later, so it needs better than the bare pot odds to continue.
        val reverseImplied = if (facingRaise && spr > 3 && hs < 0.85) (if (profile.style == BotStyle.BEGINNER) 0.03 else 0.07) else 0.0

        // Raising: a first raise needs a strong made hand (or a low SPR); re-raising a raise needs
        // a near-nut hand. This stops raise wars where both players shove one pair.
        val raiseT = 0.80 - (profile.aggression - 0.5) * 0.1 + 0.04 * extraOpponents
        val strongEnoughToRaise = when {
            raisesThisStreet >= 1 -> hs >= 0.95 || (eq >= 0.9 && hs >= 0.88)
            profile.overvaluesPairs -> hs >= 0.7 || spr <= 3      // casual leak: raises top pair
            else -> hs >= 0.82 || spr <= 3
        }
        // Calling off a big part of the stack when deep needs more than one pair (except for players
        // whose leak is exactly that).
        val commitsStack = legal.toCall >= c.me.stack * 0.45
        val onePairDeep = commitsStack && spr > 4 && hs < 0.85 && made.category <= HandCategory.PAIR
        val stackOffMargin = if (onePairDeep && !profile.overvaluesPairs) 0.08 else 0.0
        return when {
            eq >= raiseT && strongEnoughToRaise && legal.canRaise && rng.nextDouble() < profile.aggression ->
                raiseTo(c, (c.view.currentBet * 2.8).roundToLong())
            raisesThisStreet == 0 && hasDraw && effEq >= required - 0.08 && legal.canRaise && spr > 2 &&
                rng.nextDouble() < bluff * profile.aggression ->
                raiseTo(c, (c.view.currentBet * 2.8).roundToLong())
            effEq >= required + stackOffMargin + reverseImplied + (if (allInCall) 0.02 else 0.0) - (if (profile.gto) 0.02 else 0.0) -> PlayerAction.Call
            else -> PlayerAction.Fold
        }
    }

    /** Raises already made on the current street (from the public history). */
    private fun raisesOnStreet(c: Context): Int {
        if (c.history.isEmpty()) return if (c.view.currentBet > 0 && c.legal.toCall < c.view.currentBet && c.me.streetCommit > 0) 1 else 0
        return c.history.count {
            it is HandEvent.ActionTaken && it.street == c.view.street && it.type == com.pokercoach.engine.game.ActionType.RAISE
        }
    }

    /**
     * Heads-up on the turn or river: solve the spot with CFR (both ranges estimated from the
     * betting) and play the solved strategy for this hand, sampled by its frequencies.
     */
    private fun solverAction(c: Context): PlayerAction? {
        val reads = if (profile.adaptiveness > 0) c.opponents.associate { o ->
            o.seat to OpponentProfile.withObservations(OpponentProfile.BALANCED, stats.of(o.playerId))
        } else emptyMap()
        val budget = if (c.view.street == Street.RIVER) solverBudgetMs / 3 else solverBudgetMs
        val advice = SolverAdvisor.advise(c.view, c.history, c.seat, c.hole, budget, reads = reads) ?: return null
        var probs = advice.frequencies.map { maxOf(0.0, it) }
        if (profile.solverSharpen != 1.0) probs = probs.map { Math.pow(it, profile.solverSharpen) }
        // Shark: against players who fold too much, lean towards the aggressive options.
        if (profile.adaptiveness >= 0.5) {
            val fold = c.opponents.mapNotNull { stats.of(it.playerId)?.foldToBet }.firstOrNull()
            if (fold != null && fold > 0.55) {
                val boost = 1 + (fold - 0.55) * 3 * profile.adaptiveness
                probs = probs.mapIndexed { i, pr ->
                    val k = advice.actions[i].kind
                    if (k == SolverAction.Kind.BET || k == SolverAction.Kind.RAISE || k == SolverAction.Kind.ALL_IN) pr * boost else pr
                }
            }
        }
        val total = probs.sum()
        if (total <= 0) return null
        var x = rng.nextDouble() * total
        var pick = probs.lastIndex
        for (i in probs.indices) { x -= probs[i]; if (x <= 0) { pick = i; break } }
        return SolverAdvisor.toPlayerAction(advice, advice.actions[pick], c.legal)
    }

    private fun equity(c: Context): Double {
        val opponents = c.opponents.size.coerceAtLeast(1)
        if (profile.readsRanges && c.history.isNotEmpty()) {
            val est = estimator.estimate(c.history)
            val dead = CardMask.of(c.hole + c.view.board)
            val ranges = c.opponents.mapNotNull { est.ranges[it.seat] }.map { r ->
                if (r.totalWeight(dead) > 1e-9) r else com.pokercoach.engine.range.Range.full()
            }
            if (ranges.isNotEmpty()) {
                return EquityCalculator.vsRanges(c.hole, c.view.board, ranges, iterations, rng).equity
            }
        }
        return QuickEquity.vsRandom(c.hole, c.view.board, opponents, iterations, rng)
    }

    private fun callOrFoldByEquity(c: Context, preflop: Boolean): PlayerAction {
        val legal = c.legal
        val eq = (equity(c) + (rng.nextDouble() * 2 - 1) * c.noise).coerceIn(0.0, 1.0)
        val required = legal.toCall.toDouble() / (c.view.pot + legal.toCall)
        val strong = eq > 0.62 && legal.canRaise && rng.nextDouble() < profile.aggression
        return when {
            strong -> allIn(legal)
            eq + c.callBias >= required + (if (preflop) 0.03 else 0.0) -> PlayerAction.Call
            legal.canCheck -> PlayerAction.Check
            else -> PlayerAction.Fold
        }
    }

    private fun isTopPairOrBetter(hole: List<Card>, board: List<Card>, category: HandCategory): Boolean {
        if (category > HandCategory.PAIR) return true
        if (category != HandCategory.PAIR) return false
        val topBoard = board.maxOf { it.rank.ordinal }
        val pairRank = hole.firstOrNull { h -> board.any { it.rank == h.rank } }?.rank?.ordinal
        val overpair = hole[0].rank == hole[1].rank && hole[0].rank.ordinal > topBoard
        return overpair || pairRank == topBoard
    }

    /** Small bets on dry boards (range advantage), big bets on wet boards. */
    private fun gtoSize(board: List<Card>): Double {
        val suits = board.groupingBy { it.suit }.eachCount().values.maxOrNull() ?: 0
        val ranks = board.map { it.rank.ordinal }.distinct().sorted()
        val paired = ranks.size < board.size
        val connected = ranks.zipWithNext().count { (a, b) -> b - a <= 2 }
        val wet = suits >= 2 && connected >= 1 || connected >= 2
        return when {
            paired && !wet -> 0.33
            wet -> 0.75
            else -> 0.5
        }
    }

    // ================================================================= sizing helpers

    /**
     * Bets/raises to [target], going all-in only when the raise would leave so little behind
     * (under a third of the pot after the raise) that the player is committed anyway.
     */
    private fun raiseTo(c: Context, target: Chips): PlayerAction {
        val legal = c.legal
        if (!legal.canRaise) return if (legal.canCheck) PlayerAction.Check else PlayerAction.Call
        val to = target.coerceIn(legal.minRaiseTo, legal.maxRaiseTo)
        val potAfter = c.view.pot + (to - c.me.streetCommit)
        val behind = legal.maxRaiseTo - to
        return if (behind * 3 < potAfter) PlayerAction.BetOrRaise(legal.maxRaiseTo) else PlayerAction.BetOrRaise(to)
    }

    private companion object {
        val PREMIUM = setOf("AA", "KK")
        val FOURBET_VALUE = setOf("AA", "KK", "QQ", "AKs", "AKo")
        val FOURBET_BLUFF = setOf("A5s", "A4s", "A3s")
        val CALL_3BET = setOf("JJ", "TT", "99", "88", "77", "AQs", "AJs", "ATs", "KQs", "KJs", "QJs", "JTs", "T9s", "AQo")
        val COLD_CALL_3BET = setOf("QQ", "JJ", "AKs", "AKo", "AQs")
        val CALL_4BET = setOf("QQ", "AKs", "AKo")
    }

    private fun allIn(legal: LegalActions): PlayerAction = when {
        legal.canRaise -> PlayerAction.BetOrRaise(legal.maxRaiseTo)
        legal.canCall -> PlayerAction.Call
        else -> PlayerAction.Check
    }

    private fun checkOrFold(legal: LegalActions) = if (legal.canCheck) PlayerAction.Check else PlayerAction.Fold
}
