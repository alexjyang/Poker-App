package com.pokercoach.engine.training

import com.pokercoach.engine.analysis.Grade
import kotlin.math.roundToInt

/** Points per decision, like chess apps' accuracy: Best 100 … Blunder 0. */
object DecisionScore {
    fun of(grade: Grade): Int = when (grade) {
        Grade.BEST -> 100
        Grade.GOOD -> 85
        Grade.INACCURACY -> 55
        Grade.MISTAKE -> 25
        Grade.BLUNDER -> 0
    }
}

object Accuracy {
    /** Average decision score (0–100), or null with no decisions. */
    fun of(grades: List<Grade>): Int? =
        if (grades.isEmpty()) null else grades.map { DecisionScore.of(it) }.average().roundToInt()
}

/**
 * A skill rating from recent decision quality: an exponential moving average of decision scores
 * (each new decision counts ~4%, so roughly the last 25 decisions matter most), mapped to a
 * familiar 400–2400 scale. Everyone starts at 1200.
 */
object SkillRating {
    const val START = 1200
    private const val ALPHA = 0.04

    private fun toRating(avgScore: Double) = 400 + 20 * avgScore
    private val startScore = (START - 400) / 20.0

    /** Rating after each decision, oldest first. */
    fun series(grades: List<Grade>): List<Int> {
        var ema = startScore
        return grades.map { g ->
            ema += ALPHA * (DecisionScore.of(g) - ema)
            toRating(ema).roundToInt()
        }
    }

    fun current(grades: List<Grade>): Int = series(grades).lastOrNull() ?: START

    fun title(rating: Int): String = when {
        rating < 1100 -> "Beginner"
        rating < 1400 -> "Recreational"
        rating < 1700 -> "Solid"
        rating < 1950 -> "Strong"
        else -> "Shark"
    }
}
