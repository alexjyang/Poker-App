package com.pokercoach.engine.solver

import com.pokercoach.engine.card.Card
import com.pokercoach.engine.card.CardMask
import com.pokercoach.engine.eval.HandEvaluator
import com.pokercoach.engine.range.Combos
import com.pokercoach.engine.range.Range
import kotlin.math.max
import kotlin.math.pow

/**
 * Bet sizes the solver may use. Bets are fractions of the pot; raises are fractions of the pot
 * after calling. All-in is added when the stack behind is small compared with the pot.
 */
data class SolverConfig(
    val betSizes: List<Double> = listOf(0.33, 0.75),
    val raiseSizes: List<Double> = listOf(0.75),
    val maxRaises: Int = 2,
    /** Include an all-in option when the stack behind is at most this many pots. */
    val allInMaxSpr: Double = 2.5,
    /** Extra bet sizes (in chips) to offer at the root only, e.g. the sizes a player actually has. */
    val rootBetAmounts: List<Double> = emptyList(),
    /** Sizes used on the river when solving from the turn (a leaner tree keeps turn solves fast). */
    val riverConfig: SolverConfig? = null,
    /** Hands whose weight is below this share of the heaviest hand are dropped (speed). */
    val minWeightShare: Double = 0.05,
    /**
     * Public chance sampling: river cards visited per iteration when solving from the turn
     * (0 = all). Unbiased; each iteration becomes several times cheaper.
     */
    val chanceSample: Int = 0,
) {
    companion object {
        /** River spot: two bet sizes, a raise size, up to two raises. */
        fun river() = SolverConfig()

        /**
         * Turn spot: on the turn one bet size plus all-in, raises all-in only; the river inside it is
         * simplified to bet ¾ pot / check and call / fold (the real river is solved in full when it
         * comes). Measured: ~1% exploitability after ~90 iterations on wide ranges.
         */
        fun turn() = SolverConfig(
            betSizes = listOf(0.66), raiseSizes = emptyList(), maxRaises = 1, allInMaxSpr = 3.0,
            riverConfig = SolverConfig(betSizes = listOf(0.75), raiseSizes = emptyList(), maxRaises = 0, allInMaxSpr = 0.0),
            minWeightShare = 0.10,
        )
    }
}

/** An action in the solver's game tree. [add] = chips the actor puts in with it. */
data class SolverAction(val kind: Kind, val add: Double) {
    enum class Kind { FOLD, CHECK, CALL, BET, RAISE, ALL_IN }
}

/**
 * A heads-up spot on the turn or river, at the moment [toAct] must decide.
 * Player 0 is out of position (acts first on each street), player 1 in position.
 * [pot] includes everything already in the middle, including this street's bets ([commits]).
 */
data class SpotState(
    val board: List<Card>,
    val pot: Double,
    val commits: DoubleArray,
    val stacks: DoubleArray,
    val toAct: Int,
    val raises: Int = 0,
    val otherChecked: Boolean = false,
) {
    init {
        require(board.size == 4 || board.size == 5) { "The solver handles turn and river spots" }
    }
}

/**
 * Discounted CFR (Brown & Sandholm, 2019: alpha 1.5, beta 0, gamma 2) over a heads-up turn or
 * river subgame, vectorized over every hand in each player's range — the same family of
 * algorithms behind Libratus and Pluribus, sized for a phone.
 *
 * Exact where it matters: every combination of hands is compared at showdown with correct card
 * removal (a player can't hold a card the opponent or the board holds), in O(n log n) per
 * showdown via sorted sweeps. Simplifications: a small set of bet sizes, a cap on raises, and
 * after an all-in on the turn the river is dealt out without further betting.
 */
class SubgameSolver(
    val spot: SpotState,
    ranges: List<Range>,
    val config: SolverConfig = SolverConfig(),
) {
    // ------------------------------------------------------------------ hands

    private val boardMask = CardMask.of(spot.board)
    /** Combo ids in each player's range (weight > 0, not using a board card). */
    val hands: Array<IntArray>
    private val initialWeight: Array<FloatArray>
    private val handIndex: Array<IntArray> // combo id -> index in hands[p], or -1

    init {
        require(ranges.size == 2)
        val h = Array(2) { IntArray(0) }
        val w = Array(2) { FloatArray(0) }
        for (p in 0..1) {
            val ids = ArrayList<Int>()
            val ws = ArrayList<Float>()
            var heaviest = 0.0
            for (c in 0 until Combos.COUNT) if (Combos.mask[c] and boardMask == 0L) heaviest = maxOf(heaviest, ranges[p].weight(c))
            val floor = heaviest * config.minWeightShare
            for (c in 0 until Combos.COUNT) {
                val weight = ranges[p].weight(c)
                if (weight <= 0.0 || weight < floor || Combos.mask[c] and boardMask != 0L) continue
                ids += c
                ws += weight.toFloat()
            }
            require(ids.isNotEmpty()) { "Player $p has an empty range on this board" }
            h[p] = ids.toIntArray()
            w[p] = ws.toFloatArray()
        }
        hands = h
        initialWeight = w
        handIndex = Array(2) { p -> IntArray(Combos.COUNT) { -1 }.also { arr -> hands[p].forEachIndexed { i, c -> arr[c] = i } } }
    }

    // Flat per-player card data for the hot loops.
    private val c1 = Array(2) { p -> IntArray(hands[p].size) { Combos.card1[hands[p][it]] } }
    private val c2 = Array(2) { p -> IntArray(hands[p].size) { Combos.card2[hands[p][it]] } }
    private val hmask = Array(2) { p -> LongArray(hands[p].size) { Combos.mask[hands[p][it]] } }

    // ------------------------------------------------------------------ tree

    private sealed class Node
    private class PlayerNode(val player: Int, val actions: List<SolverAction>, val children: Array<Node>, val slot: Int) : Node()
    private class ChanceNode(val cards: IntArray, val children: Array<Node>) : Node()
    private class FoldNode(val folder: Int, val potTotal: Float, val added: FloatArray) : Node()
    private class ShowdownNode(val potTotal: Float, val added: FloatArray, val boardKey: Int) : Node()

    private val playerNodes = ArrayList<PlayerNode>()
    private lateinit var regrets: Array<FloatArray>
    private lateinit var strategySum: Array<FloatArray>
    private val root: Node

    private data class BState(
        val board: List<Int>, val pot: Double, val c: DoubleArray, val st: DoubleArray, val toAct: Int,
        val raises: Int, val otherChecked: Boolean, val added: DoubleArray, val atRoot: Boolean,
    )

    init {
        root = build(
            BState(spot.board.map { it.id }, spot.pot, spot.commits.copyOf(), spot.stacks.copyOf(), spot.toAct,
                spot.raises, spot.otherChecked, DoubleArray(2), atRoot = true),
        )
        regrets = Array(playerNodes.size) { i -> FloatArray(hands[playerNodes[i].player].size * playerNodes[i].actions.size) }
        strategySum = Array(playerNodes.size) { i -> FloatArray(hands[playerNodes[i].player].size * playerNodes[i].actions.size) }
    }

    /** The actions available at the root (the decision being solved). */
    val rootActions: List<SolverAction> get() = (root as PlayerNode).actions

    private fun endStreet(s: BState, pot: Double, added: DoubleArray, st: DoubleArray): Node {
        val allIn = st[0] <= 1e-9 || st[1] <= 1e-9
        if (s.board.size == 5) return ShowdownNode(pot.toFloat(), added.toFloatArray(), s.board.last())
        // Turn finished: deal the river.
        val used = s.board.fold(0L) { m, id -> m or (1L shl id) }
        val cards = (0 until 52).filter { used and (1L shl it) == 0L }.toIntArray()
        val children = Array(cards.size) { i ->
            val board5 = s.board + cards[i]
            if (allIn) {
                ShowdownNode(pot.toFloat(), added.toFloatArray(), cards[i])
            } else {
                build(BState(board5, pot, DoubleArray(2), st.copyOf(), 0, 0, false, added.copyOf(), atRoot = false))
            }
        }
        return ChanceNode(cards, children)
    }

    private fun cfgFor(s: BState): SolverConfig =
        if (spot.board.size == 4 && s.board.size == 5) config.riverConfig ?: config else config

    private fun build(s: BState): Node {
        val config = cfgFor(s)
        val me = s.toAct
        val opp = 1 - me
        val toCall = s.c[opp] - s.c[me]
        val actions = ArrayList<SolverAction>()
        val kids = ArrayList<Node>()

        fun after(add: Double, kind: SolverAction.Kind): BState {
            val c = s.c.copyOf(); val st = s.st.copyOf(); val added = s.added.copyOf()
            c[me] += add; st[me] -= add; added[me] += add
            return s.copy(pot = s.pot + add, c = c, st = st, added = added, toAct = opp,
                raises = if (kind == SolverAction.Kind.BET || kind == SolverAction.Kind.RAISE || kind == SolverAction.Kind.ALL_IN) s.raises + 1 else s.raises,
                otherChecked = false, atRoot = false)
        }

        if (toCall <= 1e-9) {
            // Check.
            actions += SolverAction(SolverAction.Kind.CHECK, 0.0)
            kids += if (s.otherChecked) endStreet(s, s.pot, s.added, s.st)
            else build(s.copy(toAct = opp, otherChecked = true, atRoot = false))
            if (s.st[me] > 1e-9 && s.st[opp] > 1e-9) {
                // At the root, the player's own sizes (when given) replace the defaults.
                val sizes = if (s.atRoot && config.rootBetAmounts.isNotEmpty()) config.rootBetAmounts else config.betSizes.map { it * s.pot }
                for (amt in sizes.distinct().sorted()) {
                    if (amt <= 0 || amt >= s.st[me] * 0.98) continue
                    if (actions.any { it.kind == SolverAction.Kind.BET && kotlin.math.abs(it.add - amt) < 0.5 }) continue
                    actions += SolverAction(SolverAction.Kind.BET, amt)
                    kids += build(after(amt, SolverAction.Kind.BET))
                }
                if (s.st[me] <= config.allInMaxSpr * s.pot || actions.size == 1) {
                    actions += SolverAction(SolverAction.Kind.ALL_IN, s.st[me])
                    kids += build(after(s.st[me], SolverAction.Kind.ALL_IN))
                }
            }
        } else {
            // Facing a bet: fold, call, raise.
            actions += SolverAction(SolverAction.Kind.FOLD, 0.0)
            kids += FoldNode(me, s.pot.toFloat(), s.added.toFloatArray())
            val call = minOf(toCall, s.st[me])
            run {
                val c = s.c.copyOf(); val st = s.st.copyOf(); val added = s.added.copyOf()
                c[me] += call; st[me] -= call; added[me] += call
                var pot = s.pot + call
                // Calling all-in for less: the unmatched part of the bet goes back.
                val refund = c[opp] - c[me]
                if (refund > 1e-9) { c[opp] -= refund; st[opp] += refund; added[opp] -= refund; pot -= refund }
                actions += SolverAction(SolverAction.Kind.CALL, call)
                kids += endStreet(s, pot, added, st)
            }
            val canRaise = s.st[opp] > 1e-9 && s.st[me] > toCall + 1e-9
            if (canRaise) {
                if (s.raises < config.maxRaises) {
                    val potAfterCall = s.pot + toCall
                    val sizes = if (s.atRoot && config.rootBetAmounts.isNotEmpty()) config.rootBetAmounts
                    else config.raiseSizes.map { toCall + it * potAfterCall }
                    for (total in sizes.distinct().sorted()) {
                        if (total <= toCall * 2 - 1e-9 || total >= s.st[me] * 0.98) continue
                        if (actions.any { it.kind == SolverAction.Kind.RAISE && kotlin.math.abs(it.add - total) < 0.5 }) continue
                        actions += SolverAction(SolverAction.Kind.RAISE, total)
                        kids += build(after(total, SolverAction.Kind.RAISE))
                    }
                }
                if (s.raises < config.maxRaises + 1 && s.st[me] <= config.allInMaxSpr * (s.pot + toCall) * 2) {
                    actions += SolverAction(SolverAction.Kind.ALL_IN, s.st[me])
                    kids += build(after(s.st[me], SolverAction.Kind.ALL_IN))
                }
            }
        }
        val node = PlayerNode(me, actions, kids.toTypedArray(), playerNodes.size)
        playerNodes += node
        return node
    }

    private fun DoubleArray.toFloatArray() = FloatArray(size) { this[it].toFloat() }

    // ------------------------------------------------------------------ showdown data

    /** Per final board (keyed by its last card): hand strengths (-1 if blocked) and sort orders. */
    private class BoardData(val strength: Array<IntArray>, val order: Array<IntArray>)

    private val boards = HashMap<Int, BoardData>()

    private fun boardData(key: Int): BoardData = boards.getOrPut(key) {
        val board5 = if (spot.board.size == 5) boardMask else boardMask or (1L shl key)
        val strength = Array(2) { p ->
            IntArray(hands[p].size) { i ->
                val m = Combos.mask[hands[p][i]]
                if (m and board5 != 0L) -1 else HandEvaluator.evaluateMask(m or board5)
            }
        }
        val order = Array(2) { p -> hands[p].indices.sortedBy { strength[p][it] }.toIntArray() }
        BoardData(strength, order)
    }

    // ------------------------------------------------------------------ CFR

    private var iteration = 0
    private val sampler = com.pokercoach.engine.rng.SeededRandom(0x5017E5L xor spot.board.fold(0L) { m, c -> m * 53 + c.id })
    private var sampling = false

    /** Runs CFR iterations until [iterations] or [timeBudgetMs] is reached. Returns iterations run. */
    fun solve(iterations: Int = 300, timeBudgetMs: Long = Long.MAX_VALUE): Int {
        val start = System.currentTimeMillis()
        var n = 0
        while (n < iterations && System.currentTimeMillis() - start < timeBudgetMs) {
            iteration++
            val t = iteration.toDouble()
            val pos = (t.pow(1.5) / (t.pow(1.5) + 1)).toFloat()
            val neg = 0.5f
            val strat = ((t / (t + 1)).pow(2.0)).toFloat()
            sampling = config.chanceSample > 0
            for (p in 0..1) {
                cfr(root, p, initialWeight[p].copyOf(), initialWeight[1 - p].copyOf(), pos, neg, strat)
            }
            sampling = false
            n++
        }
        return n
    }

    private fun currentStrategy(node: PlayerNode, h: Int, out: FloatArray) {
        val k = node.actions.size
        val r = regrets[node.slot]
        var sum = 0f
        for (a in 0 until k) { val v = r[h * k + a]; if (v > 0) sum += v }
        if (sum > 0) for (a in 0 until k) { val v = r[h * k + a]; out[a] = if (v > 0) v / sum else 0f }
        else for (a in 0 until k) out[a] = 1f / k
    }

    private fun cfr(node: Node, p: Int, reachP: FloatArray, reachO: FloatArray, pos: Float, neg: Float, strat: Float): FloatArray = when (node) {
        is FoldNode -> foldValues(node, p, reachO)
        is ShowdownNode -> showdownValues(node, p, reachO)
        is ChanceNode -> if (sampling && config.chanceSample in 1 until node.cards.size) {
            sampledChanceValues(node, p, reachP, reachO) { child, rp, ro -> cfr(child, p, rp, ro, pos, neg, strat) }
        } else {
            chanceValues(node, p, reachP, reachO) { child, rp, ro -> cfr(child, p, rp, ro, pos, neg, strat) }
        }
        is PlayerNode -> {
            val k = node.actions.size
            if (node.player == p) {
                val n = hands[p].size
                // Children first; this node's regrets don't change while they're traversed.
                val values = Array(k) { a -> cfr(node.children[a], p, reachP, reachO, pos, neg, strat) }
                val result = FloatArray(n)
                val r = regrets[node.slot]
                val s = strategySum[node.slot]
                val sigma = FloatArray(k)
                for (h in 0 until n) {
                    currentStrategy(node, h, sigma)
                    var v = 0f
                    for (a in 0 until k) v += sigma[a] * values[a][h]
                    result[h] = v
                    val rh = reachP[h]
                    for (a in 0 until k) {
                        val i = h * k + a
                        val old = r[i]
                        r[i] = old * (if (old > 0) pos else neg) + (values[a][h] - v)
                        s[i] = s[i] * strat + rh * sigma[a]
                    }
                }
                result
            } else {
                val o = 1 - p
                val n = hands[o].size
                val tmp = FloatArray(k)
                val childReach = Array(k) { FloatArray(n) }
                for (h in 0 until n) {
                    currentStrategy(node, h, tmp)
                    for (a in 0 until k) childReach[a][h] = reachO[h] * tmp[a]
                }
                val result = FloatArray(hands[p].size)
                for (a in 0 until k) {
                    val v = cfr(node.children[a], p, reachP, childReach[a], pos, neg, strat)
                    for (h in result.indices) result[h] += v[h]
                }
                result
            }
        }
    }

    private inline fun chanceValues(
        node: ChanceNode,
        p: Int,
        reachP: FloatArray,
        reachO: FloatArray,
        recurse: (Node, FloatArray, FloatArray) -> FloatArray,
    ): FloatArray {
        val o = 1 - p
        val result = FloatArray(hands[p].size)
        for (i in node.cards.indices) {
            val bit = 1L shl node.cards[i]
            val mp = hmask[p]; val mo = hmask[o]
            val rp = FloatArray(reachP.size) { h -> if (mp[h] and bit != 0L) 0f else reachP[h] }
            val ro = FloatArray(reachO.size) { h -> if (mo[h] and bit != 0L) 0f else reachO[h] }
            val v = recurse(node.children[i], rp, ro)
            for (h in result.indices) if (mp[h] and bit == 0L) result[h] += v[h]
        }
        // For any pair of hands, the river can be any card neither player holds (4 fewer).
        val denom = (node.cards.size - 4).toFloat()
        for (h in result.indices) result[h] /= denom
        return result
    }

    /** Like [chanceValues] over a random subset of river cards, scaled to stay unbiased. */
    private inline fun sampledChanceValues(
        node: ChanceNode,
        p: Int,
        reachP: FloatArray,
        reachO: FloatArray,
        recurse: (Node, FloatArray, FloatArray) -> FloatArray,
    ): FloatArray {
        val o = 1 - p
        val n = node.cards.size
        val k = config.chanceSample
        val idx = IntArray(n) { it }
        for (i in 0 until k) { val j = i + sampler.nextInt(n - i); val t = idx[i]; idx[i] = idx[j]; idx[j] = t }
        val result = FloatArray(hands[p].size)
        for (s in 0 until k) {
            val i = idx[s]
            val bit = 1L shl node.cards[i]
            val mp = hmask[p]; val mo = hmask[o]
            val rp = FloatArray(reachP.size) { h -> if (mp[h] and bit != 0L) 0f else reachP[h] }
            val ro = FloatArray(reachO.size) { h -> if (mo[h] and bit != 0L) 0f else reachO[h] }
            val v = recurse(node.children[i], rp, ro)
            for (h in result.indices) if (mp[h] and bit == 0L) result[h] += v[h]
        }
        val scale = n.toFloat() / k / (n - 4)
        for (h in result.indices) result[h] *= scale
        return result
    }

    /** Opponent reach compatible with each of p's hands (no shared cards). */
    private fun compatibleTotals(p: Int, reachO: FloatArray): FloatArray {
        val o = 1 - p
        var total = 0f
        val card = FloatArray(52)
        for (j in reachO.indices) {
            val r = reachO[j]
            if (r == 0f) continue
            total += r
            card[Combos.card1[hands[o][j]]] += r
            card[Combos.card2[hands[o][j]]] += r
        }
        return FloatArray(hands[p].size) { h ->
            val c = hands[p][h]
            val same = handIndex[o][c].let { if (it >= 0) reachO[it] else 0f }
            total - card[Combos.card1[c]] - card[Combos.card2[c]] + same
        }
    }

    private fun foldValues(node: FoldNode, p: Int, reachO: FloatArray): FloatArray {
        val tot = compatibleTotals(p, reachO)
        val payoff = if (node.folder == p) -node.added[p] else node.potTotal - node.added[p]
        return FloatArray(tot.size) { tot[it] * payoff }
    }

    private fun showdownValues(node: ShowdownNode, p: Int, reachO: FloatArray): FloatArray {
        val o = 1 - p
        val bd = boardData(node.boardKey)
        val sp = bd.strength[p]
        val so = bd.strength[o]
        val op = bd.order[p]
        val oo = bd.order[o]
        val nP = hands[p].size
        val nO = hands[o].size
        val win = FloatArray(nP)
        val lose = FloatArray(nP)
        val co1 = c1[o]; val co2 = c2[o]; val cp1 = c1[p]; val cp2 = c2[p]

        // Sweep up: opponent hands strictly weaker.
        var cum = 0f
        val cumCard = FloatArray(52)
        var j = 0
        for (idx in 0 until nP) {
            val h = op[idx]
            val s = sp[h]
            if (s < 0) continue
            while (j < nO && so[oo[j]] < s) {
                val q = oo[j]; val r = reachO[q]
                if (so[q] >= 0 && r != 0f) {
                    cum += r; cumCard[co1[q]] += r; cumCard[co2[q]] += r
                }
                j++
            }
            win[h] = cum - cumCard[cp1[h]] - cumCard[cp2[h]]
        }
        // Sweep down: opponent hands strictly stronger.
        cum = 0f
        cumCard.fill(0f)
        j = nO - 1
        for (idx in nP - 1 downTo 0) {
            val h = op[idx]
            val s = sp[h]
            if (s < 0) continue
            while (j >= 0 && so[oo[j]] > s) {
                val q = oo[j]; val r = reachO[q]
                if (r != 0f) {
                    cum += r; cumCard[co1[q]] += r; cumCard[co2[q]] += r
                }
                j--
            }
            lose[h] = cum - cumCard[cp1[h]] - cumCard[cp2[h]]
        }
        val tot = compatibleTotalsValid(p, reachO, so)
        val pot = node.potTotal
        val add = node.added[p]
        return FloatArray(nP) { h ->
            if (sp[h] < 0) 0f else {
                val tie = tot[h] - win[h] - lose[h]
                pot * (win[h] + 0.5f * tie) - add * tot[h]
            }
        }
    }

    /** Like [compatibleTotals] but ignoring opponent hands blocked by the final board. */
    private fun compatibleTotalsValid(p: Int, reachO: FloatArray, so: IntArray): FloatArray {
        val o = 1 - p
        var total = 0f
        val card = FloatArray(52)
        for (j in reachO.indices) {
            val r = reachO[j]
            if (r == 0f || so[j] < 0) continue
            total += r
            card[Combos.card1[hands[o][j]]] += r
            card[Combos.card2[hands[o][j]]] += r
        }
        return FloatArray(hands[p].size) { h ->
            val c = hands[p][h]
            val same = handIndex[o][c].let { if (it >= 0 && so[it] >= 0) reachO[it] else 0f }
            total - card[Combos.card1[c]] - card[Combos.card2[c]] + same
        }
    }

    // ------------------------------------------------------------------ results

    private fun averageStrategy(node: PlayerNode, h: Int): FloatArray {
        val k = node.actions.size
        val s = strategySum[node.slot]
        var sum = 0f
        for (a in 0 until k) sum += s[h * k + a]
        return FloatArray(k) { a -> if (sum > 0) s[h * k + a] / sum else 1f / k }
    }

    /** The solved (average) strategy at the root for one of the acting player's hands. */
    fun rootStrategy(combo: Int): FloatArray? {
        val node = root as PlayerNode
        val h = handIndex[node.player][combo]
        return if (h < 0) null else averageStrategy(node, h)
    }

    /** Frequency of each root action across the whole range of the acting player. */
    fun rootRangeFrequencies(): FloatArray {
        val node = root as PlayerNode
        val p = node.player
        val out = FloatArray(node.actions.size)
        var total = 0f
        for (h in hands[p].indices) {
            val w = initialWeight[p][h]
            val st = averageStrategy(node, h)
            for (a in out.indices) out[a] += w * st[a]
            total += w
        }
        return FloatArray(out.size) { out[it] / total }
    }

    /**
     * Expected chips (relative to the start of the subgame) of each root action for one hand,
     * with both players following the solved strategy afterwards.
     */
    fun rootActionValues(combo: Int): DoubleArray? {
        val node = root as PlayerNode
        val p = node.player
        val h = handIndex[p][combo]
        if (h < 0) return null
        val reachO = initialWeight[1 - p]
        val tot = compatibleTotals(p, reachO)[h]
        if (tot <= 0f) return null
        return DoubleArray(node.actions.size) { a -> evalAverage(node.children[a], p, initialWeight[p], reachO)[h] / tot.toDouble() }
    }

    private fun evalAverage(node: Node, p: Int, reachP: FloatArray, reachO: FloatArray): FloatArray = when (node) {
        is FoldNode -> foldValues(node, p, reachO)
        is ShowdownNode -> showdownValues(node, p, reachO)
        is ChanceNode -> chanceValues(node, p, reachP, reachO) { child, rp, ro -> evalAverage(child, p, rp, ro) }
        is PlayerNode -> {
            val k = node.actions.size
            if (node.player == p) {
                val values = Array(k) { a -> evalAverage(node.children[a], p, reachP, reachO) }
                FloatArray(hands[p].size) { h -> val st = averageStrategy(node, h); var v = 0f; for (a in 0 until k) v += st[a] * values[a][h]; v }
            } else {
                val o = 1 - p
                val result = FloatArray(hands[p].size)
                for (a in 0 until k) {
                    val ro = FloatArray(hands[o].size) { h -> reachO[h] * averageStrategy(node, h)[a] }
                    val v = evalAverage(node.children[a], p, reachP, ro)
                    for (h in result.indices) result[h] += v[h]
                }
                result
            }
        }
    }

    private fun bestResponse(node: Node, p: Int, reachO: FloatArray): FloatArray = when (node) {
        is FoldNode -> foldValues(node, p, reachO)
        is ShowdownNode -> showdownValues(node, p, reachO)
        is ChanceNode -> chanceValues(node, p, FloatArray(hands[p].size) { 1f }, reachO) { child, _, ro -> bestResponse(child, p, ro) }
        is PlayerNode -> {
            val k = node.actions.size
            if (node.player == p) {
                val values = Array(k) { a -> bestResponse(node.children[a], p, reachO) }
                FloatArray(hands[p].size) { h -> var m = Float.NEGATIVE_INFINITY; for (a in 0 until k) m = max(m, values[a][h]); m }
            } else {
                val o = 1 - p
                val result = FloatArray(hands[p].size)
                for (a in 0 until k) {
                    val ro = FloatArray(hands[o].size) { h -> reachO[h] * averageStrategy(node, h)[a] }
                    val v = bestResponse(node.children[a], p, ro)
                    for (h in result.indices) result[h] += v[h]
                }
                result
            }
        }
    }

    /**
     * How much a perfect opponent could gain against the current solution, as a fraction of the
     * pot (0 = exact equilibrium). Used by tests to prove convergence.
     */
    fun exploitability(): Double {
        var sum = 0.0
        for (p in 0..1) {
            val br = bestResponse(root, p, initialWeight[1 - p])
            val tot = compatibleTotals(p, initialWeight[1 - p])
            var num = 0.0
            var den = 0.0
            for (h in br.indices) {
                num += initialWeight[p][h] * br[h]
                den += initialWeight[p][h] * tot[h]
            }
            sum += num / den
        }
        return (sum - spot.pot) / 2 / spot.pot
    }

    val nodeCount: Int get() = playerNodes.size

    /** Solved strategy for [combo] at the node reached by following root [path] (action indices). */
    fun strategyAt(path: List<Int>, combo: Int): FloatArray? {
        var node: Node = root
        for (a in path) node = (node as? PlayerNode)?.children?.getOrNull(a) ?: return null
        val pn = node as? PlayerNode ?: return null
        val h = handIndex[pn.player][combo]
        return if (h < 0) null else averageStrategy(pn, h)
    }

    fun actionsAt(path: List<Int>): List<SolverAction>? {
        var node: Node = root
        for (a in path) node = (node as? PlayerNode)?.children?.getOrNull(a) ?: return null
        return (node as? PlayerNode)?.actions
    }
}
