package com.pokercoach.engine.bot

/**
 * Preflop strategy charts computed with CFR (see tools/PreflopSolve.kt): open-raise, 3-bet,
 * 4-bet and all-in frequencies for every hand between every pair of 6-max positions, plus
 * heads-up, at 100 big blinds with 2.5bb opens (3bb from the small blind).
 *
 * Lookups return null for spots or hands the charts don't cover (e.g. a hand that would never
 * reach that decision), so callers can fall back to their own logic.
 */
object PreflopCharts {
    enum class Pos { UTG, HJ, CO, BTN, SB, BB }

    /** Position from how many players act after you preflop (0 = big blind). */
    fun position(leftBehind: Int, players: Int): Pos? = when {
        players == 2 -> if (leftBehind == 1) Pos.SB else Pos.BB
        leftBehind == 0 -> Pos.BB
        leftBehind == 1 -> Pos.SB
        leftBehind == 2 -> Pos.BTN
        leftBehind == 3 -> Pos.CO
        leftBehind == 4 -> Pos.HJ
        else -> Pos.UTG // UTG at 6-max; earlier seats at full ring are tightened by the caller
    }

    private fun decode(table: String, cls: Int): Double? {
        val c = table[cls]
        if (c == '-') return null
        val v = if (c <= '9') c - '0' else c - 'a' + 10
        return v / 35.0
    }

    private val fields: Map<String, String> get() = PreflopChartData.ALL

    private fun get(name: String, cls: Int): Double? = fields[name]?.let { decode(it, cls) }

    /** How often to open-raise first in. */
    fun open(pos: Pos, cls: Int, headsUp: Boolean): Double? =
        if (headsUp) get("HU_OPEN", cls) else if (pos == Pos.BB) null else get("RFI_${pos.name}", cls)

    /** Facing a single open: (call, 3-bet) frequencies. */
    fun vsOpen(me: Pos, opener: Pos, cls: Int, headsUp: Boolean): Pair<Double, Double>? {
        val (c, t) = if (headsUp) "HU_CALL" to "HU_THREEBET" else "CALL_${me.name}_VS_${opener.name}" to "THREEBET_${me.name}_VS_${opener.name}"
        return pair(c, t, cls)
    }

    /** The opener facing a 3-bet: (call, 4-bet). */
    fun vsThreeBet(me: Pos, threeBettor: Pos, cls: Int, headsUp: Boolean): Pair<Double, Double>? {
        val (c, t) = if (headsUp) "HU_CALL3B" to "HU_FOURBET" else "CALL3B_${me.name}_VS_${threeBettor.name}" to "FOURBET_${me.name}_VS_${threeBettor.name}"
        return pair(c, t, cls)
    }

    /** The 3-bettor facing a 4-bet: (call, all-in). */
    fun vsFourBet(me: Pos, opener: Pos, cls: Int, headsUp: Boolean): Pair<Double, Double>? {
        val (c, t) = if (headsUp) "HU_CALL4B" to "HU_JAM" else "CALL4B_${me.name}_VS_${opener.name}" to "JAM_${me.name}_VS_${opener.name}"
        return pair(c, t, cls)
    }

    /** The 4-bettor facing an all-in: call frequency. */
    fun vsJam(me: Pos, jammer: Pos, cls: Int, headsUp: Boolean): Double? =
        if (headsUp) get("HU_CALLJAM", cls) else get("CALLJAM_${me.name}_VS_${jammer.name}", cls)

    private fun pair(a: String, b: String, cls: Int): Pair<Double, Double>? {
        val x = get(a, cls) ?: return null
        val y = get(b, cls) ?: return null
        return x to y
    }
}
