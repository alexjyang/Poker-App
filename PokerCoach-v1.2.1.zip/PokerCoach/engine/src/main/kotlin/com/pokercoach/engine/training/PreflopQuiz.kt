package com.pokercoach.engine.training

import com.pokercoach.engine.bot.PreflopCharts
import com.pokercoach.engine.bot.PreflopCharts.Pos
import com.pokercoach.engine.card.Card
import com.pokercoach.engine.range.Combos
import com.pokercoach.engine.range.HandClass
import com.pokercoach.engine.rng.SeededRandom

enum class QuizSpot(val label: String) {
    OPEN("First in"),
    DEFEND("Facing an open"),
    VS_3BET("Facing a 3-bet"),
}

enum class QuizAnswer { FOLD, CALL, RAISE }

/**
 * One preflop question: "You're on the CO with KTo, everyone folded. Raise or fold?"
 * [frequencies] is the CFR chart's answer (how often each action is played with this hand).
 */
data class QuizQuestion(
    val spot: QuizSpot,
    val hero: Pos,
    val villain: Pos?,
    val handClass: Int,
    val cards: List<Card>,
    val frequencies: Map<QuizAnswer, Double>,
) {
    val handLabel: String get() = HandClass.fromIndex(handClass).label

    /** The available answers in display order. */
    val answers: List<QuizAnswer>
        get() = if (spot == QuizSpot.OPEN) listOf(QuizAnswer.FOLD, QuizAnswer.RAISE) else QuizAnswer.entries

    fun raiseLabel(): String = when (spot) {
        QuizSpot.OPEN -> "Raise"
        QuizSpot.DEFEND -> "3-bet"
        QuizSpot.VS_3BET -> "4-bet"
    }

    val situation: String
        get() = when (spot) {
            QuizSpot.OPEN -> "You're ${hero.name} with $handLabel. Everyone before you folded."
            QuizSpot.DEFEND -> "You're ${hero.name} with $handLabel. ${villain!!.name} raised to 2.5 BB, everyone else folded."
            QuizSpot.VS_3BET -> "You opened from ${hero.name} with $handLabel and ${villain!!.name} 3-bet."
        }
}

data class QuizResult(
    /** The most frequent action in the chart. */
    val best: QuizAnswer,
    /** How often the chart takes the chosen action with this hand. */
    val chosenFrequency: Double,
    /** Main action (chosen ≥ 50%, or the most frequent). */
    val correct: Boolean,
    /** Part of a mixed strategy (chosen ≥ 15%) — not wrong, just not the main line. */
    val acceptable: Boolean,
)

/**
 * Questions from the CFR preflop charts (6-max, 100 BB). Hands near the edge of a range — the
 * ones worth practising — are picked far more often than obvious folds and premiums.
 */
object PreflopQuiz {
    private val openers = listOf(Pos.UTG, Pos.HJ, Pos.CO, Pos.BTN, Pos.SB)
    private val order = listOf(Pos.UTG, Pos.HJ, Pos.CO, Pos.BTN, Pos.SB, Pos.BB)

    fun next(rng: SeededRandom, spots: Collection<QuizSpot> = QuizSpot.entries, hardShare: Double = 0.75): QuizQuestion {
        val allowed = spots.toList().ifEmpty { QuizSpot.entries }
        repeat(2_000) {
            val spot = allowed[rng.nextInt(allowed.size)]
            val (hero, villain) = when (spot) {
                QuizSpot.OPEN -> openers[rng.nextInt(openers.size)] to null
                QuizSpot.DEFEND -> {
                    val h = rng.nextInt(5) + 1               // HJ..BB
                    order[h] to order[rng.nextInt(h)]        // opener acts earlier
                }
                QuizSpot.VS_3BET -> {
                    val o = rng.nextInt(5)                   // UTG..SB opens
                    order[o] to order[o + 1 + rng.nextInt(5 - o)]
                }
            }
            val cls = sampleClass(rng)
            val freqs = frequencies(spot, hero, villain, cls) ?: return@repeat
            // Facing a 3-bet only makes sense with hands you'd open.
            if (spot == QuizSpot.VS_3BET && (PreflopCharts.open(hero, cls, false) ?: 0.0) < 0.5) return@repeat
            val top = freqs.values.max()
            val hard = top < 0.9 || nearEdge(spot, hero, villain, cls)
            if (!hard && rng.nextDouble() < hardShare) return@repeat
            val combos = (0 until Combos.COUNT).filter { Combos.classOf[it] == cls }
            val combo = combos[rng.nextInt(combos.size)]
            return QuizQuestion(spot, hero, villain, cls, Combos.cards(combo), freqs)
        }
        error("Could not build a quiz question")
    }

    fun frequencies(spot: QuizSpot, hero: Pos, villain: Pos?, cls: Int): Map<QuizAnswer, Double>? = when (spot) {
        QuizSpot.OPEN -> PreflopCharts.open(hero, cls, false)?.let { r -> mapOf(QuizAnswer.FOLD to 1 - r, QuizAnswer.RAISE to r) }
        QuizSpot.DEFEND -> PreflopCharts.vsOpen(hero, villain!!, cls, false)?.let { (c, r) ->
            mapOf(QuizAnswer.FOLD to (1 - c - r).coerceAtLeast(0.0), QuizAnswer.CALL to c, QuizAnswer.RAISE to r)
        }
        QuizSpot.VS_3BET -> PreflopCharts.vsThreeBet(hero, villain!!, cls, false)?.let { (c, r) ->
            mapOf(QuizAnswer.FOLD to (1 - c - r).coerceAtLeast(0.0), QuizAnswer.CALL to c, QuizAnswer.RAISE to r)
        }
    }

    fun grade(q: QuizQuestion, answer: QuizAnswer): QuizResult {
        val best = q.frequencies.maxBy { it.value }.key
        val f = q.frequencies[answer] ?: 0.0
        return QuizResult(best, f, correct = f >= 0.5 || answer == best, acceptable = f >= 0.15)
    }

    /** Uniform over the 1,326 starting hands (so offsuit hands appear as often as in real play). */
    private fun sampleClass(rng: SeededRandom): Int = Combos.classOf[rng.nextInt(Combos.COUNT)]

    /** A hand is "near the edge" if a neighbouring hand in strength gets a different main answer. */
    private fun nearEdge(spot: QuizSpot, hero: Pos, villain: Pos?, cls: Int): Boolean {
        val mine = frequencies(spot, hero, villain, cls)?.maxBy { it.value }?.key ?: return false
        val hc = HandClass.fromIndex(cls)
        val neighbours = listOf(hc.row - 1 to hc.col, hc.row + 1 to hc.col, hc.row to hc.col - 1, hc.row to hc.col + 1)
            .filter { (r, c) -> r in 0..12 && c in 0..12 }
            .map { (r, c) -> HandClass(r, c).index }
        return neighbours.any { n -> frequencies(spot, hero, villain, n)?.maxBy { it.value }?.key?.let { it != mine } == true }
    }
}
