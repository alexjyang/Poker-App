// Offline generator for engine/.../bot/PreflopCharts.kt.
// Run from the project root with the engine classes on the classpath, e.g.:
//   kotlinc tools/PreflopSolve.kt -cp engine/build/classes/kotlin/main -d /tmp/ps && \
//   kotlin -cp engine/build/classes/kotlin/main:/tmp/ps PreflopSolveKt > engine/src/main/kotlin/com/pokercoach/engine/bot/PreflopCharts.kt
//
// Method: vectorized CFR over the 169 hand classes for two-player preflop games (open 2.5bb,
// 3-bet, 4-bet, 5-bet all-in) between every pair of 6-max positions, 100bb deep. Postflop pots
// are valued by all-in equity adjusted for equity realization (in position realizes more). Opening
// ranges then combine all the players still to act, and the pairwise games are re-solved with those
// ranges until stable.
import com.pokercoach.engine.card.Card
import com.pokercoach.engine.eval.HandEvaluator
import com.pokercoach.engine.range.Combos
import com.pokercoach.engine.range.HandClass
import com.pokercoach.engine.rng.SeededRandom

const val N = 169
val cnt = IntArray(N) { HandClass.fromIndex(it).comboCount }
val combosOf: Array<IntArray> = Array(N) { c -> (0 until Combos.COUNT).filter { Combos.classOf[it] == c }.toIntArray() }
lateinit var J: Array<DoubleArray>   // compatible combo pairs
lateinit var E: Array<DoubleArray>   // all-in equity of class a vs class b

fun precompute() {
    val cache = java.io.File("/tmp/preflop_equity.bin")
    J = Array(N) { DoubleArray(N) }
    for (a in 0 until N) for (b in 0 until N) {
        var n = 0
        for (x in combosOf[a]) for (y in combosOf[b]) if (Combos.mask[x] and Combos.mask[y] == 0L) n++
        J[a][b] = n.toDouble()
    }
    E = Array(N) { DoubleArray(N) }
    if (cache.exists()) {
        java.io.DataInputStream(cache.inputStream().buffered()).use { inp -> for (a in 0 until N) for (b in 0 until N) E[a][b] = inp.readDouble() }
        return
    }
    val rng = SeededRandom(169169)
    val samples = 2500
    for (a in 0 until N) for (b in a until N) {
        var won = 0.0
        var done = 0
        while (done < samples) {
            val x = combosOf[a][rng.nextInt(combosOf[a].size)]
            val y = combosOf[b][rng.nextInt(combosOf[b].size)]
            if (Combos.mask[x] and Combos.mask[y] != 0L) continue
            var used = Combos.mask[x] or Combos.mask[y]
            var board = 0L
            repeat(5) { var id: Int; do { id = rng.nextInt(52) } while (used and (1L shl id) != 0L); used = used or (1L shl id); board = board or (1L shl id) }
            val hx = HandEvaluator.evaluateMask(Combos.mask[x] or board)
            val hy = HandEvaluator.evaluateMask(Combos.mask[y] or board)
            won += if (hx > hy) 1.0 else if (hx == hy) 0.5 else 0.0
            done++
        }
        E[a][b] = won / samples
        E[b][a] = 1 - E[a][b]
    }
    java.io.DataOutputStream(cache.outputStream().buffered()).use { out -> for (a in 0 until N) for (b in 0 until N) out.writeDouble(E[a][b]) }
}

// Positions: 0 UTG, 1 HJ, 2 CO, 3 BTN, 4 SB, 5 BB. Postflop order: SB, BB, UTG, HJ, CO, BTN.
val posNames = listOf("UTG", "HJ", "CO", "BTN", "SB", "BB")
fun postflopRank(p: Int) = when (p) { 4 -> 0; 5 -> 1; else -> p + 2 }
fun blind(p: Int) = when (p) { 4 -> 0.5; 5 -> 1.0; else -> 0.0 }

/** A two-player preflop game: opener O vs defender D. */
class PairGame(val o: Int, val d: Int, val headsUp: Boolean = false) {
    val stack = 100.0
    val open = if (o == 4) 3.0 else 2.5
    val oIp = headsUp || postflopRank(o) > postflopRank(d) // heads-up the button (small blind) has position
    val threeBet = if (oIp) open * 4.0 else open * 3.0   // out of position 3-bets bigger
    val fourBet = threeBet * 2.25
    val dead = (if (headsUp) 0.0 else 1.5) - (if (headsUp) 0.0 else blind(o) + blind(d)) // other blinds (dead money)

    // Nodes: 0 O open?  1 D vs open (F,C,3B)  2 O vs 3B (F,C,4B)  3 D vs 4B (F,C,Jam)  4 O vs Jam (F,C)
    val actionsPer = intArrayOf(2, 3, 3, 3, 2)
    val player = intArrayOf(0, 1, 0, 1, 0)
    val regret = Array(5) { DoubleArray(N * actionsPer[it]) }
    val stratSum = Array(5) { DoubleArray(N * actionsPer[it]) }
    var fixedOpen: DoubleArray? = null

    /** Players still to act behind the defender (they can squeeze or wake up with a hand). */
    private val behindD = if (headsUp || d == 5) 0 else (d + 1..5).count { it != o }

    private val baseIp = System.getProperty("rip", "1.06").toDouble()
    private val baseOop = System.getProperty("roop", "0.80").toDouble()
    private val handAdj = System.getProperty("adj", "0.50").toDouble()
    private val behindPenalty = System.getProperty("behind", "0.10").toDouble()

    /**
     * Equity realization: in position realizes more; strong, playable hands realize more than
     * weak offsuit ones (they win big pots and don't get bluffed off); a cold-caller with
     * players behind realizes less. The effect shrinks as pots get bigger (less play left).
     */
    /**
     * Postflop playability beyond raw equity: suited hands make flushes and draws, connected hands
     * make straights, small pairs flop sets; offsuit gappers realize poorly.
     */
    private fun structure(cls: Int): Double {
        val hc = HandClass.fromIndex(cls)
        if (hc.isPair) return if (hc.row >= 6) 0.03 else 0.0 // 8 and below: set mining
        val gap = kotlin.math.abs(hc.row - hc.col) - 1
        var b = if (hc.isSuited) 0.06 else -0.02
        b += when (gap) { 0 -> 0.04; 1 -> 0.02; 2 -> 0.0; else -> -0.02 }
        return b
    }

    private fun realization(cls: Int, ip: Boolean, potType: Int, isDefender: Boolean): Double {
        if (potType >= 4) return 1.0
        val shrink = when (potType) { 1 -> 1.0; 2 -> 0.7; else -> 0.35 }
        val q = 1 - com.pokercoach.engine.bot.PlayabilityRanking.rankPct(cls)
        val base = if (ip) baseIp else baseOop
        var r = 1 + (base - 1) * shrink + (-0.75 * handAdj + handAdj * q + structure(cls)) * shrink
        if (isDefender) r *= (1 - behindPenalty * behindD * shrink)
        return r.coerceIn(0.3, 1.25)
    }

    /** O's share of the pot for class a vs class b in a pot of [potType]. */
    private fun shareO(a: Int, b: Int, potType: Int): Double {
        val eo = E[a][b] * realization(a, oIp, potType, false)
        val ed = (1 - E[a][b]) * realization(b, !oIp, potType, true)
        return eo / (eo + ed)
    }

    /** O's realized pot share for each (O class, D class), per pot type 1..4. */
    private val shares: Array<Array<DoubleArray>> by lazy {
        Array(5) { pt -> if (pt == 0) emptyArray() else Array(N) { x -> DoubleArray(N) { y -> shareO(x, y, pt) } } }
    }

    /** Utilities (O, D) for a showdown with investments io/id. */
    private fun showdown(a: Int, b: Int, io: Double, id: Double, potType: Int): Pair<Double, Double> {
        val pot = io + id + dead
        val s = shareO(a, b, potType)
        return (pot * s - io) to (pot * (1 - s) - id)
    }

    fun strategy(node: Int, h: Int, out: DoubleArray, average: Boolean) {
        val k = actionsPer[node]
        if (node == 0 && fixedOpen != null) { out[1] = fixedOpen!![h]; out[0] = 1 - out[1]; return }
        val arr = if (average) stratSum[node] else regret[node]
        var sum = 0.0
        for (i in 0 until k) sum += if (average) arr[h * k + i] else maxOf(0.0, arr[h * k + i])
        for (i in 0 until k) out[i] = if (sum > 0) (if (average) arr[h * k + i] else maxOf(0.0, arr[h * k + i])) / sum else 1.0 / k
    }

    // Counterfactual values for the traverser at each node, vectorized over classes.
    // reach arrays are per-class probabilities of reaching (per combo).
    fun traverse(node: Int, trav: Int, reachO: DoubleArray, reachD: DoubleArray, io: Double, id: Double, update: Boolean, average: Boolean): DoubleArray {
        val k = actionsPer[node]
        val actor = player[node]
        val children = Array(k) { DoubleArray(N) }
        val sig = Array(N) { DoubleArray(k) }
        for (h in 0 until N) strategy(node, h, sig[h], average)
        for (a in 0 until k) {
            val rO = if (actor == 0) DoubleArray(N) { reachO[it] * sig[it][a] } else reachO
            val rD = if (actor == 1) DoubleArray(N) { reachD[it] * sig[it][a] } else reachD
            children[a] = child(node, a, trav, rO, rD, io, id, update, average)
        }
        val result = DoubleArray(N)
        if (actor == trav) {
            val reachSelf = if (trav == 0) reachO else reachD
            for (h in 0 until N) {
                var v = 0.0
                for (a in 0 until k) v += sig[h][a] * children[a][h]
                result[h] = v
                if (update && !(node == 0 && fixedOpen != null)) {
                    for (a in 0 until k) {
                        val i = h * k + a
                        regret[node][i] = maxOf(0.0, regret[node][i] + children[a][h] - v) // CFR+
                        stratSum[node][i] += reachSelf[h] * sig[h][a] * iterWeight
                    }
                }
            }
        } else {
            for (a in 0 until k) for (h in 0 until N) result[h] += children[a][h]
        }
        return result
    }

    var iterWeight = 1.0

    private fun terminalFold(trav: Int, folderIsO: Boolean, reachOpp: DoubleArray, io: Double, id: Double): DoubleArray {
        val pot = io + id + dead
        val u = if (trav == 0) (if (folderIsO) -io else pot - io) else (if (folderIsO) pot - id else -id)
        return DoubleArray(N) { h -> var s = 0.0; for (b in 0 until N) s += reachOpp[b] * J[h][b]; s * u }
    }

    private val rake = System.getProperty("rake", "0.05").toDouble()
    private val rakeCap = System.getProperty("rakecap", "3.0").toDouble()

    private fun terminalShowdown(trav: Int, reachOpp: DoubleArray, io: Double, id: Double, potType: Int): DoubleArray {
        val pot = io + id + dead
        val sh = shares[potType]
        return DoubleArray(N) { h ->
            var s = 0.0
            var w = 0.0
            val jr = J[h]
            if (trav == 0) {
                val row = sh[h]
                for (b in 0 until N) { val r = reachOpp[b]; if (r == 0.0) continue; val x = r * jr[b]; s += x * row[b]; w += x }
                pot * s - io * w
            } else {
                for (b in 0 until N) { val r = reachOpp[b]; if (r == 0.0) continue; val x = r * jr[b]; s += x * (1 - sh[b][h]); w += x }
                pot * s - id * w
            }
        }
    }

    private fun child(node: Int, a: Int, trav: Int, rO: DoubleArray, rD: DoubleArray, io: Double, id: Double, update: Boolean, average: Boolean): DoubleArray {
        val opp = if (trav == 0) rD else rO
        return when (node) {
            0 -> if (a == 0) DoubleArray(N) { h -> var s = 0.0; for (b in 0 until N) s += opp[b] * J[h][b]; s * (if (trav == 0) -io else 0.0) }
                 else traverse(1, trav, rO, rD, open, id, update, average)
            1 -> when (a) {
                0 -> terminalFold(trav, false, opp, io, id)
                1 -> terminalShowdown(trav, opp, io, open, 1)
                else -> traverse(2, trav, rO, rD, io, threeBet, update, average)
            }
            2 -> when (a) {
                0 -> terminalFold(trav, true, opp, io, id)
                1 -> terminalShowdown(trav, opp, threeBet, id, 2)
                else -> traverse(3, trav, rO, rD, fourBet, id, update, average)
            }
            3 -> when (a) {
                0 -> terminalFold(trav, false, opp, io, id)
                1 -> terminalShowdown(trav, opp, io, fourBet, 3)
                else -> traverse(4, trav, rO, rD, io, stack, update, average)
            }
            else -> when (a) {
                0 -> terminalFold(trav, true, opp, io, id)
                else -> terminalShowdown(trav, opp, stack, stack, 4)
            }
        }
    }

    fun solve(iterations: Int) {
        avgCache = null
        for (t in 1..iterations) {
            iterWeight = t.toDouble() // linear averaging
            for (trav in 0..1) traverse(0, trav, DoubleArray(N) { 1.0 }, DoubleArray(N) { 1.0 }, blind(o).let { if (headsUp) 0.5 else it }, if (headsUp) 1.0 else blind(d), true, false)
        }
    }

    private var avgCache: Array<Array<DoubleArray>>? = null
    fun avg(node: Int, h: Int): DoubleArray {
        val c = avgCache ?: Array(5) { n -> Array(N) { x -> DoubleArray(actionsPer[n]).also { strategy(n, x, it, true) } } }.also { avgCache = it }
        return c[node][h]
    }

    /** Range-average fold frequency of D facing the open, given O holds class a (card removal). */
    fun foldVsOpen(a: Int): Double {
        var w = 0.0; var f = 0.0
        for (b in 0 until N) { w += J[a][b]; f += J[a][b] * avg(1, b)[0] }
        return f / w
    }

    /** O's expected utility with class a given D continues (calls or 3-bets), using averages. */
    fun valueIfContinued(a: Int): Double {
        val io = blind(o)
        val id = blind(d)
        val reachO = DoubleArray(N) { if (it == a) 1.0 else 0.0 }
        // D continues: remove D's fold probability.
        val rD = DoubleArray(N) { 1.0 - avg(1, it)[0] }
        var num = 0.0
        // Call branch and 3-bet branch with D's split.
        val rCall = DoubleArray(N) { avg(1, it)[1] }
        val r3 = DoubleArray(N) { avg(1, it)[2] }
        num += traverseValueCall(a, rCall, io)
        num += traverse(2, 0, reachO, r3, open, threeBet, false, true)[a] // O has put in the open by now
        var den = 0.0
        for (b in 0 until N) den += J[a][b] * rD[b]
        return if (den > 0) num / den else 0.0
    }

    private fun traverseValueCall(a: Int, rCall: DoubleArray, io: Double): Double {
        var s = 0.0
        val gross = 2 * open + dead
        val net = gross - minOf(gross * rake, rakeCap)
        for (b in 0 until N) if (rCall[b] > 0) s += rCall[b] * J[a][b] * (shares[1][a][b] * net - open)
        return s
    }
}

fun enc(f: Double): Char {
    val v = Math.round(f.coerceIn(0.0, 1.0) * 35).toInt()
    return if (v < 10) '0' + v else 'a' + (v - 10)
}
fun table(f: (Int) -> Double) = String(CharArray(N) { enc(f(it)) })
/** Like [table], but '-' for hands that (almost) never reach this decision. */
fun masked(reach: (Int) -> Double, f: (Int) -> Double) = String(CharArray(N) { if (reach(it) < 0.01) '-' else enc(f(it)) })

fun main() {
    precompute()
    val iterations = 700
    val pairs = mutableMapOf<Pair<Int, Int>, PairGame>()
    for (o in 0..4) for (d in (o + 1)..5) pairs[o to d] = PairGame(o, d).also { it.solve(iterations) }
    // Combine: opening ranges against everyone still to act, then re-solve with those ranges.
    val rfi = Array(5) { DoubleArray(N) }
    repeat(3) {
        for (o in 0..4) {
            val defenders = (o + 1)..5
            for (a in 0 until N) {
                var allFold = 1.0
                var ev = 0.0
                for (d in defenders) {
                    val g = pairs.getValue(o to d)
                    val f = g.foldVsOpen(a)
                    ev += allFold * (1 - f) * g.valueIfContinued(a)
                    allFold *= f
                }
                val openPot = 1.5 - blind(o)  // blinds won when everyone folds (own blind back)
                ev += allFold * openPot
                val foldValue = -blind(o)
                rfi[o][a] = if (ev > foldValue + 0.02) 1.0 else if (ev > foldValue - 0.02) 0.5 else 0.0
            }
            for (d in defenders) pairs.getValue(o to d).apply {
                fixedOpen = rfi[o]
                for (i in 1..4) { regret[i].fill(0.0); stratSum[i].fill(0.0) }
                solve(iterations)
            }
        }
    }
    val hu = PairGame(4, 5, headsUp = true).also { it.solve(iterations) }

    // ---- emit Kotlin
    val out = StringBuilder()
    out.appendLine("package com.pokercoach.engine.bot")
    out.appendLine()
    out.appendLine("// GENERATED by tools/PreflopSolve.kt — do not edit by hand.")
    out.appendLine("// CFR (CFR+, linear averaging, $iterations iterations per game) over 169 hand classes, 100bb.")
    out.appendLine("// Each table has 169 characters in HandClass.index order; '0'..'9','a'..'z' = frequency 0..1 in 35 steps; '-' = hand doesn't reach this spot.")
    out.appendLine("internal object PreflopChartData {")
    for (o in 0..4) out.appendLine("    const val RFI_${posNames[o]} = \"${table { rfi[o][it] }}\"")
    for ((k, g) in pairs.toSortedMap(compareBy({ it.first }, { it.second }))) {
        val (o, d) = k
        val tag = "${posNames[d]}_VS_${posNames[o]}"
        out.appendLine("    const val CALL_$tag = \"${table { g.avg(1, it)[1] }}\"")
        out.appendLine("    const val THREEBET_$tag = \"${table { g.avg(1, it)[2] }}\"")
        val tag2 = "${posNames[o]}_VS_${posNames[d]}"
        out.appendLine("    const val CALL3B_$tag2 = \"${masked({ rfi[o][it] }) { g.avg(2, it)[1] }}\"")
        out.appendLine("    const val FOURBET_$tag2 = \"${masked({ rfi[o][it] }) { g.avg(2, it)[2] }}\"")
        out.appendLine("    const val CALL4B_$tag = \"${masked({ g.avg(1, it)[2] }) { g.avg(3, it)[1] }}\"")
        out.appendLine("    const val JAM_$tag = \"${masked({ g.avg(1, it)[2] }) { g.avg(3, it)[2] }}\"")
        out.appendLine("    const val CALLJAM_$tag2 = \"${masked({ rfi[o][it] * g.avg(2, it)[2] * 10 }) { g.avg(4, it)[1] }}\"")
    }
    out.appendLine("    const val HU_OPEN = \"${table { hu.avg(0, it)[1] }}\"")
    out.appendLine("    const val HU_CALL = \"${table { hu.avg(1, it)[1] }}\"")
    out.appendLine("    const val HU_THREEBET = \"${table { hu.avg(1, it)[2] }}\"")
    out.appendLine("    const val HU_CALL3B = \"${masked({ hu.avg(0, it)[1] }) { hu.avg(2, it)[1] }}\"")
    out.appendLine("    const val HU_FOURBET = \"${masked({ hu.avg(0, it)[1] }) { hu.avg(2, it)[2] }}\"")
    out.appendLine("    const val HU_CALL4B = \"${masked({ hu.avg(1, it)[2] }) { hu.avg(3, it)[1] }}\"")
    out.appendLine("    const val HU_JAM = \"${masked({ hu.avg(1, it)[2] }) { hu.avg(3, it)[2] }}\"")
    out.appendLine("    const val HU_CALLJAM = \"${masked({ hu.avg(0, it)[1] * hu.avg(2, it)[2] * 10 }) { hu.avg(4, it)[1] }}\"")
    val names = Regex("const val (\\w+) = ").findAll(out).map { it.groupValues[1] }.toList()
    out.appendLine("    val ALL: Map<String, String> = mapOf(")
    names.forEach { out.appendLine("        \"$it\" to $it,") }
    out.appendLine("    )")
    out.appendLine("}")
    print(out)
    // Summary to stderr.
    fun share(f: (Int) -> Double) = (0 until N).sumOf { f(it) * cnt[it] } / 1326.0
    for (o in 0..4) System.err.println("RFI ${posNames[o]}: ${"%.1f".format(share { rfi[o][it] } * 100)}%")
    for (d in listOf(3, 4, 5)) {
        val g = pairs.getValue((if (d == 3) 2 else if (d == 4) 3 else 3) to d)
        System.err.println("${posNames[d]} vs ${posNames[g.o]}: call ${"%.1f".format(share { g.avg(1, it)[1] } * 100)}%, 3-bet ${"%.1f".format(share { g.avg(1, it)[2] } * 100)}%")
    }
    System.err.println("HU: SB opens ${"%.1f".format(share { hu.avg(0, it)[1] } * 100)}%, BB calls ${"%.1f".format(share { hu.avg(1, it)[1] } * 100)}%, 3-bets ${"%.1f".format(share { hu.avg(1, it)[2] } * 100)}%")
}
