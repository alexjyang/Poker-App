package com.pokercoach.app.ui.training

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.pokercoach.app.PokerCoachApplication
import com.pokercoach.app.data.Settings
import com.pokercoach.app.ui.table.SeatUi
import com.pokercoach.app.ui.table.TableUiState
import com.pokercoach.engine.analysis.Decision
import com.pokercoach.engine.analysis.Grade
import com.pokercoach.engine.analysis.HandAnalyzer
import com.pokercoach.engine.game.HandEngine
import com.pokercoach.engine.game.IllegalActionException
import com.pokercoach.engine.game.PlayerAction
import com.pokercoach.engine.rng.SeededRandom
import com.pokercoach.engine.training.Accuracy
import com.pokercoach.engine.training.DecisionScore
import com.pokercoach.engine.training.DrillGenerator
import com.pokercoach.engine.training.DrillSpot
import com.pokercoach.engine.training.DrillType
import com.pokercoach.engine.training.PreflopQuiz
import com.pokercoach.engine.training.QuizAnswer
import com.pokercoach.engine.training.QuizQuestion
import com.pokercoach.engine.training.QuizResult
import com.pokercoach.engine.training.QuizSpot
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

data class DrillUi(
    val type: DrillType? = null,
    val loading: Boolean = false,
    val failed: Boolean = false,
    /** The table frozen at your decision. */
    val table: TableUiState? = null,
    val analyzing: Boolean = false,
    /** The coach's grade for your answer. */
    val result: Decision? = null,
    /** Grades in this run of the drill. */
    val grades: List<Grade> = emptyList(),
    val names: Map<Int, String> = emptyMap(),
) {
    val accuracy: Int? get() = Accuracy.of(grades)
}

data class QuizUi(
    val question: QuizQuestion? = null,
    val chosen: QuizAnswer? = null,
    val result: QuizResult? = null,
    val spots: Set<QuizSpot> = QuizSpot.entries.toSet(),
    val answered: Int = 0,
    val correct: Int = 0,
    val streak: Int = 0,
)

/**
 * Training: spot drills (deal a situation, you act, the coach grades that one decision at once)
 * and the preflop quiz on the CFR charts. Lifetime records live in [Settings.training].
 */
class TrainingViewModel(application: Application) : AndroidViewModel(application) {
    private val app = application as PokerCoachApplication
    private val rng = SeededRandom(System.nanoTime())
    // Turn and river drills use the CFR solver too (fixed iterations, capped on slow phones).
    private val analyzer = HandAnalyzer(iterations = 4_000, solverBudgetMs = 5_000)
    private var settings = Settings()

    private val _drill = MutableStateFlow(DrillUi())
    val drill: StateFlow<DrillUi> = _drill.asStateFlow()
    private var spot: DrillSpot? = null

    private val _quiz = MutableStateFlow(QuizUi())
    val quiz: StateFlow<QuizUi> = _quiz.asStateFlow()

    init {
        viewModelScope.launch {
            app.settings.settings.collect {
                settings = it
                val s = spot
                if (s != null && _drill.value.result == null) _drill.value = _drill.value.copy(table = tableState(s.engine))
            }
        }
    }

    // ------------------------------------------------------------------ drills

    fun startDrill(type: DrillType) {
        _drill.value = DrillUi(type = type)
        nextDrill()
    }

    fun nextDrill() {
        val type = _drill.value.type ?: return
        _drill.value = _drill.value.copy(loading = true, failed = false, result = null, table = null, analyzing = false)
        viewModelScope.launch {
            val s = withContext(Dispatchers.Default) { DrillGenerator.generate(type, SeededRandom(rng.nextLong())) }
            spot = s
            _drill.value = _drill.value.copy(
                loading = false,
                failed = s == null,
                table = s?.let { tableState(it.engine) },
                names = s?.engine?.snapshot()?.seats?.associate { it.seat to it.name } ?: emptyMap(),
            )
        }
    }

    fun answer(action: PlayerAction) {
        val s = spot ?: return
        if (_drill.value.result != null || _drill.value.analyzing) return
        val before = tableState(s.engine).copy(heroLegal = null)
        try {
            s.engine.act(action)
        } catch (e: IllegalActionException) {
            return
        }
        _drill.value = _drill.value.copy(analyzing = true, table = before)
        val events = s.engine.events
        viewModelScope.launch {
            val d = try {
                withContext(Dispatchers.Default) { analyzer.analyze(events, s.heroSeat).decisions.lastOrNull() }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                null
            }
            _drill.value = _drill.value.copy(analyzing = false, result = d, grades = _drill.value.grades + listOfNotNull(d?.grade))
            if (d != null) {
                app.settings.update { it.copy(training = it.training.withDrill(s.type.name, DecisionScore.of(d.grade))) }
            }
        }
    }

    /** The drill's table as the hero sees it (other players' cards hidden). */
    private fun tableState(h: HandEngine): TableUiState {
        val snap = h.snapshotFor(0)
        val hero = snap.seat(0)
        return TableUiState(
            active = true,
            tableSize = snap.seats.size,
            heroSeat = 0,
            seats = snap.seats.map { sv ->
                SeatUi(
                    seat = sv.seat,
                    name = sv.name,
                    style = null,
                    avatarColor = AVATARS[sv.seat % AVATARS.size],
                    stack = sv.stack,
                    bet = sv.streetCommit,
                    cards = sv.holeCards,
                    dealtIn = true,
                    folded = sv.folded,
                    allIn = sv.allIn,
                    isHero = sv.seat == 0,
                    isButton = snap.buttonSeat == sv.seat,
                    isActing = snap.actorSeat == sv.seat,
                    lastAction = null,
                    wonAmount = 0L,
                    busted = false,
                )
            },
            board = snap.board,
            pot = snap.pot,
            street = snap.street,
            currentBet = snap.currentBet,
            heroStreetCommit = hero.streetCommit,
            heroLegal = snap.legalActions,
            bigBlind = snap.blinds.bigBlind,
            heroStack = hero.stack,
            settings = settings,
        )
    }

    // ------------------------------------------------------------------ preflop quiz

    fun nextQuestion() {
        val q = PreflopQuiz.next(rng, _quiz.value.spots)
        _quiz.value = _quiz.value.copy(question = q, chosen = null, result = null)
    }

    fun answerQuiz(a: QuizAnswer) {
        val state = _quiz.value
        val q = state.question ?: return
        if (state.result != null) return
        val r = PreflopQuiz.grade(q, a)
        val streak = if (r.correct) state.streak + 1 else 0
        _quiz.value = state.copy(
            chosen = a, result = r,
            answered = state.answered + 1,
            correct = state.correct + if (r.correct) 1 else 0,
            streak = streak,
        )
        viewModelScope.launch {
            app.settings.update {
                val t = it.training
                it.copy(
                    training = t.copy(
                        quizAnswered = t.quizAnswered + 1,
                        quizCorrect = t.quizCorrect + if (r.correct) 1 else 0,
                        quizBestStreak = maxOf(t.quizBestStreak, streak),
                    ),
                )
            }
        }
    }

    fun toggleQuizSpot(spot: QuizSpot) {
        val s = _quiz.value.spots
        val next = if (spot in s && s.size > 1) s - spot else s + spot
        _quiz.value = _quiz.value.copy(spots = next)
        nextQuestion()
    }

    private companion object {
        val AVATARS = listOf(0xFF1B6B3A, 0xFF8E44AD, 0xFFD35400, 0xFF2980B9, 0xFFC0392B, 0xFF16A085)
    }
}
