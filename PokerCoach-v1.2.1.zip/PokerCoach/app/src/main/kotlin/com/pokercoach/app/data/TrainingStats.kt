package com.pokercoach.app.data

/** Lifetime training record per drill (and the preflop quiz), stored in DataStore as one line. */
data class TrainingStats(
    /** Drill name -> (attempts, sum of decision scores 0–100). */
    val drills: Map<String, Pair<Int, Int>> = emptyMap(),
    val quizAnswered: Int = 0,
    val quizCorrect: Int = 0,
    val quizBestStreak: Int = 0,
) {
    fun accuracy(drill: String): Int? = drills[drill]?.let { (n, sum) -> if (n == 0) null else sum / n }
    fun attempts(drill: String): Int = drills[drill]?.first ?: 0

    fun withDrill(drill: String, score: Int): TrainingStats {
        val (n, sum) = drills[drill] ?: (0 to 0)
        return copy(drills = drills + (drill to (n + 1 to sum + score)))
    }

    fun encode(): String = (drills.map { (k, v) -> "$k=${v.first},${v.second}" } +
        "QUIZ=$quizAnswered,$quizCorrect,$quizBestStreak").joinToString(";")

    companion object {
        fun decode(text: String?): TrainingStats {
            if (text.isNullOrBlank()) return TrainingStats()
            var stats = TrainingStats()
            val drills = mutableMapOf<String, Pair<Int, Int>>()
            for (part in text.split(";")) {
                val i = part.indexOf('=')
                if (i <= 0) continue
                val key = part.substring(0, i)
                val nums = part.substring(i + 1).split(",").mapNotNull { it.toIntOrNull() }
                if (key == "QUIZ" && nums.size == 3) stats = stats.copy(quizAnswered = nums[0], quizCorrect = nums[1], quizBestStreak = nums[2])
                else if (nums.size == 2) drills[key] = nums[0] to nums[1]
            }
            return stats.copy(drills = drills)
        }
    }
}
