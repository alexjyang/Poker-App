package com.pokercoach.app.game

import com.pokercoach.engine.bot.BotStyle
import com.pokercoach.engine.bot.CustomSettings
import com.pokercoach.engine.rng.SeededRandom

enum class GameType(val label: String) { CASH("Cash game"), SIT_AND_GO("Sit & Go") }

/** [solverMs]: how long solver bots may think heads-up on the turn (the river needs a third). */
enum class BotSpeed(val label: String, val thinkMs: Long, val pauseMs: Long, val solverMs: Long) {
    RELAXED("Relaxed", 1_100, 900, 1_400),
    NORMAL("Normal", 650, 650, 900),
    FAST("Fast", 220, 300, 450),
}

data class GameConfig(
    val type: GameType = GameType.CASH,
    val players: Int = 6,
    /** Cash games only: buy-in in big blinds. Sit & Go always starts at 1,500 chips. */
    val startingBb: Int = 100,
    val speed: BotSpeed = BotSpeed.NORMAL,
    /** Style of each bot, in seat order (seat 1, 2, ...). */
    val lineup: List<BotStyle> = List(players - 1) { BotStyle.REGULAR },
    /** Slider values used by every seat set to Custom. */
    val custom: CustomSettings = CustomSettings(),
    /** Show each bot's style label at the table. */
    val showStyles: Boolean = true,
) {
    companion object {
        const val CASH_SMALL_BLIND = 1L
        const val CASH_BIG_BLIND = 2L
        const val SNG_STACK = 1_500L
        const val SNG_HANDS_PER_LEVEL = 10
    }
}

data class BotIdentity(val id: String, val name: String, val color: Long)

object BotRoster {
    private val names = listOf(
        "Ava", "Bruno", "Chen", "Dara", "Emeka", "Freya", "Gus", "Hana", "Ivan",
        "Jade", "Kofi", "Lena", "Mateo", "Nia", "Oskar", "Priya", "Quinn", "Rosa",
    )
    private val colors = listOf(
        0xFF8E44AD, 0xFFD35400, 0xFF2980B9, 0xFFC0392B, 0xFF16A085,
        0xFF7F8C8D, 0xFFB7950B, 0xFF1ABC9C, 0xFF34495E, 0xFFAD1457,
    )

    /** [count] distinct bots, chosen deterministically from [seed]. */
    fun pick(count: Int, seed: Long): List<BotIdentity> {
        val rng = SeededRandom(seed)
        val pool = names.toMutableList()
        return List(count) { i ->
            val name = pool.removeAt(rng.nextInt(pool.size))
            BotIdentity(id = "bot-${name.lowercase()}", name = name, color = colors[(i + rng.nextInt(colors.size)) % colors.size])
        }
    }
}

/** Quick table presets in the lobby. */
enum class OpponentMix(val label: String) {
    BEGINNER("Beginner"), CASUAL("Casual"), REGULAR("Regular"), SHARK("Shark"),
    GTO("GTO-approx"), MIXED("Mixed"), CUSTOM("Custom");

    fun lineup(count: Int): List<BotStyle> = when (this) {
        BEGINNER -> List(count) { BotStyle.BEGINNER }
        CASUAL -> List(count) { BotStyle.CASUAL }
        REGULAR -> List(count) { BotStyle.REGULAR }
        SHARK -> List(count) { BotStyle.SHARK }
        GTO -> List(count) { BotStyle.GTO }
        CUSTOM -> List(count) { BotStyle.CUSTOM }
        MIXED -> List(count) { MIXED_ORDER[it % MIXED_ORDER.size] }
    }

    val description: String
        get() = when (this) {
            MIXED -> "A typical low-stakes table: mostly recreational players who like to see flops, plus a regular (and a shark at bigger tables)."
            else -> BotStyle.valueOf(if (this == GTO) "GTO" else name).description
        }

    private companion object {
        // A typical low-stakes table: mostly recreational players, a regular, and (at bigger tables) a shark.
        val MIXED_ORDER = listOf(
            BotStyle.CASUAL, BotStyle.BEGINNER, BotStyle.REGULAR, BotStyle.CASUAL,
            BotStyle.BEGINNER, BotStyle.SHARK, BotStyle.CASUAL, BotStyle.REGULAR,
        )
    }
}

/**
 * Everything chosen in the lobby, remembered between visits and app restarts
 * (stored in DataStore as one line, see [encode]).
 */
data class LobbyPrefs(
    val type: GameType = GameType.CASH,
    val players: Int = 6,
    val stackBb: Int = 100,
    val speed: BotSpeed = BotSpeed.NORMAL,
    val mix: OpponentMix = OpponentMix.MIXED,
    /** Per-seat style overrides: comma-separated style names, "" = use the preset. */
    val overrides: String = "",
    val showStyles: Boolean = true,
    val looseness: Float = 0.28f,
    val aggression: Float = 0.5f,
    val bluffing: Float = 0.10f,
    val tilt: Float = 0.2f,
    val adaptiveness: Float = 0.3f,
) {
    fun encode(): String = listOf(
        "type=${type.name}", "players=$players", "stack=$stackBb", "speed=${speed.name}", "mix=${mix.name}",
        "over=$overrides", "styles=${if (showStyles) 1 else 0}", "loose=$looseness", "aggr=$aggression",
        "bluff=$bluffing", "tilt=$tilt", "adapt=$adaptiveness",
    ).joinToString(";")

    companion object {
        fun decode(text: String?): LobbyPrefs {
            if (text.isNullOrBlank()) return LobbyPrefs()
            val m = text.split(";").mapNotNull { kv -> kv.indexOf('=').takeIf { it > 0 }?.let { kv.substring(0, it) to kv.substring(it + 1) } }.toMap()
            val d = LobbyPrefs()
            return LobbyPrefs(
                type = GameType.entries.firstOrNull { it.name == m["type"] } ?: d.type,
                players = m["players"]?.toIntOrNull()?.takeIf { it in listOf(2, 6, 9) } ?: d.players,
                stackBb = m["stack"]?.toIntOrNull()?.coerceIn(20, 200) ?: d.stackBb,
                speed = BotSpeed.entries.firstOrNull { it.name == m["speed"] } ?: d.speed,
                mix = OpponentMix.entries.firstOrNull { it.name == m["mix"] } ?: d.mix,
                overrides = m["over"] ?: d.overrides,
                showStyles = m["styles"]?.let { it == "1" } ?: d.showStyles,
                looseness = m["loose"]?.toFloatOrNull() ?: d.looseness,
                aggression = m["aggr"]?.toFloatOrNull() ?: d.aggression,
                bluffing = m["bluff"]?.toFloatOrNull() ?: d.bluffing,
                tilt = m["tilt"]?.toFloatOrNull() ?: d.tilt,
                adaptiveness = m["adapt"]?.toFloatOrNull() ?: d.adaptiveness,
            )
        }
    }
}
