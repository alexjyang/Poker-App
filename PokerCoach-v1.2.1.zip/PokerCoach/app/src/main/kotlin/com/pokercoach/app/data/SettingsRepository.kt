package com.pokercoach.app.data

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.MutablePreferences
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.pokercoach.app.game.LobbyPrefs
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

enum class ThemeMode(val label: String) { SYSTEM("System"), LIGHT("Light"), DARK("Dark") }

/** Multiplies animation durations; OFF skips them entirely. */
enum class AnimationSpeed(val label: String, val factor: Float) {
    NORMAL("Normal", 1f), FAST("Fast", 0.5f), OFF("Off", 0f),
}

enum class CardFaceStyle(val label: String) { CLASSIC("Classic"), LARGE("Large index") }

enum class CardBackStyle(val label: String, val top: Long, val bottom: Long) {
    BLUE("Blue", 0xFF2E55A8, 0xFF15295E),
    RED("Red", 0xFFB3262B, 0xFF5E1015),
    GREEN("Green", 0xFF2E7D4F, 0xFF123B24),
    BLACK("Black", 0xFF3A3A3A, 0xFF111111),
}

/** User preferences for the table, betting controls, appearance and feel. */
data class Settings(
    val amountsInBb: Boolean = false,
    val confirmFoldWhenCheck: Boolean = true,
    val confirmAllIn: Boolean = true,
    val coachHints: Boolean = false,
    val haptics: Boolean = true,
    /** Opening raise sizes in big blinds. */
    val openSizes: List<Double> = listOf(2.5, 3.0, 4.0),
    /** Re-raise sizes as multiples of the bet faced. */
    val reraiseSizes: List<Double> = listOf(3.0, 4.0),
    /** Postflop sizes in % of the pot. */
    val postflopSizes: List<Int> = listOf(33, 50, 75, 100),
    // Stage 6: appearance and feel.
    val themeMode: ThemeMode = ThemeMode.SYSTEM,
    /** Material You colors from the wallpaper (Android 12+). */
    val dynamicColor: Boolean = false,
    val fourColorDeck: Boolean = false,
    val cardFace: CardFaceStyle = CardFaceStyle.CLASSIC,
    val cardBack: CardBackStyle = CardBackStyle.BLUE,
    val sound: Boolean = true,
    val animationSpeed: AnimationSpeed = AnimationSpeed.NORMAL,
    /** Show each player's VPIP/PFR on their seat (a HUD, like poker trackers). */
    val showHud: Boolean = true,
    /** The last lobby setup, so it's there next time. */
    val lobby: LobbyPrefs = LobbyPrefs(),
    /** Drill and preflop-quiz record. */
    val training: TrainingStats = TrainingStats(),
) {
    companion object {
        val OPEN_CHOICES = listOf(2.0, 2.2, 2.5, 3.0, 3.5, 4.0, 5.0)
        val RERAISE_CHOICES = listOf(2.5, 3.0, 3.5, 4.0, 5.0)
        val POSTFLOP_CHOICES = listOf(25, 33, 50, 66, 75, 100, 125, 150)
    }
}

private val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "settings")

/** Settings stored with Jetpack DataStore (Preferences). */
class SettingsRepository(private val context: Context) {
    private object Keys {
        val inBb = booleanPreferencesKey("amounts_in_bb")
        val confirmFold = booleanPreferencesKey("confirm_fold_when_check")
        val confirmAllIn = booleanPreferencesKey("confirm_all_in")
        val coach = booleanPreferencesKey("coach_hints")
        val haptics = booleanPreferencesKey("haptics")
        val open = stringPreferencesKey("open_sizes")
        val reraise = stringPreferencesKey("reraise_sizes")
        val postflop = stringPreferencesKey("postflop_sizes")
        val theme = stringPreferencesKey("theme_mode")
        val dynamic = booleanPreferencesKey("dynamic_color")
        val fourColor = booleanPreferencesKey("four_color_deck")
        val face = stringPreferencesKey("card_face")
        val back = stringPreferencesKey("card_back")
        val sound = booleanPreferencesKey("sound")
        val anim = stringPreferencesKey("animation_speed")
        val hud = booleanPreferencesKey("show_hud")
        val lobby = stringPreferencesKey("lobby")
        val training = stringPreferencesKey("training")
    }

    val settings: Flow<Settings> = context.dataStore.data.map(::read)

    suspend fun update(transform: (Settings) -> Settings) {
        context.dataStore.edit { p -> write(p, transform(read(p))) }
    }

    private inline fun <reified E : Enum<E>> enumOf(name: String?, default: E): E =
        enumValues<E>().firstOrNull { it.name == name } ?: default

    private fun read(p: Preferences): Settings {
        val d = Settings()
        return Settings(
            amountsInBb = p[Keys.inBb] ?: d.amountsInBb,
            confirmFoldWhenCheck = p[Keys.confirmFold] ?: d.confirmFoldWhenCheck,
            confirmAllIn = p[Keys.confirmAllIn] ?: d.confirmAllIn,
            coachHints = p[Keys.coach] ?: d.coachHints,
            haptics = p[Keys.haptics] ?: d.haptics,
            openSizes = p[Keys.open]?.split(",")?.mapNotNull { it.toDoubleOrNull() }?.takeIf { it.isNotEmpty() } ?: d.openSizes,
            reraiseSizes = p[Keys.reraise]?.split(",")?.mapNotNull { it.toDoubleOrNull() }?.takeIf { it.isNotEmpty() } ?: d.reraiseSizes,
            postflopSizes = p[Keys.postflop]?.split(",")?.mapNotNull { it.toIntOrNull() }?.takeIf { it.isNotEmpty() } ?: d.postflopSizes,
            themeMode = enumOf(p[Keys.theme], d.themeMode),
            dynamicColor = p[Keys.dynamic] ?: d.dynamicColor,
            fourColorDeck = p[Keys.fourColor] ?: d.fourColorDeck,
            cardFace = enumOf(p[Keys.face], d.cardFace),
            cardBack = enumOf(p[Keys.back], d.cardBack),
            sound = p[Keys.sound] ?: d.sound,
            animationSpeed = enumOf(p[Keys.anim], d.animationSpeed),
            showHud = p[Keys.hud] ?: d.showHud,
            lobby = LobbyPrefs.decode(p[Keys.lobby]),
            training = TrainingStats.decode(p[Keys.training]),
        )
    }

    private fun write(p: MutablePreferences, n: Settings) {
        p[Keys.inBb] = n.amountsInBb
        p[Keys.confirmFold] = n.confirmFoldWhenCheck
        p[Keys.confirmAllIn] = n.confirmAllIn
        p[Keys.coach] = n.coachHints
        p[Keys.haptics] = n.haptics
        p[Keys.open] = n.openSizes.sorted().joinToString(",")
        p[Keys.reraise] = n.reraiseSizes.sorted().joinToString(",")
        p[Keys.postflop] = n.postflopSizes.sorted().joinToString(",")
        p[Keys.theme] = n.themeMode.name
        p[Keys.dynamic] = n.dynamicColor
        p[Keys.fourColor] = n.fourColorDeck
        p[Keys.face] = n.cardFace.name
        p[Keys.back] = n.cardBack.name
        p[Keys.sound] = n.sound
        p[Keys.anim] = n.animationSpeed.name
        p[Keys.hud] = n.showHud
        p[Keys.lobby] = n.lobby.encode()
        p[Keys.training] = n.training.encode()
    }
}
